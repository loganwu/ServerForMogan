#!/bin/sh

killall -9 AServer

./AServer --config=22345.conf &
./AServer --config=22346.conf &
./AServer --config=22347.conf &
