#include "ServerImp.h"
#include "servant/Application.h"

using namespace std;

//////////////////////////////////////////////////////
ServerImp::ServerImp()
: _iNum(0)
{
    //_iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
}
void ServerImp::initialize()
{
	//initialize servant here:
	//...
}

//////////////////////////////////////////////////////
void ServerImp::destroy()
{
	//destroy servant here:
	//...
}

taf::Int32 ServerImp::testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current)
{
    iOut = iIn;
    _iNum ++;
    if(_iNum == 100000)
    {
        LOG->debug()<<"time"<<"|"<<taf::TC_TimeProvider::getInstance()->getNowMs() - _iTime <<endl;
        _iNum = 0;
        _iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
    }
    return 0;
}
