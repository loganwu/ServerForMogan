#ifndef _TafLoadTestServer_H_
#define _TafLoadTestServer_H_

#include <iostream>
#include "servant/Application.h"

using namespace taf;

/**
 *
 **/
class TafLoadTestServer : public Application
{
public:
	/**
	 *
	 **/
	virtual ~TafLoadTestServer() {};

	/**
	 *
	 **/
	virtual void initialize();

	/**
	 *
	 **/
	virtual void destroyApp();
};

extern TafLoadTestServer g_app;

////////////////////////////////////////////
#endif
