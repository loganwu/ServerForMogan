#ifndef _ServerImp_H_
#define _ServerImp_H_

#include "servant/Application.h"
#include "Server.h"

/**
 *
 *
 */
class ServerImp : public Test::Server
{
public:
	/**
	 *
	 */
    ServerImp();
	virtual ~ServerImp() {}

	/**
	 *
	 */
	virtual void initialize();

	/**
	 *
	 */
    virtual void destroy();

	/**
	 *
	 */
    taf::Int32 testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current);
private:
    int _iNum;
    int64_t _iTime;
};
/////////////////////////////////////////////////////
#endif
