#ifndef _TafLoadTestProxyServer_H_
#define _TafLoadTestProxyServer_H_

#include <iostream>
#include "servant/Application.h"

using namespace taf;

/**
 *
 **/
class TafLoadTestProxyServer : public Application
{
public:
	/**
	 *
	 **/
	virtual ~TafLoadTestProxyServer() {};

	/**
	 *
	 **/
	virtual void initialize();

	/**
	 *
	 **/
	virtual void destroyApp();

    bool cmdprofile(const string& command, const string& params, string& result);
};

extern TafLoadTestProxyServer g_app;

////////////////////////////////////////////
#endif
