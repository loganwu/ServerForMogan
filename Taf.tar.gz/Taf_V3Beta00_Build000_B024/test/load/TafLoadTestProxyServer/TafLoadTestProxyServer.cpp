#include "TafLoadTestProxyServer.h"
#include "ProxyImp.h"

//#include "google/profiler.h"
//#include "google/heap-profiler.h"

using namespace std;

TafLoadTestProxyServer g_app;

/////////////////////////////////////////////////////////////////
void
TafLoadTestProxyServer::initialize()
{
	//initialize application here:
	//...

	addServant<ProxyImp>(ServerConfig::Application + "." + ServerConfig::ServerName + ".ProxyObj");

    TAF_ADD_ADMIN_CMD_NORMAL("profile", TafLoadTestProxyServer::cmdprofile);
}
/////////////////////////////////////////////////////////////////
void
TafLoadTestProxyServer::destroyApp()
{
	//destroy application here:
	//...
}
/////////////////////////////////////////////////////////////////
//
bool TafLoadTestProxyServer::cmdprofile(const string& command, const string& params, string& result)
{    
#if 0
    string param = TC_Common::trim(params);
    if(param=="start")
    {
        string file ="cpuprofile.TafLoadTestProxyServer_" + TC_Common::now2str();
        setenv("CPUPROFILE",file.c_str(),true);
        ProfilerStart(file.c_str());
    }
    else if(param == "stop")
    {
        ProfilerStop(); 
        ProfilerFlush();
        unsetenv("CPUPROFILE");
    }
    else 
    {
        result = "usage:profile start|stop";
    }
#endif
    return true;
}


int
main(int argc, char* argv[])
{
	try
	{
#if 0
        string file ="cpuprofile.TafLoadTestProxyServer_" + TC_Common::now2str();
        setenv("CPUPROFILE",file.c_str(),true);
        ProfilerStart(file.c_str());

        string heapfile ="heapprofile.TafLoadTestProxyServer_" + TC_Common::now2str();
        //setenv("HEAPPROFILE",heapfile.c_str(),true);
        HeapProfilerStart(heapfile.c_str());
#endif

		g_app.main(argc, argv);
		g_app.waitForShutdown();
	}
	catch (std::exception& e)
	{
		cerr << "std::exception:" << e.what() << std::endl;
	}
	catch (...)
	{
		cerr << "unknown exception." << std::endl;
	}
	return -1;
}
/////////////////////////////////////////////////////////////////
