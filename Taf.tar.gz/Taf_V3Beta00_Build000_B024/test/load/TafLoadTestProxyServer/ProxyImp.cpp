#include "ProxyImp.h"
#include "servant/Application.h"
#include "util/tc_timeprovider.h"

using namespace std;
using namespace taf;

//////////////////////////////////////////////////////
void ProxyImp::initialize()
{
	//initialize servant here:
	//...
    _iNum = 0;
    _iTime = taf::TC_TimeProvider::getInstance()->getNow();
    //Application::getCommunicator()->stringToProxy("Test.ZhangcunliCServer.CObj@tcp -h 10.135.36.114 -p 10900 -t 5000",_pServerObj);
    //Application::getCommunicator()->stringToProxy("Test.TafLoadTestServer.ServerObj",_pServerObj);
    //Application::getCommunicator()->stringToProxy("Test.TafLoadTestServer.ServerObj@tcp -h 10.148.147.140 -t 5000 -p 10000:tcp -h 10.148.147.79 -t 5000 -p 10006:tcp -h 10.148.144.147 -t 60000 -p 10006:tcp -h 10.148.147.209 -t 60000 -p 10003",_pServerObj);
    //Application::getCommunicator()->stringToProxy("Test.TafLoadTestServer.ServerObj@tcp -h 10.148.147.140 -t 5000 -p 10000:tcp -h 10.148.147.79 -t 5000 -p 10006:tcp -h 10.148.147.209 -t 60000 -p 10003",_pServerObj);
    //Application::getCommunicator()->stringToProxy("Test.TafLoadTestServer.ServerObj@tcp -h 10.148.147.140 -t 5000 -p 10000:tcp -h 10.148.147.209 -t 60000 -p 10003",_pServerObj);
    //Application::getCommunicator()->stringToProxy("Test.TafLoadTestServer.ServerObj@tcp -h 10.148.147.140 -t 5000 -p 10000:tcp -h 10.148.147.79 -t 5000 -p 10006:tcp -h 10.148.147.209 -t 60000 -p 10003",_pServerObj);
    Application::getCommunicator()->stringToProxy("Test.TafLoadTestServer.ServerObj",_pServerObj);
    //_pServerObj->taf_async_timeout(1000);
    //Application::getCommunicator()->stringToProxy("Test.TafLoadTestServer.ServerObj",_pServerObj);
}

//////////////////////////////////////////////////////
void ProxyImp::destroy()
{
	//destroy servant here:
	//...
}

taf::Int32 ProxyImp::testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current)
{
    _iNum++;
    current->setResponse(false);
    //_pServerObj->testInt(iIn,iOut);
    ServerPrxCallback * cb=new ServerCallBack(current);
    _pServerObj->async_testInt(cb,iIn);
    if(_iNum == 100000)
    {
        LOG->debug()<<"time:"<<pthread_self()<<"|"<<TC_TimeProvider::getInstance()->getNowMs()-_iTime<<endl;
        _iTime=TC_TimeProvider::getInstance()->getNowMs();
        _iNum=0;
    }
    return 0;
}
