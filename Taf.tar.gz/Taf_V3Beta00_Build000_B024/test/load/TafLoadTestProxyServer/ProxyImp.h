#ifndef _ProxyImp_H_
#define _ProxyImp_H_

#include "servant/Application.h"
#include "Proxy.h"
#include "Server.h"

/**
 *
 *
 */

using namespace Test;

class ServerCallBack : public ServerPrxCallback 
{
public:
    ServerCallBack(taf::JceCurrentPtr current)
    {
        _current=current;
    }

    void callback_testInt(taf::Int32 ret, taf::Int32 iOut)
    {
        Server::async_response_testInt(_current,ret,iOut);
    }
    void callback_testInt_exception(taf::Int32 ret)
    {
        LOG->error()<<"ServerPrxCallback callback_testInt_exception:"<<ret<<endl;
    }
private:
    taf::JceCurrentPtr _current;
};

class ServerCallBack1 : public ServerPrxCallback 
{
public:
    ServerCallBack1()
    {
    }

    void callback_testInt(taf::Int32 ret, taf::Int32 iOut)
    {
    }
    void callback_testInt_exception(taf::Int32 ret)
    {
        LOG->debug()<<"ServerPrxCallback1 callback_testInt_exception:"<<ret<<endl;
    }
};

class ProxyImp : public Test::Proxy
{
public:
	/**
	 *
	 */
	virtual ~ProxyImp() {}

	/**
	 *
	 */
	virtual void initialize();

	/**
	 *
	 */
    virtual void destroy();

	/**
	 *
	 */
    taf::Int32 testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current);
private:
    ServerPrx _pServerObj;
    int _iNum;
    time_t _iTime;
};
/////////////////////////////////////////////////////
#endif
