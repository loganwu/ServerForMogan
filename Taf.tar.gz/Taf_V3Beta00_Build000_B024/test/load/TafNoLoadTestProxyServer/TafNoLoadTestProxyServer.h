#ifndef _TafNoLoadTestProxyServer_H_
#define _TafNoLoadTestProxyServer_H_

#include <iostream>
#include "servant/Application.h"

using namespace taf;

/**
 *
 **/
class TafNoLoadTestProxyServer : public Application
{
public:
	/**
	 *
	 **/
	virtual ~TafNoLoadTestProxyServer() {};

	/**
	 *
	 **/
	virtual void initialize();

	/**
	 *
	 **/
	virtual void destroyApp();

    bool cmdprofile(const string& command, const string& params, string& result);
};

extern TafNoLoadTestProxyServer g_app;

////////////////////////////////////////////
#endif
