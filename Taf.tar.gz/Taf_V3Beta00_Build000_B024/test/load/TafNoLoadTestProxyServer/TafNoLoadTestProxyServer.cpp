#include "TafNoLoadTestProxyServer.h"
#include "ProxyImp.h"

#include "google/profiler.h"

using namespace std;

TafNoLoadTestProxyServer g_app;

/////////////////////////////////////////////////////////////////
void
TafNoLoadTestProxyServer::initialize()
{
	//initialize application here:
	//...

	addServant<ProxyImp>(ServerConfig::Application + "." + ServerConfig::ServerName + ".ProxyObj");

    TAF_ADD_ADMIN_CMD_NORMAL("profile", TafNoLoadTestProxyServer::cmdprofile);
}
/////////////////////////////////////////////////////////////////
void
TafNoLoadTestProxyServer::destroyApp()
{
	//destroy application here:
	//...
}
/////////////////////////////////////////////////////////////////
//
bool TafNoLoadTestProxyServer::cmdprofile(const string& command, const string& params, string& result)
{    
    string param = TC_Common::trim(params);
    if(param=="start")
    {
        string file ="cpuprofile.TafNoLoadTestProxyServer_" + TC_Common::now2str();
        setenv("CPUPROFILE",file.c_str(),true);
        ProfilerStart(file.c_str());
    }
    else if(param == "stop")
    {
        ProfilerStop(); 
        ProfilerFlush();
        unsetenv("CPUPROFILE");
    }
    else 
    {
        result = "usage:profile start|stop";
    }
    return true;
}


int
main(int argc, char* argv[])
{
	try
	{
        string file ="cpuprofile.TafNoLoadTestProxyServer_" + TC_Common::now2str();
        setenv("CPUPROFILE",file.c_str(),true);
        ProfilerStart(file.c_str());

		g_app.main(argc, argv);
		g_app.waitForShutdown();
	}
	catch (std::exception& e)
	{
		cerr << "std::exception:" << e.what() << std::endl;
	}
	catch (...)
	{
		cerr << "unknown exception." << std::endl;
	}
	return -1;
}
/////////////////////////////////////////////////////////////////
