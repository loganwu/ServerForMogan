#include "ProxyImp.h"
#include "servant/Application.h"
#include "util/tc_timeprovider.h"

#include "SelfProtocol.h"

using namespace std;
using namespace taf;

//////////////////////////////////////////////////////
void ProxyImp::initialize()
{
	//initialize servant here:
	//...
    _iNum = 0;
    _iTime = taf::TC_TimeProvider::getInstance()->getNow();
    Application::getCommunicator()->stringToProxy("Test.TafNoLoadTestServer.ServerObj",_pServerObj);
    ProxyProtocol protocol;
    protocol.requestFunc = ProxyProtocol::streamRequest;
    protocol.responseFunc = ProxyProtocol::streamResponse<0,uint32_t,true,4,uint32_t,true>;
    _pServerObj->taf_set_protocol(protocol);
    //_pServerObj->taf_async_timeout(1000);
}

//////////////////////////////////////////////////////
void ProxyImp::destroy()
{
	//destroy servant here:
	//...
}

taf::Int32 ProxyImp::testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current)
{
    _iNum++;
    current->setResponse(false);
    //_pServerObj->testInt(iIn,iOut);
    ServantProxyCallbackPtr cb=new ServerCallBack(current);
    uint32_t iId = _pServerObj->taf_gen_requestid(); 
    string s;
    uint32_t iLen=12;
    iLen = htonl(iLen);
    s.assign((const char*)&iLen,4);
    iIn = htonl(iIn);
    uint32_t iBuf;
    iBuf = htonl(iId);
    s.append((const char *)&iBuf,4);
    s.append((const char *)&iIn,4);
    LOG->debug()<<"request:"<<TC_Common::bin2str(s)<<endl;
    _pServerObj->rpc_call_async(iId,"test",s.c_str(),s.size(),cb);

    ServantProxyCallbackPtr cb1=new ServerCallBack(current);
    _pServerObj->rpc_call_async(_pServerObj->taf_gen_requestid(),"test",s.c_str(),0,cb1);
    if(_iNum == 100000)
    {
        LOG->debug()<<"time:"<<pthread_self()<<"|"<<TC_TimeProvider::getInstance()->getNowMs()-_iTime<<endl;
        _iTime=TC_TimeProvider::getInstance()->getNowMs();
        _iNum=0;
    }
    return 0;
}
