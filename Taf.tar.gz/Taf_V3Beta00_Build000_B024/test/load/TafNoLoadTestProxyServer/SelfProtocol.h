#ifndef __SELF_PROTOCOL_H_
#define __SELF_PROTOCOL_H_

#include <string>
#include <memory>
#include <map>
#include <vector>

using namespace std;

class Protocol
{
public:
    /**
     * ��ͨ�����������
     * @param request
     * @param buff
     */
    static void streamRequest(const RequestPacket& request, string& buff)
    {
        vector<char> v;
        buff.assign((const char*)(&v[0]), v.size());
    }

};

#endif
