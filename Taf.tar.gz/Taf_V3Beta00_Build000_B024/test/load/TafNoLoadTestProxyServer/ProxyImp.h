#ifndef _ProxyImp_H_
#define _ProxyImp_H_

#include "servant/Application.h"
#include "Proxy.h"
#include "Server.h"

/**
 *
 *
 */

using namespace Test;

class ServerCallBack : public ServantProxyCallback 
{
public:
    ServerCallBack(taf::JceCurrentPtr current)
    {
        _current=current;
    }

    int onDispatch(ReqMessagePtr msg)
    {
        if(msg->response.iRet != taf::JCESERVERSUCCESS)
        {
            LOG->error()<<"ServerPrxCallback exception:"<<msg->response.iRet<<endl;
        }
        else
        {
            int iOut;
            memcpy((void *)&iOut,(void *)&msg->response.sBuffer[8],4);
            iOut = ntohl(iOut);
            Server::async_response_testInt(_current,0,iOut);
        }
        return 0;
    }

private:
    taf::JceCurrentPtr _current;
};

class ProxyImp : public Test::Proxy
{
public:
	/**
	 *
	 */
	virtual ~ProxyImp() {}

	/**
	 *
	 */
	virtual void initialize();

	/**
	 *
	 */
    virtual void destroy();

	/**
	 *
	 */
    taf::Int32 testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current);
private:
    ServantPrx _pServerObj;
    int _iNum;
    time_t _iTime;
};
/////////////////////////////////////////////////////
#endif
