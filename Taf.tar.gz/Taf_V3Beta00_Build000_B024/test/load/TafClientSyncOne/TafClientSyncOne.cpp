#include <iostream>
#include <fstream>

#include "Proxy.h"

#include "jce/RequestF.h"
#include "jce/Jce.h"
#include "jce/wup.h"
#include "util/tc_common.h"
#include "servant/Communicator.h"

using namespace std;
using namespace Test;
using namespace taf;
using namespace wup;

CommunicatorPtr  g_pCommunicator;

int main(int argc,char * argv[])
{
    if(argc < 2)
    {
        cerr<<"Usage: "<<argv[0]<<" obj"<<endl;
        return -1;
    }
    string sObj=string(argv[1]);
    srand(time(NULL));

    g_pCommunicator=new Communicator();

    ProxyPrx pProxy;
    g_pCommunicator->stringToProxy(sObj,pProxy);


    while(1)
    {
        try
        {
            int iOut;
            int iIn=rand();
            pProxy->testInt(iIn,iOut);
            if(iIn != iOut)
                cerr<<"invoke error|"<<iIn<<"|"<<iOut<<endl;
            else
                cout<<"invoke ok|"<<iIn<<"|"<<iOut<<endl;
        }
        catch(...)
        {
            cerr<<"error|"<<"except"<<endl;
        }
    }

    return 0;
}
