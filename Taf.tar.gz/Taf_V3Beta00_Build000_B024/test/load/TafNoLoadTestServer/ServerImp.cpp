#include "ServerImp.h"
#include "servant/Application.h"

using namespace std;

//////////////////////////////////////////////////////
ServerImp::ServerImp()
: _iNum(0)
{
    //_iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
}
void ServerImp::initialize()
{
	//initialize servant here:
	//...
}

//////////////////////////////////////////////////////
void ServerImp::destroy()
{
	//destroy servant here:
	//...
}

int ServerImp::doRequest(taf::JceCurrentPtr current, vector<char> &buffer)
{
    buffer = current->getRequestBuffer();
    _iNum ++;
    if(_iNum == 100000)
    {
        //LOG->debug()<<pthread_self()<<"|"<<taf::TC_TimeProvider::getInstance()->getNowMs() - _iTime <<endl;
        _iNum = 0;
        //_iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
    }
    return 0;
}
