#ifndef _ServerImp_H_
#define _ServerImp_H_

#include "servant/Application.h"
#include "Server.h"

/**
 *
 *
 */
class ServerImp : public Servant
{
public:
	/**
	 *
	 */
    ServerImp();
	virtual ~ServerImp() {}

	/**
	 *
	 */
	virtual void initialize();

	/**
	 *
	 */
    virtual void destroy();

	/**
	 *
	 */
    int doRequest(taf::JceCurrentPtr current, vector<char> &buffer);
private:
    int _iNum;
    int64_t _iTime;
};
/////////////////////////////////////////////////////
#endif
