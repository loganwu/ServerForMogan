#ifndef _TafNoLoadTestServer_H_
#define _TafNoLoadTestServer_H_

#include <iostream>
#include "servant/Application.h"

using namespace taf;

/**
 *
 **/
class TafNoLoadTestServer : public Application
{
public:
	/**
	 *
	 **/
	virtual ~TafNoLoadTestServer() {};

	/**
	 *
	 **/
	virtual void initialize();

	/**
	 *
	 **/
	virtual void destroyApp();
};

extern TafNoLoadTestServer g_app;

////////////////////////////////////////////
#endif
