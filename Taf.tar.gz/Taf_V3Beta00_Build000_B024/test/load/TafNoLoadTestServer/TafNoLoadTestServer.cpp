#include "TafNoLoadTestServer.h"
#include "ServerImp.h"

#include "google/profiler.h"

using namespace std;

TafNoLoadTestServer g_app;

/////////////////////////////////////////////////////////////////
void
TafNoLoadTestServer::initialize()
{
	//initialize application here:
	//...

	addServant<ServerImp>(ServerConfig::Application + "." + ServerConfig::ServerName + ".ServerObj");
	addServantProtocol(ServerConfig::Application + "." + ServerConfig::ServerName + ".ServerObj",AppProtocol::parseStream<0,uint32_t,true> );
}
/////////////////////////////////////////////////////////////////
void
TafNoLoadTestServer::destroyApp()
{
	//destroy application here:
	//...
}
/////////////////////////////////////////////////////////////////
int
main(int argc, char* argv[])
{
	try
	{
        string file ="cpuprofile.TafNoLoadTestServer_" + TC_Common::now2str();
        setenv("CPUPROFILE",file.c_str(),true);
        ProfilerStart(file.c_str());

		g_app.main(argc, argv);
		g_app.waitForShutdown();
	}
	catch (std::exception& e)
	{
		cerr << "std::exception:" << e.what() << std::endl;
	}
	catch (...)
	{
		cerr << "unknown exception." << std::endl;
	}
	return -1;
}
/////////////////////////////////////////////////////////////////
