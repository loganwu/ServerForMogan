#include <iostream>
#include <fstream>

#include "Proxy.h"

#include "jce/RequestF.h"
#include "jce/Jce.h"
#include "jce/wup.h"
#include "util/tc_common.h"
#include "servant/Communicator.h"

using namespace std;
using namespace Test;
using namespace taf;
using namespace wup;

CommunicatorPtr  g_pCommunicator;

string sObj;

void * run(void * p)
{
    ProxyPrx pProxy;
    g_pCommunicator->stringToProxy(sObj,pProxy);
    int i=0;
    int64_t iBegin=TC_Common::now2ms();
    while(true)
    {
        try
        {
            int iOut;
            int iIn=rand();
            pProxy->testInt(iIn,iOut);
            if(iIn != iOut)
                cerr<<"invoke error|"<<iIn<<"|"<<iOut<<endl;
            i++;
            if(i==1000)
            {
                cerr<<"time:"<<TC_Common::now2ms()-iBegin<<endl;
                iBegin=TC_Common::now2ms();
                i=0;
            }
        }
        catch(...)
        {
            cerr<<"error|"<<"except"<<endl;
        }
    }
}

int main(int argc,char * argv[])
{
    if(argc < 3)
    {
        cerr<<"Usage: "<<argv[0]<<" iNum obj"<<endl;
        return -1;
    }
    srand(time(NULL));
    g_pCommunicator=new Communicator();
    int iNum=atoi(argv[1]);
    sObj=string(argv[2]);

    for(int i=0;i<iNum;i++)
    {
        pthread_t tid;
        pthread_create(&tid,0,(void *(*)(void *))&run,NULL);
    }
    run(NULL);

    return 0;
}
