#include "TestRecvThread.h"
#include <iostream>
#include <arpa/inet.h>

/*
 ��Ӧ�����뺯���������ض���ʽ����ӷ�����յ������ݣ�����ΪResponsePacket
*/

static size_t pushResponse(const char* recvBuffer, size_t length, list<ResponsePacket>& done)
{
	size_t pos = 0;
    while (pos < length)
    {
        unsigned int len = length - pos;
        if(len < sizeof(unsigned int))
        {
            break;
        }

        unsigned int iHeaderLen = ntohl(*(unsigned int*)(recvBuffer + pos));

        //��һ�±���,���ȴ���10M
        if (iHeaderLen > 100000 || iHeaderLen < sizeof(unsigned int))
        {
            throw JceDecodeException("packet length too long or too short,len:" + TC_Common::tostr(iHeaderLen));
        }

        //��û�н���ȫ
        if (len < iHeaderLen)
        {
            break;
        }
        else
        {
            ResponsePacket rsp;
			rsp.iRequestId = ntohl(*((unsigned int *)(recvBuffer + pos + sizeof(unsigned int))));
			rsp.sBuffer.resize(iHeaderLen - 2*sizeof(unsigned int));
		    ::memcpy(&rsp.sBuffer[0], recvBuffer + pos + 2*sizeof(unsigned int), iHeaderLen - 2*sizeof(unsigned int));

			pos += iHeaderLen;

            done.push_back(rsp);
        }
    }

    return pos;
}

/*
   ��������뺯�����������Ĵ����ʽΪ
   ���������ȣ�4�ֽڣ�+iRequestId��4�ֽڣ�+������
*/
static void pushRequest(const RequestPacket& request, string& buff)
{
    unsigned int net_bufflength = htonl(request.sBuffer.size()+8);
    unsigned char * bufflengthptr = (unsigned char*)(&net_bufflength);

    buff = "";
    for (int i = 0; i<4; ++i)
    {
        buff += *bufflengthptr++;
    }

    unsigned int netrequestId = htonl(request.iRequestId);
    unsigned char * netrequestIdptr = (unsigned char*)(&netrequestId);

    for (int i = 0; i<4; ++i)
    {
        buff += *netrequestIdptr++;
    }

    string tmp;
    tmp.assign((const char*)(&request.sBuffer[0]), request.sBuffer.size());
    buff+=tmp;
}

static void printResult(int iRequestId, const string &sResponseStr)
{
	cout << "request id: " << iRequestId << endl;
	cout << "response str: " << sResponseStr << endl;
}
static void printPushInfo(const string &sResponseStr)
{
	cout << "push message: " << sResponseStr << endl;
}

int TestPushCallBack::onDispatch(ReqMessagePtr msg)
{
	if(msg->response.iRequestId == 0)
	{
		string sRet;
		sRet.assign(&(msg->response.sBuffer[0]), msg->response.sBuffer.size());
		printPushInfo(sRet);
		return 0;
	}
	else
	{
		string sRet;
		sRet.assign(&(msg->response.sBuffer[0]), msg->response.sBuffer.size());

		if(sRet == "heartbeat")
		{
			printResult(msg->request.iRequestId, sRet);
			return 0;
		}
		else
		{
			cout << "data error!" <<endl;
		}
	}
	return -3;
}

RecvThread::RecvThread():_bTerminate(false)
{
	string sObjName = "Test.TestPushServer.TestPushServantObj";
    //string sObjHost = "tcp -h 10.148.144.147 -p 15283 -t 60000";
	string sObjHost = "tcp -h 172.27.206.150 -p 35896 -t 60000";

	_comm.setProperty("netthread", "2");

    _prx = _comm.stringToProxy<ServantPrx>(sObjName+"@"+sObjHost);

	ProxyProtocol prot;

    prot.requestFunc = pushRequest;
    prot.responseFunc = pushResponse;

    _prx->taf_set_protocol(prot);
}

void RecvThread::terminate()
{
	_bTerminate = true;
	{
	    taf::TC_ThreadLock::Lock sync(*this);
	    notifyAll();
	}
}

void RecvThread::run(void)
{
	TestPushCallBackPtr cbPush = new TestPushCallBack();

	_prx->taf_set_push_callback(cbPush);	

	string buf("heartbeat");

	while(!_bTerminate)
	{
		{
			try
			{
				TestPushCallBackPtr cb = new TestPushCallBack();
			
				_prx->rpc_call_async(_prx->taf_gen_requestid(), "printResult", buf.c_str(), buf.length(), cb);
			}
			catch(TafException& e)
			{     
				cout << "TafException: " << e.what() << endl;
			}
			catch(...)
			{
				cout << "unknown exception" << endl;
			}
		}

		{
            TC_ThreadLock::Lock sync(*this);
            timedWait(5000);
		}
	}
}