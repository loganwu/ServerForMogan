#include "TestPushServantImp.h"
#include "servant/Application.h"
#include "TestPushThread.h"

using namespace std;

//////////////////////////////////////////////////////
void TestPushServantImp::initialize()
{
	//initialize servant here:
	//...
}

//////////////////////////////////////////////////////
void TestPushServantImp::destroy()
{
	//destroy servant here:
	//...
}

int TestPushServantImp::doRequest(taf::JceCurrentPtr current, vector<char>& response)
{
	
	string sKey = current->getIp();
	sKey += ":";
	sKey += TC_Common::tostr(current->getPort());

	(PushUser::mapMutex).lock();
	map<string, JceCurrentPtr>::iterator it = PushUser::pushUser.find(sKey);
	if(it == PushUser::pushUser.end())
	{
		PushUser::pushUser.insert(map<string, JceCurrentPtr>::value_type(sKey, current));
		LOG->debug() << "connect ip:port: " << sKey << endl;
	}
	(PushUser::mapMutex).unlock();

	const vector<char>& request = current->getRequestBuffer();
	response = request;

	return 0;
}

int TestPushServantImp::doClose(JceCurrentPtr current)
{
	string sKey = current->getIp();
	sKey += ":";
	sKey += TC_Common::tostr(current->getPort());

	(PushUser::mapMutex).lock();
	map<string, JceCurrentPtr>::iterator it = PushUser::pushUser.find(sKey);
	if(it != PushUser::pushUser.end())
	{
		PushUser::pushUser.erase(it);
		LOG->debug() << "close ip:port: " << sKey << endl;
	}
	(PushUser::mapMutex).unlock();

	return 0;
}