#ifndef _TestPushServer_H_
#define _TestPushServer_H_

#include <iostream>
#include "servant/Application.h"
#include "TestPushThread.h"

using namespace taf;

/**
 *
 **/
class TestPushServer : public Application
{
public:
	/**
	 *
	 **/
	virtual ~TestPushServer() {};

	/**
	 *
	 **/
	virtual void initialize();

	/**
	 *
	 **/
	virtual void destroyApp();
private:
	PushInfoThread pushThread;
};

extern TestPushServer g_app;

////////////////////////////////////////////
#endif
