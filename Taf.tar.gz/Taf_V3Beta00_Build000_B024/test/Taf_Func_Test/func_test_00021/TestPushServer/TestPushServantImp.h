#ifndef _TestPushServantImp_H_
#define _TestPushServantImp_H_

#include "servant/Application.h"


/**
 *
 *
 */
class TestPushServantImp : public taf::Servant
{
public:
	/**
	 *
	 */
	virtual ~TestPushServantImp() {}

	/**
	 *
	 */
	virtual void initialize();

	/**
	 *
	 */
    virtual void destroy();

	/**
	 *
	 */
	virtual int test(taf::JceCurrentPtr current) { return 0;};

	int doRequest(taf::JceCurrentPtr current, vector<char>& response);

	int doClose(JceCurrentPtr current);

};
/////////////////////////////////////////////////////
#endif
