#ifndef _AServantImp_H_
#define _AServantImp_H_

#include "servant/Application.h"
#include "AServant.h"

/**
 *
 *
 */
class AServantImp : public Test::AServant
{
public:
	/**
	 *
	 */
	virtual ~AServantImp() {}

	/**
	 *
	 */
	virtual void initialize();

	/**
	 *
	 */
    virtual void destroy();

	virtual int doCustomMessage(bool bExpectIdle);
    virtual int doCustomMessage() ;

	/**
	 *
	 */
	//virtual int test(taf::JceCurrentPtr current) { return 0;};
	virtual int test(taf::JceCurrentPtr current); 
    virtual string saysomething(const std::string& s, taf::JceCurrentPtr current);

	taf::Int32 testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current);
private:
	int _iNum;
    time_t _iTime;
	bool bFlag1;
	bool bFlag2;
	bool bFlag3;
};
/////////////////////////////////////////////////////
#endif
