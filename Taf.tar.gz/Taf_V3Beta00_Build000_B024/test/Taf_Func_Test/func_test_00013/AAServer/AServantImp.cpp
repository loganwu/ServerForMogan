#include "AServantImp.h"
#include "servant/Application.h"

using namespace std;

//////////////////////////////////////////////////////
void AServantImp::initialize()
{
	//initialize servant here:
	//...
	_iNum = 0;
	_iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
	bFlag1 = false;
	bFlag2 = false;
	bFlag3 = false;
}

//////////////////////////////////////////////////////
void AServantImp::destroy()
{
	//destroy servant here:
	//...
}


int AServantImp::test(taf::JceCurrentPtr current) { return 0;};

string AServantImp::saysomething(const std::string& s, taf::JceCurrentPtr current)
{
	++_iNum;

	if(_iNum == 100000)
    {
        LOG->debug()<<"time:"<<pthread_self()<<"|"<<TC_TimeProvider::getInstance()->getNowMs()-_iTime<<endl;
        _iTime=TC_TimeProvider::getInstance()->getNowMs();
        _iNum=0;
    }
	bFlag1 = true;
	bFlag2 = true;
	bFlag3 = true;
    return s;
}

taf::Int32 AServantImp::testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current)
{
    iOut = iIn;
    _iNum ++;
    if(_iNum == 100000)
    {
        LOG->debug()<<pthread_self()<<"|"<<taf::TC_TimeProvider::getInstance()->getNowMs() - _iTime <<endl;
        _iNum = 0;
        _iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
    }
	bFlag1 = true;
	bFlag2 = true;
	bFlag3 = true;
    return 0;
}

int AServantImp::doCustomMessage(bool bExpectIdle)
{
	if(bExpectIdle)
	{
		if(bFlag1)
		{
			LOG->debug() << "AServantImp::doCustomMessage(bool true)..." << endl;
			bFlag1 = false;
		}
	}
	else
	{
		if(bFlag2)
		{
			LOG->debug() << "AServantImp::doCustomMessage(bool false)..." << endl;
			bFlag2 = false;
		}
	}
	return 0;
}

int AServantImp::doCustomMessage()
{
	if(bFlag3)
	{
		LOG->debug() << "AServantImp::doCustomMessage()..." << endl;
		bFlag3 = false;
	}
	return 0;
}