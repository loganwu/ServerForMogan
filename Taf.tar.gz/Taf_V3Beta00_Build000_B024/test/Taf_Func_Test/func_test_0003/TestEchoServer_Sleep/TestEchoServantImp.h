#ifndef _TestEchoServantImp_H_
#define _TestEchoServantImp_H_

#include "servant/Application.h"

/**
 *
 *
 */
class TestEchoServantImp : public taf::Servant
{
public:
	/**
	 *
	 */
	virtual ~TestEchoServantImp() {}

	/**
	 *
	 */
	virtual void initialize();

	/**
	 *
	 */
    virtual void destroy();

	/**
	 *
	 */
	int doRequest(taf::JceCurrentPtr current, vector<char>& response)
	{
		const vector<char>& request = current->getRequestBuffer();
		response = request;

		LOG->debug() << "begin sleep..." << endl;
		usleep(1000000);
		LOG->debug() << "end sleep..." << endl;

		return 0;
	}
};
/////////////////////////////////////////////////////
#endif
