#include "AServant.h"
#include <string.h>
#include "util/tc_config.h"
#include "servant/Communicator.h"
#include <iostream>

using namespace std;
using namespace taf;
using namespace Test;


int main(int argc, char *argv[])
{
	if(argc != 3)
	{
		cout << "usage: " << argv[0] << " Count Speed" << endl;
		return -1;
	}

	int iCount = TC_Common::strto<int>(argv[1]);

	int iSpeed = TC_Common::strto<int>(argv[2]);

	string stringToProxy("Test.AAServer.AAServantObj");

	CommunicatorPtr pComm = new Communicator;

	pComm->setProperty("locator", "taf.tafregistry.QueryObj@tcp -h 172.27.194.147 -p 17890");

	AServantPrx proxyPrx = pComm->stringToProxy<AServantPrx>(stringToProxy);

	struct timeval tStart, tEnd;
	taf::Int32 count = 0;
	gettimeofday(&tStart, NULL);

	int iSend = 0;
	time_t tBegin = time(NULL);

	while(count < iCount)
	{
		try
		{
			proxyPrx->async_saysomething(NULL, "hello world");
		}
		catch (const std::exception & ex)
		{
			cout << "id: " << count << "async_getString exception: " << ex.what() << endl;
		}
		count++;
		iSend++;		
		if(iSend > iSpeed)
		{
			time_t tNow = time(NULL);
			while(tNow <= tBegin)
			{
				usleep(1000);
				tNow = time(NULL);
			}
			tBegin = tNow;
			iSend = 0;
		}
	}
	cout << "send:" << count <<endl;

	sleep(60);

	gettimeofday(&tEnd, NULL);

	cout << TC_Common::tostr<taf::Int32>(1000000*(tEnd.tv_sec-tStart.tv_sec)+(tEnd.tv_usec-tStart.tv_usec)) << endl;
	
	return 0;
}
