#include "BServantImp.h"
#include "BServer.h"
#include "servant/Application.h"
#include "servant/Communicator.h"

using namespace std;
using namespace taf;

//////////////////////////////////////////////////////
void BServantImp::initialize()
{
	//initialize servant here:
	//...
	_iNum = 0;
    _iTime = taf::TC_TimeProvider::getInstance()->getNow();
    _pPrx = Application::getCommunicator()->stringToProxy<AServantPrx>("Test.AAServer.AAServantObj");//@tcp -h 10.148.139.39 -p 15976
}
//////////////////////////////////////////////////////
void BServantImp::destroy()
{
}
  
class AServantCallback : public AServantPrxCallback
{

public:
	AServantCallback(JceCurrentPtr &current): _current(current){}
    virtual void callback_saysomething(const std::string& _ret)
	{ 	
		//assert(r == "hello word");
		AServant::async_response_saysomething(_current,_ret);
		
	}
    virtual void callback_saysomething_exception(taf::Int32 ret)
	{ 	
		//assert(ret == 0);
		cout << "callback exception:" << ret << endl; 
	}

	void callback_testInt(taf::Int32 ret, taf::Int32 iOut)
    {
        AServant::async_response_testInt(_current,ret,iOut);
    }
    void callback_testInt_exception(taf::Int32 ret)
    {
        LOG->debug()<<"ServerPrxCallback callback_testInt_exception:"<<ret<<endl;
    }

	JceCurrentPtr _current;
};



int BServantImp::test(taf::JceCurrentPtr current) { return 0;}

string BServantImp::dohandle(const string &s, JceCurrentPtr current)
{
	_iNum++;
    Test::AServantPrxCallbackPtr cb = new AServantCallback(current);
	_pPrx->async_saysomething(cb,s);

	current->setResponse(false);

	if(_iNum == 100000)
	{
		LOG->debug()<<"time:"<<pthread_self()<<"|"<<TC_TimeProvider::getInstance()->getNowMs()-_iTime<<endl;
		_iTime=TC_TimeProvider::getInstance()->getNowMs();
		_iNum=0;
	}

	/*vector<EndpointInfo> active, inactive;
	_pPrx->taf_endpoints(active, inactive);

	for(size_t i = 0; i < active.size(); ++i)
	{
		LOG->debug() << "active : i = " << i << " | desc: " << active[i].desc() << endl;
	}

	for(size_t i = 0; i < inactive.size(); ++i)
	{
		LOG->debug() << "inactive : i = " << i << " | desc: " << inactive[i].desc() << endl;
	}*/

	return "";
}

taf::Int32 BServantImp::testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current)
{
    _iNum++;
    current->setResponse(false);
    Test::AServantPrxCallbackPtr cb=new AServantCallback(current);
    _pPrx->async_testInt(cb,iIn);
    if(_iNum == 100000)
    {
        LOG->debug()<<"time:"<<pthread_self()<<"|"<<TC_TimeProvider::getInstance()->getNowMs()-_iTime<<endl;
        _iTime=TC_TimeProvider::getInstance()->getNowMs();
        _iNum=0;
    }
    return 0;
}



