#include <iostream>
#include <arpa/inet.h>
#include "servant/Communicator.h"
#include "wbl.h"
#include "wbl/thread_pool.h"

using namespace std;
using namespace taf;
using namespace wbl;

TC_Atomic      g_succ_count;
TC_Atomic      g_error_count;

/*
 ��Ӧ�����뺯���������ض���ʽ����ӷ�����յ������ݣ�����ΪResponsePacket
*/
static size_t echoResponse(const char* recvBuffer, size_t length, list<ResponsePacket>& done)
{
    size_t pos = 0;
    while (pos < length)
    {
        unsigned int len = length - pos;
        if(len < sizeof(unsigned int))
        {
            break;
        }

        unsigned int iHeaderLen = ntohl(*(unsigned int*)(recvBuffer + pos));

        //��һ�±���,���ȴ���10M
        if (iHeaderLen > 100000 || iHeaderLen < sizeof(unsigned int))
        {
            throw JceDecodeException("packet length too long or too short,len:" + TC_Common::tostr(iHeaderLen));
        }

        //��û�н���ȫ
        if (len < iHeaderLen)
        {
            break;
        }
        else
        {
            ResponsePacket rsp;
			rsp.iRequestId = ntohl(*((unsigned int *)(recvBuffer + pos + sizeof(unsigned int))));
			rsp.sBuffer.resize(iHeaderLen - 2*sizeof(unsigned int));
		    ::memcpy(&rsp.sBuffer[0], recvBuffer + pos + 2*sizeof(unsigned int), iHeaderLen - 2*sizeof(unsigned int));

			pos += iHeaderLen;

            done.push_back(rsp);
        }
    }

    return pos;
}

/*
   ��������뺯�����������Ĵ����ʽΪ
   ���������ȣ�4�ֽڣ�+iRequestId��4�ֽڣ�+������
*/
static void echoRequest(const RequestPacket& request, string& buff)
{
    unsigned int net_bufflength = htonl(request.sBuffer.size()+8);
    unsigned char * bufflengthptr = (unsigned char*)(&net_bufflength);

    buff = "";
    for (int i = 0; i<4; ++i)
    {
        buff += *bufflengthptr++;
    }

    unsigned int netrequestId = htonl(request.iRequestId);
    unsigned char * netrequestIdptr = (unsigned char*)(&netrequestId);

    for (int i = 0; i<4; ++i)
    {
        buff += *netrequestIdptr++;
    }

    string tmp;
    tmp.assign((const char*)(&request.sBuffer[0]), request.sBuffer.size());
    buff+=tmp;
}


class TestEchoCallBack : public ServantProxyCallback
{
	virtual int onDispatch(ReqMessagePtr msg)
	{
		string sRet;
		sRet.assign(&(msg->response.sBuffer[0]), msg->response.sBuffer.size());

		if(sRet == "abc")
		{
			g_succ_count.inc();
			return 0;
		}
		else
		{
			cout<<"ret: " << msg->response.iRet << endl;
			g_error_count.inc();
		}

		return -3;
	}
};
typedef taf::TC_AutoPtr<TestEchoCallBack> TestEchoCallBackPtr;

class Test1
{
public:
	Test1(int iSpeed = 100);

	~Test1();

	void th_dohandle_async(int excut_num);

private:
	Communicator _comm;
	ServantPrx prx;
	int			_iSpeed;
};

Test1::Test1(int iSpeed)
: _iSpeed(iSpeed)
{
	string testServer("Test.TestEchoServer.TestEchoServantObj");

	_comm.setProperty("locator", "taf.tafregistry.QueryObj@tcp -h 172.27.194.147 -p 17890");

	_comm.setProperty("netthread", "2");
	_comm.stringToProxy(testServer, prx);

	ProxyProtocol prot;

    prot.requestFunc = echoRequest;
    prot.responseFunc = echoResponse;

    prx->taf_set_protocol(prot);

	prx->taf_async_timeout(1000);
}

Test1::~Test1()
{
	
}

void Test1::th_dohandle_async(int excut_num)
{
	taf::Int32 count = 0;

	int iSend = 0;

	string buf("abc");
	string func("printResult");

	time_t _iTime = TC_TimeProvider::getInstance()->getNowMs();

	for(int i=0; i<excut_num; i++) 
	{
		TestEchoCallBackPtr cb = new TestEchoCallBack();

		try
		{
			prx->rpc_call_async(prx->taf_gen_requestid(), func, buf.c_str(), buf.length(), cb);
		}
		catch (const std::exception & ex)
		{
			cout << "rpc_call_async exception: " << ex.what() << endl;
			g_error_count.inc();
		}

		count++;
		iSend++;

		if(iSend > _iSpeed)
		{
			usleep(100000);
			iSend = 0;
		}
	}
	cout << "send:" << count <<endl;
	cout << "pthread id: " << pthread_self() << " | " << TC_TimeProvider::getInstance()->getNowMs() - _iTime << endl;
}

int main(int argc,char ** argv)
{
	if(argc != 4)
	{
		cout << "usage: " << argv[0] << " ThreadNum CallTimes SendSpeed" << endl;
		return -1;
	}

	taf::Int32 threads = TC_Common::strto<taf::Int32>(string(argv[1]));

	taf::Int32 times = TC_Common::strto<taf::Int32>(string(argv[2]));

	taf::Int32 iSpeed = TC_Common::strto<taf::Int32>(string(argv[3]));

	Test1 test1(iSpeed);

    try
    {
		thread_pool tp;

        if(tp.start(threads))
        {
            cout << "init tp succ" << endl;
        }
		
		for(int i = 0; i<threads; i++) 
		{
			tp.execute_memfun(test1,&Test1::th_dohandle_async,times);
			cout << "********************" <<endl;
		}

        tp.wait(); 
    }
	catch(exception &e)
    {
        cout<<e.what()<<endl;
    }
    catch(...)
    {
        
    }

	while(true)
	{
		int sum = g_succ_count.get() + g_error_count.get();
		cout << "response :" << "sum ="  << sum << ", succ = " << g_succ_count.get() << ",error = " << g_error_count.get() << endl;
		if( sum >= threads * times )
			break;
		else
			usleep(100000);
	}
	
    return 0;
}
