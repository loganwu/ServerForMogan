#include "servant/Application.h"
#include <iostream>
#include <arpa/inet.h>
#include "wbl.h"
#include "wbl/thread_pool.h"

using namespace std;
using namespace taf;
using namespace wbl;

/*
 ��Ӧ�����뺯���������ض���ʽ����ӷ�����յ������ݣ�����ΪResponsePacket
*/
static size_t echoResponse(const char* recvBuffer, size_t length, list<ResponsePacket>& done)
{
    size_t pos = 0;
    while (pos < length)
    {
        unsigned int len = length - pos;
        if(len < sizeof(unsigned int))
        {
            break;
        }

        unsigned int iHeaderLen = ntohl(*(unsigned int*)(recvBuffer + pos));

        //��һ�±���,���ȴ���10M
        if (iHeaderLen > 100000 || iHeaderLen < sizeof(unsigned int))
        {
            throw JceDecodeException("packet length too long or too short,len:" + TC_Common::tostr(iHeaderLen));
        }

        //��û�н���ȫ
        if (len < iHeaderLen)
        {
            break;
        }
        else
        {
            ResponsePacket rsp;
			rsp.iRequestId = ntohl(*((unsigned int *)(recvBuffer + pos + sizeof(unsigned int))));
			rsp.sBuffer.resize(iHeaderLen - 2*sizeof(unsigned int));
		    ::memcpy(&rsp.sBuffer[0], recvBuffer + pos + 2*sizeof(unsigned int), iHeaderLen - 2*sizeof(unsigned int));

			pos += iHeaderLen;

            done.push_back(rsp);
        }
    }

    return pos;
}

/*
   ��������뺯�����������Ĵ����ʽΪ
   ���������ȣ�4�ֽڣ�+iRequestId��4�ֽڣ�+������
*/
static void echoRequest(const RequestPacket& request, string& buff)
{
    unsigned int net_bufflength = htonl(request.sBuffer.size()+8);
    unsigned char * bufflengthptr = (unsigned char*)(&net_bufflength);

    buff = "";
    for (int i = 0; i<4; ++i)
    {
        buff += *bufflengthptr++;
    }

    unsigned int netrequestId = htonl(request.iRequestId);
    unsigned char * netrequestIdptr = (unsigned char*)(&netrequestId);

    for (int i = 0; i<4; ++i)
    {
        buff += *netrequestIdptr++;
    }

    string tmp;
    tmp.assign((const char*)(&request.sBuffer[0]), request.sBuffer.size());
    buff+=tmp;
}

class Test1
{
public:
	Test1();

	~Test1();

	void  th_dohandle(int excut_num);

private:
	Communicator _comm;
	ServantPrx prx;
};

Test1::Test1()
{
	string testServer("Test.TestEchoServer.TestEchoServantObj");

	_comm.setProperty("locator", "taf.tafregistry.QueryObj@tcp -h 172.27.194.147 -p 17890");
	_comm.setProperty("netthread", "2");

	_comm.stringToProxy(testServer, prx);

	ProxyProtocol prot;

    prot.requestFunc = echoRequest;
    prot.responseFunc = echoResponse;

    //����Э��Ľ�����������������ı���������Ӧ���Ľ�����
    prx->taf_set_protocol(prot);

	prx->taf_timeout(1000);
}

Test1::~Test1()
{
	
}

void Test1::th_dohandle(int excut_num)
{
	taf::Int32 count = 0;
	unsigned long sum = 0;
	string buf ="abc";
    ResponsePacket rsp;

	time_t _iTime = TC_TimeProvider::getInstance()->getNowMs();

	for(int i = 0; i < excut_num; i++) 
	{
		try
		{
			prx->rpc_call(prx->taf_gen_requestid(), "", buf.c_str(), buf.length(), rsp);

			string output;

			output.assign((const char*)(&rsp.sBuffer[0]), rsp.sBuffer.size());
			if(output == buf)
			{
				count++;
				sum++;
				if(count == excut_num)
				{
					cout << "pthread id: " << pthread_self() << " | " << TC_TimeProvider::getInstance()->getNowMs() - _iTime << endl;
					_iTime = TC_TimeProvider::getInstance()->getNowMs();
					count = 0;
				}
			}
		}
		catch(TC_Exception &e)
		{
			cout << "pthread id: " << pthread_self() << "id: " << i << "exception: " << e.what() << endl;
		}
		catch(...)
		{
			cout << "pthread id: " << pthread_self() << "id: " << i << "unknown exception." << endl;
		}
	}
	cout << "succ:" << sum <<endl;
}
int main(int argc,char**argv)
{
	if(argc != 3)
	{
		cout << "usage: " << argv[0] << " ThreadNum CallTimes" << endl;
		return -1;
	}

	Test1 test1;

	taf::Int32 threads = TC_Common::strto<taf::Int32>(string(argv[1]));

	taf::Int32 times = TC_Common::strto<taf::Int32>(string(argv[2]));

    try
    {
		thread_pool tp;
        if(tp.start(threads))
        {
            cout << "init tp succ" << endl;
        }
		
		for(int i = 0; i<threads; i++) 
		{
			tp.execute_memfun(test1,&Test1::th_dohandle, times);
			cout<<"***********"<<endl;
		}

        tp.wait(); 
    }
	catch(std::exception &e)
    {
        cout<<e.what()<<endl;
    }
    catch(...)
    {
        
    }

    return 0;
}
