#ifndef _AServantImp_H_
#define _AServantImp_H_

#include "servant/Application.h"
#include "AServant.h"

/**
 *
 *
 */
class AServantImp : public Test::AServant
{
public:
	/**
	 *
	 */
	virtual ~AServantImp() {}

	/**
	 *
	 */
	virtual void initialize();

	/**
	 *
	 */
    virtual void destroy();

	/**
	 *
	 */
	taf::Int32 testUdp(const std::string& sIn, std::string& sOut,taf::JceCurrentPtr current);

	virtual int doClose(JceCurrentPtr current);

private:
	int _iNum;
    time_t _iTime;
	static TC_Atomic      g_total_request;
};
/////////////////////////////////////////////////////
#endif
