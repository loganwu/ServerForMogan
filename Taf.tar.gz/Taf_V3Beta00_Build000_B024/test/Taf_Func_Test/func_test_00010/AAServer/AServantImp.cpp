#include "AServantImp.h"
#include "servant/Application.h"

using namespace std;

TC_Atomic      AServantImp::g_total_request = 0;

//////////////////////////////////////////////////////
void AServantImp::initialize()
{
	//initialize servant here:
	//...
	_iNum = 0;
	_iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
}

//////////////////////////////////////////////////////
void AServantImp::destroy()
{
	//destroy servant here:
	//...
}

taf::Int32 AServantImp::testUdp(const std::string& sIn, std::string& sOut,taf::JceCurrentPtr current)
{
    sOut = sIn;
    _iNum ++;
    if(_iNum == 100000)
    {
        LOG->debug()<<pthread_self()<<"|"<<taf::TC_TimeProvider::getInstance()->getNowMs() - _iTime <<endl;
        _iNum = 0;
        _iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
    }
	g_total_request.inc();
	LOG->debug() << "total request packet: " << g_total_request.get() << endl;
    return 0;
}

int AServantImp::doClose(JceCurrentPtr current)
{
	LOG->debug() << "do Close total request packet: " << g_total_request.get() << endl;
	return 0;
}