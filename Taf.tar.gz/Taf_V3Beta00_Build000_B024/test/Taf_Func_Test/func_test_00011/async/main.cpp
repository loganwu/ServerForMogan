#include "AServant.h"
#include "servant/Communicator.h"
#include "wbl.h"
#include "wbl/thread_pool.h"
#include <iostream>

using namespace std;
using namespace Test;
using namespace taf;
using namespace wbl;

TC_Atomic      g_succ_count;
TC_Atomic      g_error_count;

class ProxyCallBack : public AServantPrxCallback
{
public:
	ProxyCallBack(){}

	virtual ~ProxyCallBack(){}

	virtual void callback_saysomething(const std::string& ret)
	{
		string s("hello world");
		assert(ret == s);

		g_succ_count.inc();
	}

	virtual void callback_saysomething_exception(taf::Int32 ret)
	{
		cout << "callback_getString_exception : ret = " << ret << endl;
		g_error_count.inc();
	}
};

class Test1
{
public:
	Test1(const string & sIp, const string & sPort, int iSpeed = 100);

	~Test1();

	void th_dohandle_async(int excut_num);
private:
	Communicator _comm;
	AServantPrx prx;
	int			_iSpeed;
};

Test1::Test1(const string & sIp, const string & sPort, int iSpeed)
: _iSpeed(iSpeed)
{
	string testServer("Test.AAServer.AAServantObj@tcp -h ");

	testServer += sIp;
	testServer += " -p ";
	testServer += sPort;

	_comm.stringToProxy(testServer, prx);

	prx->taf_async_timeout(1500);
}

Test1::~Test1()
{
	
}

void Test1::th_dohandle_async(int excut_num)
{
	taf::Int32 count = 0;

	int iSend = 0;

	time_t _iTime = TC_TimeProvider::getInstance()->getNowMs();

	for(int i=0; i<excut_num; i++) 
	{
		AServantPrxCallbackPtr cb = new ProxyCallBack();

		try
		{
			prx->async_saysomething(cb, "hello world");
		}
		catch (const std::exception & ex)
		{
			cout << "async_saysomething exception: " << ex.what() << endl;
			g_error_count.inc();
		}

		count++;
		iSend++;

		if(iSend > _iSpeed)
		{
			usleep(100000);
			iSend = 0;
		}
	}
	cout << "send:" << count <<endl;
	cout << "pthread id: " << pthread_self() << " | " << TC_TimeProvider::getInstance()->getNowMs() - _iTime << endl;
}

int main(int argc,char ** argv)
{
	if(argc != 6)
	{
		cout << "usage: " << argv[0] << " Ip Port ThreadNum CallTimes SendSpeed" << endl;
		return -1;
	}

	string sIp = string(argv[1]);

	string sPort = string(argv[2]);

	taf::Int32 threads = TC_Common::strto<taf::Int32>(string(argv[3]));

	taf::Int32 times = TC_Common::strto<taf::Int32>(string(argv[4]));

	taf::Int32 iSpeed = TC_Common::strto<taf::Int32>(string(argv[5]));

	Test1 test1(sIp, sPort, iSpeed);

    try
    {
		thread_pool tp;

        if(tp.start(threads))
        {
            cout << "init tp succ" << endl;
        }
		
		for(int i = 0; i<threads; i++) 
		{
			tp.execute_memfun(test1,&Test1::th_dohandle_async,times);
			cout << "********************" <<endl;
		}

        tp.wait(); 
    }
	catch(exception &e)
    {
        cout<<e.what()<<endl;
    }
    catch(...)
    {
        
    }

	while(true)
	{
		int sum = g_succ_count.get() + g_error_count.get();
		cout << "response :" << "sum ="  << sum << ", succ = " << g_succ_count.get() << ",error = " << g_error_count.get() << endl;
		if( sum >= threads * times )
			break;
		else
			usleep(100000);
	}
	
    return 0;
}
