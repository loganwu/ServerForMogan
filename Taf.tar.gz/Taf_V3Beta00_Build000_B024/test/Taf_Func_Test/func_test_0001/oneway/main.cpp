#include "AServant.h"
#include <string.h>
#include "util/tc_config.h"
#include "servant/Communicator.h"
#include <iostream>

using namespace std;
using namespace taf;
using namespace Test;


int main(int argc, char *argv[])
{
	if(argc != 5)
	{
		cout << "usage: " << argv[0] << " Ip Port Count Speed" << endl;
		return -1;
	}

	string sIp = string(argv[1]);

	string sPort = string(argv[2]);

	int iCount = TC_Common::strto<int>(argv[3]);

	int iSpeed = TC_Common::strto<int>(argv[4]);

	string stringToProxy("Test.AAServer.AAServantObj@tcp -h ");

	stringToProxy += sIp;
	stringToProxy += " -p ";
	stringToProxy += sPort;

	CommunicatorPtr pComm = new Communicator;

	AServantPrx proxyPrx = pComm->stringToProxy<AServantPrx>(stringToProxy);

	struct timeval tStart, tEnd;
	taf::Int32 count = 0;
	gettimeofday(&tStart, NULL);

	int iSend = 0;
	time_t tBegin = time(NULL);

	while(count < iCount)
	{
		try
		{
			proxyPrx->async_saysomething(NULL, "hello world");
		}
		catch (const std::exception & ex)
		{
			cout << "id: " << count << "async_getString exception: " << ex.what() << endl;
		}
		count++;
		iSend++;		
		if(iSend > iSpeed)
		{
			time_t tNow = time(NULL);
			while(tNow <= tBegin)
			{
				usleep(1000);
				tNow = time(NULL);
			}
			tBegin = tNow;
			iSend = 0;
		}
	}
	cout << "send:" << count <<endl;

	sleep(60);

	gettimeofday(&tEnd, NULL);

	cout << TC_Common::tostr<taf::Int32>(1000000*(tEnd.tv_sec-tStart.tv_sec)+(tEnd.tv_usec-tStart.tv_usec)) << endl;
	
	return 0;
}
