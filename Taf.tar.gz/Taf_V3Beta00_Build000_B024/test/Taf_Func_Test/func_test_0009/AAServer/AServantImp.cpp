#include "AServantImp.h"
#include "servant/Application.h"

using namespace std;

//////////////////////////////////////////////////////
void AServantImp::initialize()
{
	//initialize servant here:
	//...
	_iNum = 0;
	_iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
}

//////////////////////////////////////////////////////
void AServantImp::destroy()
{
	//destroy servant here:
	//...
}


int AServantImp::test(taf::JceCurrentPtr current) { return 0;};

string AServantImp::saysomething(const std::string& s, taf::JceCurrentPtr current)
{
	++_iNum;

	if(_iNum == 100000)
    {
        LOG->debug()<<"time:"<<pthread_self()<<"|"<<TC_TimeProvider::getInstance()->getNowMs()-_iTime<<endl;
        _iTime=TC_TimeProvider::getInstance()->getNowMs();
        _iNum=0;
    }
	usleep(3000000);
    return s;
}

taf::Int32 AServantImp::testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current)
{
    iOut = iIn;
    _iNum ++;
    if(_iNum == 100000)
    {
        LOG->debug()<<pthread_self()<<"|"<<taf::TC_TimeProvider::getInstance()->getNowMs() - _iTime <<endl;
        _iNum = 0;
        _iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
    }
	usleep(3000000);
    return 0;
}