#include "AServantImp.h"
#include "servant/Application.h"

using namespace std;

TC_Atomic      AServantImp::g_total_request = 0;

//////////////////////////////////////////////////////
void AServantImp::initialize()
{
	//initialize servant here:
	//...
	_iNum = 0;
	_iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
}

//////////////////////////////////////////////////////
void AServantImp::destroy()
{
	//destroy servant here:
	//...
}


int AServantImp::test(taf::JceCurrentPtr current) { return 0;};

string AServantImp::saysomething(const std::string& s, taf::JceCurrentPtr current)
{
	++_iNum;
	g_total_request.inc();

	if(_iNum == 100000)
    {
        LOG->debug()<<"time:"<<pthread_self()<<"|"<<TC_TimeProvider::getInstance()->getNowMs()-_iTime<<endl;
        _iTime=TC_TimeProvider::getInstance()->getNowMs();
        _iNum=0;
    }
    return s;
}

taf::Int32 AServantImp::testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current)
{
    iOut = iIn;
    _iNum ++;

	g_total_request.inc();

    if(_iNum == 100000)
    {
        LOG->debug()<<pthread_self()<<"|"<<taf::TC_TimeProvider::getInstance()->getNowMs() - _iTime <<endl;
        _iNum = 0;
        _iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
    }
    return 0;
}

int AServantImp::doClose(JceCurrentPtr current)
{
	LOG->debug() << "do Close total request packet: " << g_total_request.get() << endl;
	return 0;
}
