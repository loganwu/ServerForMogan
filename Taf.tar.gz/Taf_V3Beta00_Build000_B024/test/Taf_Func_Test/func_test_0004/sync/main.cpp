#include "AServant.h"
#include "servant/Communicator.h"
#include "wbl.h"
#include "wbl/thread_pool.h"
#include <iostream>

using namespace std;
using namespace Test;
using namespace taf;
using namespace wbl;

class Test1
{
public:
	Test1();

	~Test1();

	void  th_dohandle(int excut_num);

private:
	Communicator _comm;
	AServantPrx prx;
};

Test1::Test1()
{
	string testServer("Test.AAServer.AAServantObj@tcp -h 10.148.144.147 -p 15976:tcp -h 10.148.147.79 -p 15976:tcp -h 10.148.139.39 -p 15976");

	_comm.stringToProxy(testServer, prx);
}

Test1::~Test1()
{
	
}

void Test1::th_dohandle(int excut_num)
{
	taf::Int32 in = 5,out = 0;

	taf::Int32 count = 0;
	unsigned long sum = 0;

	time_t _iTime=TC_TimeProvider::getInstance()->getNowMs();

	for(int i=0; i<excut_num; i++) 
	{
		try
		{
			prx->testInt(in, out);
			if(in == out)
			{
				++sum;
				++count;
				if(count == 200000)
				{
					cout << "pthread id: " << pthread_self() << " | " << TC_TimeProvider::getInstance()->getNowMs() - _iTime << endl;
					_iTime=TC_TimeProvider::getInstance()->getNowMs();
					count = 0;
				}
			}
		}
		catch(TC_Exception &e)
		{
			cout << "pthread id: " << pthread_self() << "id: " << i << "exception: " << e.what() << endl;
		}
		catch(...)
		{
			cout << "pthread id: " << pthread_self() << "id: " << i << "unknown exception." << endl;
		}
	}
	cout << "succ:" << sum <<endl;
}

int main(int argc,char ** argv)
{
	if(argc != 3)
	{
		cout << "usage: " << argv[0] << " ThreadNum CallTimes" << endl;
		return -1;
	}

	Test1 test1;

	taf::Int32 threads = TC_Common::strto<taf::Int32>(string(argv[1]));

	taf::Int32 times = TC_Common::strto<taf::Int32>(string(argv[2]));

    try
    {
		thread_pool tp;

        if(tp.start(threads))
        {
            cout << "init tp succ" << endl;
        }
		
		for(int i = 0; i<threads; i++) 
		{
			tp.execute_memfun(test1,&Test1::th_dohandle,times);
			cout << "********************" <<endl;
		}

        tp.wait(); 
    }
	catch(exception &e)
    {
        cout<<e.what()<<endl;
    }
    catch(...)
    {
        
    }
	
    return 0;
}
