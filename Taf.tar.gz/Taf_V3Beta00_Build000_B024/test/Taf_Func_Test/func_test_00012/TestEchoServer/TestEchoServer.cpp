#include "TestEchoServer.h"
#include "TestEchoServantImp.h"

using namespace std;

TestEchoServer g_app;

static int parse(string &in, string &out)
{
	if(in.length() < sizeof(unsigned int))
    {
        return 0;
    }

    unsigned int iHeaderLen;

    memcpy(&iHeaderLen, in.c_str(), sizeof(unsigned int));

    iHeaderLen = ntohl(iHeaderLen);

    if(iHeaderLen < (unsigned int)(sizeof(unsigned int))|| iHeaderLen > 1000000)
    {
        return -1;
    }

    if((unsigned int)in.length() < iHeaderLen)
    {
        return 0;
    }

    out = in.substr(0, iHeaderLen);

    in  = in.substr(iHeaderLen);

    return 1;
}
/////////////////////////////////////////////////////////////////
void
TestEchoServer::initialize()
{
	//initialize application here:
	//...

	addServant<TestEchoServantImp>(ServerConfig::Application + "." + ServerConfig::ServerName + ".TestEchoServantObj");
	addServantProtocol("Test.TestEchoServer.TestEchoServantObj", parse);
}
/////////////////////////////////////////////////////////////////
void
TestEchoServer::destroyApp()
{
	//destroy application here:
	//...
}
/////////////////////////////////////////////////////////////////
int
main(int argc, char* argv[])
{
	try
	{
		g_app.main(argc, argv);
		g_app.waitForShutdown();
	}
	catch (std::exception& e)
	{
		cerr << "std::exception:" << e.what() << std::endl;
	}
	catch (...)
	{
		cerr << "unknown exception." << std::endl;
	}
	return -1;
}
/////////////////////////////////////////////////////////////////
