#ifndef _TestEchoServer_H_
#define _TestEchoServer_H_

#include <iostream>
#include "servant/Application.h"

using namespace taf;

/**
 *
 **/
class TestEchoServer : public Application
{
public:
	/**
	 *
	 **/
	virtual ~TestEchoServer() {};

	/**
	 *
	 **/
	virtual void initialize();

	/**
	 *
	 **/
	virtual void destroyApp();
};

extern TestEchoServer g_app;

////////////////////////////////////////////
#endif
