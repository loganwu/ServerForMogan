#ifndef _TestEchoServantImp_H_
#define _TestEchoServantImp_H_

#include "servant/Application.h"

/**
 *
 *
 */
class TestEchoServantImp : public taf::Servant
{
public:
	/**
	 *
	 */
	virtual ~TestEchoServantImp() {}

	/**
	 *
	 */
	virtual void initialize();

	/**
	 *
	 */
    virtual void destroy();

	/**
	 *
	 */
	int doRequest(taf::JceCurrentPtr current, vector<char>& response)
	{
		const vector<char>& request = current->getRequestBuffer();
		response = request;

		//string sRet;
		//sRet.assign(&response[0], response.size());

		//LOG->debug() << " recv str: " << sRet << " | size " << response.size() << endl;

		//usleep(2000000);

		return 0;
	}
};
/////////////////////////////////////////////////////
#endif
