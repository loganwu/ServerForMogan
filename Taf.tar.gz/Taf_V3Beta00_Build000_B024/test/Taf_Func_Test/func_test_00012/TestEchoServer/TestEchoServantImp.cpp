#include "TestEchoServantImp.h"
#include "servant/Application.h"

using namespace std;

//////////////////////////////////////////////////////
void TestEchoServantImp::initialize()
{
	//initialize servant here:
	//...
}

//////////////////////////////////////////////////////
void TestEchoServantImp::destroy()
{
	//destroy servant here:
	//...
}

