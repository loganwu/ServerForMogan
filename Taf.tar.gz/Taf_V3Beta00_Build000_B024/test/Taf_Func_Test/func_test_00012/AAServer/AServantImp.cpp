#include "AServantImp.h"
#include "servant/Application.h"

using namespace std;

/*
 ��Ӧ�����뺯���������ض���ʽ����ӷ�����յ������ݣ�����ΪResponsePacket
*/

static size_t echoResponse(const char* recvBuffer, size_t length, list<ResponsePacket>& done)
{
    size_t pos = 0;
    while (pos < length)
    {
        unsigned int len = length - pos;
        if(len < sizeof(unsigned int))
        {
            break;
        }

        unsigned int iHeaderLen = ntohl(*(unsigned int*)(recvBuffer + pos));

        //��һ�±���,���ȴ���10M
        if (iHeaderLen > 100000 || iHeaderLen < sizeof(unsigned int))
        {
            throw JceDecodeException("packet length too long or too short,len:" + TC_Common::tostr(iHeaderLen));
        }

        //��û�н���ȫ
        if (len < iHeaderLen)
        {
            break;
        }
        else
        {
            ResponsePacket rsp;
			rsp.iRequestId = ntohl(*((unsigned int *)(recvBuffer + pos + sizeof(unsigned int))));
			rsp.sBuffer.resize(iHeaderLen - 2*sizeof(unsigned int));
		    ::memcpy(&rsp.sBuffer[0], recvBuffer + pos + 2*sizeof(unsigned int), iHeaderLen - 2*sizeof(unsigned int));

			pos += iHeaderLen;

            done.push_back(rsp);
        }
    }

    return pos;
}

/*
   ��������뺯�����������Ĵ����ʽΪ
   ���������ȣ�4�ֽڣ�+iRequestId��4�ֽڣ�+������
*/
static void echoRequest(const RequestPacket& request, string& buff)
{
    unsigned int net_bufflength = htonl(request.sBuffer.size()+8);
    unsigned char * bufflengthptr = (unsigned char*)(&net_bufflength);

    buff = "";
    for (int i = 0; i<4; ++i)
    {
        buff += *bufflengthptr++;
    }

    unsigned int netrequestId = htonl(request.iRequestId);
    unsigned char * netrequestIdptr = (unsigned char*)(&netrequestId);

    for (int i = 0; i<4; ++i)
    {
        buff += *netrequestIdptr++;
    }

    string tmp;
    tmp.assign((const char*)(&request.sBuffer[0]), request.sBuffer.size());
    buff+=tmp;
}

//////////////////////////////////////////////////////
void AServantImp::initialize()
{
	//initialize servant here:
	//...
	_iNum = 0;
	_iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
	_prx = Application::getCommunicator()->stringToProxy<ServantPrx>("Test.TestEchoServer.TestEchoServantObj");

	ProxyProtocol prot;

    prot.requestFunc = echoRequest;
    prot.responseFunc = echoResponse;

    _prx->taf_set_protocol(prot);

	//_prx->taf_async_timeout(1000);
}

//////////////////////////////////////////////////////
void AServantImp::destroy()
{
	//destroy servant here:
	//...
}


int AServantImp::test(taf::JceCurrentPtr current) { return 0;};

string AServantImp::saysomething(const std::string& s, taf::JceCurrentPtr current)
{
	/*++_iNum;

	if(_iNum == 100000)
    {
        LOG->debug()<<"time:"<<pthread_self()<<"|"<<TC_TimeProvider::getInstance()->getNowMs()-_iTime<<endl;
        _iTime=TC_TimeProvider::getInstance()->getNowMs();
        _iNum=0;
    }
    return s;*/
	ServantCallbackPtr cb = new ServantCallback("", this, current);
	_prx->rpc_call_async(_prx->taf_gen_requestid(), "", s.c_str(), s.length(), cb);
	current->setResponse(false);

	return "";
}

taf::Int32 AServantImp::testInt(taf::Int32 iIn,taf::Int32 &iOut,taf::JceCurrentPtr current)
{
    iOut = iIn;
    _iNum ++;
    if(_iNum == 100000)
    {
        LOG->debug()<<pthread_self()<<"|"<<taf::TC_TimeProvider::getInstance()->getNowMs() - _iTime <<endl;
        _iNum = 0;
        _iTime = taf::TC_TimeProvider::getInstance()->getNowMs();
    }
    return 0;
}

int AServantImp::doResponse(ReqMessagePtr resp)
{
	
	ServantCallbackPtr cb = ServantCallbackPtr::dynamicCast(resp->callback);

	string sRet;
	sRet.assign(&resp->response.sBuffer[0], resp->response.sBuffer.size());

	//LOG->debug() << "doResponse ret: " << resp->response.iRet << " | ret str: " << sRet << endl;

	Test::AServant::async_response_saysomething(cb->getCurrent(), sRet);

	return 0;
}

int AServantImp::doResponseException(ReqMessagePtr resp)
{
	LOG->debug() << "doResponseException ret: " << resp->response.iRet << endl;
	return 0;
}