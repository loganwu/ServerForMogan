#!/bin/sh

killall -9 HelloServer

#./HelloServer --config=hello2.conf &
