#!/bin/sh

killall -9 HelloServer

ulimit -c unlimited

./HelloServer --config=hello.conf &
#./HelloServer --config=hello2.conf &
