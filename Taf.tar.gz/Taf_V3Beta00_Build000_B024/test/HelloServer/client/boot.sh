#!/bin/sh

killall -9 HelloClient

ulimit -c unlimited

./HelloClient ../src/hello.conf 100 0 0
