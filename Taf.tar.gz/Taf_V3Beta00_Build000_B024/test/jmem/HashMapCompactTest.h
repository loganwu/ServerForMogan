
#include "test.h"
#include <iostream>

using namespace taf;

int startHashMapCompactTest(int argc, char* argv[]);
