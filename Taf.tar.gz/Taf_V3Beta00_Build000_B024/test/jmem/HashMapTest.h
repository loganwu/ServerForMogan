
#include "test.h"
#include <iostream>

using namespace taf;

int startHashMapTest(int argc, char* argv[]);
