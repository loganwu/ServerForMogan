
#include "test.h"
#include <iostream>

using namespace taf;
using namespace Test;

int startMultiHashMapTest(int argc, char* argv[]);
