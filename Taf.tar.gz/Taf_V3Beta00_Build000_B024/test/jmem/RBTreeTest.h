
#include "test.h"
#include <iostream>

using namespace taf;

int startRBTreeTest(int argc, char* argv[]);
