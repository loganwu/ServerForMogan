#!/bin/sh

killall -9 TransServer
