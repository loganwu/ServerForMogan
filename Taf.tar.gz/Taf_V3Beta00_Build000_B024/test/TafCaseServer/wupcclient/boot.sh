#!/bin/sh

./wupcclient --s=Java.TestCase.TafCaseServant --h=10.130.64.220  --p=12121 --w=2 --f=getUser
#./wupcclient --s=Java.TestCase.TafCaseServant --h=10.130.64.220  --p=12121 --w=3 --f=getUser

#./wupcclient --s=Java.TestCase.TafCaseServant --h=10.130.64.220  --p=12121 --w=2 --f=testUnsigned
#./wupcclient --s=Java.TestCase.TafCaseServant --h=10.130.64.220  --p=12121 --w=3 --f=testUnsigned

#./wupcclient --s=Test.TafCaseServer.TafCaseServantObj --h=172.27.205.110 --p=30000 --w=2 --f=getUser
#./wupcclient --s=Test.TafCaseServer.TafCaseServantObj --h=172.27.205.110 --p=30000 --w=3 --f=getUser

#./wupcclient --s=Test.TafCaseServer.TafCaseServantObj --h=172.27.205.110 --p=30000 --w=2 --f=testUnsigned
#./wupcclient --s=Test.TafCaseServer.TafCaseServantObj --h=172.27.205.110 --p=30000 --w=3 --f=testUnsigned