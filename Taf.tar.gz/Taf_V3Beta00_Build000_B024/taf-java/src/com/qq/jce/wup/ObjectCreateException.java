package com.qq.jce.wup;

@SuppressWarnings("serial")
public class ObjectCreateException extends RuntimeException {

	public ObjectCreateException(Exception ex) {
		super(ex);
	}

}
