package com.qq.taf.jce;



public class JceDecodeException extends RuntimeException{

	public JceDecodeException(String string) {
		super(string);
	}

}
