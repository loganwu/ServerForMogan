package com.qq.taf;

public final class ResponsePacketHolder
{
    public ResponsePacketHolder()
    {
    }
    public ResponsePacketHolder(ResponsePacket value)
    {
        this.value = value;
    }

    public ResponsePacket value;
}
