package com.qq.taf;

public final class RequestPacketHolder
{
    public RequestPacketHolder()
    {
    }
    public RequestPacketHolder(RequestPacket value)
    {
        this.value = value;
    }

    public RequestPacket value;
}
