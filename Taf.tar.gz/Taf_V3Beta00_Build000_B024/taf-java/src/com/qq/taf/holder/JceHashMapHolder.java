package com.qq.taf.holder;


public final class JceHashMapHolder 
{
    public
    JceHashMapHolder()
    {
    }

    public
    JceHashMapHolder(java.util.Map value)
    {
        this.value = value;
    }

    public java.util.Map value;

	public java.util.Map getValue() {
		return value;
	}

	public void setValue(java.util.Map value) {
		this.value = value;
	}
	

}
