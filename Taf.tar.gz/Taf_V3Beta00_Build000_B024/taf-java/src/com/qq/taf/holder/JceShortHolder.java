package com.qq.taf.holder;

public final class JceShortHolder
{
    public
    JceShortHolder()
    {
    }

    public
    JceShortHolder(short value)
    {
        this.value = value;
    }

    public short value;
}
