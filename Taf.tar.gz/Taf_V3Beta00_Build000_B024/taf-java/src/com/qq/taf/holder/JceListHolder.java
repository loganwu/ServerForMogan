package com.qq.taf.holder;

public final class JceListHolder
{
    public
    JceListHolder()
    {
    }

    public
    JceListHolder(java.util.List value)
    {
        this.value = value;
    }

    public java.util.List value;
}
