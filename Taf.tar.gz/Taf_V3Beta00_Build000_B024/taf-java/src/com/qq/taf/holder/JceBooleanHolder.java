package com.qq.taf.holder;

public final class JceBooleanHolder
{
    public
    JceBooleanHolder()
    {
    }

    public
    JceBooleanHolder(boolean value)
    {
        this.value = value;
    }

    public boolean value;
}
