package com.qq.taf.holder;

public final class JceMapHolder
{
    public
    JceMapHolder()
    {
    }

    public
    JceMapHolder(java.util.Map value)
    {
        this.value = value;
    }

    public java.util.Map value;
}
