package com.qq.taf.holder;

public final class JceIntHolder
{
    public
    JceIntHolder()
    {
    }

    public
    JceIntHolder(int value)
    {
        this.value = value;
    }

    public int value;
}
