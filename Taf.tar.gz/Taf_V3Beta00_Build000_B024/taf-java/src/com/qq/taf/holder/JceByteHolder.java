package com.qq.taf.holder;

public final class JceByteHolder
{
    public
    JceByteHolder()
    {
    }

    public
    JceByteHolder(byte value)
    {
        this.value = value;
    }

    public byte value;
}
