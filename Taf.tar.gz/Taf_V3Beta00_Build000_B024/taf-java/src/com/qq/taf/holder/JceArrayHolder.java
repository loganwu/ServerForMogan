package com.qq.taf.holder;

public final class JceArrayHolder {
	public JceArrayHolder() {
	}

	public JceArrayHolder(Object value) {
		this.value = value;
	}

	public Object value;

	public Object getValue() {
		return value;
	}
}