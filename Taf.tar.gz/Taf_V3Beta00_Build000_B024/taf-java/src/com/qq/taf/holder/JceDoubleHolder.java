package com.qq.taf.holder;

public final class JceDoubleHolder
{
    public
    JceDoubleHolder()
    {
    }

    public
    JceDoubleHolder(double value)
    {
        this.value = value;
    }

    public double value;
}
