package com.qq.taf.holder;

public final class JceLongHolder
{
    public
    JceLongHolder()
    {
    }

    public
    JceLongHolder(long value)
    {
        this.value = value;
    }

    public long value;
}
