#ifndef __H_COMPAT_DIGIT_H__
#define __H_COMPAT_DIGIT_H__

#include "realconfig.h"
#if COMPAT_GLIBC
#include <stdint.h>
#include "bitops.h"
extern const uint32_t digitmask[8];
extern const uint32_t xdigitmask[8];
extern const uint32_t alnummask[8];
extern const uint32_t spacemask[8];
#define is_digit(x)	test_bit((unsigned char)(x), digitmask)
#define is_xdigit(x)	test_bit((unsigned char)(x), xdigitmask)
#define is_alnum(x)	test_bit((unsigned char)(x), alnummask)
#define is_space(x)	test_bit((unsigned char)(x), spacemask)

#else
#include <ctype.h>
#define is_digit isdigit
#define is_xdigit isxdigit
#define is_alnum isalnum
#define is_space isspace
#endif

#endif
