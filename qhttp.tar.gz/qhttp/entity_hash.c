#include <string.h>
#include "global.h"
#include "myconfig.h"
#include "entity.h"
#include "entity_hash.h"
#include "thread.h"
#include "tsc.h"
#include "log.h"
#include "compat_thread.h"

int tsc4_fdcache __init__;
int tsc4_fdcache1 __init__;
int tsc4_fdcache_negative __init__;
int cachelockmode __init__;

int entity_expired(struct entity_hash *ent) {
	uint64_t tsc = readtsc();
	if(ent->tsc4 < TSCRND(tsc)) return -1;
	return 0;
}

/* init_fdcache_mode() {{{1 */
int init_fdcache_mode(void) {
	if(sizeof(struct fdentity) > sizeof(struct fdinfo)) {
		lprintf("FIXME: bad sizeof(struct fdentity)\n");
		return -1;
	}

	fdcache_max = mconns;
	tsc4_fdcache = myconfig_get_intval("fdcache_timeout", 300);
	if(tsc4_fdcache > 0) {
	    tsc4_fdcache1 = SECRND(tsc4_fdcache+60);
	    tsc4_fdcache = SECRND(tsc4_fdcache);
	    tsc4_fdcache_negative = myconfig_get_intval("fdcache_negative_timeout", 0);
	    tsc4_fdcache_negative = SECRND(tsc4_fdcache_negative);

	    if(nworks==1) {
	    	cachelockmode = CLM_SINGLE;	// single thread, no lock needed
	    } else {
		    const char *p = myconfig_get_value("fdcache_lock_mode");
		    if(p==NULL)
                // Ϊʲô������������nworks>=1�أ�CLM_SINGLE��CLM_LOCKLESS��ʲô����
			    cachelockmode = nworks >= 10 ? CLM_GLOBAL : CLM_LOCKLESS;
		    else if(!strcasecmp(p, "globallock") || !strcasecmp(p, "global"))
		        cachelockmode = CLM_GLOBAL;
		    else if(!strcasecmp(p, "futex"))
		        cachelockmode = has_futex>0 ? CLM_FUTEX : CLM_GLOBAL;
		    else if(!strcasecmp(p, "mutex"))
		        cachelockmode = CLM_MUTEX;
		    else if(!strcasecmp(p, "sysvsem"))
		        cachelockmode = CLM_SYSVSEM;
		    else if(!strcasecmp(p, "lockless") && nconns >= 100)
		        cachelockmode = CLM_LOCKLESS;
		    else
		        cachelockmode = nworks >= 10 ? CLM_GLOBAL : CLM_LOCKLESS;
	    }
	    if(cachelockmode==CLM_GLOBAL)
	    	cachelockmode = (threadmode&CLONE_THREAD) ? CLM_MUTEX :
			(has_futex > 0) ? CLM_FUTEX : CLM_SYSVSEM;
	    lprintf("fdcache lock mode: %s\n",
	    	((const char *[]) {
			"lockless",
			"global",
			"singlethread",
			"futex",
			"mutex",
			"sysvsem",
		})[cachelockmode]
	    );

        lprintf("fdcache_max is %d", fdcache_max);
        lprintf("fdcache_timeout/tsc4_fdcache is %d", tsc4_fdcache);        
        lprintf("fdcache_negative_timeout/tsc4_fdcache_negative is %d", tsc4_fdcache_negative);
	    return cachelockmode==CLM_LOCKLESS ? init_fdcache_mode_lockless() : init_fdcache_mode_global();
	}

	tsc4_fdcache = 0;
    lprintf("fdcache_max is %d", fdcache_max);
    lprintf("fdcache_timeout/tsc4_fdcache is %d", tsc4_fdcache);        
    lprintf("fdcache_negative_timeout/tsc4_fdcache_negative is %d", tsc4_fdcache_negative);
	return 0;
}

