
#if PLUGIN_SUPPORT
	extern void set_worker_key(struct worker *);
	set_worker_key(wt);
#endif
	int i, n, tail;
	struct epoll_event *pev = wt->pev;

	if(pev==NULL) pev = alloca(sizeof(struct epoll_event)*nepoll_events);

	pev->events = POLLIN|EPOLLET;
	pev->data.fd = 0;
	fast_epoll_ctl(wt->epfd, EPOLL_CTL_ADD, wt->epwait, pev);
	fast_write(wt->epwake, wt->workbuf, 4);

#if PROFILE_SUPPORT
	init_poll(wt);
#endif
	wt->thst = get_threadstat();

	while(!stop) {
#if PROFILE_SUPPORT
	    before_poll(wt);
#endif
	    if(loopdelay) {
		struct timespec tv;
		tv.tv_sec = 0;
		tv.tv_nsec = loopdelay;
		fast_nanosleep(&tv, &tv);
	    }
	    n = fast_epoll_wait(wt->epfd, pev, nepoll_events, calc_poll_timeout(wt));
	    thread_reached(wt->thst);
#if PROFILE_SUPPORT
	    after_poll(wt);
#endif
	    check_timestamp(wt);
	    /* process incoming first, prevent io collision */
	    for(i=0; i<n; i++) {
		if(pev[i].events == POLLIN && pev[i].data.fd==0) {
		    pev[i].events = 0;
		    fast_read(wt->epwait, wt->workbuf, workbufsz);
		}
	    }
	    tail = wt->inc_tail;
	    while(wt->inc_pend != tail) {
		/* new incoming */
		thread_reached(wt->thst);
		GET_LIST_ITEM(i, wt->inc_list, wt->inc_pend, nconns1);
#if WORKER_METHOD==0
		init_connection(wt, i);
		resume_http_connection(i, check_events(i, POLLIN));
#else
        if(try_init_connection(wt, i)==NULL) {        
		    ISDSTAT(atomic_dec(&countermap->workcon));
        }
		else {
		    resume_http_connection(i, check_events(i, POLLIN));
		}
#endif
	    }
	    for(i=0; i<n; i++) {
		if(pev[i].events != POLLIN) continue;
		thread_reached(wt->thst);
		pev[i].events = 0;
		resume_connection(wt, pev[i].data.fd, POLLIN);
	    }
	    for(i=0; i<n; i++) {
		if(pev[i].events == 0) continue;
		thread_reached(wt->thst);
		resume_connection(wt, pev[i].data.fd, pev[i].events);
	    }
	    check_pending(wt);
#if WORKER_METHOD==0
	    check_idle_switch(wt);
#else
	    check_direct_idle_switch(wt);
#endif
	    check_timeout(wt);
#if WORKER_METHOD
	    check_idle_timeout(wt);
#endif
	}
	return 0;

#undef WORKER_METHOD
