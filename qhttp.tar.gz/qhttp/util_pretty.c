#include <stdio.h>

//static char *int2str(char *, unsigned int) __attribute__((unused));

#define inline /* */
#include "util.h"

static char *prettyU(char *buf, uint32_t i, char *unit) {
	static char sbuf[30];
	char *p;
	int n;
	char sign[2], nc;

	if(buf==NULL)
		buf = sbuf;
	p=buf+2;
	sign[0]='\0';
	sign[1]='\0';

	buf[0] = ' ';
	buf[1] = '(';
	n = i >> 30;
	i -= n<<30;

	if((i & 0x3FF00000) == 0x3FF00000 || (i&0x380FFFFF) == 0x38000000) {
		n++;
		i = (1<<30)-i;
		nc = '-';
	} else
		nc = '+';
	if(n) {
		p = uint2str(p, n);
		*p++ = unit[0]; /* G */
		sign[0] = nc;
	}

	if(i==0) goto out;
	n = i >> 20;
	i -= n<<20;

	if((i & 0xFFC00) == 0xFFC00 || (i&0xE03FF) == 0xE0000) {
		n++;
		i = (1<<20)-i;
		nc = nc=='-'?'+':'-';
	} else if(nc!='-')
		nc = '+';

	if(n) {
		if(sign[0]) *p++ = sign[0];
		p = uint2str(p, n);
		*p++ = unit[1]; /* M */
		sign[0]=nc;
	}
	if(i==0) goto out;
	n = i >> 10;
	i -= n<<10;

	if((i&0x380) == 0x380) {
		n++;
		i = (1<<10)-i;
		nc = nc=='-'?'+':'-';
	} else if(nc!='-')
		nc = '+';

	if(n) {
		if(sign[0]) *p++ = sign[0];
		p = uint2str(p, n);
		*p++ = unit[2]; /* K */
		sign[0]=nc;
	}
	if(i==0 || p==buf+2) goto out;
	*p++ = sign[0];
	p = uint2str(p, i);
out:
	if(p==buf+2) {
		buf[0] = '\0';
	} else {
		if(unit[3])
			*p++ = unit[3];
		*p++ = ')';
		*p = '\0';
	}
	return buf;
}

char *pretty_r(char *buf, uint32_t i) {
	return prettyU(buf, i, "GMK");
}

char *prettyK_r(char *buf, uint32_t i) {
	return prettyU(buf, i, "TGMK");
}

char *pretty(uint32_t i) {
	return prettyU(NULL, i, "GMK");
}

char *prettyK(uint32_t i) {
	return prettyU(NULL, i, "TGMK");
}

char *int2hex(char *buf, uint32_t val) {
	buf[0] = "0123456789ABCDEF"[ (val>>28) & 0xf ];
	buf[1] = "0123456789ABCDEF"[ (val>>24) & 0xf ];
	buf[2] = "0123456789ABCDEF"[ (val>>20) & 0xf ];
	buf[3] = "0123456789ABCDEF"[ (val>>16) & 0xf ];
	buf[4] = "0123456789ABCDEF"[ (val>>12) & 0xf ];
	buf[5] = "0123456789ABCDEF"[ (val>> 8) & 0xf ];
	buf[6] = "0123456789ABCDEF"[ (val>> 4) & 0xf ];
	buf[7] = "0123456789ABCDEF"[ (val    ) & 0xf ];
	return buf+8;
}
