#ifndef _H_FAST_SYSCALL_H
#define _H_FAST_SYSCALL_H
#include <stdint.h>
#include <sys/stat.h>
#include <sys/signal.h>
#include <sys/socket.h>
#include <time.h>
#include <string.h>
#include "syscall.h"

#ifdef __x86_64__
#define __syscall_entry	"syscall"
#define __syscall_clobber "r11","rcx","memory" 
#define __syscall_arg1(arg1)	"D" ((long)(arg1))
#define __syscall_arg2(arg2)	"S" ((long)(arg2))
#define __syscall_arg3(arg3)	"d" ((long)(arg3))
#define __syscall_mov4	"movq %5,%%r10 ;"
#define __syscall_arg4(arg4)	"g" ((long)(arg4))
#define __syscall_reg4	,"r10"
#define __syscall_mov5	"movq %5,%%r10 ; movq %6,%%r8 ; "
#define __syscall_arg5(arg5)	"g" ((long)(arg5))
#define __syscall_reg5	,"r8","r10"
#define __syscall_mov6	"movq %5,%%r10 ; movq %6,%%r8 ; movq %7,%%r9 ; "
#define __syscall_pop6	""
#define __syscall_idx6	"0"
#define __syscall_arg6(arg6)	"g" ((long)(arg6))
#define __syscall_reg6	,"r8","r10","r9"
#else

#define __syscall_entry	"call *linuxgate"
#define __syscall_clobber "memory" 
#define __syscall_arg1(arg1)	"b" ((long)(arg1))
#define __syscall_arg2(arg2)	"c" ((long)(arg2))
#define __syscall_arg3(arg3)	"d" ((long)(arg3))
#define __syscall_mov4	""
#define __syscall_arg4(arg4)	"S" ((long)(arg4))
#define __syscall_reg4	/* */
#define __syscall_mov5	""
#define __syscall_arg5(arg5)	"D" ((long)(arg5))
#define __syscall_reg5	/* */
#define __syscall_mov6	"push %%ebp ; movl %%eax,%%ebp ; movl %1,%%eax ; "
#define __syscall_pop6	"; pop %%ebp"
#define __syscall_idx6	"i"
#define __syscall_arg6(arg6)	"0" ((long)(arg6))
#define __syscall_reg6	/* */
#endif

#define fast_syscall0(type,name) \
static inline type fast_##name(void) \
{ \
long __res; \
__asm__ volatile ( __syscall_entry \
	: "=a" (__res) \
	: "0" (__NR_##name) \
	: __syscall_clobber); \
return (type)__res; \
}

#define fast_syscall1(type,name,type1,arg1) \
static inline type fast_##name(type1 arg1) \
{ \
long __res; \
__asm__ volatile ( __syscall_entry \
	: "=a" (__res) : "0" (__NR_##name), \
	  __syscall_arg1(arg1) \
	: __syscall_clobber); \
return (type)__res; \
}

#define fast_syscall2(type,name,type1,arg1,type2,arg2) \
static inline type fast_##name(type1 arg1,type2 arg2) \
{ \
long __res; \
__asm__ volatile ( __syscall_entry \
	: "=a" (__res) : "0" (__NR_##name), \
	  __syscall_arg1(arg1), \
	  __syscall_arg2(arg2) \
	: __syscall_clobber); \
return (type)__res; \
}

#define fast_syscall3(type,name,type1,arg1,type2,arg2,type3,arg3) \
static inline type fast_##name(type1 arg1,type2 arg2,type3 arg3) \
{ \
long __res; \
__asm__ volatile ( __syscall_entry \
	: "=a" (__res) : "0" (__NR_##name), \
	  __syscall_arg1(arg1), \
	  __syscall_arg2(arg2), \
	  __syscall_arg3(arg3) \
	: __syscall_clobber); \
return (type)__res; \
}

#define fast_syscall4(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4) \
static inline type fast_##name (type1 arg1, type2 arg2, type3 arg3, type4 arg4) \
{ \
long __res; \
__asm__ volatile ( __syscall_mov4 __syscall_entry \
	: "=a" (__res) : "0" (__NR_##name), \
	  __syscall_arg1(arg1), \
	  __syscall_arg2(arg2), \
	  __syscall_arg3(arg3), \
	  __syscall_arg4(arg4) \
	: __syscall_clobber __syscall_reg4); \
return (type)__res; \
} 

#define fast_syscall4_2(type,name,type1,arg1,type2,arg2,type3,arg3) \
static inline type fast_##name (type1 arg1, type2 arg2, type3 arg3) \
{ \
long __res; \
__asm__ volatile ( __syscall_entry : "=a" (__res) \
	: "0" (__NR_##name),"b" ((long)(arg1)), \
	  __syscall_arg1(arg1), \
          __syscall_arg2(*(long *)&arg2), \
          __syscall_arg3(((long *)&arg2)[1]), \
	  __syscall_arg4(arg3) \
	: __syscall_clobber __syscall_reg4); \
return (type)__res; \
} 

#define fast_syscall5(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4, \
	  type5,arg5) \
static inline type fast_##name (type1 arg1,type2 arg2,type3 arg3,type4 arg4,type5 arg5) \
{ \
long __res; \
__asm__ volatile ( __syscall_mov5 __syscall_entry \
	: "=a" (__res) : "0" (__NR_##name), \
	  __syscall_arg1(arg1), \
	  __syscall_arg2(arg2), \
	  __syscall_arg3(arg3), \
	  __syscall_arg4(arg4), \
	  __syscall_arg5(arg5) \
	: __syscall_clobber __syscall_reg5); \
return (type)__res; \
}

#define fast_syscall5_4(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4) \
static inline type fast_##name (type1 arg1,type2 arg2,type3 arg3,type4 arg4) \
{ \
long __res; \
__asm__ volatile ( __syscall_entry \
	: "=a" (__res) : "0" (__NR_##name), \
	  __syscall_arg1(arg1), \
	  __syscall_arg2(arg2), \
	  __syscall_arg3(arg3), \
	  __syscall_arg4(*(long *)&arg4), \
	  __syscall_arg5(((long *)&arg4)[1]) \
	: __syscall_clobber); \
return (type)__res; \
}

#define fast_syscall6(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4, \
	  type5,arg5,type6,arg6) \
static inline type fast_##name (type1 arg1,type2 arg2,type3 arg3,type4 arg4,type5 arg5,type6 arg6) \
{ \
long __res; \
__asm__ volatile ( \
	__syscall_mov6 __syscall_entry __syscall_pop6 \
	: "=a" (__res) : __syscall_idx6 (__NR_##name), \
	  __syscall_arg1(arg1), \
	  __syscall_arg2(arg2), \
	  __syscall_arg3(arg3), \
	  __syscall_arg4(arg4), \
	  __syscall_arg5(arg5), \
	  __syscall_arg6(arg6) \
	: __syscall_clobber __syscall_reg6); \
return (type)__res; \
}


fast_syscall0(int, setsid);
fast_syscall0(int, getpid);
fast_syscall0(int, getppid);
fast_syscall1(int, getpgid, int, pid);
fast_syscall0(int, gettid);
#ifdef __NR_getuid32
fast_syscall0(int, getuid32);
fast_syscall0(int, getgid32);
fast_syscall0(int, geteuid32);
fast_syscall0(int, getegid32);
fast_syscall3(int, getresuid32, uid_t *, ruid, uid_t *, euid, uid_t *, suid);
fast_syscall3(int, getresgid32, gid_t *, ruid, gid_t *, euid, gid_t *, suid);
fast_syscall3(int, setresuid32, uid_t, ruid, uid_t, euid, uid_t, suid);
fast_syscall3(int, setresgid32, gid_t, ruid, gid_t, euid, gid_t, suid);
fast_syscall2(int, setgroups32, gid_t, ng, gid_t *, gs);
fast_syscall1(int, setfsuid32, uid_t, uid);
fast_syscall1(int, setfsgid32, gid_t, uid);
#define fast_getuid fast_getuid32
#define fast_getgid fast_getgid32
#define fast_geteuid fast_geteuid32
#define fast_getegid fast_getegid32
#define fast_getresuid fast_getresuid32
#define fast_getresgid fast_getresgid32
#define fast_setresuid fast_setresuid32
#define fast_setresgid fast_setresgid32
#define fast_setgroups fast_setgroups32
#define fast_setfsuid fast_setfsuid32
#define fast_getfsuid fast_getfsuid32
#else
fast_syscall0(int, getuid);
fast_syscall0(int, getgid);
fast_syscall0(int, geteuid);
fast_syscall0(int, getegid);
fast_syscall3(int, getresuid, uid_t *, ruid, uid_t *, euid, uid_t *, suid);
fast_syscall3(int, getresgid, gid_t *, ruid, gid_t *, euid, gid_t *, suid);
fast_syscall3(int, setresuid, uid_t, ruid, uid_t, euid, uid_t, suid);
fast_syscall3(int, setresgid, gid_t, ruid, gid_t, euid, gid_t, suid);
fast_syscall2(int, setgroups, int, ng, gid_t *, gs);
fast_syscall1(int, setfsuid, uid_t, uid);
fast_syscall1(int, setfsgid, gid_t, uid);
#endif

#define __NR_time0 __NR_time
#if __x86_64__
#define fast_time0 time
#else
fast_syscall1(int, time0, time_t *, ptr);
#endif
static inline int fast_time(void) { return fast_time0(0); }
#if __x86_64__
#define fast_gettimeofday time
#else
fast_syscall2(int, gettimeofday, struct timeval *, tv, void *, tz);
#endif
fast_syscall1(int, fchdir, int, fd);
fast_syscall1(int, chdir, const char *, fn);
fast_syscall1(int, chroot, const char *, fn);
fast_syscall2(int, capget, void *, header, void *, data);
fast_syscall2(int, capset, void *, header, void *, data);
fast_syscall1(int, exit, int, status);
fast_syscall1(int, exit_group, int, status);
fast_syscall1(int, unshare, int, flags);
struct rlimit;
fast_syscall2(int, getrlimit, int, res, struct rlimit *, lim);
fast_syscall2(int, setrlimit, int, res, struct rlimit *, lim);
fast_syscall2(int, clone, int, flag, void *, stack);
fast_syscall2(int, nanosleep, const struct timespec *, tv1, struct timespec *, tv2);
#define __NR_open2	__NR_open
fast_syscall2(int, open2, const char *, fn, int, flags);
fast_syscall3(int, open, const char *, fn, int, flags, int, mode);
#define __NR_openat3	__NR_openat
fast_syscall3(int, openat3, int, fd, const char *, fn, int, flags);
fast_syscall4(int, openat, int, fd, const char *, fn, int, flags, int, mode);
#define __NR_fcntl2	__NR_fcntl
fast_syscall2(int, fcntl2, int, fd, int, op);
fast_syscall3(int, fcntl, int, fd, int, op, long, arg);
#if __WORDSIZE==64
#define __NR_filestat	__NR_fstat
#else
#define __NR_filestat	__NR_fstat64
#endif
fast_syscall2(int, filestat, int, fd, stat64_t *, st);
#if __WORDSIZE==64
#define __NR_linkstat	__NR_lstat
#else
#define __NR_linkstat	__NR_lstat64
#endif
fast_syscall2(int, linkstat, const char *, fn, stat64_t *, st);
#if __WORDSIZE==64
#define __NR_stat64 __NR_stat
#endif
fast_syscall2(int, stat64, const char *, fn, stat64_t *, st);
fast_syscall3(int, readlink, const char *, fn, char *, buf, int, len);
fast_syscall2(int, link, const char *, src, const char *, dst);
fast_syscall1(int, unlink, const char *, fn);
#if __NR_lseek64
fast_syscall3(int, lseek64, int, fd, int, off, int, whence);
#define fast_seek_start(fd) fast_lseek64(fd, 0, SEEK_SET)
#define fast_file_size(fd) fast_lseek64(fd, 0, SEEK_END)
#else
fast_syscall3(int, lseek, int, fd, int, off, int, whence);
#define fast_seek_start(fd) fast_lseek(fd, 0, SEEK_SET)
#define fast_file_size(fd) fast_lseek(fd, 0, SEEK_END)
#endif
fast_syscall1(int, close, int, fd);
fast_syscall3(int, read, int, fd, char *, buf, int, len);
#ifndef __NR_pread
#ifdef __NR_pread64
#define __NR_pread __NR_pread64
#endif
#endif
fast_syscall3(int, write, int, fd, const char *, buf, int, len);
fast_syscall3(int, writev, int, fd, const void *, v, int, c);
fast_syscall4(int, vmsplice, int, fd, const void *, v, int, n, int, flags);
fast_syscall6(int, splice, int, ofd, off64_t, *oof, int, ifd, off64_t, *iof, int, len, int, flags);
fast_syscall5_4(int, pread, int, fd, char *, buf, int, len, long long, offh);
fast_syscall4(int, sendfile, int, tfd, int, sfd, off_t *, off, int, size);
fast_syscall4(int, sendfile64, int, tfd, int, sfd, off64_t *, off, int, size);
fast_syscall3(int, poll, void *, pfds, int, n, int, timeout);

struct epoll_event;
fast_syscall1(int, epoll_create, int, maxfds);
fast_syscall4(int, epoll_wait, int, fd, struct epoll_event *, ev, int, maxevents, int, timeout);
fast_syscall4(int, epoll_ctl, int, epfd, int, op, int, fd, struct epoll_event *, ev);
fast_syscall2(int, tkill, int, tid, int, signo);
fast_syscall3(int, tgkill, int, tgid, int, tid, int, signo);
fast_syscall1(int, set_tid_address, int *, tidptr);

#if !__x86_64__
#define __NR_ipc4 __NR_ipc
#define __NR_ipc5 __NR_ipc
fast_syscall4(int, ipc4, int, op, int, id, int, size, int, flag);
fast_syscall5(int, ipc5, int, op, int, id, int, ctl, int, a3, void *, ds);
#endif

#if __x86_64__
fast_syscall3(int, socket, int, af, int, type, int, prot);
fast_syscall4(int, socketpair, int, af, int, type, int, prot, int *, fd);
fast_syscall3(int, bind, int, fd, const void *, buf, int, len);
fast_syscall3(int, connect, int, fd, const void *, buf, int, len);
fast_syscall3(int, accept, int, fd, void *, buf, unsigned *, len);
fast_syscall3(int, getpeername, int, fd, void *, buf, unsigned *, len);
fast_syscall3(int, getsockname, int, fd, void *, buf, unsigned *, len);
fast_syscall2(int, listen, int, fd, int, len);
fast_syscall2(int, shutdown, int, fd, int, flag);
fast_syscall3(int, recvmsg, int, fd, void *, buf, int, flags);
fast_syscall3(int, sendmsg, int, fd, const void *, buf, int, flags);
fast_syscall5(int, setsockopt, int, fd, int, l, int, opt, const void *, buf, socklen_t, len);
fast_syscall5(int, getsockopt, int, fd, int, l, int, opt, void *, buf, socklen_t *, len);
#define fast_send send
#define fast_recv recv
#else
fast_syscall2(int, socketcall, int, call, void *, arg);
#include "compat_socketcall.h"
#endif

#define __NR_futex4 __NR_futex
fast_syscall3(int, futex,  uint32_t *, p, int, o, int, v);
fast_syscall4(int, futex4, uint32_t *, p, int, o, int, v, void *, t);

fast_syscall0(int, inotify_init);
fast_syscall3(int, inotify_add_watch, int, fd, const char *, path, int, mask);

#endif

