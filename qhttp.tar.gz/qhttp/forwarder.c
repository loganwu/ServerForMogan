#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "qhttpd_api.h"
#include "util.h"
#define create_pattern _create_pattern
#define add_prefix_pattern _add_prefix_pattern
#define add_suffix_pattern _add_suffix_pattern
#define add_pattern _add_pattern
#define match_url_pattern _match_url_pattern
#define match_pattern _match_pattern
#include "pattern.h"

static int filter_forward(cbdata_t *cb) {
	void *g;
	struct pattern *pat = cb->priv;

	g = match_url_pattern(pat, cb->url, NULL);
	if(g==NULL) return RC_CONTINUE;

	cb->ftarget = g;
	return RF_FORWARD_GROUP;
}

void plugin_load(int argc, const char *const*argv){
	struct pattern *pat;
	int i, j, n;
	const char *p0;
	char *field[100];
	void *g;
	const char *name;
	char *key;
	char *p = NULL;

	name = getparam(argv, "name");
	if(name==NULL) {
		name = getparam(argv, "host");
		if(name==NULL)
			name = "@default";
	}
	key = alloca(strlen(name)+20);
	pat = create_pattern();

	sprintf(key, "forward_%s_prefix", name);
	for(i=0; (p0=myconfig_get_multivalue(key, i)); i++) {
		if(p) free(p);
		p = strdup(p0);
		if((n = str_explode(NULL, p, field, 100)) < 2) continue;
		if(!strcmp(field[0], "@local"))
			g = NULL;
		else if((g = find_forward_group(field[0]))==NULL) {
			lprintf("forward group %s not found\n", field[0]);
			continue;
		}
		for(j=1; j<n; j++)
			add_prefix_pattern(pat, shdup(field[j]), g);
	}

	sprintf(key, "forward_%s_suffix", name);
	for(i=0; (p0=myconfig_get_multivalue(key, i)); i++) {
		if(p) free(p);
		p = strdup(p0);
		if((n = str_explode(NULL, p, field, 100)) < 2) continue;
		if(!strcmp(field[0], "@local"))
			g = NULL;
		else if((g = find_forward_group(field[0]))==NULL) {
			lprintf("forward group %s not found\n", field[0]);
			continue;
		}

		for(j=1; j<n; j++)
			add_suffix_pattern(pat, shdup(field[j]), g);
	}

	sprintf(key, "forward_%s_pattern", name);
	for(i=0; (p0=myconfig_get_multivalue(key, i)); i++) {
		if(p) free(p);
		p = strdup(p0);
		if((n = str_explode(NULL, p, field, 100)) < 2) continue;
		if(!strcmp(field[0], "@local"))
			g = NULL;
		else if((g = find_forward_group(field[0]))==NULL) {
			lprintf("forward group %s not found\n", field[0]);
			continue;
		}

		for(j=1; j<n; j++)
			add_pattern(pat, shdup(field[j]), g);
	}
	if(p) free(p);

	register_url_filter(
			getparam(argv, "host"), 0,
			filter_forward, (void *)pat
			);
}

