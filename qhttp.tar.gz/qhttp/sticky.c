/* vim: set sw=4 ai :*/
#include "realconfig.h"
#if RELAY_SUPPORT

#include "myalloc.h"
#include "group.h"

struct sticky {
};

struct sticky *new_sticky_table(int maxcount) {
	return NULL;
}

void *get_sticky(struct sticky *st, uint32_t addr) {
	return NULL;
}

void set_sticky(struct sticky *st, uint32_t addr, void *target) {
}

void prune_sticky(struct sticky *st, void *target) {
}

void free_sticky(struct sticky *st) {
	free(st);
}

#endif
