#include "myalloc.h"
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>

#include "autoconfig.h"
#include "compat_sysvipc.h"
#include "lock.h"

void send_semkey_to_watchdog(int key);
void remove_semkey_from_watchdog(int key);

static int sem_array_lock(mutex_t *m, int i) {
	int id = *(int *)(m+1);
	struct sembuf sb = { i, -1, 0 };
	int rv;

	do {
	    rv = fast_semop(id, &sb, 1);
	} while (rv<0 && errno==EINTR);
	return rv<0?errno:0;
}

static int sem_array_unlock(mutex_t *m, int i) {
	int id = *(int *)(m+1);
	struct sembuf sb = { i, 1, 0 };
	int rv = fast_semop(id, &sb, 1);
	return rv<0?errno:0;
}

static int sem_array_trylock(mutex_t *m, int i) {
	int id = *(int *)(m+1);
	struct sembuf sb = { i, -1, IPC_NOWAIT };
	int rv = fast_semop(id, &sb, 1);
	return rv<0?errno:0;
}

static void sem_array_destroy(mutex_t *m) {
	int id = *(int *)(m+1);
	remove_semkey_from_watchdog(id);
	fast_semctl(id, 0, IPC_RMID, NULL);
	free(m);
}

mutex_t *CreateSysVSem(int n) {
	mutex_t *m = malloc(sizeof(mutex_t)+sizeof(int));
	if(m==NULL) {
		return NULL;
	}
	int *idptr = (int *)(m+1);

	*idptr = fast_semget(IPC_PRIVATE, n, IPC_CREAT|0666);
	if(*idptr < 0) {
		free(m);
		return NULL;
	}

	send_semkey_to_watchdog(*idptr);

	int i;
	for(i=0; i<n; i++) {
	    struct sembuf sb = { i, 1, 0 };
	    fast_semop(*idptr, &sb, 1);
	}
	m->lock = sem_array_lock;
	m->unlock = sem_array_unlock;
	m->trylock = sem_array_trylock;
	m->destroy = sem_array_destroy;

	return m;
}

