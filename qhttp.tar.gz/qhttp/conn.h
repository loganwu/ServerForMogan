#ifndef _H_CONN_H_
#define _H_CONN_H_

#include <stdio.h>
#include <fcntl.h>
#include <sys/poll.h>
#include "compat_epoll.h"

#include "list.h"
#include "atomic.h"
#include "autoconfig.h"
#if PROFILE_SUPPORT
#include "profile.h"
#endif

#define POLL_DEFER_ACCEPT (-1)

/*
 * only forward urlencoded, form-data, xml(w/o charset) content
 * 3 bits used, 3 states remain
 */
enum {
	POST_NONE = 0,
	POST_URLENCODED,
	POST_XML,
	POST_FORMDATA,
	POST_OTHER,
};

/*
 * HTTP method supported
 * 2 bits used, 1 state remain
 */
enum {
	METHOD_GET = 0,
	METHOD_HEAD,
	METHOD_POST,
};

/*
 * working slot state
 * 3 bits used, 2 state remain
 */
enum {
	CS_WAIT_REQUEST = 0,	/* waiting new request */
	CS_PARSE_REQUEST,		/* parseing request */
	CS_FLUSH_DATA,		/* transmit data */
	CS_PARTIAL_COOKIE,		/* long (unended) cookie */
	CS_AFTER_COOKIE,		/* cookie parsed, check LWS */
	CSR_FORWARD,		/* forwarding */
	CS_TOTAL_STATES
};

/*
 * IMS type
 * 2 bits used
 */
enum {
	NO_IMS = 0,		/* NO timestamp checking */
	IMS,		/* If-Modified-Since */
	IUMS,		/* If-Unmodified-Since */
	IR			/* If-Range */
};

/*
 * cache control
 * 2 bits used, 1 state remain
 */
enum {
	CACHE_PUBLIC = 0,
	CACHE_PRIVATE,
	CACHE_NOCACHE
};

/*
 * client2server forward
 * 3 bits used
 */
enum {
	REQ_HEADER = 0,
	REQ_PASS,
	REQ_CLEN,
	REQ_CLEN1,
	REQ_POST,
	REQ_TRAILER,
	REQ_PARSED,
	REQ_FORWARDED,
	REQ_TOTAL_STATES
};

/*
 * server2client forward
 * 3 bits used
 */
enum {
	REPLY_STATUS = 0,
	REPLY_HEADER,
	REPLY_PASS,
	REPLY_CLEN,
	REPLY_DATA,
	REPLY_TRAILER,
	REPLY_PARSED,
	REPLY_FORWARDED,
	REPLY_TOTAL_STATES
};

#define VH_NOLOG	1
#define VH_DISABLED	2
#define VH_DEFAULT	0x40
#define VH_UPDATED	0x80

struct worker;
struct vhost;
struct cookie;
struct group;
#if PLUGIN_SUPPORT
struct filtercb;
#endif
struct tfcinfo;
struct threadstat;

struct vhost {
	struct vhost *vhost;
	volatile int logfd;
	atomic_t req;
#if HAS_ATOMIC8
	atomic8_t bytes;
#else
	atomic_t kbytes;
	atomic_t bytes;
#endif
#if PLUGIN_SUPPORT
	struct filtercb *plugin;
#endif
	int statid;
	volatile unsigned char flag;
	char name[0];
} __align1__;

typedef void (*resumeproc_t)(int, int);

struct baseconn {
#if TRACE_FD
	char name[16];
#endif
	struct worker *thread;
	resumeproc_t proc;
	int netfd;
} __align4__;

struct conn {          
	union {
		struct baseconn baseconn;
		struct {
#if TRACE_FD
			char name[16];
#endif
			struct worker *thread;
			resumeproc_t proc;
			int netfd;
			int postsize; // for 64 bit align
		};
	};

	char *url;
	char *host;
	//union {
		struct vhost *vhost;
		struct conn *freenext; /* free slot */
	//};
#if COOKIE_SUPPORT
	char *cookie;
	char *cookiestr;
#endif
	union {
		struct {
			unsigned char pending:1;
			unsigned char tcpcork:1;
			unsigned char state:3;
			unsigned char method:2;
			unsigned char no_header:1;
			/* bit 8 */
			unsigned char ims:2;
			unsigned char cachemode:2;
			unsigned char long_line:1;
			unsigned char http_v11:1;
			unsigned char header_parsed:1;
			unsigned char referer_checked:1;
			/* bit 16 */
			unsigned char keepalive:1;
			unsigned char keepalive_header:1;
			unsigned char keepalive_off:1;
			unsigned char has_ct:1;
			unsigned char has_cl:1;
			unsigned char has_chunked:1;
			unsigned char gzippable:1;
			unsigned char gzipped:1;
			/* bit 24 */
			unsigned char suspend:1;
			unsigned char relaymode:1;
			unsigned char qvia:1;
			unsigned char resume:1;
			unsigned char expect100:1;
			unsigned char urloverwriten:1;
			unsigned char flag:2; /* 2 bits remain */
		};
		struct {
			unsigned char flag_kox:2;
			unsigned int  flag_zero:30;
		};
		unsigned int flag_all;
	};

	int16_t events;
	uint16_t sendcode;

	char *recvbuf;
	char *sendbuf;
	uint16_t recvptr;
	uint16_t recvlen;
	uint16_t sendptr;
	uint16_t sendlen;

	off64_t logsize;
	uint64_t tsc_io /*__align8__*/;
	struct list_head timer_io;
#if IOPERF_SUPPORT
	uint64_t iowait;
#endif
#if PROFILE_SUPPORT
	uint64_t profiletsc;
#endif

#if !DEBUG_RELAY
	union {
#endif
	struct {
		/* for http connection */
		off64_t range_start;
		off64_t range_last;
		union {
			off64_t sendfd_start;
			struct iovec *sendiov;
		};
		off64_t sendfd_end;
#if THROTTLE_SUPPORT
		uint64_t send_tsc __align8__;
#endif
		int32_t sendfd;
		int32_t expire;
		void *entity;
		struct list_head timer_req;
		time_t imstime;
		uint32_t tsc4_req;
#if THROTTLE_SUPPORT
		uint16_t speed;
#endif
	};
#if DEBUG_RELAY
	union {
#endif
#if RELAY_SUPPORT
	struct baseconn relayconn;
	struct {
		/* for relay connection */
#if TRACE_FD
		char relayname[16];
#endif
		struct worker *thread1;
		resumeproc_t relayproc;
		int relayfd;
		int16_t relayevents;
		union {
			uint16_t relayflag_all;
			struct {
				unsigned char pass_mode:3;
				unsigned char reply_mode:3;
				unsigned char reply_has_content:1;
				unsigned char reply_has_length:1;
				/* bit 8 */
				unsigned char relay_retry:3;
				unsigned char reply_long_line:1;
				unsigned char reply_chunked:1;
				unsigned char relay_flag:3; /* 3 bits remain */
			};
		};

		off64_t replysize;
		struct forward_target *ftarget;
		uint16_t recvcnt;
		uint16_t sendcnt;
		int cachefd;
		off_t cachefd_start;
		off_t cachefd_end;
		struct group *fgroup;
	};
#endif
	};

    // ***BEGIN*** Added by yijian    
    int deep;
    int netfd_old;
    void* group;
    void* target; 
    struct forward_target *ftarget_old;
    // ***BEGIN*** Added by yijian for cache on 2008-01-23    
    int proxyfd;
    int need_relay;
    int relay_zipped;
    int compress_flag;
    int compress_arithmetic;    
    off64_t cachedsize;
    off64_t cachedoffset;
    // ***END*** Added by yijian for cache on 2008-01-23
    // ***END*** Added by yijian
} __align__;

struct worker {
	struct baseconn idleconn;
	struct conn *conn;
	struct conn *freeconn;
	struct conn *workconn;
	struct threadstat *thst;
	char *workbuf;
	char *fnbuf;
	char *aclbuf;
	struct tfcinfo *tfc;

	int *inc_list;
	volatile int inc_head;
	volatile int inc_tail;
	volatile int inc_pend;
	int inc_negative;
	uint16_t id;
	char datestr[30];
	time_t ts_date;

	union {
		struct {
			/* for epoll */
			struct epoll_event *pev;
			int epfd;
			int epwake;
			int epwait;
		};
#if WITH_RTSIG
		struct {
			/* for rtsig */
			struct pollfd *pfd;
			int mypid;
			int nextpid;
		};
#endif
		/* for dynamic */
		struct pollfd pfd0[2];
	};

	/* for direct_idle, not for dynamic */
	struct list_head idle_list;
	int idle_cnt;

#if THROTTLE_SUPPORT
	int tsc01;
#endif
#if THROTTLE_SUPPORT
	struct list_head suspend[16];
#endif
	struct list_head linger_list; /* not for dynamic */

	uint64_t tsc_timer __align8__;
	uint64_t tsc_now __align8__;
	struct list_head timer_idle;
	struct list_head timer_recv;
	struct list_head timer_send;
	struct list_head timer_req;
	struct list_head pending;
#if RELAY_SUPPORT
	struct list_head timer_relay;
	struct list_head timer_connect;
#endif

#if IOPERF_SUPPORT
	uint64_t ioperf_ptsc;
	uint64_t ioperf_sum;
	uint16_t ioperf_10s;
	uint16_t ioperf_avg;
#endif

#if PROFILE_SUPPORT
	uint64_t polltsc;
	uint64_t profile[PROFILE_PLUGIN+1];
	uint64_t reqcnt;
#endif
} __align__;

#include <stddef.h>
#include "fdinfo.h"
#define connof(bc,m)	((struct conn *)((char *)(bc)-offsetof(struct conn,m)))
#define fd2conn(fd,m)	((struct conn *)((char *)fdinfo[fd].conn-offsetof(struct conn,m)))


#define GET_LIST_ITEM(x,y,z,b)	x=(y)[z];barrier();z=(z+1)%(b)
#define ADD_LIST_ITEM(x,y,z,b)	(y)[z]=(x);barrier();z=(z+1)%(b)
#define SET_LIST_ITEM(x,y,z)	(y)[z]=(x)
#define NEXT_LIST_ITEM(z,b)	z=(z+1)%(b)
#endif
