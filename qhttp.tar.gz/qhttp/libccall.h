#ifndef _H_LIBC_SYSCALL_H
#define _H_LIBC_SYSCALL_H
#include <stdint.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include "syscall.h"

/* setresgid in glibc2.4 is buggy */
extern int getresuid(uid_t*, uid_t*, uid_t*);
extern int getresgid(gid_t*, gid_t*, gid_t*);
#define fast_getresuid  getresuid
#define fast_getresgid  getresgid
static inline int fast_setresuid(uid_t r, uid_t e, uid_t s) {
#ifdef __NR_setresuid32
	return syscall(__NR_setresuid32, r, e, s);
#else
	return syscall(__NR_setresuid, r, e, s);
#endif
}
static inline int fast_setresgid(gid_t r, gid_t e, gid_t s) {
#ifdef __NR_setresuid32
	return syscall(__NR_setresgid32, r, e, s);
#else
	return syscall(__NR_setresgid, r, e, s);
#endif
}
#define fast_setsid	setsid
#define fast_getpid	getpid
#define fast_getppid	getppid
#define fast_getpgid	getpgid
#define fast_getuid	getuid
#define fast_getgid	getgid
#define fast_geteuid	geteuid
#define fast_getegid	getegid
#define fast_setfsuid	setfsuid
#define fast_setfsgid	setfsgid
static inline time_t fast_time(void) { return time(NULL); }
#define fast_gettimeofday gettimeofday
#define fast_fchdir	fchdir
#define fast_chdir	chdir
#define fast_chroot	chroot
#define fast_capget		capget
#define fast_capset		capset
#define fast_setgroups	setgroups
#define fast_getrlimit	getrlimit
#define fast_setrlimit	setrlimit
#define fast_nanosleep	nanosleep
#define fast_inotify_init	inotify_init
#define fast_inotify_add_watch	inotify_add_watch
#define fast_sendfile	sendfile
#define fast_open	open
#define fast_open2	open
#define fast_openat	sys_openat
#define fast_openat3	sys_openat3
#define fast_fcntl	fcntl
#define fast_fcntl2	fcntl
#define fast_read	read
#if __WORDSIZE==64
#define fast_pread	pread
#else
#define fast_pread	sys_pread64
#endif
#define fast_write	write
#define fast_writev	writev
#define fast_splice	sys_splice
#define fast_vmsplice	sys_vmsplice
#undef lseek
#define fast_lseek	lseek
#define fast_seek_start(fd) fast_lseek64(fd, 0, SEEK_SET)
#define fast_file_size(fd) fast_lseek64(fd, 0, SEEK_END)
#if __WORDSIZE==64
#define fast_filestat	fstat
#define fast_linkstat	lstat
#else
#define fast_filestat	filestat
#define fast_linkstat	linkstat
#endif
#define fast_readlink	readlink
#define fast_link	link
#define fast_unlink	unlink
#define fast_close	close
#define fast_socket	socket
#define fast_socketpair	socketpair
#define fast_shutdown	shutdown
#define fast_bind	bind
#define fast_connect	connect
#define fast_listen	listen
#define fast_accept	accept
#define fast_setsockopt	setsockopt
#define fast_getsockopt	getsockopt
#define fast_recv	recv
#define fast_send	send
#define fast_recvmsg	recvmsg
#define fast_sendmsg	sendmsg
#define fast_getsockname	getsockname
#define fast_getpeername	getpeername
#define fast_exit	_exit
#define fast_unshare	sys_unshare
#define fast_poll	poll
#define fast_shmget	shmget
#if __x86_64__
#define fast_shmctl	shmctl
#define fast_semctl	semctl
#define fast_semget	semget
#define fast_semop	semop
#else
#define fast_semget	sys_semget
#define fast_shmctl	sys_shmctl
#define fast_semctl	sys_semctl
#endif
#define fast_shmat	shmat
#define fast_epoll_create	epoll_create
#define fast_epoll_ctl	epoll_ctl
#define fast_epoll_wait	epoll_wait
#define fast_futex(i1,i2,i3)	syscall(__NR_futex,i1,i2,i3)
#define fast_futex4(i1,i2,i3,i4)	syscall(__NR_futex,i1,i2,i3,i4)

#endif

