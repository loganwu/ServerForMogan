/* stat API custom for qhttpd */
#include "myalloc.h"
#include <sys/fcntl.h>
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include "message.h"

#include "autoconfig.h"
#if ISDSTAT_SUPPORT
#include "global.h"
#include "stat.h"

/*
 * standard data format
 *     arg1(4byte) arg2(4byte) arg3(4byte) ...
 * log message format    
 *     level(1byte) reserved(1byte) textlen(2byte) text...
 */
int msglog(const char *logfile, uint32_t type, time_t timestamp, const void *data, int len) {
	if(need_filemon) {
		message_header_t h[1];
		struct iovec iov[2];

		if(statfd < 0) return -1;

		memset(h, 0, sizeof(message_header_t));
		h->len = sizeof(message_header_t)+len;
		h->hlen = sizeof(message_header_t);
		h->type = type;
		h->timestamp = timestamp;

		iov[0].iov_base = h;
		iov[0].iov_len = sizeof(message_header_t);
		iov[1].iov_base = (char *)data;
		iov[1].iov_len = len;

		return fast_writev(statfd, iov, 2);
	} else {
		message_header_t *h;
		int fd, s;

		s = sizeof(message_header_t)+len;
		h = (message_header_t *)malloc(s);
		bzero(h, s);
		h->len = s;
		h->hlen = sizeof(message_header_t);
		h->type = type;
		h->timestamp = timestamp;

		if(len>0)memcpy((char *)(h+1), data, len);

		fd = fast_open(statfile, O_WRONLY|O_APPEND|O_CREAT, 0666);
		if(fd>=0) {
			fast_write(fd, (char *)h, s);
			fast_close(fd);
		}
		free(h);
	}
	return 0;
}

void set_str(char *ptr, int pos, const char *str, int *lenp) {
	if(str==NULL) {
		*(uint16_t *)(ptr+pos*4+0) = 0;
		*(uint16_t *)(ptr+pos*4+2) = 0;
	} else {
		int l = strlen(str)+1;
		*(uint16_t *)(ptr+pos*4+0) = *lenp;
		*(uint16_t *)(ptr+pos*4+2) = l;
		strcpy(ptr + (*lenp), str);
		*lenp += l;
	}
}

/*
 * format: <option indicator>...<data indicator>...
 * options:
 *	D --- Discardable, don't send to sentbox
 * data type:
 *	i --- 4 bit integer
 *      s --- string
 *
 * eg: "Diissis" is a discardable message with data:
 *	integer0, integer1, string2, string3, integer4, string5
 */
int vmsgprintf(const char *logfile, uint32_t type, time_t timestamp, const char *fmt, va_list ap) {
	message_header_t *h;
	char *data;
	int s, i;

	if(statfd <= 0) return -1;

	/* prevent malloc() */
	data = malloc(65536);
	h = (message_header_t *)data;
	data += sizeof(message_header_t);
	h->hlen = sizeof(message_header_t);
	h->type = type;
	h->timestamp = timestamp;
	
	if(fmt == NULL) {
		s = sizeof(message_header_t);
	} else {
		if(fmt[0]=='D') {
			h->flag |= MF_DISCARDABLE;
			fmt++;
		}
		s = strlen(fmt)*4;

		for(i=0; fmt[i]; i++) {
			if(fmt[i]=='i') {
				int val = va_arg(ap, int);
				set_int(data, i, val);
			} else if(fmt[i]=='s'){
				char *val = va_arg(ap, char *);
				set_str(data, i, val, &s);
			} else {
				(void)va_arg(ap, int);
				set_int(data, i, 0);
			}
		}
		s += sizeof(message_header_t);
	}

	h->len = s;

	if(need_filemon) {
		fast_send(statfd, (char *)h, s, 0);
	} else {
		int fd;
		fd = fast_open(statfile, O_WRONLY|O_APPEND|O_CREAT, 0666);
		if(fd>=0) {
			fast_write(fd, (char *)h, s);
			fast_close(fd);
		}
	}
	free(h);
	return 0;
}

int msgprintf(const char *logfile, uint32_t type, time_t timestamp, const char *fmt, ...) {
	va_list ap;
	int rv;

	va_start(ap, fmt);
	rv = vmsgprintf(logfile, type, timestamp, fmt, ap);
	va_end(ap);
	return rv;
}

#endif
