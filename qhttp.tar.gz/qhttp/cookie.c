/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include "myalloc.h"
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <dlfcn.h>
#include <netinet/in.h>
#include "compat_ctype.h"

#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "conn.h"
#include "cookie.h"
#include "log.h"
#include "util.h"

#if COOKIE_SUPPORT

static int zzuin;
static int zzkey;
static int oiwuin;
static int oiwkey;
static int oiwkey2;
static int (*fnAuth)(int panel_uin, const char* panel_key, int expire_time) __init__;

static inline int hash_string(register const char *string) {
	register int hash = 0;
	register char c;
	while((c=*string++))
	    hash = hash * 11 + c;
	return hash;
}

int add_cookie(const char *name, int size) {
	struct cookie *c;
	int nl = strlen(name);

	if(nl==0 || size <= 0 || nl+size+10 > sendbufsz) return -1;
	for(c=cookieinfo; c; c=c->next) {
		if(c->namelen==nl && !strcmp(c->name, name)) {
			if(size > c->maxlen) c->maxlen = size;
			return 0;
		}
	}

	c = calloc(1, sizeof(struct cookie) + nl + 1);
	if(c==NULL) return -ENOMEM;
	c->next = cookieinfo;
	cookieinfo = c;
	c->namelen = nl;
	c->maxlen = size;
	c->hash = hash_string(name);
	strcpy(c->name, name);
	return 0;
}

void calculate_cookie_size(void) {
	struct cookie *c;
	for(c=cookieinfo; c; c=c->next) {
		c->offset = cookiesize;
		cookiesize += c->maxlen + 1;
		lprintf("Decode cookie %s length %d at %d\n", c->name, c->maxlen, c->offset);
	}
}

int load_panel_auth(void) {
	if(fnAuth != NULL) return 0;

	const char *tlib = myconfig_get_value("panelauth_path");
	void *lib;
	if(tlib) {
	    lib = dlopen(tlib, RTLD_NOW);
	} else {
	    lib = dlopen("panelauth2.so", RTLD_NOW);
	    if(lib==NULL)
		lib = dlopen("panelauth.so", RTLD_NOW);
	}
	if(lib) {
	    fnAuth = dlsym(lib, "panel_auth");
	    if(fnAuth==NULL)
		fnAuth = dlsym(lib, "TBase_PanelAuth");
	    if(fnAuth==NULL)
	    	dlclose(lib);
	}
	return fnAuth==NULL;
}

int init_cookie_info(void) {
	char *p;
	int i;
	int s;

	/* NO plugin, we don't need cookie */
	if(!has_plugin) return 0;
	for(i=0; i<1000; i++) {
		p = myconfig_get_multivalue("decode_cookie", i);
		if(p==NULL) break;
		s = strtoul(p, &p, 10);
		while(*p==' '||*p=='\t'||*p==',') p++;
		add_cookie(p, s);
	}
	calculate_cookie_size();
	zzuin = cookie_offset("zzpaneluin");
	zzkey = cookie_offset("zzpanelkey");
	oiwuin = cookie_offset("uin");
	oiwkey = cookie_offset("skey");
	oiwkey2 = cookie_offset("skey2");
	if(cookiesize)
	    lprintf("Cookie buffer size %d bytes per connection\n", cookiesize);

	zzuin = cookie_offset("zzpaneluin");
	zzkey = cookie_offset("zzpanelkey");

	if(zzuin >= 0 && zzkey >= 0)
		load_panel_auth();
	return 0;
}

int need_panel_auth(void) {
	if(zzuin < 0 || zzkey < 0)
		return 0;
	return load_panel_auth();
}

void free_cookie_info(void) {
	while(cookieinfo) {
		void *p = cookieinfo;
		cookieinfo = cookieinfo->next;
		free(p);
	}
}

/*
 * decode cookie
 * cbuf      --- cookie buffer, cookie store at offset+maxlen
 * data      --- source cookie string
 * datasz:
 * 0         --- This is a single line source
 * recvbufsz --- a cookie exceed recvbuf
 *
 * return    --- 0 if datasz==0
 *               0 if all source string parsed
 *              >0 unparsed(remain) source length
 */

int decode_cookie(char *cbuf, char *data, int datasz) {
	struct cookie *c;
	int hash;
	int nl;
	char *eoc = NULL;
	char *line;
	char *p;

	line = data;
	data += datasz;
	while(1) {
		while(*line==' '||*line=='\t'||*line==';') line++;

		/* find cookie name and calculate hash */
		for(p=line, hash=0; *p && *p!='=' && *p != ';'; p++) {
			hash = hash * 11 + *p;
		}

		if(*p==';') {
			line = p+1;
			continue;
		}
		/* find ';' */
		if(*p == '=') {
			eoc = strchr(p, ';');
			if(eoc) *eoc++ = '\0';
		}
		
		/* incomplete name or partial decode w/o ';' */
		if(*p != '=' || (datasz && eoc==NULL)) {
			if(datasz==0) return 0;
			if(p != data /* '\0' inside cookie */ ||
					p-line > recvbufsz-1)
			{
				data[-1] = '=';
				return 1;
			}
			return data-line;
		}

		for(nl=p-line, c=cookieinfo; c; c=c->next) {
			if(c->namelen==nl && c->hash==hash &&
				!strncmp(line, c->name, nl))
			{
				strncpy(cbuf+c->offset, p+1, c->maxlen);
			}
		}
		if(eoc==NULL) return 0;
		line = eoc;
	}
	return 0;
}

int encode_cookie(char *buf, int len, const char *cookie) {
	struct cookie *c;
	int off;

	if(cookie==NULL) return 0;
	if(len < 8) return -1;
	for(c=cookieinfo, off=0; c; c=c->next) {
		int l;
		if(cookie[c->offset]=='\0') continue;
		l = strlen(cookie+c->offset);
		if(l + c->namelen + 3 > len-off) 
			return -1;
		memcpy(buf+off, c->name, c->namelen);
		off += c->namelen;
		buf[off++] = '=';
		memcpy(buf+off, cookie+c->offset, l);
		off += l;
		buf[off++] = ';';
		buf[off++] = ' ';
	}

	if(off==0) return 0;
	return off-2;
}

int encode_cookie_overlay(char *buf, const char *cookie) {
	char *ptr;
	struct cookie *c;

	if(cookie==NULL) return 0;
	if(cookie-buf < 8) return -1;

	for(c=cookieinfo, ptr=buf; c; cookie+=c->maxlen, c=c->next) {
		if(*cookie=='\0') continue;
		if(ptr+c->namelen+2 > cookie)
			return -1;
		memcpy(ptr, c->name, c->namelen);
		ptr += c->namelen;
		*ptr++ = '=';
		int l = strlen(cookie);
		memmove(ptr, cookie, l);
		ptr += l;
		*ptr++ = ';';
		*ptr++ = ' ';
	}

	if(ptr==buf) return 0;
	return ptr-buf-2;
}

int cookie_offset(const char *name) {
	struct cookie *c;
	for(c=cookieinfo; c; c=c->next) {
		if(!strcmp(name, c->name))
			return c->offset;
	}
	return -1;
}

int cookie_maxlength(const char *name) {
	struct cookie *c;
	for(c=cookieinfo; c; c=c->next) {
		if(!strcmp(name, c->name))
			return c->maxlen;
	}
	return -1;
}

__attribute__((weak))
int panel_auth(int panel_uin, const char* panel_key, int expire_time) {
	return fnAuth==NULL ? -1 : fnAuth(panel_uin, panel_key, expire_time);
}

int cookie_auth_uin(const char *cookie, int expire) {
	int uin;

	if(zzuin >= 0 && zzkey >= 0 && is_digit(cookie[zzuin]) && cookie[zzkey]) {
		uin = atoi(cookie+zzuin);
		if(panel_auth(uin, cookie+zzkey, expire)==0)
			return uin;
	}
	if(oiwuin>=0 && oiwkey>=0 && cookie[oiwuin]=='o' && cookie[oiwkey]) {
		if(oiwkey2 >= 0 && cookie[oiwkey2]) {
			uin = atoi(cookie+oiwuin+1);
			if(panel_auth(uin, cookie+oiwkey2, expire)==0)
				return uin;
		}
		return -1;
	}
	return 0;
}

#endif
