#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include <sys/mman.h>
#include "compat_ctype.h"

#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "util.h"
#include "log.h"

#if __x86_64__
#define rdtscll(val) do { \
     unsigned int __a,__d; \
          asm volatile("rdtsc" : "=a" (__a), "=d" (__d)); \
	       (val) = ((unsigned long)__a) | (((unsigned long)__d)<<32); \
	       } while(0)
#else

#define rdtscll(val) \
     __asm__ __volatile__("rdtsc" : "=A" (val))

#endif

int ncpus __init__ = 1;
int ht __init__ = 1;
int cs __init__ = 1;
static int khz __init__ = 0;
int tscmsec __init__ = 1000;
double tscusecf __init__ = 1.0;
int tsc4shift __init__ = 10;
uint64_t tscsec __init__ = 1000000LL;
uint64_t tscmin __init__ = 60000000LL;
uint64_t tschour __init__ = 3600000000LL;

uint32_t init_clocksource_tsc(void) {
	/* STACK-USAGE: 600 */

	if(myconfig_get_intval("disable_tsc", 0)) return 0;
	if(khz) return khz;

	uint64_t tsc0, tsc1, tsc2;
	struct timespec tv;

	rdtscll(tsc0);
	tv.tv_sec = 1;
	tv.tv_nsec = 1000000;
	while(fast_nanosleep(&tv,&tv)!=0)/*NULL LOOP*/;
	rdtscll(tsc1);
	tv.tv_sec = 0;
	tv.tv_nsec = 1000000;
	while(fast_nanosleep(&tv,&tv)!=0)/*NULL LOOP*/;
	rdtscll(tsc2);
	khz = (2*tsc1-tsc0-tsc2)/1000;
	lprintf("Calibrating CPU Speed...%d.%03d MHz\n", khz/1000, khz%1000);

	return khz;
}

uint64_t clocksource_tsc(void) {
	uint64_t a;
	rdtscll(a);
	return a;
}

static volatile uint64_t *hpet_ptr = NULL;
uint32_t init_clocksource_hpet(void) {
	if(myconfig_get_intval("disable_hpet", 0)) return 0;
	int fd = fast_open("/dev/hpet", 0, 0666);
	if(fd < 0) return 0;
	hpet_ptr = mmap(0L, 1024, PROT_READ, MAP_SHARED, fd, 0);
	fast_close(fd);
	if(BADADDR(hpet_ptr)) return 0;
	unsigned long a = hpet_ptr[0] >> 32;
	if(a==0) {
		munmap((char *)hpet_ptr, 1024);
		return 0;
	}
	hpet_ptr += 0xF0/8;
	return 1000000000000LL / a;
}

uint64_t clocksource_hpet(void) {
	return *hpet_ptr;
}

int init_clocksource_os(void) {
	return 1000;
}

uint64_t clocksource_os(void) {
	struct timeval tv;
	fast_gettimeofday(&tv, NULL);
	return tv.tv_sec * 1000000LL + tv.tv_usec;
}

static void init_cpuid(void) {
	unsigned int a, b, c, d, lv, vn=0;

	__asm__("cpuid":"=a"(a), "=b"(b), "=c"(c), "=d"(d) : "0"(0));
	lv = a; cs = 1; ht = 1;
	if(b==0x756e6547 && c==0x6c65746e && d==0x49656e69) {
	    vn = 1;

	    if(lv>=4) {
		__asm__("cpuid":"=a"(a), "=b"(b), "=c"(c), "=d"(d) : "0"(4), "c"(0));
		if((a&0x1f) > 0) cs = (a>>26)+1;
	    }

	    if(lv>=1) {
		__asm__("cpuid":"=a"(a), "=b"(b), "=c"(c), "=d"(d) : "0"(1));
		ht = (b & 0xff0000) >> 16;
	    }
	} else if(b==0x68747541 && c==0x444d4163 && d==0x69746e65) {
	    vn = 2;
	    if (lv>=0x80000008) {
		__asm__("cpuid":"=a"(a), "=b"(b), "=c"(c), "=d"(d) : "0"(0x80000008));
		cs = (c & 0xff) + 1;
	    }
	} else 
	    vn = 0;
	ht /= cs; if(ht<1) ht = 1;
}

void init_cpu(void) {
	/* STACK-USAGE: 600 */
        char buf[512], *p, *q, *info[3];
	int fd;

	fd = fast_open2("/proc/stat", O_RDONLY);
	if(fd >= 0) {
	    fast_read(fd, buf, 512);
	    fast_close(fd);
	    buf[511] = '\0';
	    for(p=buf; (p=strchr(p, '\n')); ) {
		p++;
		if(strncmp(p, "cpu", 3)==0 && is_digit(p[3]))
		    ncpus = strtol(p+3, NULL, 10) + 1;
	    }
	    if(ncpus <= 0) ncpus = 1;
	}

        fd = fast_open2("/proc/cpuinfo", O_RDONLY);
        if(fd<0) return;
        fast_read(fd, buf, 512);
        fast_close(fd);
        buf[511] = '\0';
        if((p=strstr(buf, "cpu MHz")) && (q=strchr(p, '\n'))) {
	    *q = '\0';
	    switch(str_explode(" :.\t\r\n", p+7, info, 3)) {
		case 1:
		    info[1] = "000";
		case 2:
		case 3:
		    khz = atoi(info[0]) * 1000;
		    if(is_digit(info[1][0])) {
			khz += (info[1][0]-'0')*100;
			if(is_digit(info[1][1])) {
			    khz += (info[1][1]-'0')*10;
			    if(is_digit(info[1][2]))
				khz += info[1][2]-'0';
			}
		    }
	    }
	}
	if(ncpus < ht)
	    ht = cs = 1;
	else if(ncpus < cs*ht)
	    cs = ncpus / ht;

	if(khz)
	    lprintf("System  processor: %d.%03d MHz, %dxCPU %dxCORE %dxHT.\n",
	    	khz/1000, khz%1000, ncpus/ht/cs, cs, ht);
}

uint64_t (*readtsc)(void) = &clocksource_os;
int init_tsc(void) {
	init_cpuid();
	init_cpu();

	int vhpet = init_clocksource_hpet();
	int vtsc = init_clocksource_tsc();
	int vos = init_clocksource_os();
	if(vhpet)
	    lprintf("Detected HPET: %d.%03d Mhz\n", vhpet/1000, vhpet%1000);

	int i, mhpet=0x7FFFFFFF, mtsc=0x7FFFFFFF, mos=0x7FFFFFFF;
	volatile uint64_t v;
	if(vhpet) {
		for(i=0; i<10; i++) {
			uint64_t a0, a1;
			rdtscll(a0);
			v = clocksource_hpet();
			rdtscll(a1);
			a1 -= a0;
			if(mhpet > a1) mhpet = a1;
		}
	}
	if(vtsc) {
		for(i=0; i<10; i++) {
			uint64_t a0, a1;
			rdtscll(a0);
			v = clocksource_tsc();
			rdtscll(a1);
			a1 -= a0;
			if(mtsc > a1) mtsc = a1;
		}
	}
	for(i=0; i<10; i++) {
	    uint64_t a0, a1;
	    rdtscll(a0);
	    v = clocksource_os();
	    rdtscll(a1);
	    a1 -= a0;
	    if(mos > a1) mos = a1;
	}

	if(verbose) {
		lprintf("Clock source cost: hpet=%d tsc=%d gettimeofday=%d\n", mhpet, mtsc, mos);
	}
	if(mhpet <= mtsc && mhpet <= mos) {
		tscmsec = vhpet;
		readtsc = clocksource_hpet;
		lprintf("Clock source used: HPET\n");
	} else if(mtsc <= mhpet && mtsc <= mos) {
		tscmsec = vtsc;
		readtsc = clocksource_tsc;
		lprintf("Clock source used: TSC\n");
	} else {
		tscmsec = vos;
		readtsc = clocksource_os;
		lprintf("\7Clock source used: gettimeofday(), performance DEGRADED.\n");
	}
    lprintf("tscmsec is %d", tscmsec);
	tscusecf = (double)tscmsec / 1000.0;
	tscsec = tscmsec * 1000LL;
	tscmin = tscsec * 60;
	tschour = tscmin * 60;
	uint64_t a = tscsec;
	for(tsc4shift=0; a >= 1; tsc4shift++)
		a >>= 1;
#if THROTTLE_SUPPORT
	tsc1k = tscsec/1024;
	tsc125msec = tscmsec * 150LL;
#endif

	return 0;
}

