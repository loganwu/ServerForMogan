#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include "bitops.h"

#include "autoconfig.h"
#include "util.h"
#include "fdinfo.h"
#include "sysctl.h"

long sysctl_increase_value(const char *fn, long value) {
	char buf[20];
	int fd;
	int n;
	long old = -1;

	fd = fast_open2(fn, O_RDWR);
	if(fd>=0) {
		n = fast_read(fd, buf, 19);
		if(n>0) {
			buf[n] = '\0';
			old = atoi(buf);
			if(old < value) {
				char *p = int2str(buf, value);
				fast_lseek(fd, 0L, SEEK_SET);
				fast_write(fd, buf, p-buf);
			}
		}
		fast_close(fd);
	}
	return old;
}

long sysctl_decrease_value(const char *fn, long value) {
	char buf[20];
	int fd;
	int n;
	int old = -1;

	fd = fast_open2(fn, O_RDWR);
	if(fd>=0) {
		n = fast_read(fd, buf, 19);
		if(n>0) {
			buf[n] = '\0';
			old = atoi(buf);
			if(old > value) {
				char *p = int2str(buf, value);
				fast_lseek(fd, 0L, SEEK_SET);
				fast_write(fd, buf, p-buf);
			}
		}
		fast_close(fd);
	}
	return old;
}

long sysctl_set_value(const char *fn, long value) {
	char buf[20];
	int fd;
	int n;
	int old = -1;

	fd = fast_open2(fn, O_RDWR);
	if(fd>=0) {
		n = fast_read(fd, buf, 19);
		if(n>0) {
			buf[n] = '\0';
			old = atoi(buf);
			if(old != value) {
				char *p = int2str(buf, value);
				fast_lseek(fd, 0L, SEEK_SET);
				fast_write(fd, buf, p-buf);
			}
		}
		fast_close(fd);
	}
	return old;
}

const uint32_t tokenmask[12] = {
	[1] = 0x03FF4000, /* 20-3F */
	[2] = 0x03FFFFFF, /* 40-5F */
	[3] = 0x03FFFFFF, /* 60-7F */
};

extern void cprintf();
long sysctl_get_value(const char *fn, int index) {
        char *p, buf[64];
        int i, fd, n;

        if((fd = fast_open2(fn, O_RDONLY))>0) {
                if((n = fast_read(fd, buf, sizeof(buf)-1)) > 0)
                {
                        buf[n] = '\0';
                        for(i=0, p=buf; i<index; i++) {
				while(*p && test_bit(*(unsigned char *)p, tokenmask))
					p++;
				while(*p && !test_bit(*(unsigned char *)p, tokenmask))
					p++;
                        }
			fast_close(fd);
                        return atol(p);
                }
		fast_close(fd);
        }
        return -1;
}

int sysctl_get_multivalue64(const char *fn, int64_t *ptr, int num) {
        char *p, buf[64];
        int i, fd, n;

        if((fd = fast_open2(fn, O_RDONLY))>0) {
                if((n = fast_read(fd, buf, sizeof(buf)-1)) > 0)
                {
                        buf[n] = '\0';
			p = strchr(buf, '\n');
			if(p) *p = '\0';
                        for(i=0, p=buf; *p && i<num; i++) {
				ptr[i] = atoll(p);
				while(test_bit(*(unsigned char *)p, tokenmask))
					p++;
				while(*p && !test_bit(*(unsigned char *)p, tokenmask))
					p++;
                        }
			fast_close(fd);
                        return i;
                }
		fast_close(fd);
        }
        return -1;
}

