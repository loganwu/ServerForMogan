#include <stdio.h>
#include <dlfcn.h>
#include <link.h>

#include "autoconfig.h"
#include "log.h"
#include "fault.h"
#include "global.h"
#include "myconfig.h"

const char * const badsym[] = {
	"dlopen", "dlsym", "dlvsym", "dlclose",
	"flockfile", "IO_flockfile",
	"lockf", "lockf64", "flock",
	"putchar", "getchar", "scanf", "vscanf",
	"semop",
	"lock__FR7istream", "lock__FR7ostream",
	"wait", "waitpid", "wait3", "wait4", "waitid", "sigwait",
	"sleep", "usleep", "nanosleep",
	"pause", "sigpause", "sigsuspend",
	"signal", "sigaction",
	NULL
};

const char * const badauth[] = {
	"panel_auth", "cookie_auth_uin",
	NULL
};

void * loadlib(const char *libfile, int argc, char **argv) {
	void *lib;

	void (*entry_load)(int, char **);

	lib = dlopen(libfile, RTLD_NOW);
	if(lib==NULL) {
		lprintf("%s\n", dlerror());
		return NULL;
	}

	check_reentrant();
	if(nconns>1 && check_symbol(*(void **)(lib+2*sizeof(void *)), libfile, badsym, 0)!=0) {
		dlclose(lib);
		return NULL;
	}
	if(check_symbol(*(void **)(lib+2*sizeof(void *)), libfile, badauth, 0)!=0 && need_panel_auth()!=0) {
		lprintf("%s: panel_auth/cookie_auth_uin used, but no panelauth.so available\n", libfile);
		dlclose(lib);
		return NULL;
	}
	entry_load = dlsym(lib, "plugin_load");
	if(entry_load==NULL) {
		lprintf("%s: symbol 'plugin_load' not found\n", libfile);
		dlclose(lib);
		return NULL;
	}
	entry_load(argc, argv);
	return lib;
}

void closelib(void *lib, int argc, char **argv) {
	dlclose(lib);
}

