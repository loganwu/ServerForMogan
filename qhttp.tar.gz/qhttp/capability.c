#include <stdlib.h>
#include <alloca.h>
#include <sys/prctl.h>
#include <strings.h>
#include <errno.h>
#include "compat_errno.h"

#include "autoconfig.h"
#include "log.h"
#include "global.h"
#include "priv.h"

#include "cap19980330.h"
extern int capget(cap_user_header_t hdrp, cap_user_data_t datap);
extern int capset(cap_user_header_t hdrp, const cap_user_data_t datap);

int check_capability(void) {
	cap_user_header_t header;
	cap_user_data_t data;
	int n;

	header = alloca(sizeof(*header));
	data = alloca(sizeof(*data));

	bzero(header, sizeof(*header));
	bzero(data, sizeof(*data));

	header->version = _LINUX_CAPABILITY_VERSION;
	header->pid = 0;

	n = fast_capget(header, data);
	FAST_ERRNO(n);
	if(n < 0) {
	    if(n == EINVAL && header->version != _LINUX_CAPABILITY_VERSION) {
		lprintf("Linux Capability Version %d not supported\n",
			header->version);
	    }
	    return -1;
	}

	if(getenv("_DEBUG_CAPABILITY"))
	    show_capability("capability");

	n = 0;
	if(data->permitted & (1<<CAP_SETPCAP)) {
		n = 0xFF;
	} else {
		if((data->permitted & (1<<CAP_SYS_CHROOT)))
			n |= PRIV_CHROOT;
		if((data->permitted & (1<<CAP_SETUID)))
			n |= PRIV_SETUID;
		if((data->permitted & (1<<CAP_SETGID)))
			n |= PRIV_SETGID;
		if((data->permitted & (1<<CAP_NET_BIND_SERVICE)))
			n |= PRIV_NETBIND;
		if((data->permitted & (1<<CAP_SYS_RESOURCE)))
			n |= PRIV_RESOURCE;
		if((data->permitted & (1<<CAP_IPC_LOCK)))
			n |= PRIV_HUGETLB;
	}
	if(data->permitted != data->effective) {
		data->effective = data->permitted;
		fast_capset(header, data);
	}
	return n;
}

void init_capability(void) {
	cap_user_header_t header;
	cap_user_data_t data;

	header = alloca(sizeof(*header));
	data = alloca(sizeof(*data));

	bzero(header, sizeof(*header));
	bzero(data, sizeof(*data));

	header->version = _LINUX_CAPABILITY_VERSION;
	header->pid = 0;

	fast_capget(header, data);
	if(data->permitted & (1<<CAP_SETPCAP)) {
	    data->permitted |=
		(1<<CAP_SETUID) |
		(1<<CAP_SETGID) |
		(1<<CAP_NET_BIND_SERVICE) |
		(1<<CAP_IPC_LOCK) |
		(1<<CAP_SYS_RESOURCE) |
		(1<<CAP_SYS_CHROOT);
	}
	/* remove unused capabilitys */
	data->permitted &= ~(1<<CAP_LINUX_IMMUTABLE);
	data->permitted &= ~(1<<CAP_NET_BROADCAST);
	data->permitted &= ~(1<<CAP_NET_ADMIN);
	data->permitted &= ~(1<<CAP_NET_RAW);
	data->permitted &= ~(1<<CAP_SYS_MODULE);
	data->permitted &= ~(1<<CAP_SYS_RAWIO);
	data->permitted &= ~(1<<CAP_SYS_PTRACE);
	data->permitted &= ~(1<<CAP_SYS_PACCT);
	data->permitted &= ~(1<<CAP_SYS_PACCT);
	//data->permitted &= ~(1<<CAP_SYS_ADMIN);
	data->permitted &= ~(1<<CAP_SYS_BOOT);
	data->permitted &= ~(1<<CAP_SYS_TIME);
	data->permitted &= ~(1<<CAP_SYS_TTY_CONFIG);
	data->permitted &= ~(1<<CAP_MKNOD);
	data->permitted &= ~(1<<CAP_LEASE);
	data->effective = data->permitted;
	fast_capset(header, data);
}

void set_capability_role(int role) {
	cap_user_header_t header;
	cap_user_data_t data;

	header = alloca(sizeof(*header));
	data = alloca(sizeof(*data));

	bzero(header, sizeof(*header));
	bzero(data, sizeof(*data));

	header->version = _LINUX_CAPABILITY_VERSION;
	header->pid = 0;
	if(role==ROLE_OWNER) {
	    fast_capget(header, data);
	    data->permitted &= CAP_FS_MASK;
	} else if(role==ROLE_ROOT) {
	    fast_capget(header, data);
	    data->permitted &= ~(
		    (1<<CAP_SETUID) |
		    (1<<CAP_SETGID) |
		    (1<<CAP_NET_BIND_SERVICE) |
		    (1<<CAP_IPC_LOCK) |
		    (1<<CAP_SYS_RESOURCE) |
		    (1<<CAP_SYS_ADMIN) |
		    (1<<CAP_SYS_CHROOT));
	}
	data->effective = data->permitted;
	fast_capset(header, data);
}

void show_capability(const char *msg) {
	cap_user_header_t header;
	cap_user_data_t data;

	header = alloca(sizeof(*header));
	data = alloca(sizeof(*data));

	bzero(header, sizeof(*header));
	bzero(data, sizeof(*data));

	header->version = _LINUX_CAPABILITY_VERSION;
	header->pid = 0;

	fast_capget(header, data);

	cprintf("%s:   effective: %08x\n", msg, data->effective);
	cprintf("%s:   permitted: %08x\n", msg, data->permitted);
	cprintf("%s: inheritable: %08x\n", msg, data->inheritable);
}

