#ifndef __H_RELAY_H__
#define __H_RELAY_H__

#include "atomic.h"

#define QVPREFIX	"QV^10#Prefix"
#define QVSUFFIX	"QV10$Suffix%"

//#define UNIX_DOMAIN_IP	"127.0.0.2"
#define UNIX_DOMAIN_IP      33554559 // 127.0.0.2

// The max length of single directoyr index, e.g.: index.html
#define DIRINDEX_MAX 512
#define DIRINDEX_FILENAME_MAX 512

extern int need_relay(char* url);

/*
 * relay/plugin routine return
 *   1 --- switch to relay mode
 *   0 --- processed
 *  -1 --- un-processed
 */
#if RELAY_SUPPORT

struct conn;
struct forward_group;
struct forward_target;
struct callback_data;

extern int init_relay_system(void);
extern int try_relay_connection(struct conn *, char *, int);
extern int forward_connection(struct conn *, void *, int);
extern void relay_timeout(struct conn *c);
extern void close_relay_connection(struct conn *c);
extern int construct_http_header(struct conn *, const char *);
extern int construct_http_reqline(struct conn *, const char *, const char *, int);
extern int timeout_connect;

struct cbdata;
struct forward_target {
	/* flags, total 16 bits */
	uint8_t  has_counter:1;
	uint8_t  connect_timeout:3;
	uint16_t reserved:12;
	uint16_t port;
	uint32_t addr;
	int (*callback)(struct callback_data *);
	int (*response)(struct callback_data *);
	/* counters, optional is has_counter==0 */
	atomic_t count_inuse;
	atomic_t count_access;
	atomic_t count_error;
	char *upath;
};

typedef struct forward_target ftarget_t;


#endif
#endif
