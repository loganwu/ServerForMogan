#if ARCHTEST
#if __i386__
"i386"
#elif __x86_64__
"x86_64"
#else
"non_x86"
#endif
#else
int main(void){return 0;}
#endif
