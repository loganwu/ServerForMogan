
#include "autoconfig.h"
extern int register_file_monitor(const char *filename,
		void (*func)(int, void *, stat64_t *), void *priv);
extern void checking_monitor_files(void);
extern int remove_file_monitor(const char *filename);
extern int open_global_file(const char *filename, int omode, int cmode);
extern int rotate_global_file(const char *filename, int omode, int cmode);
extern int init_filemon_server(void);
extern int init_filemon_client(void);
extern void wait_filemon_server(void);
extern int init_filemon_watchdog(void);
extern int cleanup_filemon(void);
