#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "qhttpd_api.h"
#include "util.h"
#define create_pattern _create_pattern
#define add_prefix_pattern _add_prefix_pattern
#define add_suffix_pattern _add_suffix_pattern
#define add_pattern _add_pattern
#define match_url_pattern _match_url_pattern
#define match_pattern _match_pattern
#include "pattern.h"
#include "relay.h"
#include "util.h"

struct forwardmap{
	char vhost[128];
	char prefix[128];
	char upath[128];
} ;

static struct forwardmap mp[48];

static int cgi_forward(cbdata_t *cb) {
	struct forward_target *g=NULL;
	int i;
	for(i=0;i<48;i++){
		if(mp[i].vhost[0] == '\0'){
			if(g==NULL) return RC_CONTINUE;
		}
		if(strcmp(mp[i].vhost,cb->host) == 0 && strncmp(mp[i].prefix,cb->url,strlen(mp[i].prefix))==0){
			g=malloc(sizeof(struct forward_target));
			memset(g,0,sizeof(struct forward_target));
			g->port = 0;
			//g->addr = str2ip(UNIX_DOMAIN_IP,NULL);
            g->addr = UNIX_DOMAIN_IP;
			g->upath=mp[i].upath;
			cb->ftarget = g;
			return RF_FORWARD_TARGET;
		}
	}
	return RC_CONTINUE;
}

void plugin_load(int argc, const char *const*argv){
	int i, j, n;
	const char *s;
	char key[128];
	char upath[128];
	char *delim=";";

	n = 0;

	memset(mp,0,sizeof(mp));
	for(i=0; n<48 && i < 48 ; i++) {

		memset(key,0,sizeof(key));
		memset(upath,0,sizeof(upath));
		sprintf(key,"group%d_unix_sock_file",i);
		s=myconfig_get_value(key);
		if(s!=NULL){
			memcpy(upath,s,strlen(s));
		}else{
			break;
		}

		memset(key,0,sizeof(key));
		sprintf(key,"group%d_cgi_map",i);

		for(j = 0; n < 48 && (s=myconfig_get_multivalue(key, j));j++){
			s=strtok((char *)s,delim);
			if(s != NULL){
				memcpy(mp[n].vhost,s,strlen(s));
			}
			s=strtok(NULL,delim);
			if(s != NULL){
				memcpy(mp[n].prefix,s,strlen(s));
			}
			memcpy(mp[n].upath,upath,strlen(upath));
			n++;
		}
	}

	register_url_filter(
			0, 0,
			cgi_forward,NULL
			);
}

