#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "compat_sysvipc.h"

#include "autoconfig.h"
#include "detect.h"
#include "myconfig.h"
#include "sysctl.h"
#include "log.h"
#include "util.h"

#if VARY_PAGE_SIZE
int pagesize __init__ = 4096;
#endif
int hugepagesize __init__ = 0;
int hugepagetotal = 0;
int hugepagefree = 0;
unsigned long hugepagealloc=0;
unsigned long memtop __init__;
unsigned long memtotal __init__;
#if __WORDSIZE==32
unsigned long memhalf;
#endif
unsigned long shmmax __init__= 1<<20;


#if VARY_PAGE_SIZE
__attribute__((constructor))
void init_pagesize(void) {
	pagesize = sysconf(_SC_PAGESIZE);
	if((pagesize & (pagesize-1))) pagesize = 4096;
}
#endif

int read_meminfo(void) {
	hugepagesize = 0;
	int fd  = fast_open2("/proc/meminfo", O_RDONLY);
	if(fd >= 0) {
	    char buf[4096], *p, *q;
	    int n = fast_read(fd, buf, 4094);
	    fast_close(fd);
	    buf[n] = '\0';
	    buf[n+1] = '\0';

	    for(p=buf; *p; p=q) {
		if ((q = strchr(p, '\n'))) *q++ = '\0';
		if(p[0]=='M' && strncasecmp(p, "memtotal:", 9)==0)
		    memtotal = strtol(p+9, NULL, 10);
		else if(p[0]=='H' && strncasecmp(p, "hugepagesize:", 13)==0)
		    hugepagesize  = strtol(p+13, NULL, 10) << 10;
	    }
	    if(hugepagesize <= pagesize) hugepagesize = 0;
	    if(myconfig_get_intval("disable_hugepage_memory", 0))
		hugepagesize = 0;
	}
	return 0;
}

int physical_memory_size(void) {
	FILE *fp = fopen("/proc/iomem", "r");
	char line[256], *p;
	unsigned long long s, e;
	int ramsz = 0;

	if(fp == NULL)
		return memtotal;

	while(fgets(line, sizeof(line), fp)) {
		s = strtoll(line, &p, 16);
		if(*p != '-') continue;
		e = strtoll(p+1, &p, 16);
		if(*p != ' ') continue;
		p = strchr(p, ':');
		if(p==NULL || strncmp(p, ": System RAM", 12))
			continue;
		ramsz += (e-s+1)>>10;
	}
	fclose(fp);
	if(ramsz < memtotal)
		ramsz = memtotal;
	return ramsz;
}

int read_hugepage_info(void) {
	int i, n;
	char buf[4096], *p, *q;

	i = fast_open2("/proc/meminfo", O_RDONLY);
	if(i < 0) return 0;
	n = fast_read(i, buf, 4094);
	fast_close(i);
	buf[n] = '\0';
	buf[n+1] = '\0';

	for(p=buf; *p; p=q) {
	    if ((q = strchr(p, '\n'))) *q++ = '\0';
	    if(p[0]=='H') {
		if(strncasecmp(p, "hugepages_total:", 16)==0)
		    hugepagetotal = strtol(p+16, NULL, 10);
		else if(strncasecmp(p, "hugepages_free:", 15)==0)
		    hugepagefree  = strtol(p+15, NULL, 10);
	    }
	}
	return 0;
}

void detect_shmmax(void) {
	shmmax = sysctl_get_value("/proc/sys/kernel/shmmax", 0);
}

void detect_memory_mode(void) {
	char *p;
#define TMS (1<<20)
	p = mmap(0, TMS, PROT_NONE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
	munmap(p, TMS);
	p += TMS;

#if __WORDSIZE==32
	memtop = ((long)&p | 0xFFFFFF)+1;
	memhalf = (unsigned long)&p / (unsigned long)p <= 1 ? 0 :
	    (memtop/3) & ~(pagesize-1);
#else
	memtop = ((long)&p | 0xFFFFFFFF)+1;
#endif
	read_meminfo();
	read_hugepage_info();
	detect_shmmax();
}

void *huge_mmap(int size) {
	if(hugepagesize==0) return NULL;
	if((size&(hugepagesize-1))!=0) return NULL;
	if(shmmax < size) {
	    sysctl_increase_value("/proc/sys/kernel/shmmax", size);
	    lprintf("Increase kernel SHMMAX to %d%s\n", size, pretty(size));
	    shmmax = sysctl_get_value("/proc/sys/kernel/shmmax", 0);
	}

	/* trying hugetlb */
	void *ptr = NULL;
	int id = fast_shmget(IPC_PRIVATE, size,
		IPC_CREAT|SHM_HUGETLB|SHM_R|SHM_W);
	if(id >= 0) {
	    ptr = fast_shmat(id, NULL, 0);
	    if(BADADDR(ptr))
		ptr = NULL;
	    else
		hugepagealloc += size;
	    fast_shmctl(id, IPC_RMID, NULL);
	}
	return ptr;
}

void *try_mmap(int size) {
	size = (size + pagesize - 1) & ~(pagesize-1);
#if __WORDSIZE==32
	void *top = memhalf ? (void *)memhalf - size : NULL;
#endif

	void *ptr = huge_mmap(size);

	if(ptr==NULL) {
		ptr = mmap(
#if __WORDSIZE==32
				top,
#else
				NULL,
#endif
				size,
				PROT_READ|PROT_WRITE,
				MAP_PRIVATE|MAP_ANONYMOUS,
				-1, 0);
		if(BADADDR(ptr)) {
			ptr = NULL;
#if __WORDSIZE==32
			if(size <= 4<<20)
				memhalf = 0;
#endif
		}
#if __WORDSIZE==32
		else if(ptr==top)
			memhalf = (unsigned long)top;
		else if(size <= 4<<20)
			memhalf = 0;
#endif
	}

	return ptr;
}

