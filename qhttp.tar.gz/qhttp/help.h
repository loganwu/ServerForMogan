
extern void print_version(void);
extern int is_front(void);
extern void check_developer_mode(void);
extern void show_developer_magic(void);
