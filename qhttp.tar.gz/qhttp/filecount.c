#define _XOPEN_SOURCE 500
#include "myalloc.h"
#include <stdio.h>
#include <dirent.h>

#include "autoconfig.h"
#include "myconfig.h"
#include "atomic.h"
#include "compat_ctype.h"
#include "namemap.h"
#include "filecount.h"
#include "entity.h"
#include "fdinfo.h"
#include "filemon.h"
#include "task.h"
#include "log.h"
#include "timestamp.h"
#include "priv.h"
#include "util.h"

#if FILECOUNT_SUPPORT

#define MAXDEPTH	20
#define HASHBASE	0x10000

struct filecount {
	atomic_t count;
#if NEED_FCINUSED
	atomic_t inuse;
#endif
#if HAS_ATOMIC8
	atomic8_t bytes;
#else
	atomic_t bytes;
	atomic_t kbytes;
	atomic_t mbytes;
#endif
};

static struct namemap *fcmap;

static int maxbytes = 100 << 20;
static int byteswarned = 0;
static int maxfilename;
static int globalcount;
static long globalbytes;
static struct filecount * otherfc;
static struct filecount * nofilefc;
static int fcmode;
static time_t nextdump;
static time_t nextrotate;
static char *fclistfile;
#define FCDISABLED (char *)0
#define FCREALTIME (char *)1
#define FCDYNAMIC (char *)2

static struct filecount *AddCountingFile(const char *filename) {
	while(*filename=='/') filename++;
	int len = strlen(filename) + 1;
	if(len > maxfilename) maxfilename = len;

	struct filecount *fc;
	fc = GetNameFromMap(fcmap, filename);
	if(fc) return fc;

	if(globalbytes >= maxbytes) {
	    if(byteswarned==0) {
		lprintf("Filecounting: too many file registered, restart may remove orphan entries\n");
		byteswarned = 1;
	    }
	    return NULL;
	}

	fc = AddNameToMap(fcmap, filename);
	if(fc==NULL) {
	    if(byteswarned==0) {
		lprintf("Filecounting: too many file registered, restart may remove orphan entries\n");
		byteswarned = 1;
	    }
	    return NULL;
	}
	globalcount++;
	globalbytes += sizeof(struct filecount) + /* overhead */0 + strlen(filename)+1;
	atomic_set(&fc->count, 0);
#if NEED_FCINUSED
	atomic_set(&fc->inuse, 0);
#endif
#if HAS_ATOMIC8
	atomic8_set(&fc->bytes, 0);
#else
	atomic_set(&fc->bytes, 0);
	atomic_set(&fc->kbytes, 0);
	atomic_set(&fc->mbytes, 0);
#endif
	return fc;
}

static int LoadFileList(void) {
	int fd = open_global_file(fclistfile, O_RDONLY, 0);
	if(fd < 0) return 0;
	FILE *fp = fdopen(fd, "r");
	if(fp==NULL) return 0;
	int n = 0;
	char line[4096];
	while(fgets(line, sizeof(line), fp)) {
	    int l = strlen(line);
	    while(l > 0 && is_space(line[l-1]))
		l--;
	    if(l==0) continue;
	    line[l] = '\0';
	    AddCountingFile(line);
	    n++;
	}
	return n;
}

static int ScanTree(const char *name) {
	char buf[4096];
	int len[MAXDEPTH];
	DIR *dir[MAXDEPTH];
	int depth = 0;
	struct dirent *de;
	int nl;
	struct stat st;

	len[0] = strlen(name);
	if(len[0]+2 >= sizeof(buf))
		return 0;
	memcpy(buf, name, len[0]);
	buf[len[0]] = '/';
	memset(dir, 0, sizeof(dir));

	while(depth >= 0) {
		if(dir[depth]==NULL) {
			buf[len[depth]] = '\0';
			dir[depth] = opendir(buf);
			if(dir[depth] == NULL)
				depth--;
			buf[len[depth]] = '/';
		} else if((de = readdir(dir[depth]))==NULL) {
			closedir(dir[depth]);
			dir[depth] = NULL;
			depth--;
		} else {
			if(de->d_name[0]=='.') {
				if(de->d_name[1] == '\0')
					continue;
				if(de->d_name[1] == '.' && de->d_name[2] == '\0')
					continue;
			}
			nl = strlen(de->d_name);
			if(len[depth] + 1 + nl + 2 > sizeof(buf))
				continue;
			memcpy(buf+len[depth]+1, de->d_name, nl);
			nl += len[depth] + 1;
			buf[nl] = '\0';
			if(lstat(buf, &st) < 0) continue;
			if(S_ISREG(st.st_mode) || S_ISLNK(st.st_mode))
				AddCountingFile(buf+len[0]);
			else if(depth < MAXDEPTH && S_ISDIR(st.st_mode))
				len[++depth] = nl;
		}
	}
	return 0;
}

static inline int ScanFileList(void) {
	ScanTree(docroot);
	return 0;
}

static inline int ScanFileListRoot(void) {
	ScanTree("/");
	return 0;
}

static int BuildHashTable(void) {
	switch(BuildFastNameMap(fcmap)) {
	case -1:
	    if(byteswarned==0) {
		lprintf("Filecounting: No enough memory rebuild hash table\n");
		byteswarned = 1;
	    }
	    return 0;
	case 0:
	    return 0;
	case 1:
	    return 1;
	}
	return 0;
}

struct filecount *get_fcid(const char *name) {
	while(*name=='/') name++;
	struct filecount *fc = GetNameFromMap(fcmap, name);
#if NEED_FCINUSED
	if(fc)
		atomic_inc(&fcid->inuse);
#endif
	return fc;
}

struct filecount *new_fcid(const char *name) {
	while(*name=='/') name++;
	struct filecount *fc = GetNameFromMap(fcmap, name);
	if(fc==NULL) {
		if(fclistfile==NULL) {
			fc = AddCountingFile(name);
			if(fc) {
			}
		}
#if NEED_FCINUSED
	} else {
		atomic_inc(&fcid->inuse);
#endif
	}
	return fc;
}

#if NEED_FCINUSED
void dup_fcid(struct filecount *fcid) {
	atomic_inc(&fcid->inuse);
}

void put_fcid(struct filecount *fcid){
	atomic_dec(&fcid->inuse);
}
#endif
// ***BEGIN*** Modified by yorkwang for file count on 2008-02-18
void log_fcid(void *ent, off64_t size, const char *url, const char *host) {
// ***END*** Modified by yorkwang for file count on 2008-02-18
	struct filecount *fcid = NULL;
	if(isptr(ent)){
	    fcid =  ((struct mementity *)ent)->fcid;
	} else if(isfd(ent)) {
	    fcid = fdent(PTR2INT(ent))->fcid ;
		// ***BEGIN*** Added by yorkwang for file count on 2008-02-18
		if(fcid == NULL && fclistfile == FCREALTIME)
		{
			char filename[PATH_MAX+1] = {0};
			sprintf(filename, "/%s%s", host, url);
			fcid = AddCountingFile(filename);
			fdent(PTR2INT(ent))->fcid = fcid;
		}
		// ***END*** Added by yorkwang for file count on 2008-02-18
	} else if(nofilefc) {
	    fcid = nofilefc;
	} else
	    return;
	if(fcid==NULL) {
	    if(otherfc==NULL) return;
	    fcid = otherfc;
	}

	atomic_inc(&fcid->count);
#if HAS_ATOMIC8
	atomic8_add(size, &fcid->bytes);
#else
	atomic_add((int)(size & 0x3FF), &fcid->bytes);
	size >>= 10;
	atomic_add((int)(size & 0x3FF), &fcid->kbytes);
	size >>= 10;
	atomic_add((int)(size & 0x3FF), &fcid->mbytes);
#endif
}

static void dump_filecounting(void *priv) {
	if(fclistfile == FCDISABLED) return;
	time_t t = fast_time();
	if(t < nextdump) return;
	nextdump += fcmode;

	if(fclistfile== FCREALTIME) {
	} else if(fclistfile == FCDYNAMIC) {
	    if(need_chroot) ScanFileListRoot();
	    else ScanFileList();
	} else
	    LoadFileList();

	if(BuildHashTable() > 0)
		lprintf("Counting Files Updated: count=%d bytes=%ld\n",
				globalcount, globalbytes);

	int fd;

	if(t < nextrotate)
	    fd = open_global_file("@logdir/filecount.log",
		    O_WRONLY|O_APPEND|O_CREAT, 0666);
	else {
	    fd = rotate_global_file("@logdir/filecount.log",
		    O_WRONLY|O_APPEND|O_CREAT, 0666);
	    nextrotate += 86400;
	}

	if(fd < 0) return;

	char line[64];
	time2logstr(line, t);
	line[14] = ' ';

	FILE *fp = fdopen(fd, "a");
	struct filecount *fc = NULL;
	int i = 0;
	while((fc = IterateNameMap(fcmap, fc, &i)) != NULL) {
		off64_t b;
		unsigned int c = atomic_read(&fc->count);
		atomic_sub(c, &fc->count);
#if HAS_ATOMIC8
		b = atomic8_read(&fc->bytes);
		atomic8_sub(b, &fc->bytes);
#else
		int t;
		t = atomic_read(&fc->mbytes);
		atomic_sub(t, &fc->mbytes);
		b = t;

		t = atomic_read(&fc->kbytes);
		atomic_sub(t, &fc->kbytes);
		b = (b<<10) + t;

		t = atomic_read(&fc->bytes);
		atomic_sub(t, &fc->bytes);
		b = (b<<10) + t;
#endif
		if(b || c) {
			char *p = uint2str(line+15, c);
			*p++ = ' ';
			p = ll2str(p, b);
			*p++ = ' ';
			*p++ = '/';
			fwrite(line, p-line, 1, fp);
			fputs(MapDataToName(fcmap, fc), fp);
			fputc('\n', fp);
		}
	}
	fclose(fp);
}

int init_filecounting(void){
	char *p;

	fcmap = CreateNameMap(HASHBASE, sizeof(struct filecount));
	p = myconfig_get_value("filecounting_list");
	if(p==NULL) return 0;
	maxbytes = myconfig_get_size("filecounting_spool_memory", maxbytes);
	if(maxbytes < 1<<20)
		maxbytes = 1<<20;
	otherfc = AddCountingFile("<OTHER>");
	nofilefc = AddCountingFile("<NOFILE>");
	if(!strcasecmp(p, "realtime")) {
	    lprintf("Scanning Document Root\n");
	    fclistfile = FCREALTIME;
	    ScanFileList();
	} else if(!strcasecmp(p, "dynamic")) {
	    lprintf("Scanning Document Root\n");
	    fclistfile = FCDYNAMIC;
	    ScanFileList();
	} else {
	    lprintf("Loading Counting Files\n");
	    fclistfile = strdup(p);
	    LoadFileList();
	}
	p = myconfig_get_value("filecounting_mode");
	if(p==NULL)
	    fcmode = 86400;
	else if(!strcasecmp(p, "hourly"))
	    fcmode = 3600;
	else if(!strcasecmp(p, "daily"))
	    fcmode = 86400;
	else if(is_digit(p[0])) {
	    fcmode = atoi(p);
	}
	if(fcmode < 60) fcmode = 60;

	nextdump = fast_time();
	nextdump += fcmode - nextdump % fcmode;
	nextrotate = nextdump;
	if(fcmode < 86400) {
	    if((nextrotate%86400))
		nextrotate += 86400 - nextrotate % 86400;
	}

	BuildHashTable();
	register_privilege_task(dump_filecounting, NULL);
	lprintf("Counting Files Loaded: count=%d bytes=%ld\n",
		globalcount, globalbytes);
	return 0;
}

void free_filecounting(void){
	if(fcmap)
		FreeNameMap(fcmap, NULL);
}

#endif
