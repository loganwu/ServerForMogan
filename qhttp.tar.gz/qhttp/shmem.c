/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <sys/mman.h>
#include <malloc.h>

#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "shmem.h"
#include "log.h"
#include "util.h"
#include "sysctl.h"

unsigned long shmem_initsize = 0;
#if DEBUG_MALLOC
#undef shalloc
#undef shdup
void *shalloc(int size) { return NONFREE(malloc(size));}
char *shdup(const char *str) { return NONFREE(strdup(str)); }
#else
struct shmem_block {
	char data[0];
	struct shmem_block *blist;
	struct shmem_block *flist;
	int size;
	int fsize;
};
#define BLOCKOVERHEAD sizeof(struct shmem_block)
#define BLOCKMINFREE  (BLOCKOVERHEAD+16)

struct shmem_block *shmem_blist = NULL;
struct shmem_block *shmem_flist = NULL;
static unsigned long shmem_alloc=0, shmem_used=0;

unsigned long count_free_shmem(void) {
	struct shmem_block *b;
	unsigned long f = 0;
	for(b = shmem_flist; b; b=b->flist)
	    f += b->fsize-BLOCKOVERHEAD;
	return f;
}

static struct shmem_block *expand_shmem(int size) {
	struct shmem_block *cur;
	int blocksize = hugepagesize ? hugepagesize : 1<<20;
 
	size += BLOCKOVERHEAD;
	if(size > blocksize) {
	    size = (size | (blocksize-1))+1;
	} else {
	    size = blocksize;
	}
	if(verbose && shmem_used > shmem_initsize)
	    cprintf("Expand shmem size=%d%s\n", size, pretty(size));
	cur = try_mmap(size);
	if(cur==NULL)
		return NULL;
	cur->size = size;
	cur->blist = shmem_blist;
	shmem_blist = cur;

	cur->fsize = size;
	cur->flist = NULL;

	shmem_used += BLOCKOVERHEAD;
	return cur;
}

void *shalign(int size, int align) {
	struct shmem_block *b, **pb;
	int off;

	pb = &shmem_flist;
	for(pb=&shmem_flist; *pb; pb = &(*pb)->flist) {
	    b = *pb;
	    if(b->fsize < size + BLOCKOVERHEAD)
	    	continue;
	    off = (b->fsize - size) & ~(align-1);
	    if(off < BLOCKOVERHEAD)
	    	continue;
	    shmem_alloc += size;
	    shmem_used += b->fsize - off;
	    b->fsize = off;
	    if(b->fsize < BLOCKMINFREE) {
	    	*pb = b->flist;
		shmem_used += b->fsize - BLOCKOVERHEAD;
	    }
	    return b->data + off;
	}

	b = expand_shmem(size+align-1);
	if(b == NULL)
		return NULL;

	*pb = b;

	off = (b->fsize - size) & ~(align-1);
	if(off < BLOCKOVERHEAD)
	    return NULL;
	shmem_alloc += size;
	shmem_used += b->fsize - off;
	b->fsize = off;
	if(b->fsize < BLOCKMINFREE) {
	    *pb = b->flist;
	    shmem_used += b->fsize - BLOCKOVERHEAD;
	}
	return b->data + off;
}

void *shalloc(int size) {
#if __WORDSIZE==64
	return shalign(size, 8);
#else
	return shalign(size, 4);
#endif
}

void *shalloc1(int size) {
	return shalign(size, 1);
}

void *shalloc4(int size) {
	return shalign(size, 4);
}

void *shalloc8(int size) {
	return shalign(size, 8);
}

char *shdup(const char *str) {
	int len;
	char *p;

	if(str==NULL) return NULL;
	if(!*str) return "";
	len = strlen(str)+1;
	p = shalign(len, 1);
	if(p) memcpy(p, str, len);
	return p;
}

void free_shmem(void) {
	while(shmem_blist) {
	    struct shmem_block *cur = shmem_blist;
	    shmem_blist = cur->blist;
	    munmap(cur, cur->size);
	}
}

void report_free_shmem(void) {
	struct shmem_block *b;
	cprintf("Allocated  memory: %ld, overhead %ld\n", shmem_alloc, shmem_used-shmem_alloc);
	for(b = shmem_flist; b; b=b->flist)
	    cprintf("Free memory block: %d\n", (int)(b->fsize-BLOCKOVERHEAD));
}

#endif

int init_shmem_data(void) {
	char buf1[30];

	if(myconfig_get_intval("disable_paging", 0))
	    mlockall(MCL_FUTURE);

	pretty_r(buf1, shmem_initsize);
#if !DEBUG_MALLOC
	if(hugepagesize==0 || myconfig_get_intval("disable_hugepage_memory", 0))
#endif
	{
	    lprintf("Est. memory usage: %lu%s\n", shmem_initsize, buf1);
	    return 0;
	}

#if !DEBUG_MALLOC
	unsigned long initsize = count_free_shmem();
	if(initsize >= shmem_initsize) return 0;

	initsize = ((shmem_initsize-initsize)|(hugepagesize-1)) + 1;

	int n = initsize / hugepagesize;
	int a = (hugepagealloc+hugepagesize-1) / hugepagesize;
	lprintf("Est. memory usage: %lu%s, hugepages %d\n", shmem_initsize, buf1, n);
	if((initsize>>9) > memtotal && hugepagesize > 0 &&
		initsize/hugepagesize > hugepagefree)
	    return 0;

	if(n > hugepagefree && hugepagetotal==hugepagefree+a) {
	    int t = hugepagetotal;
	    sysctl_increase_value("/proc/sys/vm/nr_hugepages", n+a);
	    read_hugepage_info();
	    if(t < hugepagetotal)
		lprintf("Increase kernel hugepages to %d\n", hugepagetotal);
	}
	if(n > hugepagefree) {
	    initsize = hugepagefree * hugepagesize;
	    lprintf("No enough free hugepages, fallback to normal page\n");
	    lprintf("Please append \"hugepages=%d\" to kernel options or\n", n+a);
	    lprintf("\"echo %d > /proc/sys/vm/nr_hugepages\" in startup script\n", n+a);
	}

	struct shmem_block *cur = try_mmap(initsize);
	if(cur) {
	    cur->blist = shmem_blist;
	    cur->size = initsize;
	    shmem_blist = cur;

	    cur->fsize = cur->size;
	    cur->flist = shmem_flist;
	    shmem_flist = cur;

	    shmem_used += BLOCKOVERHEAD;
	}
#endif
	return 0;
}

