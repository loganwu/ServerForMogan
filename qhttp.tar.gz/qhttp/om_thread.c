/**
* @file  om_thread.c
* @brief Timed get some stat items
*
* @author yijian
* @date 2008-03-12
* @{
 */
#include "realconfig.h"
#include "autoconfig.h"
#include "log.h"
#include "myconfig.h"
#include "om_thread.h"
#include "shmem.h"
#include "proc_net_dev.h"
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <alloca.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#ifdef __cplusplus
extern "C" {
#endif
  
#define LOG_FREQ 1000
#define FLUX_SIZE_MAX   (1024*1024*100)
#define OM_INTERVAL_MIN 1
#define OM_INTERVAL_MAX 100000
#define REGISTER_LOGIC_FUNC(logic_list,logic_func) \
    if (NULL == logic_list) { \
        logic_list = shalloc1(sizeof(struct logic_node)); \
        logic_list->logic_func = logic_func; \
        logic_list->next = NULL; \
    } \
    else { \
        struct logic_node* cur_node = logic_list; \
        while (cur_node->next != NULL) \
            cur_node = cur_node->next; \
        cur_node->next = shalloc1(sizeof(struct logic_node)); \
        cur_node->next->logic_func = logic_func; \
        cur_node->next->next = NULL; \
    }
#define CALL_LOGIC_FUNC(logic_list) \
    struct logic_node* cur_node = logic_list; \
    while (cur_node != NULL) { \
        cur_node->logic_func(); \
        cur_node = cur_node->next; \
    }
#define CALC_BYTES(bytes1,bytes2,bytes,bytes_deta) \
    bytes2 = bytes; \
    if (bytes2 > bytes1) { /* don't use (bytes2 - bytes1 > 0) */ \
        volatile unsigned long deta = bytes2 - bytes1; \
        deta *= 8; \
        deta /= 1024; /* kB */ \
        deta *= 1000; /* S */ \
        deta /= om_interval; /* ms */ \
        bytes_deta = deta; \
    } \
    else { \
        bytes_deta = 0; \
    }


struct logic_node {
    struct logic_node* next;
    logic_func_def logic_func;
};
struct logic_node* before_logic_list = NULL;
struct logic_node* after_logic_list  = NULL;

unsigned long om_interval __init__;
unsigned char start_om_thread_flag __init__;
volatile unsigned long t_bytes_deta __init__;
char* flux_filename __init__ = NULL;
int flux_fd __init__ = -1;
int flux_size __init__ = 0;

static pthread_t om_thread;
static volatile unsigned char to_stop;
static struct ProcNetDev net_dev = {-1,0,NULL};
struct om_net_dev_param net_dev_param = {0,NULL,NULL,NULL};

void call_before_logic();
void call_after_logic();
void before_logic_of_netdev();
void after_logic_of_netdev();
void* om_thread_proc(void* param);
void close_flux();
const char* get_now(char* buf, size_t len);
void write_flux(const char* name, unsigned long t_bytes, unsigned long r_bytes);

void open_flux(int log)
{
    if (NULL == flux_filename) return;        
    flux_fd = open(flux_filename, O_CREAT|O_WRONLY|O_TRUNC, S_IWUSR|S_IRUSR|S_IRGRP|S_IROTH);
    if (-1 == flux_fd) {
        if (log)
            lprintf("can't open %s: %s", flux_filename, strerror(errno));
    }    
}
void close_flux()
{
    if (flux_fd > 0) {
        close(flux_fd);
        flux_fd = -1;
    }
}

int start_om_thread() {        
    to_stop = 0;
    om_interval = myconfig_get_intval("om_interval", 0);
    if (0 == om_interval) {
        lprintf("Not use OM-thread");
        return 0;
    }
    if (om_interval < OM_INTERVAL_MIN) om_interval = OM_INTERVAL_MIN;
    if (om_interval > OM_INTERVAL_MAX) om_interval = OM_INTERVAL_MAX;    
    lprintf("OM interval is %lus and %lums", om_interval/1000, om_interval%1000);

    char* filename = myconfig_get_value("flux_file");
    if (filename != NULL) { 
        size_t len = strlen(logdir)+strlen(filename)+3;
        flux_filename = (char *)malloc(len);
        if (NULL == flux_filename) return -1;
        
        snprintf(flux_filename, len-1, "%s/%s", logdir, filename);
        lprintf("flux_file is %s", flux_filename);
        open_flux(1);
    }

    int act = ProcNetDev_activate(&net_dev);
    if (act < 0) {
        lprintf("\7ERROR activate, %s", strerror(errno));
        close_flux();
        return -1;
    }

    memset(&net_dev_param, 0, sizeof(net_dev_param));
    net_dev_param.count = ProcNetDev_getDevCount(&net_dev);
    if (net_dev_param.count > 0) {
        net_dev_param.t_bytes1     = calloc(1, sizeof(net_dev_param.t_bytes1)     * net_dev_param.count);
        net_dev_param.t_bytes2     = calloc(1, sizeof(net_dev_param.t_bytes2)     * net_dev_param.count);
        net_dev_param.t_bytes_deta = calloc(1, sizeof(net_dev_param.t_bytes_deta) * net_dev_param.count);
        net_dev_param.r_bytes1     = calloc(1, sizeof(net_dev_param.r_bytes1)     * net_dev_param.count);
        net_dev_param.r_bytes2     = calloc(1, sizeof(net_dev_param.r_bytes2)     * net_dev_param.count);
        net_dev_param.r_bytes_deta = calloc(1, sizeof(net_dev_param.r_bytes_deta) * net_dev_param.count);        
        register_before_logic(before_logic_of_netdev);
        register_after_logic(after_logic_of_netdev);
    }
    
    int cr = pthread_create(&om_thread, NULL, om_thread_proc, NULL);
    if (cr != 0) {
        lprintf("\7ERROR create thread, %s", strerror(errno));
        ProcNetDev_deactivate(&net_dev);
        close_flux();
        return -cr;
    }

    lprintf("OM thread-ID is %lu", om_thread);
    return 0;
}

void stop_om_thread() {
    to_stop = 1;
    ProcNetDev_deactivate(&net_dev);
    close_flux();
}

int to_stop_om_thread() {
    return to_stop;
}

void heart_beat()
{
    volatile static int heart_beat_count = 0;
    if (LOG_FREQ == ++heart_beat_count) {
        lprintf("OM-thread heart-beat signal");
        heart_beat_count = 0;
    }
}
void* om_thread_proc(void* param) {    
    for (;;) {
        heart_beat();
        if (to_stop_om_thread()) break;        

        call_before_logic();
        milli_sleep(om_interval);
        call_after_logic();        
    }

    lprintf("OM-thread %lu exited", (unsigned long)pthread_self());
    return NULL;
}

void register_before_logic(logic_func_def logic_func)
{
    REGISTER_LOGIC_FUNC(before_logic_list,logic_func);
}
void register_after_logic(logic_func_def logic_func)
{
    REGISTER_LOGIC_FUNC(after_logic_list,logic_func);
}

void call_before_logic()
{    
    CALL_LOGIC_FUNC(before_logic_list);    
}
void call_after_logic()
{
    CALL_LOGIC_FUNC(after_logic_list);
}

void before_logic_of_netdev()
{
    int i = 0;    
    for (i=0; i<net_dev_param.count; ++i) {
        net_dev_param.r_bytes1[i] = net_dev_param.r_bytes2[i];    
        net_dev_param.t_bytes1[i] = net_dev_param.t_bytes2[i];
    }
}

int after_parse(int ret)
{
    volatile static int error_count = 0;
    if (ret < 1) {        
        if (LOG_FREQ == ++error_count) {
            error_count = 0;
            lprintf("parse /proc/net/dev error: %s", strerror(errno));
        }        
        return 0;
    }
    
    return 1;
}

void after_logic_of_netdev()
{
    int i = 0;    
    int dev = ProcNetDev_parse(&net_dev);
    if (!after_parse(dev)) return;    
    for (i=0; i<net_dev_param.count; ++i)
    {
        CALC_BYTES(net_dev_param.r_bytes1[i],net_dev_param.r_bytes2[i],net_dev.m_pDevStruct[i].r_bytes,net_dev_param.r_bytes_deta[i])
        CALC_BYTES(net_dev_param.t_bytes1[i],net_dev_param.t_bytes2[i],net_dev.m_pDevStruct[i].t_bytes,net_dev_param.t_bytes_deta[i])

        write_flux(net_dev.m_pDevStruct[i].name, 
                   net_dev_param.t_bytes_deta[i], 
                   net_dev_param.r_bytes_deta[i]);
    }
}

inline int check_fd()
{
    volatile static int error_count = 0;
    if (-1 == flux_fd) {
        ++error_count;
        if (LOG_FREQ == error_count) {
            open_flux(1);
            error_count = 0;
        }
        else {
            open_flux(0);
        }
        if (-1 == flux_fd)
            return 0;
    }
    return 1;
}
inline int check_size()
{
    if (flux_size > FLUX_SIZE_MAX) {        
        if (0 == ftruncate(flux_fd, 0)) {
            flux_size = 0;
            if (-1 == lseek(flux_fd, SEEK_SET, 0)) {
                lprintf("can't seek flux for %s", strerror(errno));
                close_flux();
                return 0;
            }
        }
        else {
            lprintf("can't truncate flux for %s", strerror(errno));
            close_flux();
            return 0;
        }
    }
    return 1;
}
inline int need_write()
{
    return ((NULL == flux_filename) || (-1 == flux_fd)) ? 0 : 1;
}

void write_flux(const char* name, unsigned long t_bytes, unsigned long r_bytes)
{    
    if (!need_write()) return;
    if (!check_fd()) return;  
    if (!check_size()) return;

    int nprt;
    const int date_len = sizeof("2008-04-11 14:54:22");
    char* date = alloca(date_len+1);
    size_t len = strlen(name)+date_len+1+32;
    char* str = alloca(len+1);
    
    if (get_now(date, date_len))
        nprt = snprintf(str, len, "%s,%s,%lu,%lu,%lu,%lu\n", date, name, t_bytes,t_bytes/1024, r_bytes,r_bytes/1024);
    else
        nprt = snprintf(str, len, "%s,%lu,%lu,%lu,%lu\n", name, t_bytes,t_bytes/1024, r_bytes,r_bytes/1024);
    int wr = write(flux_fd, str, nprt);
    if (wr > 0) {
        flux_size += wr;
    }
    else {
        lprintf("write %d bytes to flux: %s", wr, strerror(errno));
        close_flux();
    }
}

const char* get_now(char* buf, size_t len)
{
    time_t tt = time(NULL);
    struct tm result;
    if (NULL == localtime_r(&tt, &result)) return NULL;
    
    snprintf(buf, len, "%04d-%02d-%02d %02d:%02d:%02d", 
        result.tm_year+1970, result.tm_mon+1, result.tm_mday,
        result.tm_hour, result.tm_min, result.tm_sec
        );
    return buf;
}

#ifdef __cplusplus
}
#endif
