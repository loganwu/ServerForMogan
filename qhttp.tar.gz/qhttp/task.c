#include "myalloc.h"
#include <errno.h>

#include "autoconfig.h"
#include "global.h"
#include "log.h"
#include "fcntl.h"
#include "shmem.h"
#include "task.h"
#include "thread.h"

struct fdinfo_sigio {
	struct baseconn *conn;
	void (*func)(void *, int);
	void *priv;
};

int register_sigio_callback(int fd, void(*func)(void*,int), void *priv) {
	struct fdinfo_sigio *info;
	if(main_epfd > 0) {
	    struct epoll_event ev;
	    ev.data.fd = fd;
	    ev.events = POLLIN|POLLOUT|EPOLLET;
	    if(fast_epoll_ctl(main_epfd, EPOLL_CTL_ADD, fd, &ev) < 0)
	        return -1;
	} else {
	    if(fast_fcntl(fd, F_SETSIG, rtsigno) < 0)
		return -1;
	    if(fast_fcntl(fd, F_SETOWN, mainthread.pid) < 0)
		return -1;
	}
	info = (struct fdinfo_sigio *)(fdinfo + fd);
	info->func = func;
	info->priv = priv;
	set_stub(fd, sigiostub);
	return 0;
}

int remove_sigio_callback(int fd) {
	if(is_stub(fd, sigiostub)) {
		struct fdinfo_sigio *info = (struct fdinfo_sigio *)(fdinfo + fd);
		set_stub(fd, NULL);
		if(main_epfd > 0) {
		    struct epoll_event ev;
		    ev.data.fd = fd;
		    ev.events = 0;
		    fast_epoll_ctl(main_epfd, EPOLL_CTL_DEL, fd, &ev);
		} else {
		    fast_fcntl(fd, F_SETSIG, 0);
		}
		info->func = NULL;
		info->priv = NULL;
	}
	return 0;
}

void run_sigio_callback(int fd, int band) {
	if(verbose>10)
	cprintf("SIGIO: fd=%d band=%s%s%s%s%s%s%s%s%s%s%s\n", fd,
			band & POLLIN ? "IN " : "",
			band & POLLPRI ? "PRI " : "",
			band & POLLOUT ? "OUT " : "",
			band & POLLMSG ? "MSG " : "",
			band & POLLERR ? "ERR " : "",
			band & POLLHUP ? "HUP " : "",
			band & POLLNVAL ? "NVAL " : "",
			band & POLLRDNORM ? "RDNORM " : "",
			band & POLLRDBAND ? "RDBAND " : "",
			band & POLLWRNORM ? "WRNORM " : "",
			band & POLLWRBAND ? "WRBAND " : ""
	       );

	if(is_stub(fd, sigiostub)) {
		struct fdinfo_sigio *info = (struct fdinfo_sigio *)(fdinfo + fd);
		(info->func)(info->priv, band);
	}
}

struct delaycb {
	struct delaycb *next;
	time_t expire;
	void (*func)(void *);
	void *priv;
};

struct sdcb {
	struct sdcb *next;
	void (*func)(void *);
	void *priv;
};
struct sdcb *sdcb_list = NULL;
struct sdcb *task_list = NULL;
struct delaycb *delay_list = NULL;
struct delaycb *delay_flist = NULL;
static struct sdcb *snext = NULL;

int register_shutdown_callback(void(*func)(void*), void *priv) {
	struct sdcb *sdcb;
	if(get_thread_id()!=0)
		return -1;
	if(func==NULL) return 0;
	sdcb = shalloc(sizeof(struct sdcb));
	if(sdcb==NULL) return -ENOMEM;
	sdcb->func = func;
	sdcb->priv = priv;
	sdcb->next = sdcb_list;
	sdcb_list = sdcb;
	return 0;
}


int register_privilege_task(void(*func)(void*), void *priv) {
	struct sdcb *sdcb, **psdcb;
	if(get_thread_id()!=0)
		return -1;
	if(func==NULL) return 0;
	sdcb = malloc(sizeof(struct sdcb));
	if(sdcb==NULL) return -ENOMEM;
	sdcb->func = func;
	sdcb->priv = priv;
	sdcb->next = NULL;
	psdcb = &task_list;
	while(*psdcb != NULL)
		psdcb = &(*psdcb)->next;
	*psdcb = sdcb;
	return 0;
}

int delay_execute(void(*func)(void*), void *priv, int sec) {
	struct delaycb *dcb, **pdcb;
	if(get_thread_id()!=0)
		return -1;
	if(func==NULL) return 0;
	if(delay_flist==NULL) {
		dcb = malloc(sizeof(struct delaycb));
		if(dcb==NULL) return -ENOMEM;
	} else {
		dcb = delay_flist;
		delay_flist = dcb->next;
	}
	dcb->expire = now + sec;
	dcb->func = func;
	dcb->priv = priv;
	dcb->next = NULL;

	pdcb = &delay_list;
	while(*pdcb != NULL && (*pdcb)->expire<dcb->expire)
		pdcb = &(*pdcb)->next;
	dcb->next = *pdcb;
	*pdcb = dcb;
	return 0;
}

static void check_delay_close(void *priv) {
	int fd = PTR2INT(priv);

	if(is_stub(fd, delaystub)) {
		set_stub(fd, NULL);
		fast_close(fd);
	}
	remove_privilege_task(check_delay_close, priv);
}

#if TRACE_FD
#include <dlfcn.h>
#endif

int delay_close(int fd, int sec) {
	if(fd < 0) return -1;
#if TRACE_FD
#if !LINK_AS_STATIC
	//if(fdinfo[fd].conn)
	{
	    void *addr = __builtin_return_address(0);
	    const char *fn = "unknown";
	    int ln = 0;
	    Dl_info info;
	    if(dladdr(addr, &info)) {
		if(info.dli_sname==NULL) {
		    fn = info.dli_fname;
		    ln = addr - info.dli_fbase;
		} else {
		    fn = info.dli_fname;
		    ln = addr - info.dli_saddr;
		}
	    }
	    lprintf("%s+0x%x: delay_closing inused %.16s fd=%d\n", fn, ln, fdinfo[fd].conn->name, fd);
	}
#endif
#endif
	set_stub(fd, delaystub);
	return delay_execute(check_delay_close, INT2PTR(fd), sec);
}

#ifdef free
static void check_delay_free(void *addr) {
	free(addr);
}
#else
#define check_delay_free free
#endif
int delay_free(void *addr, int sec) {
	if(addr==NULL)
		return -1;
	return delay_execute(check_delay_free, addr, sec);
}

static int remove_task(struct sdcb **list, void (*func)(void *), void *priv) {
	struct sdcb *p;
	if(get_thread_id()!=0)
		return -1;
	if(func==NULL) return 0;
	while((p=*list) != NULL) {
		if(p->func == func && p->priv == priv) {
			if(p==snext)
				snext = p->next;
			*list = p->next;
			free(p);
			return 0;
		}
		list = &p->next;
	}
	return -1;
}

int remove_shutdown_callback(void(*func)(void*), void *priv) {
	return remove_task(&sdcb_list, func, priv);
}

int remove_privilege_task(void(*func)(void*), void *priv) {
	return remove_task(&task_list, func, priv);
}

void run_shutdown_callback(void) {
	struct sdcb *s;
	while(sdcb_list) {
		s = sdcb_list;
		sdcb_list = s->next;
		s->func(s->priv);
	}
}

void run_privilege_task(void) {
	struct sdcb *s;
	struct delaycb *d;
	while(delay_list && delay_list->expire <= now) {
		d = delay_list;
		delay_list = d->next;
		d->func(d->priv);
		d->next = delay_flist;
		delay_flist = d;
	}
	for(s=task_list; s; s=snext) {
		snext = s->next;
		s->func(s->priv);
	}
	snext = NULL;
}

void cleanup_privilege_task(void) {
	struct sdcb *s;
	struct delaycb *d;
	while(delay_list) {
		d = delay_list;
		delay_list = d->next;
		d->func(d->priv);
		free(d);
	}
	while(delay_flist) {
		d = delay_flist;
		delay_flist = delay_flist->next;
		free(d);
	}
	while(task_list) {
		s = task_list;
		task_list = task_list->next;
		free(s);
	}
}

#define MAXWORKERTASK	10
struct worker;
typedef void (*wtsk_t)(struct worker *);
static wtsk_t wtsktab[MAXWORKERTASK] __init__;
static int nwtsk __init__ = 0;

int register_worker_task(wtsk_t t) {
	if(nwtsk < MAXWORKERTASK) {
		wtsktab[nwtsk++] = t;
	}
	return -ENOMEM;
}

void run_worker_task(struct worker *wt) {
	int i;
	for(i=0; i<nwtsk; i++)
		wtsktab[i](wt);
}
