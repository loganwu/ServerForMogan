/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include "myalloc.h"
#include <stdlib.h>
#include <alloca.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>
#include <sys/socket.h>
#include "compat_inotify.h"
#include "compat_dnotify.h"
#include "compat_stat64.h"

#include "autoconfig.h"
#include "myconfig.h"
#include "list.h"
#include "global.h"
#include "filemon.h"
#include "daemon.h"
#include "log.h"
#include "task.h"
#include "thread.h"
#include "list.h"
#include "priv.h"
#include "stat.h"

struct filedir {
	int len;
	const char *dir;
	int access;
};

struct filedir dirlist[6];
#define DIR_ROOT	0
#define DIR_BIN 	1
#define DIR_CONF	2
#define DIR_DOC 	3
#define DIR_LOG 	4
#define DIR_DATA	5

struct filemon {
	struct filemon *next;
	char *filename;
	char *realname;
	int omode;
	int cmode;
	void (*func)(int, void *, stat64_t *);
	void *priv;
	time_t mtime;
	struct list_head dlist;
};

struct dirmon {
	struct dirmon *next;
	char *name;
	int len;
	struct list_head dlist;
	int fd;
};

static int fmpid __init__ = 0;
static int stop_filemon = 0;
static int control_socket = 0;
static int notify_socket = 0;
static struct filemon *filelist = NULL;
static struct filemon *freelist = NULL;
static struct filemon *filenext = NULL;
static struct dirmon *dlist = NULL;

static int fmuid __init__ = 0;
static int fmgid __init__ = 0;

static int inotify_fd __init__ = 0;

static char *expand_filename(const char *filename);
static void scan_dirmon(void *priv, int band);

static void send_error(int sock, int err) {
	fast_send(sock, (void *)&err, sizeof(err), 0);
}

/* sending fd with data in iov */
static void send_fd(int sock, int fd, struct iovec *iov, int n) {
        struct msghdr msg = { 0 };
	struct cmsghdr *cmsg;
	char buf[CMSG_SPACE(sizeof(int))];
	int err = 0;

	if(n==0) {
		iov = alloca(sizeof(struct iovec));
		iov[0].iov_base = &err;
		iov[0].iov_len = sizeof(int);
		n =1;
	}
	msg.msg_control = buf;
	msg.msg_controllen = sizeof buf;
	cmsg = CMSG_FIRSTHDR(&msg);
	cmsg->cmsg_level = SOL_SOCKET;
	cmsg->cmsg_type = SCM_RIGHTS;
	cmsg->cmsg_len = CMSG_LEN(sizeof(int));
	*(int *)CMSG_DATA(cmsg) = fd;
	msg.msg_controllen = cmsg->cmsg_len;

	msg.msg_iov = iov;
	msg.msg_iovlen = n;
	msg.msg_flags = 0;

	fast_sendmsg(sock, &msg, 0);
	fast_close(fd);
}

/* receive fd with data in buffer */
static int recv_fd(int s, void *buffer, int len) {
	int n;
	struct msghdr msg = { 0 };
	struct cmsghdr *cmsg;
	char buf[CMSG_SPACE(sizeof(int))];
	struct iovec iov[2];
	int err = -EINVAL;

	msg.msg_control = buf;
	msg.msg_controllen = sizeof buf;

	iov[0].iov_base = &err;
	iov[0].iov_len = sizeof(int);
	iov[1].iov_base = buffer;
	iov[1].iov_len = len;

	msg.msg_iov = iov;
	msg.msg_iovlen = len<=0?1:2;
	msg.msg_flags = 0;

	n = fast_recvmsg(s, &msg, MSG_TRUNC);
	if(n < sizeof(int))
		err = -EINVAL, n = 0;
	else
		n -= sizeof(int);

	if(msg.msg_controllen<CMSG_SPACE(sizeof(int)))
	    return err;

	cmsg = CMSG_FIRSTHDR(&msg);
	if(cmsg->cmsg_level == SOL_SOCKET &&
		cmsg->cmsg_type == SCM_RIGHTS &&
		cmsg->cmsg_len == CMSG_LEN(sizeof(int)) &&
		msg.msg_controllen == cmsg->cmsg_len)
	{
	    return *(int *)CMSG_DATA(cmsg);
	}
	return n;
}

/* send_req with credential */
static inline int send_req(int sock, struct iovec *iov, int n) {
	return fast_writev(sock, iov, n);
}

static void add_to_dir_monitor(struct filemon *fm) {
	char *rp;
	char *p;
	int namelen;
	struct dirmon *dm;

	INIT_LIST_HEAD(&fm->dlist);
	rp = canonicalize_file_name(fm->realname);
	if(rp==NULL) rp = strdup(fm->realname);
	if(rp==NULL)
		return;
	if((p = strrchr(rp, '/'))==NULL) {
		free(rp);
		return;
	}
	*p = '\0';
	namelen = p - rp;

	for(dm=dlist; dm; dm=dm->next) {
	    if(namelen == dm->len && !memcmp(dm->name, rp, namelen))
	    {
		list_add(&fm->dlist, &dm->dlist);
		free(rp);
		return;
	    }
	}
	dm = malloc(sizeof(struct dirmon));
	dm->len = namelen;
	dm->name = rp;
	INIT_LIST_HEAD(&dm->dlist);
	list_add(&fm->dlist, &dm->dlist);
	if(inotify_fd) {
	    dm->fd = fast_inotify_add_watch(inotify_fd, rp, IN_MOD_MASK);
	} else if(has_dnotify) {
	    dm->fd = fast_open2(rp, O_RDONLY|O_DIRECTORY);
	    if(dm->fd > 0) {
		if(need_filemon) {
		    //fast_fcntl(dm->fd, F_SETSIG, SIGIO);
		    fast_fcntl(dm->fd, F_NOTIFY, DN_CREATE|DN_DELETE|DN_RENAME|DN_MULTISHOT);
		    fast_fcntl(dm->fd, F_SETOWN, fast_getpid());
		} else {
		    fast_fcntl(dm->fd, F_NOTIFY, DN_CREATE|DN_DELETE|DN_RENAME|DN_MULTISHOT);
		    register_sigio_callback(dm->fd, scan_dirmon, dm);
		}
	    }
	}
	dm->next = dlist;
	dlist = dm;
}

static int register_file_monitor0(const char *filename, void (*func)(int, void *, stat64_t *), void *priv) {
	struct filemon *fm;

	if(freelist) {
	    fm = freelist;
	    freelist = fm->next;
	} else {
	    fm = malloc(sizeof(struct filemon));
	}
	fm->filename = strdup(filename);
	fm->realname = expand_filename(filename);
	fm->omode = O_RDONLY;
	fm->cmode = 0666;
	fm->func = func;
	fm->priv = priv;
	fm->mtime = 0;
	INIT_LIST_HEAD(&fm->dlist);
	add_to_dir_monitor(fm);

	fm->next = filelist;
	filelist = fm;

	return 0;
}

int register_file_monitor(const char *filename, void (*func)(int, void *, stat64_t *), void *priv) {
	struct iovec iov[4];

	if(get_thread_id() != 0)
	    return -EPERM;
	if(need_filemon==0)
	    return register_file_monitor0(filename, func, priv);

	iov[0].iov_base = "MONF";
	iov[0].iov_len = 4;
	iov[1].iov_base = &func;
	iov[1].iov_len = sizeof(void *);
	iov[2].iov_base = &priv;
	iov[2].iov_len =  sizeof(void *);
	iov[3].iov_base = (char *)filename;
	iov[3].iov_len = strlen(filename);
	if(send_req(control_socket, iov, 4) < 0)
		return -EPERM;
	return recv_fd(control_socket, NULL, 0);
}

static void checking_file(struct filemon *fm) {
	/* STACK-USAGE: ~~100 */
	int fd;
	stat64_t st;

	fd = fast_open(fm->realname, fm->omode, fm->cmode);
	if(fd < 0 || fast_filestat(fd, &st) < 0)
		memset(&st, 0, sizeof(st));
	if(fm->mtime < st.st_mtime) {
	    if(need_filemon==0) {
		fm->func(fd, fm->priv, &st);
	    } else {
	    	struct iovec iov[4];
		int err = 0;
		iov[0].iov_base = &err;
		iov[0].iov_len  = sizeof(int);
		iov[1].iov_base = &fm->func;
		iov[1].iov_len  = sizeof(void *);
		iov[2].iov_base = &fm->priv;
		iov[2].iov_len  = sizeof(void *);
		iov[3].iov_base = &st;
		iov[3].iov_len  = sizeof(stat64_t);
		send_fd(notify_socket, fd, iov, 4);
	    }
	    fm->mtime = st.st_mtime;
	} else if(fd > 0) {
		fast_close(fd);
	}
}

void checking_monitor_files(void) {
	/* STACK-USAGE: ~~110 */
	struct filemon *fm;
	for(fm=filelist; fm; fm=filenext)
	{
		filenext = fm->next;
		checking_file(fm);
	}
}

static void scan_dirmon(void *priv, int band) {
	struct dirmon *dm = (struct dirmon *)priv;
	struct filemon *fm;
	/* STACK-USAGE: ~~120 */
	list_for_each_entry(fm, &dm->dlist, dlist)
		checking_file(fm);
}

static void scan_dirmon_by_fd(int fd) {
	/* STACK-USAGE: ~~110 */
	struct dirmon *dm;
	for(dm=dlist; dm; dm=dm->next) {
	    struct filemon *fm;
	    list_for_each_entry(fm, &dm->dlist, dlist)
		checking_file(fm);
	}
}

static void inotify_callback(void *priv, int mask) {
	char buf[4096];
	int n;
	while((n=fast_read(inotify_fd, buf, sizeof(buf))) >= sizeof(struct inotify_event)) {
	    if(n<0) break; /* BUGGY gcc 4.1.1 */
	    int i = 0;
	    do {
		struct inotify_event *ev = (struct inotify_event *)(buf+i);
		scan_dirmon_by_fd(ev->wd);
		i += sizeof(*ev)+ev->len;
	    } while(i<n);
	}
}

int remove_file_monitor(const char *filename) {
	struct filemon *fm, **fmp;

	for(fmp=&filelist; (fm=*fmp); fmp = &fm->next) {
		if(!strcmp(fm->filename, filename)) {
			if(fm==filenext)
				filenext = fm->next;
			*fmp = fm->next;
			if(fm->realname != filename)
				free(fm->realname);
			free(fm->filename);
			fm->filename = fm->realname = NULL;
			fm->next = freelist;
			freelist = fm;
			list_del_init(&fm->dlist);
		}
	}
	return -1;
}

struct filedir * RESOLV_FILENAME(const char *filename, const char **fnp) {
	struct filedir *dir = dirlist+DIR_DOC;

	if(filename[0]=='/') {
	    dir = dirlist + DIR_ROOT;
	} else if(filename[0]=='@') {
	    if(filename[1] == '/') {
	        filename +=  2;
	        dir = dirlist + DIR_DOC;
	    } else if(!strncmp(filename+1, "bindir/", 7)) {
	        filename +=  8;
	        dir = dirlist + DIR_BIN;
	    } else if(!strncmp(filename+1, "bin/", 4)) {
	        filename +=  5;
	        dir = dirlist + DIR_BIN;
	    } else if(!strncmp(filename+1, "confdir/", 8)) {
	        filename +=  9;
	        dir = dirlist + DIR_CONF;
	    } else if(!strncmp(filename+1, "etc/", 4)) {
	        filename +=  5;
	        dir = dirlist + DIR_CONF;
	    } else if(!strncmp(filename+1, "docroot/", 8)) {
	        filename +=  9;
	        dir = dirlist + DIR_DOC;
	    } else if(!strncmp(filename+1, "logdir/", 7)) {
	        filename +=  8;
	        dir = dirlist + DIR_LOG;
	    } else if(!strncmp(filename+1, "log/", 4)) {
	        filename +=  5;
	        dir = dirlist + DIR_LOG;
	    } else if(!strncmp(filename+1, "datadir/", 8)) {
	        filename +=  9;
	        dir = dirlist + DIR_DATA;
	    } else if(!strncmp(filename+1, "data/", 5)) {
	        filename +=  6;
	        dir = dirlist + DIR_DATA;
	    } else if(!strncmp(filename+1, "var/", 4)) {
	        filename +=  5;
	        dir = dirlist + DIR_DATA;
	    } else {
	    	return NULL;
	    }
	}
	while(filename[0]=='/')
		filename++;
	*fnp = filename;
	return dir;
}

static char *expand_filename(const char *filename) {
	struct filedir *dir;
	char *realname;

	dir = RESOLV_FILENAME(filename, &filename);
	if(dir==NULL)
	    return NULL;

	realname = malloc(dir->len+1+strlen(filename)+1);
	sprintf(realname, "%s/%s", dir->dir, filename);

	return realname;
}

static int open_global_file0(const char *filename, int omode, int cmode) {
	struct filedir *dir;
	char *realname;

	dir = RESOLV_FILENAME(filename, &filename);
	if(dir==NULL)
	    return -ENOENT;

	realname = alloca(dir->len+1+strlen(filename)+1);
	sprintf(realname, "%s/%s", dir->dir, filename);

	return fast_open(realname, omode, cmode);
}

int open_global_file(const char *filename, int omode, int cmode) {
	struct iovec iov[4];

	if(get_thread_id() != 0)
	    return -EPERM;
	if(need_filemon==0)
	    return open_global_file0(filename, omode, cmode);

	iov[0].iov_base = "OPEN";
	iov[0].iov_len = 4;
	iov[1].iov_base = &omode;
	iov[1].iov_len = sizeof(int);
	iov[2].iov_base = &cmode;
	iov[2].iov_len =  sizeof(int);
	iov[3].iov_base = (char *)filename;
	iov[3].iov_len = strlen(filename);
	if(send_req(control_socket, iov, 4) < 0)
		return -EPERM;

	return recv_fd(control_socket, NULL, 0);
}

static int rotate_global_file0(const char *filename, int omode, int cmode) {
	int n;
	struct filedir *dir;
	char *realname;
	char *rotatename;

	dir = RESOLV_FILENAME(filename, &filename);
	if(dir==NULL)
		return -ENOENT;

	n = dir->len+1+strlen(filename)+1;
	realname = alloca(n);
	rotatename = alloca(n+9);
	sprintf(realname, "%s/%s", dir->dir, filename);

	for(n=1; n<10000; n++) {
	    sprintf(rotatename, "%s.%d", realname, n);
	    if(fast_link(realname, rotatename)==0)
		break;
	}
	fast_unlink(realname);
	return fast_open(realname, omode, cmode);
}

int rotate_global_file(const char *filename, int omode, int cmode) {
	struct iovec iov[4];

	if(get_thread_id() != 0)
	    return -EPERM;
	if(need_filemon==0)
	    return rotate_global_file0(filename, omode, cmode);

	iov[0].iov_base = "ROTF";
	iov[0].iov_len = 4;
	iov[1].iov_base = &omode;
	iov[1].iov_len = sizeof(int);
	iov[2].iov_base = &cmode;
	iov[2].iov_len =  sizeof(int);
	iov[3].iov_base = (char *)filename;
	iov[3].iov_len = strlen(filename);
	if(send_req(control_socket, iov, 4) < 0)
		return -EPERM;

	return recv_fd(control_socket, NULL, 0);
}

static void filemon_event(void *priv, int band) {
	int fd;
	struct {
	    void (*func)(int, void *, stat64_t *);
	    void *priv;
	    stat64_t st;
	} msg;
	memset(&msg, 0, sizeof(msg));
	fd =  recv_fd(notify_socket, &msg, sizeof(msg));
	if(msg.func)
	    msg.func(fd, msg.priv, &msg.st);
	else if(fd>0){
	    fast_close(fd);
	}
}

static void control_task(void) {
	const int sock = control_socket;
	char buf[4096+1];
	int n, fd;
	struct msghdr msg = { 0 };
	char ucbuf[CMSG_SPACE(sizeof(struct ucred))];
	struct iovec iov[1];

	iov[0].iov_base = buf;
	iov[0].iov_len  = 4096;
	msg.msg_control = ucbuf;
	msg.msg_controllen = sizeof ucbuf;
	msg.msg_iov = iov;
	msg.msg_iovlen = 1;
	msg.msg_flags = 0;


	while((n=fast_recvmsg(sock, &msg, MSG_DONTWAIT)) > 0)
	{
	    struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg);
	    struct ucred *uc;
	    if( msg.msg_controllen < sizeof(ucbuf) ||
	    	cmsg->cmsg_level != SOL_SOCKET ||
		    cmsg->cmsg_type != SCM_CREDENTIALS ||
		    cmsg->cmsg_len != CMSG_LEN(sizeof(struct ucred)) ||
		    msg.msg_controllen < cmsg->cmsg_len)
		continue;
	    uc = (struct ucred *)CMSG_DATA(cmsg);
	    if(!(main_chown || uc->uid==0 || (uc->uid==fmuid && uc->gid==fmgid)))
	    	continue;

	    buf[n] = '\0';

	    if(*(uint32_t *)buf == *(uint32_t *)"OPEN")
	    {
		fd = open_global_file0(
			buf+4+2*sizeof(int),
			*(int *)(buf+4),
			*(int *)(buf+4+sizeof(int)));
		if(fd < 0) {
		    send_error(sock, fd);
		} else {
		    send_fd(sock, fd, NULL, 0);
		}
	    }
	    else if(*(uint32_t *)buf == *(uint32_t *)"ROTF")
	    {
		fd = rotate_global_file0(
			buf+4+2*sizeof(int),
			*(int *)(buf+4),
			*(int *)(buf+4+sizeof(int)));
		if(fd < 0) {
		    send_error(sock, fd);
		} else {
		    send_fd(sock, fd, NULL, 0);
		}
	    }
	    else if(*(uint32_t *)buf == *(uint32_t *)"MONF")
	    {
		fd = register_file_monitor0(
			buf+4+2*sizeof(void *),
			*(void **)(buf+4),
			*(void **)(buf+4+sizeof(void *)));
		send_error(sock, fd);
	    }
	    else if(*(uint32_t *)buf == *(uint32_t *)"QUIT")
	    {
	    	stop_filemon = 1;
	    }
	    else
	    {
		cprintf("fm: UNKNOWN FDMON REQ\n");
		send_error(sock, -EINVAL);
	    }
	}
}

static int init_filemon_local(void) {
	int i;

	dirlist[DIR_ROOT].dir = "";
	dirlist[DIR_ROOT].access = 0;

	dirlist[DIR_BIN].dir = bindir;
	dirlist[DIR_BIN].access = 0;;

	dirlist[DIR_CONF].dir = confdir;
	dirlist[DIR_CONF].access = O_RDONLY+1;;

	dirlist[DIR_DOC].dir = docroot;
	dirlist[DIR_DOC].access = O_RDONLY+1;;
	if(dirlist[DIR_DOC].dir==NULL)
	    dirlist[DIR_DOC].dir = "", dirlist[DIR_DOC].access = 0;

	dirlist[DIR_LOG].dir = logdir;
	if(dirlist[DIR_LOG].dir==NULL)
	    dirlist[DIR_LOG].dir = "", dirlist[DIR_LOG].access = 0;

	dirlist[DIR_DATA].dir = datadir;
	if(dirlist[DIR_DATA].dir==NULL)
	    dirlist[DIR_DATA].dir = "",
	    	dirlist[DIR_DATA].access = dirlist[DIR_LOG].access;

	for(i=0; i<5; i++) {
		dirlist[i].len = strlen(dirlist[i].dir);
	}

	if(need_filemon==0) {
	    if(main_epfd) {
		inotify_fd = fast_inotify_init();
		fast_fcntl(inotify_fd, F_SETFL, O_RDONLY|O_NONBLOCK);
		register_sigio_callback(inotify_fd, inotify_callback, NULL);
	    }
	}
	return 0;
}

int init_filemon_client(void) {
	if(need_filemon==0) return init_filemon_local();
	fast_fcntl(notify_socket, F_SETFL, O_RDWR|O_NONBLOCK|O_ASYNC);
	register_sigio_callback(notify_socket,
		filemon_event, INT2PTR(notify_socket));
	return 0;
}

static void filemon_server_rtsig(void) {
	sigset_t sset;
	siginfo_t si;
	int no;

	int pid = fast_getpid();
	sigemptyset(&sset);
	sigaddset(&sset, SIGALRM);
	sigaddset(&sset, SIGIO);
	sigaddset(&sset, SIGUSR1);
	sigaddset(&sset, SIGUSR2);
	sigprocmask(SIG_BLOCK, &sset, NULL);

	fast_setsockopt(control_socket, SOL_SOCKET, SO_PASSCRED, (no=1,&no), sizeof(int));
	fast_fcntl(control_socket, F_SETSIG, SIGUSR1);
	fast_fcntl(control_socket, F_SETOWN, pid);
	fast_fcntl(control_socket, F_SETFL, O_RDWR|O_NONBLOCK|O_ASYNC);

#if ISDSTAT_SUPPORT
	if(statfile) {
	    fast_fcntl(notify_socket, F_SETSIG, SIGUSR2);
	    fast_fcntl(notify_socket, F_SETOWN, pid);
	    fast_fcntl(notify_socket, F_SETFL, O_RDWR|O_NONBLOCK|O_ASYNC);
	}
#endif

	fast_send(control_socket, (void *)&pid, sizeof(int), 0);

	pid = fast_getppid();
	alarm(10);
	while(stop_filemon==0 && pid == fast_getppid()) {
	    no = sigwaitinfo(&sset, &si);
	    now = fast_time();
	    switch(no) {
	    case SIGALRM: alarm(10); checking_monitor_files(); break;
	    case SIGUSR1: control_task(); break;
#if ISDSTAT_SUPPORT
	    case SIGUSR2: pipe_statistics_data(notify_socket); break;
#endif
	    case SIGIO: scan_dirmon_by_fd(si.si_fd); break;
	    }
	}
	exit(0);
}

static void filemon_server_poll(void) {
	struct pollfd pfd[3];
	int npfds = 2;
	int no;

	fast_setsockopt(control_socket, SOL_SOCKET, SO_PASSCRED, (no=1,&no), sizeof(int));
	fast_fcntl(control_socket, F_SETFL, O_RDWR|O_NONBLOCK);
	pfd[0].fd = control_socket;
	pfd[0].events = POLLIN;

	pfd[1].fd = inotify_fd;
	pfd[1].events = POLLIN;

#if ISDSTAT_SUPPORT
	if(statfile) {
	    fast_fcntl(notify_socket, F_SETFL, O_RDWR|O_NONBLOCK);
	    pfd[2].fd = notify_socket;
	    pfd[2].events = POLLIN;
	    npfds = 3;
	}
	pfd[2].revents = 0;
#endif

	fast_send(control_socket, (void *)&npfds, sizeof(int), 0);

	int pid = fast_getppid();
	int next_check = fast_time() + 10;
	while(stop_filemon==0 && pid == fast_getppid()) {
	    int to = (next_check - fast_time())*1000;
	    if(to < 0) to = 0;

	    if(fast_poll(pfd, npfds, to) > 0) {
	    	if(pfd[0].revents & (POLLHUP|POLLERR)) {
			pfd[0].fd = -1;
		} else if(pfd[0].revents & POLLIN) {
			control_task();
		}
		if(pfd[1].revents & POLLIN) {
			inotify_callback(NULL, POLLIN);
		}
#if ISDSTAT_SUPPORT
		if(pfd[2].revents & (POLLHUP|POLLERR)) {
		    npfds = 2;
		} else if(pfd[2].revents & POLLIN) {
		    pipe_statistics_data(pfd[2].fd);
		}
#endif
	    }
	    
	    to = fast_time();
	    if(to >= next_check) {
	    	next_check = to + 10;
		checking_monitor_files();
	    }
	}
	exit(0);
}

int init_filemon_server(void) {
	int control_server, notify_server;
	int s[2];
	int pid;

	if(need_filemon==0) return 0;

	ISDSTAT(statfile = myconfig_get_value("statistics_inbox_file"));
	fast_socketpair(AF_UNIX, SOCK_DGRAM, 0, s);
	control_socket = s[0]; control_server = s[1];
	fast_socketpair(AF_UNIX, SOCK_DGRAM, 0, s);
	notify_socket = s[0]; notify_server = s[1];

	pid=fork();
	if(pid==-1) return -errno;
	if(pid != 0) {
	    // main process
	    fast_close(control_server);
	    fast_close(notify_server);
#if ISDSTAT_SUPPORT
	    if(statfile==NULL)
		fast_close(notify_socket);
	    else {
		int size = 8<<20;
	    	statfd = notify_socket;
		fast_setsockopt(notify_socket, SOL_SOCKET, SO_SNDBUF,
			&size, sizeof(size));
	    }
#endif
	    fast_recv(control_socket, (void *)s, sizeof(int), 0);
	    fmpid = pid;
	    return 0;
	}
	logmode = LOG_DISABLED;

	daemon_set_title("tws-filemon");
	daemon_set_name("tws-filemon");
	set_security_role(ROLE_OWNER);
	fmuid = fast_getuid();
	fmgid = fast_getgid();

	signal(SIGCHLD, SIG_DFL);
	signal(SIGSEGV, SIG_DFL);
	signal(SIGBUS, SIG_DFL);
	signal(SIGILL, SIG_DFL);
	signal(SIGFPE, SIG_DFL);
	signal(SIGABRT, SIG_DFL);
	daemon_close_output();
	init_filemon_local();
	fast_close(control_socket);
	control_socket = control_server;
	notify_socket = notify_server;

	if(has_inotify>0) {
	    inotify_fd = fast_inotify_init();
	    fast_fcntl(inotify_fd, F_SETFL, O_RDONLY|O_NONBLOCK);
	}

	if(inotify_fd)
	    filemon_server_poll();
	else
	    filemon_server_rtsig();
	return 0;
}

void wait_filemon_server(void) {
	if(fmpid) {
	    int status;
	    if(control_socket>0) {
		struct iovec iov[1];
		iov[0].iov_base = "QUIT";
		iov[0].iov_len = 4;
		send_req(control_socket, iov, 1);
		fast_close(control_socket);
		control_socket = 0;
	    }
	    kill(fmpid, SIGTERM);
	    waitpid(fmpid, &status, 0);
	}
}

int init_filemon_watchdog(void) {
	if(need_filemon==0) return 0;
	if(main_epfd > 0)
	    fast_close(main_epfd);
	fast_close(notify_socket);
	return 0;
}

int cleanup_filemon(void) {
	if(need_filemon==0) {
	    struct filemon *fm;
	    struct dirmon *dm;
	    while(freelist != NULL) {
	    	fm = freelist;
		freelist = freelist->next;
		free(fm);
	    }
	    while(filelist) {
	    	fm = filelist;
		filelist = filelist->next;
		if(fm->realname && fm->realname != fm->filename)
			free(fm->realname);
		if(fm->filename)
			free(fm->filename);
		free(fm);
	    }
	    while(dlist) {
	    	dm = dlist;
		dlist = dlist->next;
		if(dm->name)
		    free(dm->name);
		if(inotify_fd <= 0 && dm->fd > 0) {
		    fast_close(dm->fd);
		}
		free(dm);
	    }
	    if(inotify_fd > 0) {
		fast_close(inotify_fd);
	    }
	} else {
	    fast_close(control_socket);
	    fast_close(notify_socket);
	}
	return 0;
}
