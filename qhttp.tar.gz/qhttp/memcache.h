
extern const unsigned int memcache_blocksize;
extern unsigned int memcache_maxsize;
extern unsigned int memcache_overhead;
extern unsigned int memcache_freesize;
extern int memcache_create(int totalsize);
extern void memcache_set_overhead(int overhead);
extern void memcache_destroy(void);
extern void *memcache_alloc(int size);
extern void memcache_free(void *);
