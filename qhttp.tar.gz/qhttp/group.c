/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include "realconfig.h"
#if RELAY_SUPPORT
#include "myalloc.h"
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/mman.h>
#include "compat_ctype.h"
#include "compat_errno.h"

#include "autoconfig.h"
#include "myconfig.h"
#include "util.h"
#include "global.h"
#include "shmem.h"
#include "daemon.h"
#include "log.h"
#include "filemon.h"
#include "task.h"
#include "group.h"
#include "listen.h"
#include "thread.h"
#include "plugin.h"
#include "namemap.h"

typedef struct target_info {
	uint32_t addr;
	uint16_t port;
	uint16_t conn;
} target_info_t;

static int ngroups;
struct group **group_table;
#define for_all_groups(i,g)	for(i=1; g=group_table[i], i<=ngroups ; i++)

static int htsize[6] = { 8, 16, 32, 64, 128, 255 };
static struct target **htlist[6];

static int expand_target_list(struct group *g) {
	int i = 0;
	struct target **old;

	switch(g->mhosts) {
	case 0: i = 0; break;
	case 8: i = 1; break;
	case 16: i = 2; break;
	case 32: i = 3; break;
	case 64: i = 4; break;
	case 128: i = 5; break;
	default:
		  return -1;
	}

	old = g->tlist;
	if(htlist[i]) {
	    g->tlist = htlist[i];
	    htlist[i] = *(struct target ***)g->tlist;
	} else {
	    g->tlist = shalloc(htsize[i] * sizeof(void *));
	    if(g->tlist == NULL)
		return -ENOMEM;
	}
	memset(g->tlist + g->mhosts, 0, (htsize[i]-g->mhosts) * sizeof(void *));
	if(old) {
		memcpy(g->tlist, old, g->mhosts * sizeof(void *));
		*(struct target ***)old = htlist[i-1];
		htlist[i-1] = old;
	}
	g->mhosts = htsize[i];
	return 0;
}

static ftarget_t *
general_sched_target( struct group *g, uint32_t addr, ftarget_t *bad) {
	struct forward_scheduler *s;
	ftarget_t *t;

	s =  g->child ? g->parent->scheduler : g->scheduler;
	if(s==NULL || s->find_target==NULL)
		return NULL;

	if(g->black && match_blacklist(g->black, addr))
		return NULL;

	if(g->sticky) {
		t = get_sticky(g->sticky, addr);
		if(t && ((struct target *)t)->state!=TS_DEAD)
			return (ftarget_t *)t;
	}

	t = s->find_target(s, addr, bad);

	if(t==NULL && g->debugmsg)
	    lprintf("fgroup %s no target available\n", g->name);

	if(t && g->sticky) {
		set_sticky(g->sticky, addr, t);
	}
	return t;
}

ftarget_t * schedule_target(struct group *g, uint32_t addr) {
	return general_sched_target(g, addr, NULL);
}

int no_target_callback(cbdata_t *cp) {
        struct group *g = cp->priv;
	if(g->error_group) {
		cp->ftarget = (void *)g->error_group;
		return RF_FORWARD_GROUP;
	}
	if(g->error_page) {
		if(g->error_page[0]=='/') {
		    cp->url = g->error_page;
		    return RF_NOCACHE|RF_URL;
		} else if(g->append_url==0) {
		    cp->url = g->error_page;
		    return RC_REDIRECT_TMP;
		} else {
		    strcpy(stpcpy(cp->buf, g->error_page), cp->url);
		    cp->url = cp->buf;
		    return RC_REDIRECT_TMP;
		}
	}
	return 0;
}

int group_callback(cbdata_t *cp, struct group *g) {
	ftarget_t *ft = NULL;
	struct target *h;

	h = cp->priv;
	if(h==NULL) {
	    lprintf("fgroup %s callback without target\n", g->name);
	    return 0;
	}
	if(cp->reason<0) h->error = -cp->reason;
	if(cp->retry < g->retry) {
	    if(g->debugmsg > 1)
		lprintf("fgroup %s url %s retry %d\n",
			g->name, cp->url, cp->retry);
	    ft = general_sched_target(g, cp->addr, &h->core);
	} else if(g->debugmsg)
	    lprintf("fgroup %s url %s failed after %d retry\n",
	    	g->name, cp->url, cp->retry);

	if(ft==NULL) {
	    cp->priv = g;
	    return no_target_callback(cp);
	}
	cp->ftarget = ft;
	return RF_FORWARD_TARGET;
}

static struct group *new_group(const char *name) {
	struct group *g;

	if(ngroups == 65535)
		return NULL;

	g = shalloc(sizeof(struct group));
	if(g==NULL)
	    return NULL;
	group_table[++ngroups] = g;
	strncpy(g->name, name, MAX_GROUPNAME_LENGTH);
	g->name[MAX_GROUPNAME_LENGTH] = '\0';
	g->gid = ngroups;
	return g;
}

static const char *
parse_target_info(const char *str, struct target_info *info) {
	uint32_t addr, port, conn;

	addr = str2ip(str, &str);

	if(addr==INADDR_NONE)
		return "invalid address";
	if(*str != '#' && *str != ':' && *str != '\0')
		return "invalid address";

	if(*str==':') {
	    if(is_digit(str[1])==0)
		return "invalid port";
	    port = strtoul(str+1, (char **)&str, 0);
	    if(*str != '#' && *str != '\0')
		return "invalid port";
	    if(port==0 || port >= 65536)
		return "invalid port";
	} else
	    port = 80;

	if(*str=='#') {
	    if(is_digit(str[1])==0)
		return "invalid connections";
	    conn = strtoul(str+1, (char **)&str, 0);
	    if(*str != '\0')
		return "invalid connections";
	    if(conn >= 65536)
		conn = 65535;
	} else 
	    conn = 1000;

	info->addr = addr;
	info->port = htons(port);
	info->conn = conn;
	return NULL;
}

static struct target *
find_target(struct target_info *info, struct target **ht, int total, int removed) {
	struct target *t;
	int i;
	for(i=0; i<total; i++) {
	    if((t=ht[i])==NULL)
		continue;
	    if(t->core.addr==info->addr && t->core.port==info->port)
	    {
	        if(removed)
			ht[i] = NULL;
		return t;
	    }
	}
	return NULL;
}

static void group_add_message(struct group *g, struct target *t) {
	char buf[16];
	ip2str(buf, t->core.addr)[0] = '\0';
	lprintf("fgroup %s: add target %s:%d#%d\n",
		g->name, buf, ntohs(t->core.port), t->mconns);
}

static void group_del_message(struct group *g, struct target *t) {
	char buf[16];
	ip2str(buf, t->core.addr)[0] = '\0';
	lprintf("fgroup %s: remove target %s:%d#%d\n",
		g->name, buf, ntohs(t->core.port), t->mconns);
}

static void group_update_message(struct group *g, struct target *t, uint16_t conn) {
	char buf[16];
	ip2str(buf, t->core.addr)[0] = '\0';
	lprintf("fgroup %s: update target %s:%d#%d to %s:%d#%d\n",
		g->name, buf, ntohs(t->core.port), t->mconns,
		buf, ntohs(t->core.port), conn);
}

static void add_target_to_group(struct group *g, const char *str) {
	struct target_info info;
	struct target *t;
	const char *p;

	p = parse_target_info(str, &info);
	if(p) {
	    lprintf("fgroup %s: Invalid target: %s : %s\n", g->name, str, p);
	    return;
	}
	t = find_target(&info, g->tlist, g->nhosts, 0);
	if(t) {
	    lprintf("fgroup %s: %s alreay in group\n", g->name, str);
	    return;
	}
	if(g->nhosts >= MAX_FORWARD_TARGETS) {
	    lprintf("fgroup %s: only %d targets allowed\n",
	    	g->name, MAX_FORWARD_TARGETS);
	    return;
	}
	t = new_target(g);
	if(t==NULL) {
	    lprintf("fgroup %s: only %d global targets allowed\n",
	    	g->name, MAX_GLOBAL_TARGETS);
	    return;
	}
	t->core.addr = info.addr;
	t->core.port = info.port;
	t->mconns = info.conn;
	t->econns = info.conn;
	if(g->nhosts==g->mhosts)
		expand_target_list(g);
	g->tlist[g->nhosts++] = t;
	t->gid = g->gid;
}

static int load_group_from_fd(struct group *g, int fd) {
	/* STACK-USAGE: 600 */
	int size, i;
	int changed;
	char *buf;
	char *str, *strn;
	const char *p;
	struct target *t;
	struct target *tlist[MAX_FORWARD_TARGETS];
	int nhosts = 0;

	size = fast_lseek(fd, 0L, SEEK_END);
	buf = malloc(size+1);
	if(buf==NULL) {
	    fast_close(fd);
	    return -1;
	}
	fast_lseek(fd, 0L, SEEK_SET);
	fast_read(fd, buf, size);
	fast_close(fd);
	buf[size] = '\0';

	nhosts = g->nhosts;
	memcpy(tlist, g->tlist, sizeof(void *)*nhosts);
	g->nhosts = 0;

	for(changed=0, str=buf, strn=NULL; str; str=strn) {
	    struct target_info info;

	    strn = strchr(str, '\n');
	    if(strn) *strn++ = '\0';
	    str += strspn(str, " \t\r\n");
	    if(str[0]=='\0'||str[0]=='#'||str[0]==';')
		continue;
	    str[strcspn(str, " \t\r\n")] = '\0';

	    p = parse_target_info(str, &info);
	    if(p) {
		lprintf("fgroup %s: Invalid target: %s : %s\n", g->name, str, p);
		continue;
	    }
	    t = find_target(&info, g->tlist, g->nhosts, 0);
	    if(t) {
		lprintf("fgroup %s: %s alreay in group\n", g->name, str);
		continue;
	    }
	    if(g->nhosts >= MAX_FORWARD_TARGETS) {
		lprintf("fgroup %s: only %d targets allowed\n",
			g->name, MAX_FORWARD_TARGETS);
		continue;
	    }
	    t = find_target(&info, tlist, nhosts, 1);
	    if(t) {
	        if(t->mconns != info.conn) {
		    changed = 1;
		    group_update_message(g, t, info.conn);
		    t->mconns = info.conn;
		    t->econns = info.conn;
		}
	    } else {
		t = new_target(g);
		if(t==NULL) {
		    lprintf("fgroup %s: only %d global targets allowed\n",
			    g->name, MAX_GLOBAL_TARGETS);
		    break;
		}
		changed = 1;
		t->core.addr = info.addr;
		t->core.port = info.port;
		t->mconns = info.conn;
		t->econns = info.conn;
		group_add_message(g, t);
	    }
	    if(g->nhosts == g->mhosts)
	    	expand_target_list(g);
	    g->tlist[g->nhosts++] = t;
	}
	free(buf);

	for(i=0; i<nhosts; i++) {
		if((t=tlist[i])==NULL)
			continue;
		group_del_message(g, t);
		changed = 1;
		free_target(t);
	}
	return changed;
}

static void load_group_from_file(struct group *g) {
	int fd;
	fd = open_global_file(g->filename, O_RDONLY, 0);
	if(fd <= 0) {
	    lprintf("group %s: cannot open file %s\n", g->name, g->filename);
	    return;
	}
	load_group_from_fd(g, fd);
	if(g->nhosts==0) {
		lprintf("group %s contains no target\n", g->name);
	}
}

static void update_group_event(int fd, void *priv, stat64_t *st) {
	struct group *g;

	if(fd < 0)
		return;

	g = priv;
	if(load_group_from_fd(g, fd)>0) {
	    struct forward_scheduler *s;
	    if(g->sched==SCHED_ADAPTIVE||g->sched==SCHED_DYNAMIC) {
	    	int i;
	    	for(i=0; i<g->nhosts; i++) {
		    struct target *t = g->tlist[i];
		    if(t->state == TS_STATIC)
		    	verify_target(t);
		}
	    }
	    s = g->scheduler;
	    g->scheduler = new_scheduler_rand(g);
	    if(s != NULL)
		delay_execute(s->cleaner, s, 60);
	}
}

static struct group *find_group(const char *name) {
	struct group *g;
	int i;
	for_all_groups(i, g)
	    if(!strncmp(name, g->name, MAX_GROUPNAME_LENGTH))
		return g;
	return NULL;
}

static void activate_group(struct group *g) {
	if(g->actived) return;
	g->actived = 1;
	if(g->error_group)
	    activate_group(g->error_group);
	if(g->child) {
	    activate_group(g->parent);
	    return;
	}
	if(g->vhostmap) {
	    struct group **gptr = NULL;
	    int n = 0;
	    while((gptr = IterateNameMap(g->vhostmap, gptr, &n)) != NULL)
		if(*gptr)
			activate_group(*gptr);
	}
	if(g->filename) {
	    load_group_from_file(g);
	    register_file_monitor(g->filename, update_group_event, g);
	}
	if(g->blistname)
	    g->black = new_blacklist(g->blistname);
	switch(g->sched) {
	    default:
	    case SCHED_RANDOM:
		g->scheduler = new_scheduler_rand(g);
		break;
	    case SCHED_ADAPTIVE:
		g->scheduler = new_scheduler_arand(g);
		break;
	    case SCHED_DYNAMIC:
		g->scheduler = new_scheduler_drand(g);
		break;
	}
}

struct group *find_forward_group(const char *name) {
	struct group *g = find_group(name);

	if(g && g->actived==0) activate_group(g);
	return g;
}

static void check_dynamic_groups(void *priv);

int init_relay_groups(void) {
	/* STACK-USAGE: 500 */
	struct group *g;
	char *field[100];
	const char *p0;
	int i, j, n;
	char *p = NULL;

	if(has_plugin==0) return 0;

	group_table = shalloc((1<<16)*sizeof(void *));
	if(group_table==NULL) return -ENOMEM;
	target_table = shalloc((1<<16)*sizeof(void *));
	if(target_table==NULL) return -ENOMEM;
	for(i=0; (p0=myconfig_get_multivalue("forward_group", i)); i++) {
	    if(p) free(p);
	    p = strdup(p0);
	    if(p==NULL)
	    	return -ENOMEM;
	    if((n = str_explode(NULL, p, field, 100)) < 2) continue;
	    g = find_group(field[0]);
	    if(g==NULL) {
		g = new_group(field[0]);
		if(g==NULL)
		    return -ENOMEM;
	    }

        // forward.group support file=@confdir/dest.lst
	    if(!strncmp(field[1], "file=", 5)) {
		    if(field[1][5]=='\0') continue; // parameter file without value
		    if(g->filename || g->nhosts)
		        lprintf("fgroup %s already defined\n", field[0]);
		    else if((g->filename = strdup(field[1]+5))==NULL) // Keep "@confdir/dest.lst" to g->filename
		        return -ENOMEM;
	    } 
        else if(!strncmp(field[1], "parent=", 7)) {
		    if(field[1][7]=='\0') continue;
		    if(g->filename || g->nhosts)
		        lprintf("fgroup %s already defined\n", field[0]);
		    else {
		        struct group *pg = find_group(field[1]+7);
		        if(pg==NULL)
			        lprintf("fgroup %s parent %s not defined\n", field[0], field[1]+5);
		        else if(pg->child) {
			        lprintf("fgroup %s parent %s: nest group not supported\n", field[0], field[1]+7);
		        } else {
		    	    g->parent = pg;
			        g->child = 1;
		        }
		    }
	    } 
        // forward.group support sched=dynamic
        else if(!strncmp(field[1], "sched=", 6)) {
		    if(field[1][6]=='\0') continue;
		    j = SCHED_RANDOM;
		    if(!strcmp(field[1]+6, "rand") ||
			    !strcmp(field[1]+6, "static") ||
			    !strcmp(field[1]+6, "random"))
		        j = SCHED_RANDOM;
		    else if(!strcmp(field[1]+6, "adaptive"))
		        j = SCHED_ADAPTIVE;
		    else if(!strcmp(field[1]+6, "dynamic"))
		        j = SCHED_DYNAMIC;
		    else {
		        lprintf("fgroup %s: unknown scheduler %s\n",
			        field[0], field[1]+6);
		    }
    		g->sched = j;
	    } 
        else if(!strncmp(field[1], "blacklist=", 10)) {
		    if(field[1][10]=='\0') continue;
		    if((g->blistname = strdup(field[1]+10))==NULL)
		        return -ENOMEM;
	    } 
        else if(!strncmp(field[1], "error=", 6)) {
		    if(field[1][6]=='\0') continue;
		    if((g->error_page = strdup(field[1]+6))==NULL)
		        return -ENOMEM;
		    int i = strlen(g->error_page);
		    if(i > maxurllen) {
			    free(g->error_page);
			    g->error_page = NULL;
			    continue;
		    }
		    if(i > 5 && g->error_page[i-5]=='/' &&
			    g->error_page[i-4]=='@' &&
			    (g->error_page[i-3]|0x20)=='u' &&
			    (g->error_page[i-2]|0x20)=='r' &&
			    (g->error_page[i-1]|0x20)=='l')
		    {
		        if(i > 500) {
			    free(g->error_page);
			    g->error_page = NULL;
			    continue;
		        } else {
			    g->error_page[i-5] = '\0';
			    g->append_url = 1;
		        }
		    }
	    } 
        else if(!strncmp(field[1], "fallback=", 9)) {
		    if(field[1][6]=='\0') continue;
		    struct group *pg = find_group(field[1]+9);
		    if(pg==NULL)
		        lprintf("fgroup %s fallback %s not defined\n", field[0], field[1]+9);
		    else if(pg==g) {
		        lprintf("fgroup %s fallback to self not supported\n", field[0]);
		    } else {
		        g->error_group = pg;
		    }
	    } 
        // forward.group top vhost=example.qq.com:6666 remap=support
        else if(n==3 && !strncmp(field[1], "vhost=", 6) &&
			!strncmp(field[2], "remap=", 6))
	    {
		    if(field[1][6]=='\0') continue; // field[1] is example.qq.com:6666
		    if(field[2][6]=='\0') continue; // and field[2] is support
		    struct group *pg = find_group(field[2]+6); // field[2]+6 is support, that the name of group
		    if(pg==NULL)
		        lprintf("fgroup %s fallback %s not defined\n", field[0], field[1]+9);
		    else if(pg==g) {
		        lprintf("fgroup %s fallback to self not supported\n", field[0]);
		    } else {
		        if(g->vhostmap==NULL)
			        g->vhostmap = CreateNameMap(256, sizeof(struct group *));
		        struct group **gptr = AddNameToMap(g->vhostmap, field[1]+6); // field[1]+6 is example.qq.com:6666
		        *gptr = pg;
		    }
	    } 
        else if(!strncmp(field[1], "debug=", 6)) {
		    if(field[1][6]=='\0') continue;
		    g->debugmsg = atoi(field[1]+6);
	    } 
        else if(!strncmp(field[1], "retry=", 6)) {
		    if(field[1][6]=='\0') continue;
		    int i = atoi(field[1]+6);
		    if(i < 0)
			    i = 0;
		    else if(i >= 8)
			    i = 7;
		    g->retry = i;
	    } 
        else if(
		    !strcmp(field[1], "mode=store-forward") ||
		    !strcmp(field[1], "mode=store_forward") ||
		    !strcmp(field[1], "mode=storeforward")
		)
	    {
		    g->sfmode = 1;
	    } 
        else {
		    if(g==NULL) {
		        g = new_group(field[0]);
		    } else if(g->filename != NULL) {
		        lprintf("fgroup %s: defined and not static\n",field[0]);
		        continue;
		    }

		    for(j=1; j<n; j++)
		        add_target_to_group(g, field[j]);
	    }
	}
	if(p) free(p);

	n = 0;
	for_all_groups(i, g) {
	    if(g->actived) {
		    if(g->blistname)
			    g->black = new_blacklist(g->blistname);
		    switch(g->sched) {
		        default:
		        case SCHED_RANDOM:
			        g->scheduler = new_scheduler_rand(g);
			        break;
		        case SCHED_ADAPTIVE:
			        g->scheduler = new_scheduler_arand(g);
			        n++;
			        break;
		        case SCHED_DYNAMIC:
			        g->scheduler = new_scheduler_drand(g);
			        n++;
			        break;
		    }
	    }
	}

	register_privilege_task(check_free_targets, NULL);
	register_privilege_task(check_dynamic_groups, NULL);
	return 0;
}

int verify_all_groups(void) {
	sigset_t sset, oset;
	struct group *g;
	int nt = 0;
	int i, j;

	if(ngroups==0) return 0;
	sigemptyset(&sset);
	rtsigno++;
	sigaddset(&sset, rtsigno);
	sigprocmask(SIG_BLOCK, &sset, &oset);

	now = fast_time();
	for_all_groups(i, g) {
	    if(g->actived==0 || g->child)
	    	continue;
	    if(g->nhosts==0) {
	    	lprintf("fgroup %s: contains no targets\n", g->name);
		continue;
	    }
	    if(g->sched!=SCHED_ADAPTIVE&&g->sched!=SCHED_DYNAMIC)
	    	continue;
	    for(j=0; j<g->nhosts; j++) {
		verify_target(g->tlist[j]);
		if(g->tlist[j]->fd > 0) {
		    if(nt==0)
			cprintf("Verifying forwarding groups\n");
		    nt++;
		}
	    }
	}
	while(nt>0) {
	    struct siginfo si;
	    struct timespec tv;
	    int signo;
	    tv.tv_sec = timeout_connect + 1;
	    tv.tv_nsec = 0;
	    signo = sigtimedwait(&sset, &si, &tv);
	    FAST_ERRNO(signo);
	    if(signo == -EINTR)
		continue;

	    if(signo < 0)
	        break;
	    if(signo==rtsigno && si.si_code>0 && si.si_code<=POLL_HUP) {
		run_sigio_callback(si.si_fd, si.si_band);
		nt--;
	    }
	}

	now = fast_time();
	for_all_groups(i, g) {
	    if(g->actived==0 || g->nhosts==0)
		continue;
	    if(g->sched!=SCHED_ADAPTIVE&&g->sched!=SCHED_DYNAMIC)
		continue;
	    for(j=0; j<g->nhosts; j++) {
		if(g->tlist[j]->fd > 0) {
		    verify_result(g->tlist[j], -ETIMEDOUT);
		}
	    }
	}
	rtsigno--;
	sigprocmask(SIG_SETMASK, &oset, NULL);

	if(stop) return -1;
	return 0;
}

static void check_dynamic_groups(void *priv){
	struct group *g;
	int i, j;

	for_all_groups(i, g) {
	    if(g->actived==0 || g->child)
	    	continue;
	    if(g->nhosts==0) {
	    	cprintf("fgroup %s: contains no targets\n", g->name);
		continue;
	    }
	    if(g->sched!=SCHED_ADAPTIVE&&g->sched!=SCHED_DYNAMIC)
	    	continue;
	    for(j=0; j<g->nhosts; j++) {
		/* checking target */
		check_dynamic_target(g->tlist[j]);
	    }
	}
}

#endif
