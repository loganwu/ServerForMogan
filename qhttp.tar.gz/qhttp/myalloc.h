#ifndef __H_MY_ALLOC_H_
#define __H_MY_ALLOC_H_

#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include "realconfig.h"

extern void report_mallinfo(void);
#if DEBUG_MALLOC
extern void dump_non_free(void);
extern void *NONFREE(void *ptr);
extern void *my_malloc_debug(size_t, const char *, unsigned);
extern void *my_realloc_debug(void *, size_t, const char *, unsigned);
extern void *my_memalign_debug(size_t, size_t, const char *, unsigned);
extern void my_free_debug(void *, const char *, int);
extern void *my_calloc_debug(size_t, size_t, const char *, unsigned);
extern char *my_strdup_debug(const char *, const char *, unsigned);
extern char *my_cfn_debug(const char *, const char *, unsigned);
extern void myalloc_init(void);
extern void myalloc_check(void);

#undef malloc
#undef calloc
#undef realloc
#undef memalign
#undef free
#define malloc(x)	my_malloc_debug((x),__FILE__,__LINE__)
#define realloc(x,y)	my_realloc_debug((x),(y),__FILE__,__LINE__)
#define memalign(x,y)	my_memalign_debug((x),(y),__FILE__,__LINE__)
#define calloc(x,y)	my_calloc_debug((x),(y),__FILE__,__LINE__)
#define free(x)		my_free_debug((x),__FILE__,__LINE__)

#undef strdup
#define strdup(x)	my_strdup_debug((x),__FILE__,__LINE__)
#undef canonicalize_file_name
#define canonicalize_file_name(x) my_cfn_debug((x),__FILE__,__LINE__)

#else
static inline void dump_non_free(){}
#define NONFREE(x) (x)
#endif
#endif
