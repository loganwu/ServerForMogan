/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/tcp.h>

#include "autoconfig.h"
#include "myconfig.h"
#include "filemon.h"
#include "global.h"
#include "util.h"
#include "vhost.h"
#include "log.h"
#include "shmem.h"
#include "timestamp.h"
#include "entity.h"
#include "thread.h"
#include "stat.h"
#include "version.h"

static int header_date __init__;
static int header_expire __init__;
static int header_cache __init__;
static int accept_ranges_threshold;
static int last_modified_threshold;
static char header_server[81] __init__;
static int header_server_len __init__;
/*static*/ char *banner_software __init__;
/*static*/ int banner_software_len __init__;
/*static*/ char *banner_address __init__;
/*static*/ int banner_address_len __init__;

struct errmsg {
	const char *resp; int len;	/* response line */
	int code;
	const char *form;		/* form */
};

struct errmsg2 {
	const char *mime;
	char *part1;
	char *part2;
	int len1;
	int len2;
	int maxage;
};

#define ENTRY_RESP(i, s)	[i].resp = #i " " s, [i].len = sizeof(s)+3
#define ENTRY_RSP2(i, s)	[i].resp = s, [i].len = sizeof(s)-1
#define ENTRY_FORM(i, s)	[i].form = s
#define ENTRY_CODE(i, s)	[i].code = s
static const struct errmsg errmsg[600] = {
ENTRY_RESP(100, "Continue"),
ENTRY_RESP(101, "Switching Protocols"),
ENTRY_RESP(102, "Processing"),
ENTRY_RESP(200, "OK"),
ENTRY_RESP(201, "Created"),
ENTRY_RESP(202, "Accepted"),
ENTRY_RESP(203, "Non-Authoritative Information"),
ENTRY_RESP(204, "No Content"),
ENTRY_RESP(205, "Reset Content"),
ENTRY_RESP(206, "Partial Content"),
ENTRY_RESP(300, "Multiple Choices"),
ENTRY_RESP(301, "Moved Permanently"),
ENTRY_FORM(301, "The actual URL is '%s'."),
ENTRY_RESP(302, "Found"),
ENTRY_FORM(302, "The actual URL is '%s'."),
ENTRY_RESP(303, "See Other"),
ENTRY_FORM(303, "The answer to your request is located '%s'."),
ENTRY_RESP(304, "Not Modified"),
ENTRY_RESP(305, "Use Proxy"),
ENTRY_FORM(305, "This resource is only accessible through the proxy '%s'."),
ENTRY_RESP(307, "Temporary Redirect"),
ENTRY_FORM(307, "The actual URL is '%s'."),
ENTRY_RESP(400, "Bad Request"),
ENTRY_FORM(400, "Your request has bad syntax or is inherently impossible to satisfy."),
ENTRY_RESP(401, "Authorization Required"),
ENTRY_FORM(401, "Authorization required for the URL '%s'."),
ENTRY_RESP(402, "Payment Required"),
ENTRY_RESP(403, "Forbidden"),
ENTRY_FORM(403, "You do not have permission to get URL '%s' from this server."),
ENTRY_RESP(404, "Not Found"),
ENTRY_FORM(404, "The requested URL '%s' was not found on this server."),
ENTRY_RESP(405, "Method Not Allowed"),
ENTRY_RESP(406, "Not Acceptable"),
ENTRY_RESP(407, "Proxy Authentication Required"),
ENTRY_FORM(407, "Authorization required for the URL '%s'."),
ENTRY_RESP(408, "Request Time-out"),
ENTRY_FORM(408, "No request appeared within a reasonable time period."),
ENTRY_RESP(409, "Conflict"),
ENTRY_RESP(410, "Gone"),
ENTRY_FORM(410, "The requested URL '%s' was not found on this server, and there is no forwarding address."),
ENTRY_RESP(411, "Length Required"),
ENTRY_FORM(411, "The request method '%s' requires a valid Content-length."),
ENTRY_RESP(412, "Precondition Failed"),
ENTRY_RESP(413, "Request Entity Too Large"),
ENTRY_FORM(413, "The amount data provided in request '%s' exceeds the capacity limit."),
ENTRY_RESP(414, "Request-URI Too Large"),
ENTRY_FORM(414, "The requested URL's length exceeds the capacity limit for this server."),
ENTRY_RESP(415, "Unsupported Media Type"),
ENTRY_FORM(415, "The supplied request data is not in a format acceptable for processing by this resource."),
ENTRY_RESP(416, "Request Range Not Satisfiable"),
ENTRY_RESP(417, "Expectation Failed"),
ENTRY_FORM(417, "The expectation given in the Expect request-header field could not be met by this server."),
ENTRY_RESP(422, "Unprocessable Entity"),
ENTRY_FORM(422, "The server understands the media type of the request entity, but was unable to process the contained instructions."),
ENTRY_RESP(423, "Locked"),
ENTRY_FORM(423, "The requested resource is currently locked."),
ENTRY_RESP(424, "Failed Dependency"),
ENTRY_FORM(424, "The method could not be performed on the resource because the requested action depended on another action and that other action failed."),
ENTRY_RESP(426, "Upgrade Required"),
ENTRY_FORM(426, "The requested resource can only be retrieved using SSL."),
ENTRY_RESP(500, "Internal Error"),
ENTRY_FORM(500, "There was an unusual problem serving the requested URL '%s'."),
ENTRY_RESP(501, "Method Not Implemented"),
ENTRY_FORM(501, "The requested method '%s' is not implemented by this server."),
ENTRY_RESP(502, "Bad Gateway"),
ENTRY_FORM(502, "The proxy server received an invalid response from upstream server."),
ENTRY_RESP(503, "Service Temporarily Unavailable"),
ENTRY_FORM(503, "The requested URL '%s' is temporarily overloaded.  Please try again later."),
ENTRY_RESP(504, "Gateway Time-out"),
ENTRY_FORM(504, "The proxy server did not receive a timely response from the upstream server."),
ENTRY_RESP(505, "HTTP Version Not Supported"),
ENTRY_FORM(505, "This server only support HTTP version 1.0 and 1.1."),
ENTRY_RESP(506, "Variant Also Negotiates"),
ENTRY_FORM(506, "A variant for the requested resource '%s' is itself a negotiable resource."),
ENTRY_RESP(507, "Insufficent Storage"),
ENTRY_FORM(507, "There is insufficient free space left in your storage allocation."),
ENTRY_RESP(510, "Not Extended"),
ENTRY_FORM(510, "A mandatory extension policy in the request is not accepted by the server for this resource."),
ENTRY_RESP(550, "Proxy Host Not Found"),
ENTRY_FORM(550, "Proxy Host Not Found."),
ENTRY_RESP(551, "Network is unreachable"),
ENTRY_FORM(551, "Network is unreachable."),

ENTRY_CODE(450, 403),	/* Bad Referer */
ENTRY_RSP2(450, "403 Forbidden"),
ENTRY_FORM(450, "You do not have permission to get URL '%s' from this server."),

ENTRY_CODE(451, 403),	/* No Referer */
ENTRY_RSP2(451, "403 Forbidden"),
ENTRY_FORM(451, "You do not have permission to get URL '%s' from this server."),
};

static struct errmsg2 *errmsg2;

#define ERRAGE(i) errmsg2[i].maxage
#define ERRMIME(i) errmsg2[i].mime
#define ERRPART1(i) errmsg2[i].part1
#define ERRPART2(i) errmsg2[i].part2
#define ERRLEN1(i) errmsg2[i].len1
#define ERRLEN2(i) errmsg2[i].len2

#define ADDCSTR(s) p=mempcpy(p, s, sizeof(s)-1)
#define ADDLSTR(s,l) p=mempcpy(p, s, l)
#define ADDRESP(i) p=mempcpy(p, errmsg[i].resp, errmsg[i].len)
#define ADDINT(l) p=uint2str(p, l)
#define ADDLINT(l) p=uint2str(p, l)
#define ADDLLINT(l) p=ll2str(p, l)
#define ADDCHAR(c)  *p++ = c
#define ADDRANGE(s,e,l) \
	ADDINT(s), ADDCHAR('-'), ADDINT(e), ADDCHAR('/'), ADDINT(l)
#define ADDLLRANGE(s,e,l) \
	ADDLLINT(s), ADDCHAR('-'), ADDLLINT(e), ADDCHAR('/'), ADDLLINT(l)
#define ADDTSTR(t)	gmtimestr(t,p),p+=29

static void http_header(/*{*/
	struct conn *c,
	int code,
	const char *mime,
	off64_t len,
	time_t mtime,
	off64_t esize
) {
	char *p;

	if(c->vhost==NULL)
		c->vhost = default_vhost();
	c->state = CS_FLUSH_DATA;
	c->sendcode = code;
	c->sendptr = 0;
	if(unlikely(c->no_header)) {
		c->sendlen = 0;
		return;
	}

	if((c->recvptr != c->recvlen) && !c->tcpcork)
	{
	    int cork;
	    if(patch_cork)
		fast_setsockopt(c->netfd, SOL_TCP, TCP_NODELAY,
			    (cork=0,&cork), sizeof(cork));
	    fast_setsockopt(c->netfd, SOL_TCP, TCP_CORK,
			    (cork=1,&cork), sizeof(cork));
	    c->tcpcork = 1;
	}

	/*
	 * assume sendbufsz never overflow, bacause minimum sendbufsz is 1024+maxurllen
	 */ 
	p = c->sendbuf;

	if(c->postsize >= (1<<20)) {
		c->postsize = 0;
		c->keepalive = 0;
	}
	if(c->header_parsed==0)
		c->keepalive = 0;

	/* 25 */
	if(c->expect100 && c->keepalive && c->postsize)
	    ADDCSTR("HTTP/1.1 100-Continue\r\n\r\n");

	/* 25+9 */
	ADDCSTR("HTTP/1.1 ");
	/* 25+9+35 */
	ADDRESP(code);
	/* 25+9+35+80 */
	if(header_server_len) {
	    ADDCSTR("\r\nServer: ");
	    ADDLSTR(header_server, header_server_len);
	}
		
	/* 25+9+35+80+56 */
	if(unlikely(c->keepalive==0)) {
		ADDCSTR("\r\nConnection: close");
	} else if(c->keepalive_header==0) {
	    ADDCSTR("\r\nConnection: keep-alive");
	} else {
	    ADDCSTR("\r\nConnection: keep-alive"
		    "\r\nKeep-Alive: timeout=");
	    ADDINT(timeout_keepalive);
	}
	if(c->entity) {
	    /* 25+9+35+80+56+120 */
	    if(c->cachemode==CACHE_NOCACHE) {
		   ADDCSTR("\r\nCache-Control: no-cache"
		   	   "\r\nPragma: no-cache");
	    } else if(c->cachemode==CACHE_PRIVATE) {
		ADDCSTR("\r\nDate: ");
		ADDLSTR(c->thread->datestr, 29);
		ADDCSTR("\r\nExpires: ");
		ADDTSTR(now - 24*60*60);
		ADDCSTR("\r\nCache-Control: private; max-age=");
		ADDINT(c->expire);
	    } else if(c->expire){
		if(header_expire) {
		    ADDCSTR("\r\nDate: ");
		    ADDLSTR(c->thread->datestr, 29);
		    ADDCSTR("\r\nExpires: ");
		    ADDTSTR(now + c->expire);
		} else if(header_date && mtime && esize >= last_modified_threshold) {
		    ADDCSTR("\r\nDate: ");
		    ADDLSTR(c->thread->datestr, 29);
		}

		if(header_cache) {
		    ADDCSTR("\r\nCache-Control: max-age=");
		    ADDINT(c->expire);
		}
	    } else if(header_date && mtime && esize >= last_modified_threshold) {
		ADDCSTR("\r\nDate: ");
		ADDLSTR(c->thread->datestr, 29);
	    }
	    /* 25+9+35+80+56+120+68 */
	    if(esize >= accept_ranges_threshold && !c->gzipped)
		ADDCSTR("\r\nAccept-Ranges: bytes");
	    if(esize >= last_modified_threshold && mtime) {
		ADDCSTR("\r\nLast-Modified: ");
		ADDTSTR(mtime);
	    }
	} else if(ERRAGE(code)>0) {
		if(header_expire) {
		    ADDCSTR("\r\nDate: ");
		    ADDLSTR(c->thread->datestr, 29);
		    ADDCSTR("\r\nExpires: ");
		    ADDTSTR(now + ERRAGE(code));
		}

		if(header_cache) {
		    ADDCSTR("\r\nCache-Control: max-age=");
		    ADDINT(ERRAGE(code));
		}
	}

	/* 25+9+35+80+56+120+68+82 */
	if(code==206) {
	    ADDCSTR("\r\nContent-Range: bytes ");
	    ADDLLRANGE(c->range_start, c->range_last, esize);
	} else if(code==416) {
	    ADDCSTR("\r\nContent-Range: bytes */");
	    ADDLLINT(esize);
	    len = 0;
	}
	/* 25+9+35+80+56+120+68+82+24 */	    
    if (1 == c->compress_flag) // gzip
        ADDCSTR("\r\nContent-Encoding: gzip");
    else if (2 == c->compress_flag) // deflate
        ADDCSTR("\r\nContent-Encoding: deflate");
    else if(c->gzipped)
	    ADDCSTR("\r\nContent-Encoding: gzip");

	if(mime) {
	    /* 25+9+35+80+56+120+68+82+24+16+128 */
	    ADDCSTR("\r\nContent-Type: ");
	    ADDLSTR(mime, strlen(mime));
	    /* 25+9+35+80+56+120+68+82+24+16+128+37 */
	    ADDCSTR("\r\nContent-Length: ");
	    ADDLLINT(len);
	}
	/* 25+9+35+80+56+120+68+82+24+16+128+37+4 */
	ADDCSTR("\r\n\r\n");

	/* MAX buffer usage: 684 */
	c->sendlen = p - c->sendbuf;
#if DEBUG_MALLOC
	if(c->sendlen > sendbufsz) {
		lprintf("%s(%d): sendbuf overflow: sendlen=%x sendbufsz=%x\n",
		__FILE__, __LINE__, c->sendlen, sendbufsz);
	}
#endif
}/*}*/

#define PART11 "<HTML><HEAD><TITLE>"
#define PART12 "</TITLE></HEAD><BODY><H2>"
#define PART13 "</H2>"
#define PART21 "<HR><ADDRESS><A HREF=\""
#define PART22 "\">"
#define PART23 "</A></ADDRESS></BODY></HTML>\n"

static int init_message_from_file(int i) {
	char key[30];
	const char *mime;

	sprintf(key, "expire_timeout_%d", i);
	ERRAGE(i) = myconfig_get_intval(key, 0);

	sprintf(key, "http_error_message_%d", i);
	char *p = myconfig_get_value(key);
	if(p==NULL)
		return 0;

	int fd = open_global_file(p, O_RDONLY, 0);
	if(fd < 0)
		return 0;
	
	int size = fast_lseek(fd, 0L, SEEK_END);
	if(size > 1<<16) {
		lprintf("message %d file %s size %d > 64K\n", i, p, size);
		return 0;
	}
	if(i>=300 && i<=307) {
	    ERRPART1(i) = shalloc1(size+1+4);
	    if(ERRPART1(i) == NULL)
	    	return -ENOMEM;
	    *(uint32_t *)ERRPART1(i) = *(uint32_t *)"\r\n\r\n";
	    ERRPART1(i) += 4;
	} else {
	    ERRPART1(i) = shalloc1(size+1);
	    if(ERRPART1(i) == NULL)
	    	return -ENOMEM;
	}
	fast_lseek(fd, 0L, SEEK_SET);
	if(fast_read(fd, ERRPART1(i), size) != size) {
		ERRPART1(i) = NULL;
		fast_close(fd);
		return 0;
	}
	fast_close(fd);
	ERRPART1(i)[size] = '\0';

	p = strrchr(p, '.');
	if(p==NULL || strrchr(p, '/'))
		mime = NULL;
	else
		mime = get_mime_type(p+1, NULL);

	if(mime == NULL) mime = "text/html";

	ERRMIME(i) = mime;

	if(strncmp(mime, "text/", 5)==0 && (p=strstr(ERRPART1(i), "%s")))
	{
		if(p == ERRPART1(i)) {
		    ERRPART1(i) = " ";
		    ERRLEN1(i) = 1;
		    size++;
		} else {
		    ERRLEN1(i) = p - ERRPART1(i);
		}
		ERRPART2(i) = p + 2;
		ERRLEN2(i) = size - 2 - ERRLEN1(i);
	} else {
		ERRLEN1(i) = size;
	}
	return 1;
}

static int init_message_internal(int i) {
	int len1, len2;
	int plen1, plen2;

	plen1 = sizeof(PART11)-1 + 
		sizeof(PART12)-1 + 
		sizeof(PART13)-1;
	plen2 = sizeof(PART21)-1 + 
		banner_address_len + 
		sizeof(PART22)-1 + 
		banner_software_len + 
		sizeof(PART23)-1;

	ERRMIME(i) = "text/html";
	const char *p = strstr(errmsg[i].form, "%s");
	if(p) {
	    len1 = p - errmsg[i].form; p+=2;
	    len2 = strlen(p);
	    ERRLEN1(i) = len1+plen1 + 2*errmsg[i].len;
	    ERRLEN2(i) = len2+plen2;
	    if(i>=300 && i <=307) {
		ERRPART1(i) = shalloc1(ERRLEN1(i) + ERRLEN2(i) + 4);
		if(ERRPART1(i) == NULL)
		    return -ENOMEM;
		*(uint32_t *)ERRPART1(i) = *(uint32_t *)"\r\n\r\n";
		ERRPART1(i) += 4;
	    } else {
		ERRPART1(i) = shalloc1(ERRLEN1(i) + ERRLEN2(i));
		if(ERRPART1(i) == NULL)
		    return -ENOMEM;
	    }
	    char *q;
	    q = mempcpy(ERRPART1(i), PART11, sizeof(PART11)-1);
	    q = mempcpy(q, errmsg[i].resp, errmsg[i].len),
	    q = mempcpy(q, PART12, sizeof(PART12)-1),
	    q = mempcpy(q, errmsg[i].resp, errmsg[i].len),
	    q = mempcpy(q, PART13, sizeof(PART13)-1),
	    q = mempcpy(q, errmsg[i].form, len1);
	    ERRPART2(i) = q;
	    q = mempcpy(q, p, len2);
	    q = mempcpy(q, PART21, sizeof(PART21)-1);
	    q = mempcpy(q, banner_address, banner_address_len);
	    q = mempcpy(q, PART22, sizeof(PART22)-1);
	    q = mempcpy(q, banner_software, banner_software_len);
	    q = mempcpy(q, PART23, sizeof(PART23)-1);
	} else {
	    len1 = strlen(errmsg[i].form);
	    ERRLEN1(i) = len1 + plen1 + 2*errmsg[i].len + plen2;
	    ERRPART1(i) = shalloc1(ERRLEN1(i));
	    if(ERRPART1(i) == NULL)
		return -ENOMEM;
	    char *q;
	    q = mempcpy(ERRPART1(i), PART11, sizeof(PART11)-1);
	    q = mempcpy(q, errmsg[i].resp, errmsg[i].len);
	    q = mempcpy(q, PART12, sizeof(PART12)-1),
	    q = mempcpy(q, errmsg[i].resp, errmsg[i].len),
	    q = mempcpy(q, PART13, sizeof(PART13)-1);
	    q = mempcpy(q, errmsg[i].form, len1);
	    q = mempcpy(q, PART21, sizeof(PART21)-1);
	    q = mempcpy(q, banner_address, banner_address_len);
	    q = mempcpy(q, PART22, sizeof(PART22)-1);
	    q = mempcpy(q, banner_software, banner_software_len);
	    q = mempcpy(q, PART23, sizeof(PART23)-1);
	}
	return 0;
}

static int init_error_messages(void) {
	int i, rv;

	errmsg2 = shalloc(600 * sizeof(struct errmsg2));
	if(errmsg2==NULL) return -ENOMEM;
	for(i=0; i<600; i++) {
	    if(errmsg[i].form==NULL) continue;
	    if((rv=init_message_from_file(i)) != 0)
	    	return rv;
	    if(rv)
	    	continue;
	    if(errmsg[i].code) {
	    	ERRPART1(i) = ERRPART1(errmsg[i].code);
	    	ERRLEN1(i) = ERRLEN1(errmsg[i].code);
	    	ERRPART2(i) = ERRPART2(errmsg[i].code);
	    	ERRLEN2(i) = ERRLEN2(errmsg[i].code);
	    } else
		init_message_internal(i);
	}
	return 0;
}


int init_response_messages(void) {
#if 0
	header_server = myconfig_get_value("header_server");
	if(header_server==NULL || header_server[0]=='\0') {
	    header_server = "TWS";
	    header_server_len = 3;
	} else if(!strcasecmp(header_server, "DISABLED"))
	    header_server = NULL;
	if(header_server) {
	    header_server_len = strlen(header_server);
	    if(header_server_len > 80)
		header_server_len = 80;
	}
#else
	strcpy(header_server, "TWS-");
	strcpy(&header_server[4], qhttpd_version_string);
	header_server_len = strlen(header_server);
#endif

	banner_address = myconfig_get_value("banner_address");
	if(banner_address==NULL || banner_address[0]=='\0')
	    banner_address = "http://www.tencent.com/";
	banner_address_len = strlen(banner_address);

	banner_software = myconfig_get_value("banner_software");
	if((banner_software==NULL || banner_software[0]=='\0') &&
			header_server )
	{
	    banner_software = shalloc1(header_server_len+8);
	    memcpy(mempcpy(banner_software, header_server, header_server_len), " Server", 8);
	}
	if(banner_software==NULL || banner_software[0]=='\0')
	    banner_software = banner_address;
	banner_software_len = strlen(banner_software);

	header_date = myconfig_get_intval("header_date", 1);
	header_expire = myconfig_get_intval("header_expire", 1);
	header_cache = myconfig_get_intval("header_cache", 1);

	accept_ranges_threshold = myconfig_get_intval("accept_ranges_threshold", 51200);
	last_modified_threshold = myconfig_get_intval("last_modified_threshold", 256);

	init_error_messages();
	return 0;
}

static inline struct iovec * GETIOV(struct conn *c, int n) {
	return (struct iovec *)(c->sendbuf + ((n+7)&~7));
}

static inline void SETIOV(struct conn *c, struct iovec *v, int n) {
	c->sendiov = v;
	c->sendfd = 1;
	c->sendlen = 0;
	c->sendptr = n;
	v += n;
#if DEBUG_MALLOC
	if((char *)v < c->sendbuf || (char *)v > c->sendbuf+sendbufsz) {
		lprintf("%s(%d): sendbuf overflow: iov=%p n=%d sendbuf=%p-%p\n",
		__FILE__, __LINE__, v-n, n, c->sendbuf, c->sendbuf+sendbufsz);
	}
#endif
}

void http_error(struct conn *c, int code, const char *url) {
	int i;
	int len;

    if (404 == code) ISDSTAT(atomic_inc(&countermap->error404));;
    if (550 == code) ISDSTAT(atomic_inc(&countermap->error550));;
    if (551 == code) ISDSTAT(atomic_inc(&countermap->error551));;

	if(url==NULL ||(c->urloverwriten && url==c->url))
	    url="";
	if(code<200 || code >=600 || errmsg[code].len==0)
	    code = 500;
	if(ERRLEN1(code)==0) {
	    http_header(c, code, NULL, 0, 0, 0);
	    return;
	}
	len = strlen(url); if(len>maxurllen) len = maxurllen;
	http_header(c, code, ERRMIME(code)?:"text/html",
		ERRLEN2(code)==0 ? ERRLEN1(code) :
		ERRLEN1(code) + len + ERRLEN2(code),
		0, 0);
	int n = c->sendlen + 8 + (url==c->url ? 0 : len);
	struct iovec *v = GETIOV(c, n);

	if((c->method==METHOD_HEAD)) {
	    if(code>=300 && code <=307 && len) {
		    memcpy(c->sendbuf+c->sendlen-2, "Location: ", 10);
		    c->sendlen += 8;

		    v[0].iov_base = c->sendbuf;
		    v[0].iov_len  = c->sendlen;

	        if(url==c->url) {
		        v[1].iov_base = (char *)url;
		    }
            else {
		        v[1].iov_base = c->sendbuf+c->sendlen;
		        memmove(v[1].iov_base, url, len);
		    }
            
		    v[1].iov_len  = len;
		    v[2].iov_base = "\r\n\r\n";
		    v[2].iov_len  = 4;
		    SETIOV(c, v, 3);
	    }
	    return;
	}

	i = 0;
	if(c->sendlen==0) {
	    /* NO HEADER, PART1 ONLY */
	    v[i].iov_base = ERRPART1(code);
	    v[i].iov_len  = ERRLEN1(code);
	    i++;
	} else if(code>=300 && code <=307 && len) {
	    /* REDIR: header1+URL+header2+part1 */
	    memcpy(c->sendbuf+c->sendlen-2, "Location: ", 10);
	    c->sendlen += 8;

	    v[i].iov_base = c->sendbuf;
	    v[i].iov_len  = c->sendlen;
	    i++;

	    if(url==c->url) {
		v[1].iov_base = (char *)url;
	    } else {
		v[1].iov_base = c->sendbuf+c->sendlen;
		memmove(v[1].iov_base, url, len);
		url = NULL;
	    }
	    v[1].iov_len  = len;
	    i++;
	    v[i].iov_base = ERRPART1(code) - 4;
	    v[i].iov_len  = ERRLEN1(code) + 4;
	    i++;
	} else {
	    /* REDIR: header+part1 */
	    v[i].iov_base = c->sendbuf;
	    v[i].iov_len  = c->sendlen;
	    i++;
	    v[i].iov_base = ERRPART1(code);
	    v[i].iov_len  = ERRLEN1(code);
	    i++;
	}
	if(ERRLEN2(code)) {
	    if(len) {
		if(url==NULL) {
		    v[i].iov_base = v[1].iov_base;
		} else if(url==c->url) {
		    v[i].iov_base = (char *)url;
		} else {
		    v[i].iov_base = c->sendbuf+c->sendlen;
		    memmove(v[i].iov_base, url, len);
		}
		v[i].iov_len  = len;
		i++;
	    }
	    v[i].iov_base = ERRPART2(code);
	    v[i].iov_len  = ERRLEN2(code);
	    i++;
	}
	if(i>1) SETIOV(c, v, i);
}

void http_redirect_directory(struct conn *c) {
	int l;
	if(c->urloverwriten || (l=strlen(c->url)) >= maxurllen) {
	    http_error(c, 404, c->url);
	} else {
	    c->url[l] = '/';
	    c->url[l+1] = '\0';
	    http_error(c, 301, c->url);
	}
}

static void http_response_fdent(struct conn *c) {
	struct fdentity *ent = fdent(c->entity);
#define FD 	PTR2INT(c->entity)
#define SIZE	ent->size
#define MIME	ent->mime
#define MTIME	ent->mtime
#define ZFD	ent->zfd
#define ZSIZE	fdent(ent->zfd)->size
#include "response.ims.c"
}

static void http_response_mement(struct conn *c) {
	struct mementity *ent = c->entity;
	if(ent->fd) {
#define FD 	ent->fd
#define SIZE	ent->size
#define MIME	ent->mime
#define MTIME	ent->mtime
#define EOFF	ent->offset[0]
#define ZSIZE	ent->zsize
#include "response.ims.c"
	} else {
#define PTR	ent->data
#define SIZE	ent->size
#define MIME	ent->mime
#define MTIME	ent->mtime
#define ZPTR	(ent->data+ent->size)
#define ZSIZE	ent->zsize
#include "response.ims.c"
	}
}

void http_response(struct conn *c) {
	if(isptr(c->entity))
		http_response_mement(c);
	else if(isfd(c->entity))
		http_response_fdent(c);
	else
		http_error(c, 500, c->url);
}

void http_send_content(/*{*/
	struct conn *c,
	const char *content,
	const char *mime,
	time_t mtime,
	int len
){
	c->entity = (void *) 1;
    	if(mtime) {
	    if(c->ims==IMS) {
		if(mtime == c->imstime) {
		    http_header(c, 304, NULL, 0, mtime, len);
		    return;
		}
	    } else if(c->ims==IUMS) {
		if(mtime != c->imstime) {
		    http_header(c, 412, NULL, 0, mtime, len);
		    return;
		}
	    }
	}

	http_header(c, 200, mime, len, mtime, len);
	if(c->method==METHOD_HEAD) return;
	if(c->sendlen + len > sendbufsz) {
	    len = sendbufsz - c->sendlen;
	    http_header(c, 200, mime, len, mtime, len);
	}
	if(len) {
	    int bytes;
	    if(c->sendlen==0) {
		bytes = fast_send(c->netfd, content, len, MSG_DONTWAIT|MSG_NOSIGNAL);
	    } else {
		struct iovec v[2];
		v[0].iov_base = c->sendbuf;
		v[0].iov_len = c->sendlen;
		v[1].iov_base = (char *)content;
		v[1].iov_len = len;
		bytes = fast_writev(c->netfd, v, 2);
	    }
	    if(bytes > 0) {
		c->logsize += bytes;
		if(c->vhost) {
#if HAS_ATOMIC8
		    atomic8_add(bytes, &c->vhost->bytes);
#else
		    atomic_add(bytes & 0x3FF, &c->vhost->bytes);
		    if((bytes>>10))
			atomic_add(bytes>>10, &c->vhost->kbytes);
#endif
		}
		if(bytes < c->sendlen) { /* header not sent */
		    c->sendptr = bytes;
		} else {
		    bytes -= c->sendlen;
		    content += bytes;
		    len -= bytes;
		    c->sendlen = 0;
		}
	    }
	    if(len) {
		memcpy(c->sendbuf+c->sendlen, content, len);
		c->sendlen += len;
	    }
	}
} /*}*/

static void http_response_fdent_sub(struct conn *c, const char *mime, time_t mtime, off64_t off, int len) {
	struct fdentity *ent = fdent(c->entity);
	if(off > ent->size)
		off = ent->size;
	if(off+len > ent->size)
		len = ent->size - off;
#define FD 	PTR2INT(c->entity)
#define SIZE	len
#define MIME	mime
#define MTIME	mtime
#define EOFF	off
#define ESIZE	ent->size
#define ZFD	ent->zfd
#define ZSIZE	fdent(ent->zfd)->size
#include "response.ims.c"
}

static void http_response_mement_sub(struct conn *c, const char *mime, time_t mtime, off64_t off, int len) {
	struct mementity *ent = c->entity;
	if(off > ent->size)
		off = ent->size;
	if(off+len > ent->size)
		len = ent->size - off;
	if(ent->fd) {
#define FD 	ent->fd
#define SIZE	len
#define MIME	ent->mime
#define MTIME	ent->mtime
#define EOFF	(ent->offset[0] + off)
#define ESIZE	ent->size
#define ZSIZE	ent->zsize
#include "response.ims.c"
	} else {
#define PTR	ent->data
#define SIZE	len
#define MIME	mime
#define MTIME	mtime
#define EOFF	off
#define ESIZE	ent->size
#define ZPTR	(ent->data+ent->size)
#define ZSIZE	ent->zsize
#include "response.ims.c"
	}
}

void http_response_sub(struct conn *c, const char *mime, time_t mtime, off64_t off, int len) {
	if(isptr(c->entity))
		http_response_mement_sub(c, mime, mtime, off, len);
	else if(isfd(c->entity))
		http_response_fdent_sub(c, mime, mtime, off, len);
	else
		http_error(c, 500, c->url);
}

void http_response_fd(struct conn *c, int fd, const char *mime, time_t mtime, off64_t off, int len) {
	ENTITY_TRACE(NULL);
	ISDSTAT(atomic_inc(&countermap->openfds));
	c->entity = INT2PTR(fd);
	fdent(fd)->entity = NULL;
	fdent(fd)->zfd = 0;
#define FD 	fd
#define SIZE	len
#define MIME	mime
#define MTIME	mtime
#define EOFF	off
#include "response.ims.c"
}

