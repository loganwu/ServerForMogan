/* vim: set sw=4 ai fdm=marker fmr={{{,}}} :*/

/* headers {{{1 */
#include "myalloc.h"
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include "compat_errno.h"
#include "compat_sendfile64.h"

#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "memcache.h"
#include "entity_hash.h"
#include "global.h"
#include "atomic.h"
#include "list.h"
#include "shmem.h"
#include "md5.h"
#include "thread.h"
#include "log.h"
#include "timestamp.h"
#include "profile.h"
#include "task.h"
#include "util.h"
#include "filecount.h"
/* }}}1 */

//#define USE_LOG_CALLSTACK

/* globals {{{1 */

struct tfcinfo {
	struct list_head *hash;
	struct list_head lru;
	struct list_head exp;
	struct list_head nexp;
	struct entity_hash *entry;
	struct entity_hash **sortbuf;
	struct entity_up *promote;
	int uptsc4;
	int tsc4;
	volatile uint16_t promotecount;
};

struct gcache {
    struct entity_hash *entry;
    struct entity_hash expired;
    struct entity_hash freelist;
    struct entity_hash **sort;
    int maxslots;
    int usedslots;
    int freeslots;
    int expiredslots;
};

struct entity_up {
	unsigned char hash[16];
	uint32_t fd;
	uint32_t tsc4;
};

static int hashmask __init__= (1<<13)-1;
static int threadslots __init__= 0;
static int promoteslots __init__;
static int promotehits __init__;

static struct list_head *globalhash;
static uint64_t gtsc;
static struct gcache gfd;
static struct gcache gmem;
static int gmem_totalsize;
static int gmem_maxsize;
/* }}}1 */

/* hashidx() {{{1 */
static inline int hashidx(const unsigned char h[16]) {
	return hashmask & *(uint16_t *)h;
}
/* }}}1 */

/* ghashidx() {{{1 */
static inline int ghashidx(const unsigned char h[16]) {
	return *(uint16_t *)h;
}
/* }}}1 */

/* close_entity() {{{1 */
static inline void close_entity(struct entity_hash * ent) {
	if(isfd(ent->fd)) {
	    close_fdentity(ent->fd);
	}
	ent->fd = OE_BAD;
}
/* }}}1 */

/* get_entity_cache() {{{1 */
static int get_entity_lockless(struct worker *wt, const char *filename, void **pent) {
	unsigned char hash[16];
	struct entity_hash *ent0;
	int nocache=0;
	md5_t ctx;
	int rv;
	struct tfcinfo *fc = wt->tfc;

	*pent = NULL;

	MD5Init(&ctx);
	MD5Update(&ctx, (const unsigned char *)filename, strlen(filename));
	MD5Final(hash, &ctx);

	uint64_t tsc = readtsc();
	ent0 = NULL;

	ENTITY_TRACE(NULL);
	/* search global hash table {{{2*/
	if(gfd.maxslots) {
	    volatile struct list_head *list;
	    struct entity_hash *ent;

	    /* be carefull: this list may change during traverse */
	    list_for_each_entry_safe_l(ent, list,
				       globalhash+ghashidx(hash),list)
	    {
		    if(ent->expired) {
		        if(verbose>=10)
		    	    lprintf("list changing, try nocache\n");
		        nocache = 1;
		        break;
		    }
		    if(ent->expiring) continue;
		    if(hasheq(hash, ent->hash)) {
		        atomic_inc(&ent->count);
		        if(ent->tsc4 < TSCRND(tsc)) {
			        ent0 = ent;
			        break;
		        }
		        ent->hits = TSCRND(tsc);
		        *pent = hash2ent(ent);
				ENTITY_TRACE("get entity from gfd");
				#ifdef USE_ENTITY_TRACE					
					char* en_type[8] = {
										"ET_UNUSED",
										"ET_LOCAL",
										"ET_NEGATIVE",
										"ET_GLOBAL",
										"ET_MEMORY",
										"ET_OFFSET",
										"ET_BAD"
										};
					lprintf("[%lu]entity type is %s", (unsigned long)pthread_self(), en_type[ent->type]);
				#endif // USE_ENTITY_TRACE
		        return 0;
		    }
	    }
	}
	/* }}}2 */

	/* search thread hash table {{{2*/
	if(ent0==NULL) {
	    struct entity_hash *ent = NULL;
	    list_for_each_entry(ent, fc->hash+hashidx(hash), list) {
		    if(hasheq(hash, ent->hash)) {
		        if(ent->type == ET_NEGATIVE) {
			        if(ent->tsc4 < TSCRND(tsc)) continue;
			        if(atomic_read(&ent->count) >= 0 || atomic_read(&ent->count) < -2)
			        {
			            lprintf("BAD negative cache value %d\n", atomic_read(&ent->count));
			            return -4;
			        }
			        return atomic_read(&ent->count);
		        }
		        atomic_inc(&ent->count);
		        if(ent->tsc4 < TSCRND(tsc)) {
			        ent0 = ent;
			        break;
		        }
		        list_del_init(&ent->lru);
		        ++ent->hits;
		        *pent = fd2ent(ent->fd);
				ENTITY_TRACE("get entity from thread");
		        return 0;
		    }
	    }
	}
	/* }}}2 */

	if(nocache || list_empty(&fc->lru)) {
	    return get_entity_nocache(wt, filename, pent);
	}

	if(ent0==NULL) {
	    PROFILE_START;
	    rv = open_fdentity(filename, wt);
	    PROFILE_WORKER(PROFILE_INIT_ENTITY);
	} else {
	    /* refresh entity {{{2 */
	    PROFILE_START;
	    if(ent0->type == ET_MEMORY)
			rv = update_mementity(filename, mem2ent(ent0), wt);
	    else
			rv = update_fdentity(filename, fdent(ent0->fd), ent0->type==ET_LOCAL, wt);
	    PROFILE_WORKER(PROFILE_INIT_ENTITY);

	    if(rv == OE_FRESH) {
		    ent0->tsc4 = TSCRND(tsc) + tsc4_fdcache;
		    if(ent0->type == ET_LOCAL)
		    {
		        list_del_init(&ent0->lru);
		        ++ent0->hits;
		        list_move(&ent0->list, fc->hash+hashidx(hash));
		        list_move_tail(&ent0->exp, &fc->exp);
		    } else {
		        ent0->hits = TSCRND(tsc);
		    }
		    *pent = hash2ent(ent0);
		    return 0;
	    }
	    if(ent0->type == ET_LOCAL) {
			//close_fdentity(ent0->fd); // fd-leak?
		    atomic_dec(&ent0->count);
		    list_del_init(&ent0->list);
		    if(atomic_read(&ent0->count)==0)
			    list_move(&ent0->lru, &fc->lru);
	    } else {
		    ent0->expiring = 1;
		    barrier();
		    atomic_dec(&ent0->count);
	    }
	    /* }}}2 */
	}

	if(rv > 2) {
	    /* entity OK {{{2 */
	    struct entity_hash *ent;
	    ent = list_entry(fc->lru.next, struct entity_hash, lru);
	    if(isfd(ent->fd)) {
    #if TRACE_FD
		    if(atomic_read(&ent->count) != 0) {
		        lprintf("%s(%d): INVALID counter %d fd %d in LRU\n", __FILE__, __LINE__, atomic_read(&ent->count), ent->fd);
		    }
    #endif
            close_fdentity(ent->fd);
		    //list_del_init(&ent->lru);
	    } //else {
#if TRACE_FD
		strcpy(ent->name, "threadentity");
#endif
		ent->type = ET_LOCAL;
		ent->flag = 0;
		ent->expired = 0;
		ent->expiring = 0;
		atomic_set(&ent->count, 1);
		ent->hits = 1;
		list_del_init(&ent->lru);
		ent->tsc4 = TSCRND(tsc) + tsc4_fdcache;
		hashcp(ent->hash, hash);
		list_move(&ent->list, fc->hash+hashidx(hash));
		list_move_tail(&ent->exp, &fc->exp);
		fdent(rv)->entity = ent;
		ent->fd = rv;
	    //}
	    *pent = fd2ent(rv);
	    /* }}}2 */
	    return 0;
	} else if(tsc4_fdcache_negative) {
	    /* entity BAD {{{2 */
	    struct entity_hash *ent;
	    ent = list_entry(fc->lru.next, struct entity_hash, lru);
	    if(isfd(ent->fd)) {
    #if TRACE_FD
		    if(atomic_read(&ent->count) != 0) {
		        lprintf("%s(%d): INVALID counter %d fd %d in LRU\n", __FILE__, __LINE__, atomic_read(&ent->count), ent->fd);
		    }
    #endif
            close_fdentity(ent->fd);
		    //list_del_init(&ent->lru);
	    } //else {
#if TRACE_FD
		strcpy(ent->name, "negativeentity");
#endif
		ent->fd = OE_BAD;
		atomic_set(&ent->count, -rv-1);
		ent->hits = 0;
		ent->flag = 0;
		ent->expired = 0;
		ent->expiring = 0;
		ent->type = ET_NEGATIVE;
		list_move_tail(&ent->lru, &fc->lru);
		ent->tsc4 = TSCRND(tsc) + tsc4_fdcache_negative;
		hashcp(ent->hash, hash);
		list_move(&ent->list, fc->hash+hashidx(hash));
		list_move_tail(&ent->exp, &fc->nexp);
	    //}
	    /* }}}2 */
	}

	return -rv-1;
}
/* }}}1 */

/* put_entity_cache() {{{1 */
static void put_entity_lockless(struct worker *wt, void *ent0) {
	if(isfd(ent0)) {
	    int fd = PTR2INT(ent0);
	    struct entity_hash *ent = fdent(fd)->entity;
	    if(ent==NULL) {
			ENTITY_TRACE(NULL);
		    close_fdentity(fd);
	    } 
        else if(atomic_dec_and_test(&ent->count)) {
			ENTITY_TRACE(NULL);
			if(ent->type==ET_LOCAL) {
				ENTITY_TRACE(NULL);
		        list_move_tail(&ent->lru, &wt->tfc->lru);
			}
	    }
	} else if(isptr(ent0)) {
		ENTITY_TRACE(NULL);
	    struct entity_hash *ent = ent2mem(ent0);
	    atomic_dec(&ent->count);
	}
}
/* }}}1 */

static void gcache_init(struct gcache *gc) {
	gc->entry = NULL;
	INIT_LIST_HEAD(&gc->freelist.list);
	INIT_LIST_HEAD(&gc->expired.list);
	gc->expired.type = ET_BAD;
	gc->expired.expired = 1;
	gc->expired.expiring = 1;
	gc->freelist.type = ET_BAD;
	gc->freelist.expired = 1;
	gc->freelist.expiring = 1;
	gc->usedslots = 0;
	gc->freeslots = 0;
	gc->sort = NULL;
}

static int gcache_init_sortbuf(struct gcache *gc) {
	if(gc->maxslots==0) return 0;
	gc->sort = malloc(gc->maxslots*sizeof(void *));
	
    if(gc->sort==NULL) return -ENOMEM;
	return 0;
}

static int gcache_expand_sortbuf(struct gcache *gc) {
	if(gc->maxslots==0) return 0;
    
	struct entity_hash **ptr = realloc(gc->sort, gc->maxslots*sizeof(void *)*2);
	if(ptr==NULL) return -ENOMEM;

	gc->sort = ptr;
	gc->maxslots *= 2;
	return 0;
}

static int gcache_init_slots(struct gcache *gc) {
	int i;
	if(gc->maxslots==0) return 0;
	gc->entry = shalloc(gc->maxslots*sizeof(struct entity_hash));
	if(gc->entry==NULL) 
        return -ENOMEM;
	for(i=0; i<gfd.maxslots; i++) {
	    atomic_set(&gc->entry[i].count, 0);
	    gc->entry[i].hits = 0;
	    gc->entry[i].fd = 0;
	    gc->entry[i].type = ET_GLOBAL;
	    gc->entry[i].flag = 0;
	    list_add(&gc->entry[i].list, &gc->freelist.list);
	    gc->freeslots++;
	}
	return 0;
}

static void gcache_free(struct gcache *gc) {
	if(gc->entry) {
	    int i;
	    for(i=0; i<gc->maxslots; i++) {
		    if(isfd(gc->entry[i].fd)) {
		        close_fdentity(gc->entry[i].fd);
		    }
	    }
	}
    if(gc->sort) {
        free(gc->sort);
        gc->sort = NULL;
    }
}

/* gcache_expire() {{{1 */
static inline void gcache_expire(struct gcache *gc, int n) {
	struct entity_hash *ent = gc->sort[n];
	list_move_tail(&ent->list, &gc->expired.list);
	ent->expired = 1;
	ent->expiring = 1;
	ent->exp4 = TSCRND(gtsc + tscmin);
	gc->expiredslots++;
	gc->usedslots--;
	if(n < gc->usedslots) {
		ent = gc->sort[gc->usedslots];
		gc->sort[n] = ent;
		ent->sortid = n;
	}
}
/* }}}1 */

/* gcache_batch_expire() {{{1 */
static inline void gcache_batch_expire(struct gcache *gc, int n) {
	int i;
	split_entity_hits(gc->sort, gc->usedslots, n);
	for(i=0; i<gc->usedslots; i++)
		gc->sort[i]->sortid = i;
	
	while(gc->usedslots > n)
	    gcache_expire(gc, gc->usedslots-1);
}
/* }}}1 */

/* gcache_add_entity() {{{1 */
static inline void gcache_add_entity(struct gcache *gc, struct entity_hash *ent) {
	ENTITY_TRACE(NULL);
	ent->sortid = gc->usedslots;
	gc->sort[gc->usedslots++] = ent;
	list_add(&ent->list, globalhash+ghashidx(ent->hash));
}
/* }}}1 */

/* gcache_check_expiring() {{{1 */
static inline void gcache_check_expiring(struct gcache *gc, int tsc4) { /* FIXME*/
	int i;
	i = 0;
	while(i<gc->usedslots) {
	    if(gc->sort[i]->expiring || (tsc4!=0 && gc->sort[i]->tsc4<tsc4))	    
		    gcache_expire(gc, i);
	    else
	    	i++;
	}
}
/* }}}1 */

/* list_for_each_expired {{{1 */

#define list_for_each_expired(list, ent, gc) \
	list = (gc)->expired.list.next; \
	while(list != &(gc)->expired.list && \
	      (ent = list_entry(list, struct entity_hash, list), \
	       list = list->next, \
	       ent->exp4 <= TSCRND(gtsc)) \
	  ) if(atomic_read(&ent->count) == 0)

/* }}}1 */

/* gmem_read_entity() {{{1 */
static inline struct entity_hash *gmem_read_entity(struct entity_up *ent) {
	if(gmem.usedslots >= gmem.maxslots && gcache_expand_sortbuf(&gmem))
		return NULL;

	ENTITY_TRACE(NULL);
	struct fdentity *fe = fdent(ent->fd);
	const int cachesize = fe->size + (isfd(fe->zfd) ? fdent(fe->zfd)->size : 0);

	struct entity_hash *ent1 = memcache_alloc(cachesize);
	if(ent1==NULL) return NULL;

	memcpy(ent1->hash, ent->hash, sizeof(ent->hash));
	ent1->type = ET_MEMORY;
	ent1->flag = 0;
	ent1->expired = 0;
	ent1->expiring = 0;
	ent1->hits = TSCRND(gtsc);
	atomic_set(&ent1->count, 0);
	ent1->fd = OE_BAD;
	ent1->exp4 = 0;

	struct mementity *me = mem2ent(ent1);
	me->fd = 0;
#if FILECOUNT_SUPPORT
	me->fcid = fe->fcid;
	dup_fcid(me->fcid);
#endif
	ent1->tsc4 = ent->tsc4;
	me->mime = fe->mime;
	me->mtime = fe->mtime;
	me->size = fe->size;
	if(fe->size>0) {
	    int n = fast_pread(ent->fd, me->data, me->size, 0);
		if (n < 0) {
			FAST_ERRNO(n);
			lprintf("[%s:%d]read error: %s", __FILE__, __LINE__, strerror(-n));
		}
		else if(n < me->size) {
		    memset(me->data+n, 0, me->size-n);
		}
	}
	if(isfd(fe->zfd)) {
	    me->zsize = fdent(fe->zfd)->size;
	    int n = fast_pread(fe->zfd, me->data+me->size, me->zsize, 0);
		if (n < 0) {
			FAST_ERRNO(n);
			lprintf("[%s:%d]read error: %s", __FILE__, __LINE__, strerror(-n));
		}
		else if(n < me->zsize) {
		    memset(me->data+me->size+n, 0, me->zsize-n);
		}
	} 
    else {
	    me->zsize = fe->zfd;
    }
	return ent1;
}
/* }}}1 */

/* gfd_move_entity() {{{1 */
static inline void gfd_move_entity(struct entity_hash *ent1, struct entity_up *ent) {
	ENTITY_TRACE(NULL);
#if TRACE_FD
	strcpy(ent1->name, "globalentity");
#endif
	memcpy(ent1->hash, ent->hash, sizeof(ent->hash));
	ent1->fd = ent->fd;
	ent1->tsc4 = ent->tsc4;
	ent1->type = ET_GLOBAL;
	ent1->flag = 0;
	ent1->expired = 0;
	ent1->expiring = 0;
	ent1->hits = TSCRND(gtsc);
	atomic_set(&ent1->count, 0);
	ent1->exp4 = 0;
	fdent(ent->fd)->entity = ent1;
}

/* }}}1 */

/* cleanup_entity() {{{1 */
static void cleanup_entity_lockless(struct worker *wt) {
	struct list_head *list;
	struct entity_hash *ent;
	struct tfcinfo *fc;

	if(tsc4_fdcache==0) return;
	fc = wt->tfc;
	if(fc->tsc4 == TSCRND(wt->tsc_now) - tsc4_fdcache) return;
	fc->tsc4 = TSCRND(wt->tsc_now) - tsc4_fdcache;

	/* expire positve cache {{{2 */
	list_for_each_entry_safe_l(ent, list, &fc->exp, exp)
	{		
	    if(ent->tsc4 > fc->tsc4) break;
	    if(atomic_read(&ent->count) > 0) continue;
		ENTITY_TRACE("cleanup entity lockless of exp");
	    close_entity(ent);
	    list_del_init(&ent->list);
	    list_del_init(&ent->exp);
	    list_move(&ent->lru, &fc->lru);
	}
	/* }}}2 */

	/* expire negative cache {{{2 */
	list_for_each_entry_safe_l(ent, list, &fc->nexp, exp)
	{		
	    if(ent->tsc4 > TSCRND(wt->tsc_now)) break;
		ENTITY_TRACE("cleanup entity lockless of nexp");
	    list_del_init(&ent->list);
	    list_del_init(&ent->exp);
	    list_move(&ent->lru, &fc->lru);
	}
	/* }}}2 */

	/* promote entity {{{2 */
	if(promoteslots>0 && fc->uptsc4<fc->tsc4 && fc->promotecount==0) {		
	    int i, u;

	    u = 0;
	    list_for_each_entry_safe_l(ent, list, &fc->exp, exp)
	    {
		    if(ent->expiring) {
				if(atomic_read(&ent->count)==0) {
					ENTITY_TRACE("promoteslots expiring");
			        list_move(&ent->lru, &fc->lru);
				}
		    } 
            else if(ent->hits >= promotehits && ent->fd) {
		        fc->sortbuf[u] = ent;
		        u++;
		    }
	    }
	    if(u==0)
		    fc->uptsc4 = fc->tsc4 + TSCRND(tscmin);
	    else {
		    sort_entity_hits(fc->sortbuf, u, u>promoteslots?promoteslots:0);
		    if(u > promoteslots) u = promoteslots;
			ENTITY_TRACE("promoteslots");
		    for(i=0; i<u; i++) {
		        ent = fc->sortbuf[u-1-i];
		        fc->promote[i].fd = dup_fdentity(ent->fd);
		        if(fc->promote[i].fd <= 2) break;
		        memcpy(fc->promote[i].hash, ent->hash, sizeof(ent->hash));
		        fc->promote[i].tsc4 = ent->tsc4;

		        ent->hits = 0;
		        ent->expiring = 1;
		    }
		    fc->promotecount = i;
	    }
	}
	/* }}}2 */
}
/* }}}1 */

/* check_global_entity() {{{1 */
static void check_global_entity(void *priv) {
	int i, n;
	struct tfcinfo *fc;
	int hidx, needed_gfd, needed_mem;
	struct entity_hash *ent;
	struct list_head *list;

	if(gfd.maxslots==0) return;
	gtsc = readtsc();

	/* cleanup expired slots {{{2 */
	list_for_each_expired(list, ent, &gfd) {
		ENTITY_TRACE("close entity of gfd");
	    close_entity(ent);
	    list_move(&ent->list, &gfd.freelist.list);
	    gfd.freeslots++;
	    gfd.expiredslots--;
	}
	/* }}}2 */

	/* cleanup gmem expired slots {{{2 */
	list_for_each_expired(list, ent, &gmem) {
		ENTITY_TRACE("close entity of gmem");
	    list_del(&ent->list);
#if FILECOUNT_SUPPORT
	    put_fcid(ent->mem->fcid);
#endif
	    memcache_free(ent);
	    gmem.expiredslots--;
	}
	/* }}}2 */

	/* checking promoted entity {{{2 */
	needed_mem = 0;
	needed_gfd = 0;
	for(n=0; n < nworks; n++) {
	    int lm;
	    fc = worker[n].tfc;
	    for(i=fc->promotecount-1, lm=0; i>=lm; i--) {
		    struct fdentity *pe = fdent(fc->promote[i].fd);
	        hidx = ghashidx(fc->promote[i].hash);
		    list_for_each_entry_safe_l(ent, list, globalhash+hidx, list)
		    {
		        if(ent->expiring) {
		            gcache_expire(ent->type==ET_MEMORY?&gmem:&gfd, ent->sortid);
			        continue;
		        }
		        if(hasheq(ent->hash, fc->promote[i].hash)) {
		            // already exists in hash
			        if(ent->type == ET_MEMORY) {
			            struct mementity *me = mem2ent(ent);
			            if(fc->promote[i].tsc4>ent->tsc4 && (me->mtime!=me->mtime || me->size!=me->size)) {
				            gcache_expire(&gmem, ent->sortid);
				            continue;
			            }
			            if(isfd(pe->zfd) && me->zsize<=2) {
				            gcache_expire(&gmem, ent->sortid);
				            continue;
			            }
			        } 
                    else 
                    {
			            struct fdentity *fe = fdent(ent->fd);
			            if(fc->promote[i].tsc4>ent->tsc4 && (pe->mtime!=fe->mtime || pe->size!=fe->size))
			            {
				            gcache_expire(&gfd, ent->sortid);
				            continue;
			            }
			            if(isfd(pe->zfd) && !isfd(fe->zfd))
			            {
				            /* swap zfd */
				            fe->zfd = pe->zfd;
				            pe->zfd = OE_BAD;
			            }
			        }

					ENTITY_TRACE("close promote");
			        close_fdentity(fc->promote[i].fd);
			        pe = NULL;
			        break;
		        }
		    }
		    if(pe==NULL) continue;
		    if(gmem_totalsize && pe->size<=gmem_maxsize) {
				ent=gmem_read_entity(fc->promote+i);
		        if(ent!=NULL) {
					ENTITY_TRACE("-->TO GMEM");
			        gcache_add_entity(&gmem, ent);
			        close_fdentity(fc->promote[i].fd);
			        continue;
		        }
		        needed_mem++;
		    }
			else {
		        if(!list_empty(&gfd.freelist.list))  {
					ENTITY_TRACE("-->TO GFD");
			        ent = list_entry(gfd.freelist.list.next, struct entity_hash, list);
			        list_del_init(&ent->list);
			        gfd.freeslots--;
			        gfd_move_entity(ent, fc->promote+i);
			        gcache_add_entity(&gfd, ent);
					//close_fdentity(fc->promote[i].fd); // fd-leak?
			        continue;
		        }
		        needed_gfd++;
		    }

		    {
		        if(i != lm) {
			        struct entity_up swap;
			        memcpy(&swap, fc->promote+i, sizeof(struct entity_up));
			        memcpy(fc->promote+i, fc->promote+lm, sizeof(struct entity_up));
			        memcpy(fc->promote+lm, &swap, sizeof(struct entity_up));
		        }
		        lm++;
		        i++;
		    }
	    }
	    fc->promotecount = lm;
	}
	/* }}}2 */

	/* check used slots */
	gcache_check_expiring(&gfd, TSCRND(gtsc)-tsc4_fdcache);

	/* expire global fdentity */
	if(needed_gfd>0 && gfd.usedslots>gfd.maxslots*3/4) {
	    n = gfd.usedslots - needed_gfd;
	    if(n < gfd.maxslots*3/4) 
            n = gfd.maxslots*3/4;
	    gcache_batch_expire(&gfd, n);
	}

	if(needed_mem && list_empty(&gmem.expired.list)) {
		n = gmem.usedslots * 9 / 10;
		gcache_check_expiring(&gmem, 0);
		if(n < gmem.usedslots)
		    gcache_batch_expire(&gmem, n);
	}

	/* }}}2 */
#if 1
	cprintf("fd(u=%d e=%d f=%d) mem(m=%d a=%d u=%d e=%d f=%d/%d)\n",
		gfd.usedslots, gfd.expiredslots,
		gfd.freeslots?:-needed_gfd,

		memcache_freesize,
		gmem.usedslots==0?0:((gmem_totalsize<<20)-memcache_freesize)/gmem.usedslots,
		gmem.usedslots, gmem.expiredslots,
		gmem.maxslots - gmem.usedslots, -needed_mem);
#endif
}
/* }}}1 */
/* init_fdcache() {{{1 */
int init_fdcache_lockless(void) {
	int n;
	struct tfcinfo *fc;
	char buf1[30], buf2[30];

	if(get_entity_internal != get_entity_lockless) return 0;
	for( n = 0; n < nworks; n++)
    {
	    worker[n].tfc = fc = shalloc(sizeof(struct tfcinfo));
	    if(fc==NULL) return -ENOMEM;
	    fc->entry = shalloc(threadslots*(sizeof(struct entity_hash)));
	    if(fc->entry==NULL) return -ENOMEM;

	    fc->hash = shalloc(sizeof(struct list_head)*(hashmask+1));
	    if(fc->hash == NULL) return -ENOMEM;
        
	    int i;
	    for(i=0; i<=hashmask; i++)
		    INIT_LIST_HEAD(fc->hash+i);

	    if(gfd.maxslots) {
		    fc->sortbuf = shalloc(sizeof(void *)*threadslots);
		    if(fc->sortbuf == NULL) return -ENOMEM;
		    
            fc->promote = shalloc(sizeof(struct entity_hash)*promoteslots);
		    if(fc->promote == NULL) return -ENOMEM;
		    fc->promotecount = 0;
	    }
	    INIT_LIST_HEAD(&fc->lru);
	    INIT_LIST_HEAD(&fc->exp);
	    INIT_LIST_HEAD(&fc->nexp);
	    for(i=0; i<threadslots; i++) {
		    atomic_set(&fc->entry[i].count, 0);
		    fc->entry[i].hits = 0;
		    fc->entry[i].fd = 0;
		    INIT_LIST_HEAD(&fc->entry[i].list);
		    INIT_LIST_HEAD(&fc->entry[i].exp);
		    list_add(&fc->entry[i].lru, &fc->lru);
	    }
	}
	if(gfd.maxslots) {
	    globalhash = shalloc(0x10000*sizeof(struct list_head));
	    if(globalhash==NULL) return -ENOMEM;
        
	    int i;
	    for(i=0; i<0x10000; i++)
		INIT_LIST_HEAD(globalhash+i);

	    if(gcache_init_sortbuf(&gfd) < 0) return -ENOMEM;
	    if(gcache_init_slots(&gfd) < 0) return -ENOMEM;
	    if(gmem_totalsize) {
		if(gcache_init_sortbuf(&gmem) < 0) return -ENOMEM;
	    	if(memcache_create(gmem_totalsize) < 0) return -ENOMEM;
		lprintf("Memory cache size: %dM, filesize %d%s, slots %d%s\n",
			gmem_totalsize,
			gmem_maxsize, pretty_r(buf1, gmem_maxsize),
			gmem.maxslots, pretty_r(buf2, gmem.maxslots)
		       );
	    }
	    register_privilege_task(check_global_entity, NULL);
	}
	register_worker_task(cleanup_entity_lockless);
	return 0;
}
/* }}}1 */

/* free_fdcache() {{{1 */
void free_fdcache_lockless(void) {
	int i, n;
	struct tfcinfo *fc;

	if(get_entity_internal != get_entity_lockless) return;
	for( n = 0; n < nworks; n++) {
		fc = worker[n].tfc;
		for(i=0; i<threadslots; i++) {
		    if(fc->entry[i].fd > 0) {
			    close_fdentity(fc->entry[i].fd);
			}
		}
		if(gfd.maxslots) {
			for(i=0; i<fc->promotecount; i++) {
				if(isfd(fc->promote[i].fd)) {
				    close_fdentity(fc->promote[i].fd);
				}
			}
		}
	}
	gcache_free(&gfd);
	gcache_free(&gmem);
	memcache_destroy();
}
/* }}}1 */

/* fdcache_shmem_size() {{{1 */
int init_fdcache_mode_lockless(void) {
	SHMEM_NEEDED(0x10000, sizeof(struct list_head));

	gcache_init(&gfd);
	gcache_init(&gmem);
	gfd.maxslots = myconfig_get_intval("fdcache_global_slots", 0);
	gmem_totalsize = myconfig_get_intval("memcache_size", 0);
	if(gmem_totalsize <= 0 || gmem_totalsize >= 3072)
		gmem_totalsize = 0;
	else {
	    memcache_set_overhead(MCOVERHEAD);
	    gmem_maxsize = myconfig_get_intval("memcache_file_size", 8192);
	    if(gmem_maxsize > memcache_maxsize)
		    gmem_maxsize = memcache_maxsize;
	    if(gmem_maxsize < 2*memcache_blocksize - memcache_overhead)
		    gmem_maxsize = 2*memcache_blocksize - memcache_overhead;

	    gmem.maxslots = 1024;
	    if(gfd.maxslots < 8192)
		    gfd.maxslots = 8192;
	}

	threadslots = myconfig_get_intval("fdcache_thread_slots", mconns*6/5);
	if(threadslots + 2*mconns + nworks + gfd.maxslots + 2000 > maxfds)
	    threadslots = maxfds - 2000 - 2*mconns - nworks - gfd.maxslots;

	threadslots /= nworks;
	for(hashmask=1; hashmask < 65536; hashmask <<= 1)
	    if(hashmask > threadslots) break;
	hashmask--;

	SHMEM_NEEDED(threadslots * nworks, sizeof(struct entity_hash));
	SHMEM_NEEDED(nworks, sizeof(struct tfcinfo));
	SHMEM_NEEDED(nworks, sizeof(struct list_head) * (hashmask+1));
	if(gfd.maxslots) {
	    promotehits = myconfig_get_intval("fdcache_promote_hits", 2);
	    promoteslots = myconfig_get_intval("fdcache_promote_percent", 10);
	    if(promoteslots > 20) promoteslots = 20;
	    promoteslots = promoteslots*gfd.maxslots/100/nworks;
	    if(promoteslots == 0) promoteslots = 1;
	    if(promoteslots > 10000) promoteslots = 10000;

	    SHMEM_NEEDED(threadslots * nworks,  sizeof(struct entity_hash *)); /* sortbuf */
	    SHMEM_NEEDED(promoteslots * nworks, sizeof(struct entity_up)); /* promote buf */
	    SHMEM_NEEDED(gfd.maxslots, sizeof(struct entity_hash)); /* gfd entry */
	}
    
	fdcache_max = gfd.maxslots + promoteslots*nworks + threadslots * nworks - mconns;
	get_entity_internal = get_entity_lockless;
	put_entity_internal = put_entity_lockless;

	lprintf("-memcache_maxsize is %d", memcache_maxsize);
	lprintf("-memcache_blocksize is %d", memcache_blocksize);
    lprintf("-fdcache_global_slots/gfd.maxslots is %d", gfd.maxslots);
    lprintf("-memcache_size/gmem_totalsize is %d", gmem_totalsize);
    lprintf("-memcache_file_size/gmem_maxsize is %d", gmem_maxsize);
    lprintf("-fdcache_thread_slots/threadslots is %d", threadslots);        
    lprintf("-fdcache_promote_hits/promotehits is %d", promotehits);
    lprintf("-fdcache_promote_percent/promoteslots is %d", promoteslots);
    lprintf("-fdcache_max is %d", fdcache_max);
	return 0;
}
/* }}}1 */

