#include <errno.h>
#include <signal.h>
#include <sys/socket.h>

#include "global.h"
#include "myconfig.h"
#include "detect.h"
#include "sysctl.h"
#include "compat_inotify.h"
#include "compat_dnotify.h"
#include "compat_openat.h"
#include "compat_sendfile64.h"
#include "compat_errno.h"
#include "compat_thread.h"
#include "compat_futex.h"
#include "compat_splice.h"
#include "compat_fadvise.h"

int has_inotify __init__;
int has_dnotify __init__;
int has_epoll __init__;
int has_futex __init__;
#if __WORDSIZE<64
int has_sendfile64 __init__;
#endif
int has_threadgroup __init__;
int has_unshare __init__;
int has_openat __init__;
int has_splice __init__;
int has_fadvise __init__;
int pipe_buffer_size __init__;

static int detect_sendfile64(int fd) {
#if __WORDSIZE<64
	int err = fast_sendfile64(fd, fd, NULL, 0);
	FAST_ERRNO(err);
	has_sendfile64 = err!=-ENOSYS;
	if(has_sendfile64 && myconfig_get_intval("disable_sys_sendfile64", 0))
	    has_sendfile64 = -1;
#endif
	return has_sendfile64;
}

static int detect_inotify(int fd) {
	int err = inotify_rm_watch(fd, 0);
	//FAST_ERRNO(err);
	if(err==-1) err = -errno;
	has_inotify = err != -ENOSYS;
	if(has_inotify && myconfig_get_intval("disable_sys_inotify", 0))
	    has_inotify = -1;
	return has_inotify;
}

static int detect_dnotify(int fd) {
	int err = fast_fcntl(fd, F_NOTIFY, DN_CREATE|DN_DELETE|DN_RENAME|DN_MULTISHOT);
	FAST_ERRNO(err);
	has_dnotify = err != -EINVAL;
	if(has_dnotify && myconfig_get_intval("disable_sys_dnotify", 0))
	    has_dnotify = -1;
	return has_dnotify;
}

static int detect_epoll(void) {
	int fd = fast_epoll_create(100);
	if(fd >= 0) {
	    has_epoll = 1;
	    fast_close(fd);
#if WITH_RTSIG
	    if(myconfig_get_intval("disable_sys_epoll", 0))
		has_epoll = -1;
#endif
	} else{
	    has_epoll = 0;
	}
	return has_epoll;
}

static int detect_futex(void) {
	unsigned int l = 0;
	int c = fast_futex_wake(&l, 1);
	if(c >= 0) {
	    has_futex = 1;
	    if(myconfig_get_intval("disable_sys_futex", 0))
		has_futex = -1;
	} else{
	    has_futex = 0;
	}
	return has_futex;
}

static int detect_threadgroup(void) {
	has_threadgroup = fast_set_tid_address(NULL) >= 0;
	return has_threadgroup;
}

static int detect_unshare(void) {
	has_unshare = fast_unshare(0) >= 0;
	if(has_unshare && myconfig_get_intval("disable_sys_unshare", 0))
	    has_unshare = -1;
	return has_unshare;
}

static int detect_openat(int fd) {
	int err = fast_openat3(fd, "", 0);
	FAST_ERRNO(err);
	has_openat = err != -ENOSYS;
	if(has_openat && myconfig_get_intval("disable_sys_openat", 0))
	    has_openat = -1;
	return has_openat;
}

static int detect_splice(void) {
	int fd[2];
	if(fast_socketpair(AF_UNIX, SOCK_STREAM, 0, fd) < 0)
		return 0;

	char buf[4];
	struct iovec v;
	v.iov_base = buf;
	v.iov_len = sizeof(buf);
	signal(SIGPIPE, SIG_IGN);
	int err = fast_vmsplice(fd[1], &v, 1, 0);
	FAST_ERRNO(err);
	if(err >= 0)
	    has_splice = 1;
	else if(err != -ENOSYS)
	    has_splice = -2;
	fast_close(fd[0]);
	fast_close(fd[1]);
	if(has_splice==1 && myconfig_get_intval("disable_sys_splice", 0))
	    has_splice = -1;

	return has_splice;
}

static int detect_fadvise(int fd) {
	int err = fadvise(fd, 1, 0, 0);
	//FAST_ERRNO(err);
	if(err==-1) err = -errno;

	if(err != -ENOSYS)
		has_fadvise = 64;
#ifdef __NR_fadvise64_64
	if(has_fadvise==0) {
	    err = fadvise_l32(fd, 1, 0, 0);
	    //FAST_ERRNO(err);
	    if(err==-1) err = -errno;
	    if(err != -ENOSYS)
		has_fadvise = 32;
	}
#endif
	if(has_fadvise && myconfig_get_intval("disable_sys_fadvise", 0))
	    has_fadvise = -1;
	return has_fadvise;
}

static int detect_pipe_buffer_size(void) {
	int fd[2];
	char buf[4096];
	int n;

	pipe(fd);
	fast_fcntl(fd[1], F_SETFL, O_WRONLY|O_NONBLOCK);
	while((n=fast_write(fd[1], buf, sizeof(buf))) > 0)
	    pipe_buffer_size += n;
	fast_close(fd[0]);
	fast_close(fd[1]);
	return pipe_buffer_size;
}

void detect_kernel(void) {
	detect_epoll();
	detect_unshare();
	detect_futex();
	detect_threadgroup();
	detect_splice();
	detect_pipe_buffer_size();

	int fd = fast_open2("/dev/null", O_RDONLY);
	if(fd > 0) {
	    detect_sendfile64(fd);
	    detect_inotify(fd);
	    detect_dnotify(fd);
	    detect_openat(fd);
	    detect_fadvise(fd);
	    fast_close(fd);
	}
}

