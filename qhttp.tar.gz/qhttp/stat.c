/* vim: set sw=4 ai :*/
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/socket.h>

#include "stat.h"
#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "thread.h"
#include "log.h"
#include "shmem.h"
#include "fdinfo.h"

#if ISDSTAT_SUPPORT
#include "message.h"

#define OUTPUT_BUFFER_MAX 511
#define STAT_FILE_MAX     (1024*1024*100)

char *statfile = NULL;
char *stat_proc_file = NULL;
char *stat_text_file = NULL;
char *stat_text_file_bak = NULL;
struct counters *countermap __init__;
int statfd __init__ = 0;
int stat_proc_fd __init__ = -1;
int stat_text_fd __init__ = -1;
int stat_text_fd_bak __init__ = -1;
int stat_output_size __init__ = 0;

static struct {
	message_header_t header;
	int totalcon;
	int totalreq;
	int idlecon;
	int workcon;
	int overflow;
	int idleswitch;
	int idleresume;
	int pipereq;
	int kbytes;
	int openfds;
	int opencnt;
	int ioperf;
	int ioperf_avg;
	int stack_used;
    int fcachefds;
    int ccachefds;
    int proxyfds;
    int relayerror;
    int fcachematch;
    int errorreq;
    int error404;
    int error550;
    int error551;
} msg;

volatile static struct {
	message_header_t header;
	int nreq;
	int kbytes;
} hmsg;

static int bytes_remain;

#ifdef ENABLE_FDTRACE
struct fd_trace_struct {
	int count;
	int update;
	unsigned long open_thread;
	unsigned long close_thread;
	int open_line;
	int close_line;
	char file[256];
	char open_file[256];
	char close_file[256];
};

volatile struct fd_trace_struct* gfd_tracer = NULL;
void fdtracer_create() {
	size_t size = sizeof(struct fd_trace_struct) * (maxfds+1);
	gfd_tracer = (struct fd_trace_struct *)malloc(size);
	memset((void *)gfd_tracer, 0, size);
}
void fdtracer_destroy() {	
	free((void *)gfd_tracer);
	gfd_tracer = NULL;
}
void fdtracer_open(int fd, int update, unsigned long thread, const char* srcfile, const char* file, int line) {
	if (NULL == gfd_tracer) return;
	if (gfd_tracer[fd].count > 0) {
		lprintf("fdtracer_open ERROR large"); return;
	}
	else if (gfd_tracer[fd].count < 0) {
		lprintf("fdtracer_open ERROR less"); return;
	}

	++gfd_tracer[fd].count;
	gfd_tracer[fd].update = update;
	gfd_tracer[fd].open_line = line;	
	gfd_tracer[fd].open_thread = thread;
	if (NULL == srcfile)
		gfd_tracer[fd].file[0] = 0;
	else
		strcpy(gfd_tracer[fd].file, srcfile);
	strcpy(gfd_tracer[fd].open_file, file);	
}
void fdtracer_close(int fd, unsigned long thread, const char* file, int line) {
	if (NULL == gfd_tracer) return;
	if (gfd_tracer[fd].count < 1) {
		lprintf("fdtracer_open ERROR less"); return;
	}
	else if (gfd_tracer[fd].count > 1) {
		lprintf("fdtracer_open ERROR large"); return;
	}

	--gfd_tracer[fd].count;
	gfd_tracer[fd].close_line = line;
	gfd_tracer[fd].close_thread = thread;
	strcpy(gfd_tracer[fd].close_file, file);
}
void fdtracer_print() {
	int fd;
	int leak = 0;
	for (fd=0; fd<maxfds; ++fd) {
		if (gfd_tracer[fd].count > 0) {
			++leak;
			if (gfd_tracer[fd].file)
				lprintf("[%d][%d][%lu,%lu]->%s:%d,%s:%d,%s", 
						 fd, gfd_tracer[fd].update, gfd_tracer[fd].open_thread, gfd_tracer[fd].close_thread,
						 gfd_tracer[fd].open_file, gfd_tracer[fd].open_line, 
						 gfd_tracer[fd].close_file, gfd_tracer[fd].close_line,
						 gfd_tracer[fd].file);
			else
				lprintf("[%d][%d][%lu,%lu]->%s:%d,%s:%d", 
						 fd, gfd_tracer[fd].update, gfd_tracer[fd].open_thread, gfd_tracer[fd].close_thread,
						 gfd_tracer[fd].open_file, gfd_tracer[fd].open_line, 
						 gfd_tracer[fd].close_file, gfd_tracer[fd].close_line);

		}
	}
	if (leak > 0)
		lprintf("===>fd leak count is %d", leak);
}
#endif // ENABLE_FDTRACE

inline void back_file_byfilename() {
    if (-1 == access(stat_text_file, R_OK|W_OK)) return;
    remove(stat_text_file_bak);
    rename(stat_text_file, stat_text_file_bak);
}
inline void close_stat_text() {
    if (stat_text_fd > 0) {
        close(stat_text_fd);
        stat_text_fd = -1;
    }
}
inline int open_stat_text() {
    close_stat_text();
    stat_text_fd = open(stat_text_file, O_CREAT|O_WRONLY|O_TRUNC, S_IWUSR|S_IRUSR|S_IRGRP|S_IROTH);
    if (-1 == stat_text_fd) {
        lprintf("%s:%d, open %s error: %s", __FILE__, __LINE__, stat_text_file, strerror(errno));            
        return 0;
    }
       
    return 1;
}
int init_statistics(void) {
	//if(statfile==0)
	//    statfile = myconfig_get_value("statistics_inbox_file");
    
#ifdef ENABLE_FDTRACE
	fdtracer_create();
#endif // ENABLE_FDTRACE

    stat_proc_file = (char *)malloc(strlen(logdir)+sizeof("tws_snapshot.txt"));
    sprintf(stat_proc_file, "%s/%s", logdir, "tws_snapshot.txt");
    stat_proc_fd = open(stat_proc_file, O_CREAT|O_WRONLY|O_TRUNC, S_IWUSR|S_IRUSR|S_IRGRP|S_IROTH);
    if (-1 == stat_proc_fd) {
        int errcode = errno;
        lprintf("can't create %s for %s", stat_proc_file, strerror(errcode));
        return -errcode;
    }
    else {
        lprintf("TWS snapshot is %s", stat_proc_file);
    }
	
    if (NULL == stat_text_file) {
        char* filename = myconfig_get_value("stat_file");
        if (filename) {            
            size_t len = strlen(logdir)+strlen(filename)+3;
            stat_text_file = (char *)malloc(len);
            if(stat_text_file==NULL) return -ENOMEM;
            snprintf(stat_text_file, len-1, "%s/%s", logdir, filename);
        }
    }
    if (stat_text_file != NULL) {
        lprintf("stat file is %s", stat_text_file);
#if 1
        stat_text_file_bak = (char*)malloc(strlen(stat_text_file)+5);
        if(stat_text_file_bak==NULL) return -ENOMEM;
        if (stat_text_file_bak != NULL) {    
            int nx = sprintf(stat_text_file_bak, "%s.bak", stat_text_file);
            stat_text_file_bak[nx] = 0;
            lprintf("stat backup file is %s", stat_text_file_bak);
            back_file_byfilename();
        }
#endif
        (void)open_stat_text();        
    }
    
	countermap = shalloc(sizeof(struct counters));
	if(countermap==NULL) return -ENOMEM;
	return 0;
}

void free_statistics(void) {
#ifdef ENABLE_FDTRACE
	fdtracer_destroy();
#endif // ENABLE_FDTRACE
	
    if (stat_text_file) {
        free(stat_text_file);
        stat_text_file = NULL;
    }
    if (stat_text_file_bak) {
        free(stat_text_file_bak);
        stat_text_file_bak = NULL;
    }
}

inline int need_output_stat() {
    return (!statfile && statfd<=0) ? 0 : 1;    
}
inline int need_output_stat_text() {    
    return (-1 == stat_text_fd) ? 0 : 1;
}
inline int back_stat_text_byfd() {
    if (-1 == stat_text_fd_bak) {
        if (0 == ftruncate(stat_text_fd, 0)) {
            stat_output_size = 0;
            if (-1 == lseek(stat_text_fd, SEEK_SET, 0)) {
                lprintf("can't seek stat for %s", strerror(errno));
                close_stat_text();
                return 0;
            }
            return 1;
        }
        else {
            lprintf("can't truncate stat for %s", strerror(errno));
            close_stat_text();
            return 0;
        }
    }
    else {
        close_stat_text();
        remove(stat_text_file_bak);
        rename(stat_text_file, stat_text_file_bak);
        return open_stat_text();
    }
}
inline int check_stat_text() {
    if (stat_output_size > STAT_FILE_MAX)
        if (!back_stat_text_byfd()) return 0;        
    return 1;
}
void output_stat_text() {                
    struct tm result;
    char output_buffer[OUTPUT_BUFFER_MAX+1];
    time_t timestamp = msg.header.timestamp;

    if (!check_stat_text()) return;
    localtime_r(&timestamp, &result);    
    int nprt = snprintf(output_buffer, sizeof(output_buffer)-1,
           "%04d-%02d-%02d %02d:%02d:%02d"
           ",%d,%d"
           ",%d,%d"
           ",%d,%d"
           ",%d,%d"
           ",%d,%d"
           ",%d,%d,%d,%d,%d"
           ",%d,%d,%d,%d"
           "\n",           
             result.tm_year+1900,result.tm_mon+1,result.tm_mday,result.tm_hour,result.tm_min,result.tm_sec
            ,msg.totalcon, msg.totalreq            
            ,msg.workcon, msg.idlecon
            ,msg.idleswitch, msg.idleresume
            ,msg.pipereq, msg.overflow
            ,msg.openfds, msg.opencnt
            ,msg.fcachefds,msg.ccachefds,msg.proxyfds,msg.relayerror,msg.fcachematch
            ,msg.errorreq,msg.error404,msg.error550,msg.error551
	       );
    output_buffer[nprt] = 0;
    int wr = write(stat_text_fd, output_buffer, nprt);
    if (wr > 0) stat_output_size += wr;
    else {
        lprintf("can't write stat for %s", strerror(errno));
        close_stat_text();
    }

    if (stat_proc_fd > 0) {    
        lseek(stat_proc_fd, 0, SEEK_SET);
        write(stat_proc_fd, output_buffer, nprt+1);    
    }
}

void check_exception()
{
	volatile int guard_openfds = maxfds - mconns - 100000;	
	if (msg.openfds > guard_openfds) {
		lprintf("openfds is %d,%d,%d", msg.openfds,maxfds,mconns);
		exit_http();
	}
}

void statistics(void) 
{	    	    
    if (!need_output_stat() && !need_output_stat_text()) return;
    
#define GETSAMPLE(name) msg.name = atomic_read(&countermap->name)
//#define GETCOUNTER(name) GETSAMPLE(name)
#define GETCOUNTER(name) msg.name = atomic_read(&countermap->name), atomic_sub(msg.name,&countermap->name)
#define GETCOUNTER8(name) msg.name = atomic8_read(&countermap->name), atomic8_sub(msg.name,&countermap->name)
#define GETMEMBER(name) msg.name = countermap->name
	GETCOUNTER(totalcon);   // accept����������
	GETCOUNTER(totalreq);   // ������������   
	GETSAMPLE(workcon);
	GETCOUNTER(idleswitch); // �л���idle��������
	GETCOUNTER(idleresume); // ��idle�ص�work��������
	GETCOUNTER(pipereq);    // ���յ��Ĺܵ�������
	GETCOUNTER(overflow);   // ���������
	GETSAMPLE(openfds);     // ��ǰ���ļ������
	GETCOUNTER(opencnt);    // ���ļ�����
	GETMEMBER(ioperf);
	GETMEMBER(ioperf_avg);
    //GETSAMPLE(fcachefds);
    GETCOUNTER(fcachefds);
    //GETSAMPLE(ccachefds);
    GETCOUNTER(ccachefds);
    //GETSAMPLE(proxyfds);
    GETCOUNTER(proxyfds);
    GETCOUNTER(relayerror);
    GETCOUNTER(fcachematch);  
    GETCOUNTER(errorreq);
    GETCOUNTER(error404);
    GETCOUNTER(error550);
    GETCOUNTER(error551);
	msg.stack_used = stack_used;
	msg.idlecon = atomic_read(&idlecon);
#if HAS_ATOMIC8
	long bytes;
	bytes = atomic8_read(&countermap->bytes);
	atomic8_sub(bytes, &countermap->bytes);
	bytes += bytes_remain;
	msg.kbytes += bytes >> 10; // ���͵�K�ֽ���
	bytes_remain = bytes & 0x3FF;
#else
	int bytes;
	GETCOUNTER(kbytes);
	bytes = atomic_read(&countermap->bytes);
	atomic_sub(bytes, &countermap->bytes);
	bytes_remain += bytes;
	msg.kbytes += bytes_remain >> 10;
	bytes_remain &= 0x3FF;
#endif

	msg.header.len = sizeof(msg);
	msg.header.hlen = sizeof(message_header_t);
	msg.header.type = 6;
	msg.header.timestamp = fast_time();

#ifdef ENABLE_FDTRACE
	fdtracer_print();
#endif // ENABLE_FDTRACE
	
	//check_exception();
    output_stat_text();
    if (!need_output_stat()) return;
    
	int fd = statfd > 0 ? statfd :
		fast_open(statfile, O_WRONLY|O_APPEND|O_CREAT, 0666);
	if(fd>=0) {
	    int i;
	    fast_write(fd, (char *)&msg, sizeof(msg));
	    for(i=0; i<countermap->hostnum; i++) {	    	
	    	if(countermap->host[i].msgid==0) continue;
            
            int bytes;
		    hmsg.header.len = sizeof(hmsg);
		    hmsg.header.hlen = sizeof(message_header_t);
		    hmsg.header.type = countermap->host[i].msgid;
		    hmsg.header.timestamp = msg.header.timestamp;
		    hmsg.nreq = atomic_read(&countermap->host[i].nreq);
		    atomic_sub(hmsg.nreq, &countermap->host[i].nreq);
    #if HAS_ATOMIC8
		    bytes = atomic8_read(&countermap->host[i].bytes);
		    bytes &= ~0x3FF;
		    atomic8_sub(bytes, &countermap->host[i].bytes);
		    hmsg.kbytes += bytes >> 10;
    #else
		    hmsg.kbytes = atomic_read(&countermap->host[i].kbytes);
		    atomic_sub(hmsg.kbytes, &countermap->host[i].kbytes);
		    bytes = atomic_read(&countermap->host[i].bytes);
		    bytes &= ~0x3FF;
		    atomic_sub(bytes, &countermap->host[i].bytes);
		    hmsg.kbytes += bytes >> 10;
    #endif
		    fast_write(fd, (char *)&hmsg, sizeof(hmsg));
	    }
	    if(statfd <= 0) fast_close(fd);
	}

	//if(console_disabled) return;
	cprintf("TOTAL %d/%d/%dK(%d) CONN %d/%d IDLE %d/%d PL %d OVF %d FD %d/%d\n",
		msg.totalcon, msg.totalreq, msg.kbytes, bytes_remain,
		msg.workcon, msg.idlecon,
		msg.idleswitch, msg.idleresume,
		msg.pipereq, msg.overflow,
		msg.openfds, msg.opencnt
	       );

}

void pipe_statistics_data(int sfd) {
	char buf[1<<16];
	message_header_t *hp = (void *)buf;
	int len;
	int c=0;
	int fd = -1;

	while((len=fast_recv(sfd, buf, sizeof(buf), MSG_DONTWAIT)) > 0)
	{
	    if(len < hp->len || hp->hlen > hp->len)
		    continue;
	    if(fd==-1)
		    fd = fast_open(statfile, O_WRONLY|O_APPEND|O_CREAT, 0666);
	    if(fd>=0) {
		    fast_write(fd, buf, hp->len);
		    if(c++ > 100) {
		        fast_close(fd);
		        fd = -1;
		        c = 0;
		    }
	    }
	}
	if(fd>0) {
	    fast_close(fd);
	}
}

#endif
