/* vim: set sw=4 ai :*/
#include "realconfig.h"
#if RELAY_SUPPORT
#include "myalloc.h"
#include <stdlib.h>

#include "global.h"
#include "group.h"

#define MAX_TARGET_WEIGHT	100

struct sch_rand {
	struct forward_scheduler core;
	int nhosts;
	int (*calc)(struct target **, uint16_t *, int, struct target *);
	struct target *tlist[0];
};

#ifdef free
static void free_wrapper(void *p) { free(p); }
#endif

static int calc_static(struct target **t, uint16_t *c, int h, struct target *l)
{
	int i, n;
	for(i=0, n=0; i<h; i++) {
	    if(t[i]==l || t[i]->state==TS_DEAD || t[i]->state==TS_INITIAL)
		c[i] = 0;
	    else if(t[i]->count_inuse >= t[i]->mconns)
		c[i] = 0;
		else 
		{
			// ***BEGIN*** Modified by yorkwang on 2008-03-04
			if(t[i]->count_inuse < 0)
			{
				t[i]->count_inuse = 0;
			}
			// ***END*** Modified by yorkwang on 2008-03-04
			c[i] = t[i]->mconns - t[i]->count_inuse;
			n += c[i];
		}
	}
	return n;
}

static int calc_adaptive(struct target **t, uint16_t *c, int h, struct target *l)
{
	int i, n;
	for(i=0, n=0; i<h; i++) {
	    if(t[i]==l || t[i]->state==TS_DEAD || t[i]->state==TS_INITIAL)
		c[i] = 0;
	    else if(t[i]->count_inuse >= t[i]->econns)
		c[i] = 0;
		else 
		{
			// ***BEGIN*** Modified by yorkwang on 2008-03-04
			if(t[i]->count_inuse < 0)
			{
				t[i]->count_inuse = 0;
			}
			// ***END*** Modified by yorkwang on 2008-03-04
			c[i] = t[i]->econns - t[i]->count_inuse;
			n += c[i];
		}
	}
	return n;
}

static int calc_dynamic(struct target **t, uint16_t *c, int h, struct target *l)
{
	int i, n;
	for(i=0, n=0; i<h; i++) {
	    if(t[i]==l || t[i]->state==TS_DEAD || t[i]->state==TS_INITIAL)
		c[i] = 0;
	    else if(t[i]->count_inuse >= t[i]->econns)
		c[i] = 0;
		else 
		{
			// ***BEGIN*** Modified by yorkwang on 2008-03-04
			if(t[i]->count_inuse < 0)
			{
				t[i]->count_inuse = 0;
			}
			// ***END*** Modified by yorkwang on 2008-03-04
			int ca, ce;
			c[i] = t[i]->econns - t[i]->count_inuse;
			ca = t[i]->count_access;
			ce = t[i]->count_error;
			if(ca >= 10) {
				if(ce > ca) {
					c[i] = 0;
					continue;
					}
				c[i] = (int)c[i] * (ca-ce)/ca;
				}
			n += c[i];
		}
	}
	return n;
}

static ftarget_t *
find_target_rand(
	struct forward_scheduler *priv,
	uint32_t addr,
	ftarget_t *last)
{
	struct sch_rand *l = (struct sch_rand *)priv;
	int i, n;
	/* STACK-USAGE: 520 */
	uint16_t c[l->nhosts];

	n = l->calc(l->tlist, c, l->nhosts, (struct target *)last);
	if(n==0) return NULL;
	n = rand() % n;

	for(i=0; i<l->nhosts && n>=0; i++) {
	    if(n < c[i])
	    	return (ftarget_t *)l->tlist[i];
	    n -= c[i];
	}
	return NULL;
}

static struct sch_rand *new_scheduler_rand_base(struct group *g)
{
	struct sch_rand *r;
	int i, j;

	if(g==NULL || g->nhosts==0) return NULL;

	r = calloc(1, sizeof(struct sch_rand) + g->nhosts * sizeof(void *));
	if(r==NULL) {
		return NULL;
	}

#ifdef free
	r->core.cleaner = free_wrapper;
#else
	r->core.cleaner = free;
#endif
	r->core.find_target = find_target_rand;
	r->nhosts = g->nhosts;
	for(i=j=0; i<g->nhosts; i++) {
		if(g->tlist[i]==0)
			continue;
		r->tlist[j] = g->tlist[i];
		if(r->tlist[j])
			j++;
	}
	return r;
}

struct forward_scheduler *new_scheduler_rand(struct group *g) {
	struct sch_rand *t = new_scheduler_rand_base(g);
	if(t)
	    t->calc = calc_static;
	return &t->core;
}

struct forward_scheduler *new_scheduler_arand(struct group *g) {
	struct sch_rand *t = new_scheduler_rand_base(g);
	if(t)
	    t->calc = calc_adaptive;
	return &t->core;
}

struct forward_scheduler *new_scheduler_drand(struct group *g) {
	struct sch_rand *t = new_scheduler_rand_base(g);
	if(t)
	    t->calc = calc_dynamic;
	return &t->core;
}

#endif
