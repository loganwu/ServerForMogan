#ifndef __H_FDINFO_H_
#define __H_FDINFO_H_

#include <fcntl.h>
#include "list.h"
#include "conn.h"

struct baseconn;

struct fdinfo {
	struct baseconn *conn;
	struct list_head ilist;
	uint32_t addr;
	int32_t nreq;
	uint32_t tsc4;
#if FILECOUNT_SUPPORT
	void *__fcid;
#endif
#if PROFILE_SUPPORT
	uint64_t tsc;
#endif
#if TRACE_FD
	const char *close_by_fn;
	int close_by_ln;
#endif
} __align__;


extern int maxfds;
extern int guardfds;
extern struct fdinfo *fdinfo;

#if WITH_RTSIG
static inline void new_fdinfo_rtsig(int fd, uint32_t addr){
	extern int rtsigno;
	fast_fcntl(fd, F_SETSIG, rtsigno);
	fast_fcntl(fd, F_SETFL, O_RDWR|O_NONBLOCK|O_ASYNC);
	fdinfo[fd].nreq = 0;
	fdinfo[fd].addr = addr;
}
#endif

static inline void new_fdinfo_epoll(int fd, uint32_t addr){
	fast_fcntl(fd, F_SETFL, O_RDWR|O_NONBLOCK);
	fdinfo[fd].nreq = 0;
	fdinfo[fd].addr = addr;
}

extern const struct baseconn idlestub[1];
extern const struct baseconn listenstub[1];
extern const struct baseconn entitystub[1];
extern const struct baseconn systemstub[1];
extern const struct baseconn sigiostub[1];
extern const struct baseconn delaystub[1];
extern int validate_file_handle(int, const char *, int);
extern void validate_events(int, int, const char *, int);

#define isfd(x) ((unsigned long)(x)>2 && (unsigned long)(x) < maxfds)
#define isptr(x) ((unsigned long)(x) >= maxfds)
#define isntfdptr(x) ((unsigned long)(x) <= 2)
#define set_stub(fd,stub) (fdinfo[fd].conn = (struct baseconn *)stub)
#define is_stub(fd,stub) (fdinfo[fd].conn == (struct baseconn *)stub)
#define check_new_fd(fd)	fd = validate_file_handle(fd, __FILE__, __LINE__);
#define check_bad_events(fd,events) validate_events(fd,events,__FILE__, __LINE__)

#endif
