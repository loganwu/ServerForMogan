#include <string.h>
#include <errno.h>

#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "entity.h"
#include "util.h"
#include "log.h"
#include "shmem.h"

#define HASHSLOT	4097

int gzmode __init__;
int compress_order __init__;
struct compress_first_type_array* compress_first_array;

struct mrec {
    int gzippable;
    const char ext[8];
    const char *mime;
    struct mrec *next;
};
#define HASH8(x) *(uint64_t *)(x)
#define HASH4(x) ((*(uint32_t *)(x)+*(uint32_t *)((x)+4))%HASHSLOT)

static struct mrec **mimetypehash;
static struct mrec mimetypes[] __init__= {
    { 1, "ai\0",  "application/postscript" },
    { 0, "ace",   "application/octet-stream" },
    { 1, "aif",   "audio/x-aiff" },
    { 1, "aifc",  "audio/x-aiff" },
    { 1, "aiff",  "audio/x-aiff" },
    { 2, "asc",   "text/plain" },
    { 0, "asf",   "video/x-ms-asf" },
    { 1, "au\0",  "audio/basic" },
    { 0, "avi",   "video/x-msvideo" },
    { 1, "bcpio", "application/x-bcpio" },
    { 1, "bin",   "application/octet-stream" },
    { 1, "bmp",   "image/bmp" },
    { 0, "bz2",   "application/x-bzip2" },
    { 0, "cab",   "application/octet-stream" },
    { 1, "cdf",   "application/x-netcdf" },
    { 1, "cgm",   "image/cgm" },
    { 1, "class", "application/octet-stream" },
    { 1, "cpio" , "application/x-cpio" },
    { 1, "cpt",   "application/mac-compactpro" },
    { 0, "cpz",   "application/x-gzip" },
    { 2, "csh",   "application/x-csh" },
    { 2, "css",   "text/css" },
    { 2, "csv",   "text/plain" },
    { 1, "dcr",   "application/x-director" },
    { 1, "dir",   "application/x-director" },
    { 1, "djv",   "image/vnd.djvu" },
    { 1, "djvu",  "image/vnd.djvu" },
    { 1, "dll",   "application/octet-stream" },
    { 1, "dl_",   "application/octet-stream" },
    { 1, "dmg",   "application/octet-stream" },
    { 1, "dms",   "application/octet-stream" },
    { 2, "doc",   "application/msword" },
    { 1, "dtd",   "application/xml-dtd" },
    { 1, "dvi",   "application/x-dvi" },
    { 1, "dxr",   "application/x-director" },
    { 2, "eml",   "message/rfc822" },
    { 1, "eps",   "application/postscript" },
    { 2, "etx",   "text/x-setext" },
    { 1, "exe",   "application/octet-stream" },
    { 1, "ex_",   "application/octet-stream" },
    { 1, "ez\0",  "application/andrew-inset" },
    { 0, "gif",   "image/gif" },
    { 1, "gram",  "application/srgs" },
    { 1, "grxml", "application/srgs+xml" },
    { 1, "gtar",  "application/x-gtar" },
    { 0, "gz\0",  "application/x-gzip" },
    { 1, "hdf",   "application/x-hdf" },
    { 2, "htc",   "text/plain" },
    { 1, "hqx",   "application/mac-binhex40" },
    { 2, "htm",   "text/html" },
    { 2, "html",  "text/html" },
    { 1, "ice",   "x-conference/x-cooltalk" },
    { 2, "ico",   "image/x-icon" },
    { 2, "ics",   "text/calendar" },
    { 1, "ief",   "image/ief" },
    { 2, "ifb",   "text/calendar" },
    { 1, "iges",  "model/iges" },
    { 1, "igs",   "model/iges" },
    { 0, "jpe",   "image/jpeg" },
    { 0, "jpeg",  "image/jpeg" },
    { 0, "jpg",   "image/jpeg" },
    { 2, "js\0",  "application/x-javascript" },
    { 0, "kar",   "audio/midi" },
    { 1, "latex", "application/x-latex" },
    { 0, "lha",   "application/octet-stream" },
    { 0, "lzh",   "application/octet-stream" },
    { 2, "m3u",   "audio/x-mpegurl" },
    { 2, "m4u",   "video/vnd.mpegurl" },
    { 1, "man",   "application/x-troff-man" },
    { 2, "mathml","application/mathml+xml" },
    { 1, "me\0",  "application/x-troff-me" },
    { 1, "mesh",  "model/mesh" },
    { 2, "mht",   "message/rfc822" },
    { 2, "mhtml", "message/rfc822" },
    { 0, "mid",   "audio/midi" },
    { 0, "midi",  "audio/midi" },
    { 1, "mif",   "application/vnd.mif" },
    { 0, "mov",   "video/quicktime" },
    { 0, "movie", "video/x-sgi-movie" },
    { 0, "mp2",   "audio/mpeg" },
    { 0, "mp3",   "audio/mpeg" },
    { 0, "mp4",   "video/mpeg" },
    { 0, "mpe",   "video/mpeg" },
    { 0, "mpeg",  "video/mpeg" },
    { 0, "mpg",   "video/mpeg" },
    { 0, "mpga",  "audio/mpeg" },
    { 1, "ms\0",  "application/x-troff-ms" },
    { 1, "msh",   "model/mesh" },
    { 0, "mxu",   "video/vnd.mpegurl" },
    { 1, "nc\0",  "application/x-netcdf" },
    { 1, "oda",   "application/oda" },
    { 0, "ogg",   "application/ogg" },
    { 1, "pbm",   "image/x-portable-bitmap" },
    { 1, "pdb",   "chemical/x-pdb" },
    { 1, "pdf",   "application/pdf" },
    { 1, "pgm",   "image/x-portable-graymap" },
    { 1, "pgn",   "application/x-chess-pgn" },
    { 2, "phtml", "text/html" },
    { 0, "png",   "image/png" },
    { 1, "pnm",   "image/x-portable-anymap" },
    { 1, "ppm",   "image/x-portable-pixmap" },
    { 1, "ppt",   "application/vnd.ms-powerpoint" },
    { 2, "ps\0",  "application/postscript" },
    { 0, "qt\0",  "video/quicktime" },
    { 0, "ra\0",  "audio/x-pn-realaudio" },
    { 1, "ram",   "audio/x-pn-realaudio" },
    { 0, "rar",   "application/x-rar" },
    { 1, "ras",   "image/x-cmu-raster" },
    { 2, "rdf",   "application/rdf+xml" },
    { 1, "rgb",   "image/x-rgb" },
    { 0, "rm\0",  "application/vnd.rn-realmedia" },
    { 0, "rmvb",  "application/vnd.rn-realmedia" },
    { 1, "roff",  "application/x-troff" },
    { 2, "rtf",   "text/rtf" },
    { 2, "rtx",   "text/richtext" },
    { 2, "sgm",   "text/sgml" },
    { 2, "sgml",  "text/sgml" },
    { 2, "sh\0",  "application/x-sh" },
    { 2, "shar",  "application/x-shar" },
    { 2, "shtml", "text/html" },
    { 1, "silo",  "model/mesh" },
    { 1, "sit",   "application/x-stuffit" },
    { 1, "skd",   "application/x-koan" },
    { 1, "skm",   "application/x-koan" },
    { 1, "skp",   "application/x-koan" },
    { 1, "skt",   "application/x-koan" },
    { 1, "smi",   "application/smil" },
    { 1, "smil",  "application/smil" },
    { 1, "snd",   "audio/basic" },
    { 1, "so\0",  "application/octet-stream" },
    { 1, "spl",   "application/x-futuresplash" },
    { 1, "src",   "application/x-wais-source" },
    { 1, "sv4cpio","application/x-sv4cpio" },
    { 1, "sv4crc","application/x-sv4crc" },
    { 1, "svg",   "image/svg+xml" },
    { 1, "swf",   "application/x-shockwave-flash" },
    { 1, "t\0\0", "application/x-troff" },
    { 1, "tar",   "application/x-tar" },
    { 0, "tbz",   "application/x-bzip2" },
    { 0, "tbz2",  "application/x-bzip2" },
    { 1, "tcl",   "application/x-tcl" },
    { 1, "tex",   "application/x-tex" },
    { 1, "texi",  "application/x-texinfo" },
    { 1, "texinfo","application/x-texinfo" },
    { 0, "tgz",   "application/x-gzip" },
    { 0, "tz\0",  "application/x-compress" },
    { 0, "tif",   "image/tiff" },
    { 0, "tiff",  "image/tiff" },
    { 1, "tr\0",  "application/x-troff" },
    { 2, "tsv",   "text/tab-separated-values" },
    { 2, "txt",   "text/plain" },
    { 1, "ustar", "application/x-ustar" },
    { 2, "vbs",   "text/plain" },
    { 1, "vcd",   "application/x-cdlink" },
    { 0, "vob",   "video/mpeg" },
    { 1, "vrml",  "model/vrml" },
    { 1, "vxml",  "application/voicexml+xml" },
    { 1, "wav",   "audio/x-wav" },
    { 1, "wbmp",  "image/vnd.wap.wbmp" },
    { 1, "wbxml", "application/vnd.wap.wbxml" },
    { 0, "wma",   "audio/x-ms-wma" },
    { 2, "wml",   "text/vnd.wap.wml" },
    { 1, "wmlc",  "application/vnd.wap.wmlc" },
    { 2, "wmls",  "text/vnd.wap.wmlscript" },
    { 1, "wmlsc", "application/vnd.wap.wmlscriptc" },
    { 0, "wmv",   "video/x-ms-wmv" },
    { 1, "wrl",   "model/vrml" },
    { 2, "xbm",   "image/x-xbitmap" },
    { 2, "xht",   "application/xhtml+xml" },
    { 2, "xhtml", "application/xhtml+xml" },
    { 2, "xls",   "application/vnd.ms-excel" },
    { 2, "xml",   "application/xml" },
    { 2, "xpm",   "image/x-xpixmap" },
    { 2, "xsl",   "application/xml" },
    { 2, "xslt",  "application/xslt+xml" },
    { 2, "xul",   "application/vnd.mozilla.xul+xml" },
    { 1, "xwd",   "image/x-xwindowdump" },
    { 1, "xyz",   "chemical/x-xyz" },
    { 0, "z\0\0", "application/x-compress" },
    { 0, "zip",   "application/zip" },
};

/* memory alloc here will not free */
int init_mimetypes_hash(void) {
	int i;
	const char *p0;

	mimetypehash = shallocz(sizeof(void *)*HASHSLOT);
	if(mimetypehash==NULL) return -ENOMEM;

	for(i=0; i < sizeof(mimetypes)/sizeof(*mimetypes); i++) {
		const int h = HASH4(mimetypes[i].ext);
		mimetypes[i].next = mimetypehash[h];
		mimetypehash[h] = mimetypes + i;
	}

	for(i=0; (p0=myconfig_get_multivalue("addtype", i)); i++)  {
		char *p;
		if((p=shdup(p0))==NULL)
			return -ENOMEM;
		int n;
		char *field[100];
		if((n = str_explode(NULL, p, field, 100)) < 2)
			continue;
		const char * const mime = field[0];
		int j;
		for(j=1; j<n; j++) {
		    if(field[j][0] != '.') {
			continue;
		    }
		    if(field[j][1]=='\0') continue;
		    char e[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
		    strncpy(e, field[j]+1, 8);
		    const int h = HASH4(e);
		    struct mrec *m;
		    for(m = mimetypehash[h]; m; m=m->next)
			if(HASH8(e)==HASH8(m->ext))
			    break;
		    if(m==NULL) {
			m = shalloc(sizeof(struct mrec));
			if(m==NULL)
				return -ENOMEM;
			m->gzippable = 1;
			HASH8(m->ext) = HASH8(e);
			m->next = mimetypehash[h];
			mimetypehash[h] = m;
		    }
		    m->mime = mime;
		}
	}

	gzmode = myconfig_get_intval("gzip_mode", 0);
	if(gzmode<=0)
		gzmode = 0;
	else if(gzmode==1)
		gzmode = 1;
	else
		gzmode = 2;

    /* compress_order */
    compress_first_array = shalloc(sizeof(struct compress_first_type_array));
    compress_order = myconfig_get_intval("compress_order", 0);    
    if ((compress_order < 0) || (compress_order > 3))
        compress_order = 0;
    
    // 0: x.htm
    // 1: x.htm.gzip -> x.htm.deflate -> x.htm
    // 2: x.htm -> x.htm.gzip -> x.htm.deflate
    // 3: according to 1 or 2 or 0
    if (compress_order != 3) {
        compress_first_array->count = 0;
    }
    else { 
        /* compress_first_type */
        char* p;        
        for(i=0; (p=myconfig_get_multivalue("compress_first_type", i)); i++) {
            strncpy(compress_first_array->type[i], p, COMPRESS_FIRST_TYPE_LENGTH_MAX-1);
            compress_first_array->type[i][COMPRESS_FIRST_TYPE_LENGTH_MAX] = 0;
            ++compress_first_array->count;            
            if (compress_first_array->count > COMPRESS_FIRST_TYPE_NUMBER_MAX) break;
	    }
        if (0 == compress_first_array->count)
            compress_order = 0;
    }    

	return 0;
}

const char *get_mime_type( register char *ext, int *gz ) {
	register struct mrec *m;
	char e[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
	strncpy(e, ext, 8);

	for(m = mimetypehash[HASH4(e)]; m; m=m->next) {
		if(HASH8(e)==HASH8(m->ext)) {
			if(gz) *gz = m->gzippable;
			return m->mime;
		}
	}

	if(gz) *gz = 1;
	return NULL;
}

