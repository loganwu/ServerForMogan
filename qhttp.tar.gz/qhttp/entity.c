#include "myalloc.h"
#include <alloca.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include "compat_stat64.h"
#include "compat_openat.h"

#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "fdinfo.h"
#include "conn.h"
#include "thread.h"
#include "entity.h"
#include "profile.h"
#include "task.h"
#include "util.h"
#include "shmem.h"
#include "priv.h"
#include "log.h"
#include "vhost.h"
#include "stat.h"
#include "filecount.h"

//#define USE_LOG_CALLSTACK

int (*get_entity_internal)(struct worker *, const char *, void **) = get_entity_nocache;
void (*put_entity_internal)(struct worker *, void *) = put_entity_nocache;

static const struct baseconn stub_gz = {
#if TRACE_FD
    "gzip"
#endif
};

enum {
	EM_PREFIX,	// prefix document_root path
	EM_ABSPATH,	// require chroot() + CAP_SYS_CHROOT
	EM_OPENAT,	// require openat()
	EM_CHDIR,	// require unshare()
};
int entity_access_method = EM_ABSPATH;

/* open_gzfile() {{{1 */
/* return: 0=notretry 1=retry */
static int open_gzfile(const char *filename, time_t mtime, off_t size, struct worker *wt, int update) {
	int fd=0, m=0;
	char *zf;
	char *zbuf = NULL;
	struct fdentity *fe;
	stat64_t st;

	m = strlen(filename);
	if(m > path_max-4) return OE_BAD;
    
	if(filename==wt->workbuf || filename==wt->fnbuf) {
	    zf = wt->workbuf;
	} else if(wt->aclbuf){
	    zf = wt->aclbuf;
	    memcpy(zf, filename, m);
	} else if((zbuf=malloc(path_max))){
	    zf = zbuf;
	    memcpy(zf, filename, m);
	} else
	    return OE_BAD;

	/* copy four char ".gz\0" */
	*(uint32_t *)(zf+m) = *(uint32_t *)".gz";
	ISDSTAT(atomic_inc(&countermap->opencnt));

	PROFILE_START;
#if IOPERF_SUPPORT
	if(ioperf_exp) {
	    uint64_t iostart = readtsc();
#endif
	    const char *p;
	    switch(entity_access_method) {
	        default:
	        case EM_PREFIX:
	        case EM_ABSPATH:
		        fd = fast_open2(zf, O_RDONLY|O_LARGEFILE);
		        break;
	        case EM_OPENAT:
		        p = zf;
		        while(*p=='/') p++;
		        fd = fast_openat3(fd_docroot, p, O_RDONLY|O_LARGEFILE);
		        break;
	        case EM_CHDIR:
		        p = zf;
		        while(*p=='/') p++;
		        fd = fast_fchdir(fd_docroot)<0 ? -1 : fast_open2(p, O_RDONLY|O_LARGEFILE);
		        break;
	    }
#if IOPERF_SUPPORT
	    uint64_t iostop = readtsc() - iostart;
	    wt->ioperf_sum += iostop;
	    wt->workconn->iowait += iostop;
	}
#endif

	PROFILE_WORKER(PROFILE_OPEN_FILE);
	zf[m] = '\0';
	if(zbuf) free(zbuf);
	if(fd<0) {
		/* gzfile not found, retryable */
	    return OZ_TRY;
	}

	PROFILE_START;
	fast_filestat(fd, &st);
	PROFILE_WORKER(PROFILE_STAT_FILE);

	if(!S_ISREG(st.st_mode) || st.st_size <= 2) {
	    /* gzfile not a regular file, not retry */
	    fast_close(fd);
	    return OE_BAD;
	}
	if(st.st_mtime != mtime) {
	    /* gzfile outdated, retryable */
	    fast_close(fd);
	    return OZ_TRY;
	}
	if( st.st_size >= 0x80000000LL || (int)(size - st.st_size) < 32) {
	    /* non-zippable */
	    fast_close(fd);
	    return OE_BAD;
	}

	check_new_fd(fd);

	ENTITY_TRACE("inc openfds");
	FDTRACER_OPEN(fd,update,pthread_self(),filename);
	ISDSTAT(atomic_inc(&countermap->openfds));
	fe = fdent(fd);
	fe->entity = (struct entity_hash *)&stub_gz;
	fe->zfd = OE_BAD;
	fe->size = st.st_size;
	fe->mtime = st.st_mtime;
	fe->mime = "application/x-gzip";
	return fd;
}

/* return: 0=notfound 1=dir */
static int open_file(const char *filename, struct worker *wt, int update) {
	int fd = 0;
	struct fdentity *fe;
	stat64_t st;
	char *ext;

	if(filename==NULL || filename[0]!='/')
	    return OE_BAD;

	if(need_chroot && allow_access_chroot(filename, wt->aclbuf)==0)
	    return OE_BAD;

	ISDSTAT(atomic_inc(&countermap->opencnt));

	PROFILE_START;
#if IOPERF_SUPPORT
	if(ioperf_exp) {
	    uint64_t iostart = readtsc();
#endif        
	    const char *p;
	    switch(entity_access_method) {
	        default:
	        case EM_PREFIX:
	        case EM_ABSPATH:
		        fd = fast_open2(filename, O_RDONLY|O_LARGEFILE);
		        break;
	        case EM_OPENAT:
		        p = filename;
		        while(*p=='/') p++;
		        fd = fast_openat3(fd_docroot, p, O_RDONLY|O_LARGEFILE);
		        break;
	        case EM_CHDIR:
		        p = filename;
		        while(*p=='/') p++;
		        fd = fast_fchdir(fd_docroot)<0 ? -1 : fast_open2(p, O_RDONLY|O_LARGEFILE);
		        break;
	    }
#if IOPERF_SUPPORT
	    uint64_t iostop = readtsc() - iostart;
	    wt->ioperf_sum += iostop;
	    wt->workconn->iowait += iostop;
	}
#endif

	PROFILE_WORKER(PROFILE_OPEN_FILE);
	if(fd<0) return OE_BAD;

	if(need_chroot==0 &&
		allow_access_realroot(fd, wt->aclbuf)==0)
	{
	    fast_close(fd);
	    return OE_BAD;
	}

	PROFILE_START;
	fast_filestat(fd, &st);
	PROFILE_WORKER(PROFILE_STAT_FILE);

	if(S_ISDIR(st.st_mode)) {
	    fast_close(fd);
	    return OE_DIR;
	}

	if(!S_ISREG(st.st_mode) || (st.st_mode&0444) != 0444)
	{
	    fast_close(fd);
	    return OE_BAD;
	}

	check_new_fd(fd);

	fe = fdent(fd);
	fe->entity = NULL;
	ENTITY_TRACE("inc openfds");
	FDTRACER_OPEN(fd,update,pthread_self(),filename);
	ISDSTAT(atomic_inc(&countermap->openfds));
	fe->size = st.st_size;
	fe->mtime = st.st_mtime;
	fe->mime = NULL;

	ext = strrchr(filename, '/');
	if(ext == NULL)
	    ext = strrchr(filename, '.');
	else
	    ext = strrchr(ext+1, '.');

	if(ext != NULL) 
	    fe->mime = get_mime_type(ext+1, &fe->zfd);

	if(fe->mime==NULL)
	    fe->mime = "application/octet-stream";

	if(fe->size < 128 || fe->size >= 0x80000000LL ||
		fe->zfd + gzmode < 3) /* gzip disabled */
	    fe->zfd = OE_BAD;
	else
	    fe->zfd = OZ_TRY;
	    
	return fd;
}

static inline void close_file(int fd) {
	if(bugcheck(fdent(fd)->entity != NULL)) {
	    lprintf("%s(%d): closing an inuse entity, fd=%d\n", __FILE__, __LINE__, fd);
	    fdent(fd)->entity = NULL;
	}
	barrier();
	ENTITY_TRACE("dec openfds");
	FDTRACER_CLOSE(fd,pthread_self());
	ISDSTAT(atomic_dec(&countermap->openfds));
	fast_close(fd);
}

const char *resolve_filename(const char *filename, struct worker *wt) {
	if(entity_access_method!=0) return filename;

	if(filename == wt->workbuf + docrootlen) {
	    memcpy(wt->workbuf, docroot, docrootlen);
	    return wt->workbuf;
	}

	int l = strlen(filename);
	/* filename too long */
	if(l+docrootlen+1 > path_max)
	    return NULL;
	memmove(wt->fnbuf+docrootlen, filename, l);
	memcpy(wt->fnbuf, docroot, docrootlen);
	wt->fnbuf[docrootlen+l] = '\0';
	filename = wt->fnbuf;
	return wt->fnbuf;
}

int update_mementity(const char *filename, struct mementity *oe, struct worker *wt) {
	struct fdentity *ne;
	int fd;

	ENTITY_TRACE(NULL);
	filename = resolve_filename(filename, wt);
	fd = open_file(filename, wt, 1);
	ne = fdent(fd);
	if(fd <= 2) return fd;
	if(ne->mtime != oe->mtime || ne->size != oe->size) {
#if FILECOUNT_SUPPORT
		ne->fcid = oe->fcid ? : get_fcid(filename);
#endif
		if(ne->zfd==OZ_TRY)
		    ne->zfd = open_gzfile(filename, ne->mtime, ne->size, wt, 1);
		return fd;
	}
	if(oe->zsize==OZ_TRY) {
	    ne->zfd = open_gzfile(filename, oe->mtime, oe->size, wt, 1);
		if(ne->zfd == OE_BAD) {
	    	oe->zsize = OE_BAD;
		}
	    else if(ne->zfd != OZ_TRY) {
#if FILECOUNT_SUPPORT
		    ne->fcid = oe->fcid ? : get_fcid(filename);
#endif
	    	return fd;
	    }
	}
	close_file(fd);
#if FILECOUNT_SUPPORT
	if(oe->fcid==NULL)
	    oe->fcid = get_fcid(filename);
#endif
	return OE_FRESH;
}

/* update_fdentity() {{{1 */
int update_fdentity(const char *filename, struct fdentity *oe, int upz, struct worker *wt) {
	struct fdentity *ne;
	int fd;

	ENTITY_TRACE(NULL);
	filename = resolve_filename(filename, wt);
	fd = open_file(filename, wt, 1);
	ne = fdent(fd);
	if(fd <= 2) return fd;
	if(ne->mtime != oe->mtime || ne->size != oe->size) {
#if FILECOUNT_SUPPORT
		ne->fcid = oe->fcid ? : get_fcid(filename);
#endif
		if(ne->zfd==OZ_TRY)
		    ne->zfd = open_gzfile(filename, ne->mtime, ne->size, wt, 1);
		return fd;
	}
	if(oe->zfd==OZ_TRY) {
	    ne->zfd = open_gzfile(filename, oe->mtime, oe->size, wt, 1);
	    if(ne->zfd > 2) {
			if(ne->zfd == OE_BAD)
				oe->zfd = OE_BAD;
			else if(ne->zfd != OZ_TRY) {
				if(upz) {
					oe->zfd = ne->zfd;
				}
				else {
	#if FILECOUNT_SUPPORT
					ne->fcid = oe->fcid ? : get_fcid(filename);
	#endif
					return fd;
				}
			}
	    }
	}
	close_file(fd);
#if FILECOUNT_SUPPORT
	if(oe->fcid==NULL)
	    oe->fcid = get_fcid(filename);
#endif
	return OE_FRESH;
}

int open_fdentity(const char *name, struct worker *wt) {
	const char *filename = resolve_filename(name, wt);

	ENTITY_TRACE(NULL);
	int fd;
	fd = open_file(filename, wt, 0);
	if(fd > 2) {
#if FILECOUNT_SUPPORT
	    fdent(fd)->fcid = get_fcid(name);
#endif
	    if(fdent(fd)->zfd==OZ_TRY)
		    fdent(fd)->zfd = open_gzfile(filename, fdent(fd)->mtime, fdent(fd)->size, wt, 0);
	}
	return fd;
}

void close_fdentity(int fd) {
	ENTITY_TRACE(NULL);
	int zfd = fdent(fd)->zfd;
	if(isfd(zfd)) {
	    fdent(zfd)->entity = NULL;
	    close_file(zfd);
	}
	fdent(fd)->entity = NULL;
#if FILECOUNT_SUPPORT
	put_fcid(fdent(fd)->fcid);
#endif
	close_file(fd);
}

int dup_fdentity(int fd) {
	int nfd = dup(fd);
	int zfd;

	ENTITY_TRACE(NULL);
	if(nfd <= 2) return OE_BAD;
	FDTRACER_OPEN(nfd,2,pthread_self(),NULL);
	ISDSTAT(atomic_inc(&countermap->openfds));
	memcpy(fdent(nfd), fdent(fd), sizeof(struct fdentity));
	fdent(nfd)->entity = NULL;
	zfd = fdent(nfd)->zfd;
	if(zfd > 2) {
	    int zsize = fdent(zfd)->size;
	    zfd = dup(zfd);
	    if(zfd <= 2)
	    	fdent(nfd)->zfd = 1;
	    else {
			FDTRACER_OPEN(zfd,2,pthread_self(),NULL);
		    ISDSTAT(atomic_inc(&countermap->openfds));
		    fdent(nfd)->zfd = zfd;
		    fdent(zfd)->entity = (struct entity_hash *)&stub_gz;
		    fdent(zfd)->size = zsize;
	    }
	}
	return nfd;
}

int get_entity_nocache(struct worker *wt, const char *filename, void **pent) {
	ENTITY_TRACE(NULL);
	int fd = open_fdentity(filename, wt);

	if(fd < 2)
		return -fd-1;
	*pent = INT2PTR(fd);
	return 0;
}

void put_entity_nocache(struct worker *wt, void *ent) {
	if(isfd(ent)) {
		ENTITY_TRACE(NULL);
	    close_fdentity(PTR2INT(ent));
	}
}

#if IOPERF_SUPPORT
unsigned int ioperf_avg;
unsigned int ioperf_cur;
unsigned int ioperf_exp;
#include "avgexp.h"

static void ioperf_task(void *p) {
	int i;
	unsigned int n0, n1;

	for(i=n0=n1=0; i<nworks; i++) {
		n0 += worker[i].ioperf_10s;
		n1 += worker[i].ioperf_avg;
	}
	ioperf_cur = n0 / nworks;
	ioperf_avg = n1 / nworks;
	ISDSTAT(countermap->ioperf = ioperf_cur);
	ISDSTAT(countermap->ioperf_avg = ioperf_avg);
}

static void ioperf_calc(struct worker *wt) {
	if(ioperf_exp==0) return;
	/* calculate IO performance */
	int p = 10000*wt->ioperf_sum / (wt->tsc_now - wt->ioperf_ptsc);
	wt->ioperf_avg = (wt->ioperf_avg * ioperf_exp +
		(65536-ioperf_exp) * p) >> 16;
	wt->ioperf_10s = (wt->ioperf_10s * avgexp[0] +
		(65536-avgexp[0]) * p) >> 16;
	wt->ioperf_sum = 0;
	wt->ioperf_ptsc = wt->tsc_now;
}

int ioperf_init(void) {
    ioperf_exp = myconfig_get_intval("ioperf_averaging_time", 600);
    ioperf_exp = ioperf_exp <= 0 ? 0 :
	                               (ioperf_exp/=10) >= NAVGEXP ? avgexp[NAVGEXP-1] :
	                                                             avgexp[ioperf_exp-1];
    if(ioperf_exp) {
	    register_privilege_task(ioperf_task, NULL);
	    register_worker_task(ioperf_calc);
    }
    return 0;
}

#endif

int init_entity_access_method(void) {
	if(need_chroot==1)
	    entity_access_method = EM_ABSPATH;
	else if(has_openat > 0)
	    entity_access_method = EM_OPENAT;
	else if(has_unshare > 0)
	    entity_access_method = EM_CHDIR;
	else
	    entity_access_method = EM_PREFIX;
	return 0;
}

#ifdef USE_ENTITY_TRACE
#include <pthread.h>
void print_entity_trace(const char* track, const char* file, int line, const char* function) {
	volatile int curfds = atomic_read(&countermap->openfds);
	volatile unsigned long thread = (unsigned long)pthread_self();
	if (NULL == track)
		lprintf("[FD-TRACE][%d][%lu]-->[%s:%d:%s]", curfds, thread, file, line, function);
	else
		lprintf("[FD-TRACE][%d][%lu]-->[%s:%d:%s]%s", curfds, thread, file, line, function, track);
}
#endif // USE_ENTITY_TRACE

