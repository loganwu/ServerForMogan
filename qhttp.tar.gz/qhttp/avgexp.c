#include <stdio.h>
#include <math.h>

#define P 65536.0

int main(){
        int i;
	FILE *f;

	f = fopen("avgexp.h", "wt");
	fprintf(f, "const unsigned short avgexp[] = { \n");
        for(i=1; i<360; i++) {
                int n =  P /exp(1.6/10.0/i) + 0.5;
                fprintf(f, "\t%d, /* %d */\n", n, i);
        }
	fprintf(f, "};\n");
	fprintf(f, "#define NAVGEXP	sizeof(avgexp)/sizeof(unsigned short)\n");
	fclose(f);
	return 0;
}
