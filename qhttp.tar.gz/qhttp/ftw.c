#include <dirent.h>

int walktree(const char *name) {
	char buf[4096];
	int len[50];
	DIR *dir[50];
	int depth = 0;
	struct dirent *de;
	int nl;
	struct stat st;

	len[0] = strlen(name);
	memcpy(rootbuf, name, rootlen);
	buf[len[0]] = '/';
	bzero(dir, 0, sizeof(dir));

	while(depth >= 0) {
		if(dir[depth]==NULL) {
			buf[len[depth]] = '\0';
			dir[depth] = opendir(buf);
			if(dir[depth] == NULL)
				depth--;
		} else if((de = readdir(dir[depth]))==NULL) {
			closedir(dir[depth]);
			dir[depth] = NULL;
			depth--;
		} else {
			if(de->d_name[0]=='.') {
				if(de->d_name[1] == '\0')
					continue;
				if(de->d_name[1] == '.' && de->d_name[2] == '\0')
					continue;
			}
			nl = strlen(de->d_name);
			memcpy(buf+len[depth]+1, de->d_name, nl);
			nl += len[depth] + 1;
			buf[nl] = '\0';
			if(lstat(buf, &st) < 0) continue;
			if(S_ISREG(st.st_mode) || S_ISLNK(st.st_mode))
				printf("FILE %s\n", buf+len[0]);
			else if(S_ISDIR(st.st_mode))
				len[++depth] = nl;
		}
	}
	return 0;
}

