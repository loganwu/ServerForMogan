
#define ROLE_STARTUP	0
#define ROLE_ROOT	1
#define ROLE_OWNER	2
#define ROLE_GUEST	3

#define PRIV_CHROOT	0x1
#define PRIV_SETUID	0x2
#define PRIV_SETGID	0x4
#define PRIV_NETBIND	0x8
#define PRIV_HUGETLB	0x10
#define PRIV_RESOURCE	0x20

extern int main_chown;
extern int need_chroot;

extern int check_capability(void);
extern void init_capability(void);
extern void show_capability(const char *);
extern void set_capability_role(int role);
extern void init_privilege(void);
extern void set_security_role(int);
