/* vim: set sw=4 ai :*/
#include "myalloc.h"
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <arpa/inet.h>

#include "autoconfig.h"
#include "task.h"
#include "filemon.h"
#include "util.h"
#include "log.h"
#include "thread.h"
#include "fdinfo.h"
#include "shmem.h"

struct iprange {
	uint32_t start;
	uint32_t last1;
};

struct array {
	int num;
	int total;
	struct iprange range[0];
};

struct blacklist {
	struct blacklist *next;
	int active;
	char *filename;
	struct array *map;
};

struct blacklist *blacklist;

static const char *parse_range(const char *str, uint32_t *addr) {
	uint32_t addr1, addr2;

	addr1 = str2ip(str, &str);
	if(addr1==INADDR_NONE)
	    return "bad start address";

	if(*str=='\0') {
	    addr[0] = addr[1] = addr1;
	    return NULL;
	}
	if(*str++ != '-')
	    return "bad syntax";

	if((addr2=str2ip(str, &str))==INADDR_NONE ||
		*str != '\0' ||
		ntohl(addr2) < ntohl(addr1))
	    return "bad last address";

	addr[0] = addr1;
	addr[1] = addr2;
	return NULL;
}

static int rcmp(const void *a, const void *b) {
	register const struct iprange *ar = a, *br = b;
	if(ar->start < br->start)
	    return -1;
	if(ar->start > br->start)
	    return 1;
	return 0;
}

void reload_blacklist(int fd, void *priv, stat64_t *st) {
	struct blacklist *bl = priv;
	int size;
	char *buf;
	char *str, *strn;
	const char *err;
	uint32_t addr[2] = {0, 0};
	struct array *m = NULL;

	if(fd <= 0)
	    return;
	size = fast_lseek(fd, 0L, SEEK_END);
	if(size > 1<<20) {
	    fast_close(fd);
	    return;
	}
	buf = malloc(size+1);
	if(buf==NULL) {
	    fast_close(fd);
	    return;
	}
	fast_lseek(fd, 0L, SEEK_SET);
	fast_read(fd, buf, size);
	fast_close(fd);
	buf[size] = '\0';

	for(str=buf, strn=NULL; str; str=strn) {
	    strn = strchr(str, '\n');
	    if(strn) *strn++ = '\0';
	    str += strspn(str, " \t\r\n");
	    if(str[0]=='\0'||str[0]=='#'||str[0]==';')
		continue;
	    str[strcspn(str, " \t\r\n")] = '\0';
	    err = parse_range(str, addr);
	    if(err)
	    	lprintf("blacklist: %s: %s\n", str, err);

	    if(m==NULL) {
	    	m = malloc(sizeof(struct array)+16*sizeof(struct iprange));
		if(m==NULL)
			enomem();
		m->num = 0;
		m->total = 16;
	    } else if(m->num >= m->total) {
	        struct array *m1;
		m1 = realloc(m, 
			sizeof(struct array)+2*m->total*sizeof(struct iprange));
		if(m1) {
			m = m1;
			m1->total *= 2;
		}
	    }
	    if(m->num < m->total) {
	    	m->range[m->num].start = ntohl(addr[0]);
		m->range[m->num].last1 = ntohl(addr[1])+1;
		m->num++;
	    }
	}
	free(buf);
	if(m) {
		int i;
		qsort(m->range, m->num, sizeof(struct iprange), rcmp);
		/* detect overlay */
		for(i=0; i<m->num-1; i++) {
		    if(m->range[i].last1 >= m->range[i+1].start) {
		    	int j;
		    	m->range[i].last1 = m->range[i+1].last1;
			m->num--;
			for(j=i+1; j<m->num; j++) {
				m->range[j].start = m->range[j+1].start;
				m->range[j].last1 = m->range[j+1].last1;
			}
		    }
		}
		if(bl->map && bl->map->num == m->num && 
			!memcmp(bl->map->range, m->range,
				m->num * sizeof(struct iprange)))
		{
		    free(m);
		} else {
		    delay_free(bl->map, 60);
		    bl->map = m;
		}
	}
}

/* blacklist object never free-ed */
struct blacklist *new_blacklist(const char *filename) {
	struct blacklist *b;
	int fd;

	for(b=blacklist; b; b=b->next) {
		if(!strcmp(filename, b->filename))
			return b;
	}
	b = shalloc(sizeof(struct blacklist));
	if(b==NULL)
		enomem();
	b->filename = shdup(filename);
	b->active = 0;
	b->map = NULL;
	b->next = blacklist;
	blacklist = b;
	
	fd = open_global_file(filename, O_RDONLY, 0666);
	if(fd > 0) {
		reload_blacklist(fd, b, NULL);
	}
	register_file_monitor(filename, reload_blacklist, b);
	return b;
}

int match_blacklist(struct blacklist *b, uint32_t addr) {
	int l, h, m;
	struct array *a = b->map;
	struct iprange *r;

	if(!a) return 0;
	addr = ntohl(addr);
	l = 0; h = a->num-1;
	while(l<=h) {
		m = (l+h)/2;
		r = &a->range[m];

		if(addr < r->start)
			h = m - 1;
		else if(addr >= r->last1)
			l = m + 1;
		else
			return 1;
	}
	return 0;
}

