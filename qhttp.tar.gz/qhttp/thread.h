struct threadstat;
struct thread {
	char name[16];
	int (*entry)(void *);
	void *arg;
	void *stack;

	pthread_t tid;
	pid_t pid;

	unsigned short id;
	unsigned char state;
	unsigned char inuse;

	int rv;
	unsigned int seed;
};

enum {
	THREAD_UNUSED = 0,	/* slot not used */
	THREAD_STOPPED = 1,	/* not running */
	THREAD_STANDBY,		/* in standby list */
	THREAD_STARTING,	/* starting thread */
	THREAD_RUNNING,		/* busy running */
	THREAD_STOPPING,	/* stopping req */
	THREAD_EXITED,		/* exited */
	THREAD_KILLED		/* killed */
};

extern int threadmode;
extern struct thread mainthread;
extern unsigned long mainstack;
#if USE_TLS
extern __thread int mythreadid __attribute__((TLS_MODEL));
#endif
extern int threads_max;
extern int sys_threads_max;
extern int thread_stack_min;
extern int main_stack_size;
extern int stack_block_size;
extern int stack_guard_size;
extern int stack_used;
extern int init_thread_mode(void);
extern int init_thread_stack(void);
extern int init_thread_data(void);
extern int register_thread(const char *name, int(*entry)(void *), void *priv);
extern void init_pthread(void);
extern int start_work_threads(struct threadstat *);
extern void stop_threads(struct threadstat *);
extern void thread_jumbo_title(void);
#if USE_TLS
static inline int get_thread_id(void) { return mythreadid; }
#else
extern int get_thread_id(void);
#endif
extern struct thread *get_my_thread(void);
extern struct thread *get_thread_by_pid(int pid);
extern int allocate_rtsig(int);
extern void start_lockab(int);
extern void check_dynamic_workers(void);
extern void check_stack_usage(void);
extern void enomem(void)__attribute__((noreturn));
extern int *(*fn__errno_location)(void);
extern int *(*fn__h_errno_location)(void);
