
/*
 * MACRO:
 *   FD
 *   PTR (optional)
 *   SIZE
 *   MIME
 *   MTIME
 *   EOFF (optional)
 *   ESIZE (optional)
 *   ZFD (optional)
 *   ZPTR (optional)
 *   ZSIZE (optional)
 */

({
#ifndef EOFF
#define EOFF 0
#endif
	__label__ ims, iums, ir, noims;

    	static void * const imsjump[] = { &&noims, &&ims, &&iums, &&ir, &&noims };
	off64_t plen;
	goto *imsjump[c->ims];
ims:
	if(MTIME && MTIME == c->imstime) {
	    http_header(c, 304, NULL, 0, MTIME, SIZE);
	    return;
	}
	goto noims;
iums:
	if(MTIME && MTIME != c->imstime) {
	    http_header(c, 412, NULL, 0, MTIME, SIZE);
	    return;
	}
	goto noims;
ir:
	if(!MTIME || MTIME != c->imstime) {
	    c->range_start = 0;
	    c->range_last = -1;
	}
noims:

	if(SIZE==0) {
	    if(c->range_start > 0)
		http_header(c, 416, MIME, 0, MTIME, SIZE);
	    else
		http_header(c, 200, MIME, 0, MTIME, SIZE);
	    return;
	} else if(c->range_start >= SIZE) {
	    http_header(c, 416, MIME, 0, MTIME, SIZE);
	    return;
	}
	if(c->range_last==-1 || c->range_last >= SIZE) {
	    c->range_last = SIZE - 1;
	}
	c->sendfd_start = EOFF + c->range_start;
	c->sendfd_end = EOFF + c->range_last + 1;
	plen = c->sendfd_end - c->sendfd_start;
#ifdef PTR
	void *ptr = NULL;
#endif
	if(c->method!=METHOD_HEAD) {
#ifdef FD
		c->sendfd = FD;
#elif defined(PTR)
		ptr = PTR + c->sendfd_start;
#endif
#if THROTTLE_SUPPORT
	    if(c->speed) {
		uint64_t tsc = readtsc();
		if(tsc > c->send_tsc)
		    c->send_tsc = tsc;
	    }
#endif
	}

	if(
#ifdef ESIZE
		plen == ESIZE
#else
		plen == SIZE
#endif
	)
	{
#ifdef ZSIZE
	    if(
#ifdef PTR
		    ptr &&
#else
		    c->sendfd &&
#endif
		    c->gzippable &&
#ifdef ZFD
		    ZFD
#else
		    ZSIZE
#endif
		    > 2)
	    {
		c->gzipped = 1;
		plen = ZSIZE;
#if defined(ZFD)
		c->sendfd = ZFD;
		//c->sendfd_start = 0; // already zero
		c->sendfd_end = plen;
#elif defined(ZPTR)
		ptr = ZPTR;
		c->sendfd_end = plen;
#else
		c->sendfd_start += SIZE;
		c->sendfd_end = c->sendfd_start + plen;
#endif
	    }
#endif
	    http_header(c, 200, MIME, plen, MTIME, SIZE);
#ifdef ESIZE
	} else if(plen==SIZE) {
	    http_header(c, 200, MIME, plen, MTIME, SIZE);
#endif
	} else {
	    http_header(c, 206, MIME, plen, MTIME, SIZE);
	}
#ifdef PTR
	if(ptr) {
	    struct iovec *v = GETIOV(c, c->sendlen);
	    v[0].iov_base = c->sendbuf;
	    v[0].iov_len = c->sendlen;
	    v[1].iov_base = ptr;
	    v[1].iov_len = plen;
	    SETIOV(c, v, 2);
	}
#endif
});

#undef FD
#undef PTR
#undef SIZE
#undef MIME
#undef MTIME
#undef EOFF
#undef ESIZE
#undef ZFD
#undef ZPTR
#undef ZOFF
#undef ZSIZE
