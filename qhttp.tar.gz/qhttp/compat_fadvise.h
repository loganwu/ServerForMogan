#ifndef __COMPAT_FADVISE_H_
#define __COMPAT_FADVISE_H_

#include <unistd.h>
#include "syscall.h"

#ifdef __NR_fadvise64_64
static inline int fadvise(int fd, off64_t off, off64_t len, int adv) {
	return syscall(__NR_fadvise64_64, off, len, adv);
}

static inline int fadvise_l32(int fd, off64_t off, off_t len, int adv) {
	return syscall(__NR_fadvise64, off, len, adv);
}
#else
static inline int fadvise(int fd, off64_t off, off64_t len, int adv) {
	return syscall(__NR_fadvise64, off, len, adv);
}

#endif

#endif
