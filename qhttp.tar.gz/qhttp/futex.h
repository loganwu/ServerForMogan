#ifndef __LOCK_H_H_
#define __LOCK_H_H_

#include <stdint.h>
typedef volatile uint32_t futex_t;

extern int futex_init(futex_t *lk);
extern int futex_lock(futex_t *lk);
extern int futex_trylock(futex_t *lk);
extern int futex_unlock(futex_t *lk);
extern int futex_destroy(futex_t *lk);

#endif
