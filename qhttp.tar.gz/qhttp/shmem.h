#include "autoconfig.h"

#if DEBUG_MALLOC
#include <sys/mman.h>
#include "myalloc.h"
#define shalloc(x)	NONFREE(my_malloc_debug((x),__FILE__,__LINE__))
#define shalloc1(x)	NONFREE(my_malloc_debug((x),__FILE__,__LINE__))
#define shalloc4(x)	NONFREE(my_memalign_debug(4,(x),__FILE__,__LINE__))
#define shalloc8(x)	NONFREE(my_memalign_debug(8,(x),__FILE__,__LINE__))
#define shalign(x,y)	NONFREE(my_memalign_debug((y),(x),__FILE__,__LINE__))
#define shallocz(x)	NONFREE(my_calloc_debug(1, (x),__FILE__,__LINE__))
#define shdup(x)	NONFREE(my_strdup_debug((x),__FILE__,__LINE__))
static inline void free_shmem(void) { }
static inline void report_free_shmem(void) { }
#else
#define shallocz shalloc
extern void *shalloc(int)__attr_malloc__;
extern void *shalloc1(int)__attr_malloc__;
extern void *shalloc4(int)__attr_malloc__;
extern void *shalloc8(int)__attr_malloc__;
extern void *shalign(int,int)__attr_malloc__;
extern char *shdup(const char *)__attr_malloc__;
extern void free_shmem(void);
extern void report_free_shmem(void);
#endif

extern unsigned long shmem_initsize;
#define SHMEM_NEEDED(x,y)	(shmem_initsize += (x)*(y))
extern int hugepagesize;
extern int hugepagetotal;
extern int hugepagefree;
extern unsigned long hugepagealloc;
extern unsigned long memtop;
extern unsigned long memtotal;
#if __WORDSIZE==32
extern unsigned long memhalf;
#endif
extern unsigned long shmmax;
extern int init_shmem_data(void);
extern void *try_mmap(int size);
extern void *huge_mmap(int size);
extern void detect_memory_mode(void);
extern int detect_hugetlb(void);
