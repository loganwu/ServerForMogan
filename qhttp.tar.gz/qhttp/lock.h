
struct mutex {
    int (*lock)(struct mutex *, int);
    int (*trylock)(struct mutex *, int);
    int (*unlock)(struct mutex *, int);
    void (*destroy)(struct mutex *);
};

typedef struct mutex mutex_t;

extern mutex_t *CreatePosixMutex(int);
extern mutex_t *CreateSysVSem(int);
extern mutex_t *CreateLinuxFutex(int);

