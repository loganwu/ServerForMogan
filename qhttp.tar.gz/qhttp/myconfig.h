#ifndef _H_MYCONFIG_H_
#define _H_MYCONFIG_H_

#include <regex.h>

extern int myconfig_init(int argc, char **argv);
extern int myconfig_put_value(const char *prefix, const char *key, const char *val);
extern int myconfig_get_intval(const char *key, int def);
extern unsigned long myconfig_get_size(const char *key, int def);
extern double myconfig_get_decimal(const char *key);
extern char * myconfig_get_value(const char *key);
extern char * myconfig_get_multivalue(const char *key, int index);
extern int myconfig_cleanup(void);
extern const char *dirindex;
extern const char *bindir;
extern const char *confdir;
extern const char *logdir;
extern const char *docroot;
extern int docrootlen;
extern const char *datadir;

// ***BEGIN*** Added by yorkwang for file cache on 2008-01-25
extern regex_t *fcache_url_pattern;
// ***END*** Added by yorkwang for file cache on 2008-01-25

// ***BEGIN*** Added by yorkwang for relay on 2008-01-31
extern int relay_mode;
// ***END*** Added by yorkwang for relay on 2008-01-31
#endif
