#ifndef __H_COMPAT_SYSVIPC_H_
#define __H_COMPAT_SYSVIPC_H_

#if __x86_64__
#define fast_shmget shmget
#define fast_shmat shmat
#define fast_shmctl shmctl
#else
#include "realconfig.h"

#if INLINE_SYSCALL
#include "autoconfig.h"
#else
#include <unistd.h>
#include <asm/unistd.h>
#define fast_ipc4(x...) syscall(__NR_ipc, x)
#define fast_ipc5(x...) syscall(__NR_ipc, x)
#endif

#ifndef SHMAT
#define SHMAT		21
#endif

#ifndef SHMDT
#define SHMDT		22
#endif

#ifndef SHMGET
#define SHMGET		23
#endif

#ifndef SHMCTL
#define SHMCTL		24
#endif

#ifndef SHM_HUGETLB
#define SHM_HUGETLB 04000
#endif

#ifndef SEMOP
#define SEMOP            1
#endif
#ifndef SEMGET
#define SEMGET           2
#endif
#ifndef SEMCTL
#define SEMCTL           3
#endif
#ifndef SEMTIMEDOP
#define SEMTIMEDOP       4
#endif

#if INLINE_SYSCALL
static inline int fast_shmget(int key, int size, int flag) {
        return fast_ipc4(SHMGET, key, size, flag);
}
static inline void *fast_shmat(int id, void *addr, int flag) {
	void *raddr;
	int rv;
	rv = fast_ipc5(SHMAT, id, flag, (int)&raddr, addr);
	if(rv < 0)
		return (void *)rv;
	return raddr;
}
static inline int fast_shmctl(int id, int op, void *ptr ) {
        return fast_ipc5(SHMCTL, id, op, 0, ptr);
}

static inline int fast_semget(int id, int n, int mode) {
        return fast_ipc5(SEMGET, id, n, mode, 0);
}
static inline int fast_semop(int id, void *ptr, int n) {
        return fast_ipc5(SEMOP, id, n, 0, ptr);
}
static inline int fast_semctl(int id, int n, int op, void *ptr ) {
	char dummy[64];
	if(ptr==NULL) ptr = dummy;
        return fast_ipc5(SEMCTL, id, n, op, ptr);
}
#elif COMPAT_GLIBC
static inline int sys_shmctl(int id, int op, void *ptr ) {
        return fast_ipc5(SHMCTL, id, op, 0, ptr);
}
static inline int sys_semop(int id, void *ptr, int n) {
        return fast_ipc5(SEMOP, id, n, ptr, 0);
}
static inline int sys_semget(int id, int n, int mode) {
        return fast_ipc5(SEMGET, id, n, mode, 0);
}
static inline int sys_semctl(int id, int n, int op, void *ptr ) {
	char dummy[64];
	if(ptr==NULL) ptr = dummy;
        return fast_ipc5(SEMCTL, id, n, op, ptr);
}
#else
#define sys_shmctl shmctl
#define sys_semget shmget
#define sys_semctl shmctl
#define sys_semop shmop
#endif

#endif

#endif
