#include <stdlib.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <net/if.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <endian.h>
#include "compat_ctype.h"
#include "compat_epoll.h"
#include "compat_errno.h"
#include "compat_thread.h"

#include "autoconfig.h"

#include "shmem.h"
#include "myconfig.h"
#include "global.h"
#include "conn.h"
#include "listen.h"
#include "util.h"
#include "daemon.h"
#include "http.h"
#include "log.h"
#include "thread.h"
#include "fault.h"
#include "sysctl.h"
#include "listen.h"
#include "stat.h"
#include "watchdog.h"

#ifndef SI_TKILL
#define SI_TKILL        -6              /* sent by tkill system call */
#endif

struct fdinfo_listen {
	struct baseconn *conn;
	int listenid;
};

struct listener {
	int fd;
	char *path;
	void (*func)(int);
};

static struct worker * (*schedule_connection)(int);
static struct worker * schedule_connection_pipe(int);
static struct worker * schedule_connection_batch(int);
static struct worker * schedule_connection_balance(int);
static struct worker * schedule_connection_latency(int);
#if WITH_RTSIG
static int accept_connections_rtsig(void *name);
static void accept_tcp_rtsig(int);
static void accept_unix_rtsig(int);
static void accept_sendfd_rtsig(int);
static void accept_pipefd_idle_rtsig(int);
#endif
static int accept_connections_epoll(void *name);
static void accept_tcp_epoll(int);
static void accept_unix_epoll(int);
static void accept_sendfd_epoll(int);
static void accept_pipefd_idle_epoll(int);
void stop_listener();

static uint64_t switchtsc;
static uint64_t currenttsc;
static int incthread = 0;
static int inctotal = 0;
int incbatch __init__ = 256;
static int overflow = 0;
static uint64_t overflowtsc = 0;
static int nlistening __init__ = 0;
static struct listener *listener __init__;
static struct threadstat *thst;
static struct list_head idle_list = LIST_HEAD_INIT(idle_list);
static int pipe2incoming;
struct blacklist *incblist;
static int so_sndbuf __init__;
static int so_rcvbuf __init__;
static int lepfd __init__ ;
static int pid_idle;
static struct epoll_event *evs;
#if WITH_RTSIG
static struct pollfd *pfds;
#endif
static int nevs;
static int loopdelay;

static inline void delay_loop() {
	if(loopdelay) {
		struct timespec tv = { 0, loopdelay };        
        fast_nanosleep(&tv, &tv);
	}
}

static inline void add_listener(int fd, void (*func)(int), char *name) {
	name = strdup(name);
	if(name==NULL) return;

    if (func == accept_tcp_epoll) 
        lprintf("listener is %s", "accept_tcp_epoll");
#if WITH_RTSIG
    else if (func == accept_tcp_rtsig) 
        lprintf("listener is %s", "accept_tcp_rtsig");
#endif
    else if (func == accept_unix_epoll) 
        lprintf("listener is %s", "accept_unix_epoll");
#if WITH_RTSIG
    else if (func == accept_unix_rtsig) 
        lprintf("listener is %s", "accept_unix_rtsig");
#endif
    else if (func == accept_sendfd_epoll) 
        lprintf("listener is %s", "accept_sendfd_epoll");
#if WITH_RTSIG
    else if (func == accept_sendfd_rtsig) 
        lprintf("listener is %s", "accept_sendfd_rtsig");
#endif
    else if (func == accept_pipefd_idle_epoll) 
        lprintf("listener is %s", "accept_pipefd_idle_epoll");
#if WITH_RTSIG
    else if (func == accept_pipefd_idle_rtsig) 
        lprintf("listener is %s", "accept_pipefd_idle_rtsig");
#endif
    else
        lprintf("listener is %s", "unknown");
    
	struct fdinfo_listen *info;
	set_stub(fd, listenstub);
	info = (struct fdinfo_listen *)(fdinfo+fd);
	info->listenid = nlistening;
	listener[nlistening].fd = fd;
	listener[nlistening].path = name;
	listener[nlistening].func = func;
	nlistening++;
}

static inline int already_listen(char *name) {
	int i;
	for(i=0; i<nlistening; i++) {
		if(listener[i].path==NULL)
			continue;
		if(!strcmp(name, listener[i].path))
			return 1;
	}
	return 0;
}

static int init_socket_tcp(char *portstr, struct ifreq *ifr, int nifr) {
	struct sockaddr_in addr;
	int fd;
	int optval;
	int count = 50;
	int port = 80;
	int i1, i2;
	char *p, *ifc = NULL;
	struct timespec ts;
	char *path;

	if(portstr == NULL || portstr[0]=='\0') return -1;

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	
	if(portstr[0]=='*') {
	    if(portstr[1]=='\0') { /* "*" */
	        port = 80;
	    } else if(portstr[1] != ':' || /* "*:port" */
		    (port=strtoul(portstr+2, &p, 0), *p))
		goto badport;
	    ifc = "*";
	    goto ok;
	}
	port = strtoul(portstr, &p, 0);
	if(!*p) { /* "port" */
	    ifc = "*";
	    goto ok;
	}
	addr.sin_addr.s_addr = str2ip(portstr, (const char **)&p);
	if(addr.sin_addr.s_addr != INADDR_NONE) {
		if(*p=='\0') { /* "ip" */
		    port = 80;
		} else if(*p!=':' || /* "ip:port" */
			(port=strtoul(p+1, &p, 0), *p))
		    goto badport;
		goto ok;
	}

	if((p=strrchr(portstr, ':'))) {
	    /* "intf:port" */
	    i2 = p - portstr;
	    port = strtoul(p+1, &p, 0);
	    if(*p) goto badport;
	} else { /* "intf" */
	    i2 = strlen(portstr);
	    port=80;
	}
	if(i2 > IFNAMSIZ) goto badport;
	for(i1=0; i1<nifr; i1++) {
	    if(ifr[i1].ifr_addr.sa_family!=AF_INET) continue;
	    if((i2 == IFNAMSIZ || ifr[i1].ifr_name[i2]=='\0') &&
		    !strncmp(ifr[i1].ifr_name, portstr, i2))
	    {
		ifc = ifr[i1].ifr_name;
		addr.sin_addr.s_addr = ((struct sockaddr_in *)&ifr[i1].ifr_addr)->sin_addr.s_addr;
	    }
	}
	if(ifc==NULL) goto badport;

ok:
	if(port <= 0 || port >= 65536) goto badport;
	addr.sin_port = htons(port);

	if(ifc==NULL) {
	    for(i1=0; i1<nifr; i1++) {
		if(ifr[i1].ifr_addr.sa_family!=AF_INET) continue;
		if( addr.sin_addr.s_addr == ((struct sockaddr_in *)&ifr[i1].ifr_addr)->sin_addr.s_addr)
		    ifc = ifr[i1].ifr_name;
	    }
	    if(ifc==NULL && *(char *)&addr.sin_addr==127)
		    ifc = "lo";
	    if(ifc==NULL) {
		lprintf("Warning: no interface matching port %s\n", portstr);
		ifc = "?";
	    }
	}

	path = alloca(22);
	p = ip2str(path, addr.sin_addr.s_addr);
	*p++ = ':';
	uint2str(p, ntohs(addr.sin_port))[0] = '\0';
	if(already_listen(path))
		return 0;

	if(nlistening == 1024) {
	    lprintf("Too much listening port defined, port %s:%d (%s) ignored\n",
		    ifc, port, portstr);
	    return -1;
	}

	fd = fast_socket(AF_INET, SOCK_STREAM, 0);
	if(fd < 0) {
		FIX_ERRNO(fd);
		lprintf("socket(AF_INET, SOCK_STREAM, 0): %m\n");
		return -1;
	}

	optval = 1;
	fast_setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval));
	struct linger linger = { 0, 0 };
	fast_setsockopt(fd, SOL_SOCKET, SO_LINGER, (int *)&linger, sizeof(linger));

	while(!stop && (i1=fast_bind(fd, (struct sockaddr *)&addr, sizeof(addr))) < 0) {
	    if(!(i1==-EADDRINUSE||(i1==-1&&errno==EADDRINUSE)) || --count < 0) {
		FIX_ERRNO(i1);
		lprintf("bind(%s): %m\n", portstr);
		return -1;
	    }
	    ts.tv_sec = 0; ts.tv_nsec = 100000000;
	    fast_nanosleep(&ts, &ts);
	}
	if(stop) return -1;

	if((i1=fast_listen(fd, myconfig_get_intval("listen_queue_backlog", 10000))) < 0) {
	    FIX_ERRNO(i1);
	    lprintf("listen(%s): %m\n", portstr);
	    return -1;
	}
	lprintf("Listening at port: %s:%d (%s)\n", ifc, port, portstr);
	fast_fcntl(fd, F_SETFL, fast_fcntl2(fd, F_GETFL) | O_NONBLOCK);
	fast_fcntl(fd, F_SETFD, FD_CLOEXEC);

	optval = myconfig_get_intval("defer_accept", 10);
	if(optval) fast_setsockopt(fd, SOL_TCP, TCP_DEFER_ACCEPT, &optval, sizeof(optval));

	optval = myconfig_get_intval("tcp_nodelay", 1);
	if(optval) {
		fast_setsockopt(fd, SOL_TCP, TCP_NODELAY, &optval, sizeof(optval));
		optval = 0;
		if(fast_setsockopt(fd, SOL_TCP, TCP_CORK, &optval, sizeof(optval))!=0)
		    patch_cork = 1;
	}

	if(so_sndbuf)
	    fast_setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &so_sndbuf, sizeof(int));

	if(so_rcvbuf)
	    fast_setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &so_rcvbuf, sizeof(int));

	add_listener(fd,
#if WITH_RTSIG
		pollmode||nconns==1?accept_tcp_epoll:accept_tcp_rtsig,
#else
		accept_tcp_epoll,
#endif
		path
		);
	return 0;
badport:
	lprintf("Unrecognized port: %s\n", portstr);
	return -1;
}

static int init_socket_unix(char *path) {
	struct sockaddr_un addr;
	int fd;
	int count = 50;
	int n;
	struct timespec ts;

	if(already_listen(path))
		return 0;
	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	if(strlen(path) > sizeof(addr.sun_path)-1)
	{
		lprintf("UNIX socket path name %s too long\n", path);
		return -1;
	}
	strcpy(addr.sun_path, path);
	
	if(nlistening == 1024) {
	    lprintf("Too much listening port defined, path %s ignored\n", path);
	    return -1;
	}

	fd = fast_socket(AF_UNIX, SOCK_STREAM, 0);
	if(fd < 0) {
		FIX_ERRNO(fd);
		lprintf("socket(AF_UNIX, SOCK_STREAM, 0): %m\n");
		return -1;
	}

	fast_setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (n=1,&n), sizeof(n));

	n = SUN_LEN(&addr);
	if(path[0]=='@')
		addr.sun_path[0] = '\0';
	while(!stop && (n=fast_bind(fd, (const struct sockaddr *)&addr, n)) < 0) {
	    if(--count < 0) {
	    	FIX_ERRNO(n);
		lprintf("bind(%s): %m\n", path);
		return -1;
	    }
	    ts.tv_sec = 0; ts.tv_nsec = 100000000;
	    fast_nanosleep(&ts, &ts);
	}
	if(stop) return -1;

	if((n=fast_listen(fd, myconfig_get_intval("listen_queue_backlog", 10000))) < 0) {
		FIX_ERRNO(n);
		lprintf("listen(%s): %m\n", path);
		return -1;
	}
	lprintf("Listening at path %s\n", path);
	fast_fcntl(fd, F_SETFL, fast_fcntl2(fd, F_GETFL) | O_NONBLOCK);
	fast_fcntl(fd, F_SETFD, FD_CLOEXEC);

	if(so_sndbuf)
	    fast_setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &so_sndbuf, sizeof(int));

	if(so_rcvbuf)
	    fast_setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &so_rcvbuf, sizeof(int));

	add_listener(fd,
#if WITH_RTSIG
		pollmode||nconns==1?accept_unix_epoll:accept_unix_rtsig,
#else
		accept_unix_epoll,
#endif
		path);
	return 0;
}

static int init_socket_sendfd(char *path) {
	struct sockaddr_un addr;
	int fd;
	int count = 50;
	int n;
	struct timespec ts;

	if(already_listen(path))
		return 0;
	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_UNIX;
	if(strlen(path) > sizeof(addr.sun_path)-1)
	{
		lprintf("UNIX socket path name %s too long\n", path);
		return -1;
	}
	strcpy(addr.sun_path, path);
	
	if(nlistening == 1024) {
	    lprintf("Too much listening port defined, path %s ignored\n", path);
	    return -1;
	}

	fd = fast_socket(AF_UNIX, SOCK_DGRAM, 0);
	if(fd < 0) {
	    FIX_ERRNO(fd);
	    lprintf("socket(AF_UNIX, SOCK_DGRAM, 0): %m\n");
	    return -1;
	}

	fast_setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (n=1,&n), sizeof(n));
	fast_setsockopt(fd, SOL_SOCKET, SO_PASSCRED, (n=1,&n), sizeof(n));

	n = SUN_LEN(&addr);
	if(path[0]=='@')
		addr.sun_path[0] = '\0';
	while(!stop && (n=fast_bind(fd, (const struct sockaddr *)&addr, n)) < 0) {
	    if(--count < 0) {
	    	FIX_ERRNO(n);
		lprintf("bind(%s): %m\n", path);
		return -1;
	    }
	    ts.tv_sec = 0; ts.tv_nsec = 100000000;
	    fast_nanosleep(&ts, &ts);
	}
	if(stop) return -1;

	lprintf("Accept FD at path %s\n", path);
	fast_fcntl(fd, F_SETFL, fast_fcntl2(fd, F_GETFL) | O_NONBLOCK);
	fast_fcntl(fd, F_SETFD, FD_CLOEXEC);

	add_listener(fd,
#if WITH_RTSIG
		pollmode||nconns==1?accept_sendfd_epoll:accept_sendfd_rtsig,
#else
		accept_sendfd_epoll,
#endif
		path);
	return 0;
}

#if WITH_RTSIG
int rtsig_add_fdset(fd_set *fdset) {
	int i;

	for(i=0; i<nlistening; i++)
	    FD_SET(listener[i].fd, fdset);
	return nlistening;
}

int rtsig_add_pollfd(struct pollfd *pfd) {
	int i;

	for(i=0; i<nlistening; i++) {
	    pfd[i].fd = listener[i].fd;
	    pfd[i].events = POLLIN;
	}
	return nlistening;
}

int rtsig_add_listening(int pid) {
    	int i;

	for(i=0; i<nlistening; i++) {
	    fast_fcntl(listener[i].fd, F_SETOWN, pid);
	    fast_fcntl(listener[i].fd, F_SETSIG, rtsigno);
	    fast_fcntl(listener[i].fd, F_SETFL, O_RDWR|O_NONBLOCK|O_ASYNC);
	}
	return nlistening;
}

int rtsig_set_listening(int pid) {
	int i;

	for(i=0; i<nlistening; i++) {
	    fast_fcntl(listener[i].fd, F_SETOWN, pid);
	}
	return nlistening;
}

#endif

int epoll_add_listening(int epfd) {
	struct epoll_event ev;
	int i;

	ev.events = POLLIN;
	for(i=0; i<nlistening; i++) {
	    ev.data.fd = listener[i].fd;
	    fast_epoll_ctl(epfd, EPOLL_CTL_ADD, listener[i].fd, &ev);
	}
	return nlistening;
}

int epoll_stop_listening(int epfd) {
	struct epoll_event ev;
	int i;

	for(i=0; i<nlistening; i++) {
	    /* 2.4 epoll patch require unused ev */
	    fast_epoll_ctl(epfd, EPOLL_CTL_DEL, listener[i].fd, &ev);
	}
	return nlistening;
}

static void create_idle_pipe(void) {
	int fd[2];

	if(pipe_buffer_size<65536) {
	    int n;
	    fast_socketpair(AF_UNIX, SOCK_STREAM, 0, fd);
	    n = 65536;
	    fast_setsockopt(fd[0], SOL_SOCKET, SO_RCVBUF, &n, sizeof(n));
	} else
	    pipe(fd);
	pipe_idle = fd[1];
	fast_fcntl(fd[0], F_SETFL, O_RDONLY|O_NONBLOCK);
	if(nconns > 1)
	    fast_fcntl(fd[1], F_SETFL, O_WRONLY|O_NONBLOCK);
	if(pollmode)
	    add_listener(fd[0], accept_pipefd_idle_epoll, "idle-pipe");
#if WITH_RTSIG
	else
	    add_listener(fd[0], accept_pipefd_idle_rtsig, "idle-pipe");
#endif
}

static void create_incoming_pipe(void) {
	int fd[2];

	/* AF_UNIX+SOCK_DGRAM has wake-one feature on read side */
	fast_socketpair(AF_UNIX, SOCK_DGRAM, 0, fd);
	pipe_incoming = fd[0];
	pipe2incoming = fd[1];
	/*FIXME? block or non-block*/
	fast_fcntl(fd[1], F_SETFL, O_WRONLY|O_NONBLOCK);
}

int init_listen_socket(void){
	struct ifconf ifc;
	struct ifreq *ifr = NULL;
	int nifr = 0;
	int i;
	char *p;

	so_sndbuf = myconfig_get_intval("send_socket_buffer", 65536);
	so_rcvbuf = myconfig_get_intval("recv_socket_buffer", 65536);

	i = myconfig_get_intval("listen_queue_backlog", 10000);
	if(i<mconns && myconfig_get_intval("defer_accept", 10))
	    i = mconns;
	if(i) sysctl_increase_value("/proc/sys/net/ipv4/tcp_max_syn_backlog", i);

	if(nconns==1) {
	    schedule_connection = schedule_connection_pipe;
	} 
    else {
	    schedule_connection = schedule_connection_batch;
	    incbatch = 256;
	    p = myconfig_get_value("scheduler");
	    if(p==NULL) {
		    incbatch = 256;
	    } 
        else if(is_digit(p[0])) {
		    incbatch = atoi(p);
		    if(incbatch < 1) incbatch = 1;
	    } 
        else if(!strncasecmp(p, "batch:", 6)) {
		    incbatch = atoi(p+6);
		    if(incbatch < 1) incbatch = 1;
	    } 
        else if(!strncasecmp(p, "balance", 7)) {
		    if(direct_accept)
		        lprintf("scheduler balance not avaible for direct accept mode\n");
		    else
		        schedule_connection = schedule_connection_balance;
	    } 
        else if(!strncasecmp(p, "latency:", 8)) {
		    if(direct_accept)
		        lprintf("scheduler latency not avaible for direct accept mode\n");
		    else {
		        incbatch = atoi(p+8);
		        if(incbatch <= 0) incbatch = nconns1;
		        schedule_connection = schedule_connection_latency;
		    }
	    } 
        else if(!strcasecmp(p, "latency")) {
		    if(direct_accept)
		        lprintf("scheduler latency not avaible for direct accept mode\n");
		    else {
		        incbatch = nconns1;
		        schedule_connection = schedule_connection_latency;
		    }
	    } else {
		    incbatch = 256;
	    }
	}
    
    if (schedule_connection == schedule_connection_pipe)
        lprintf("schedule_connection is %s:%d", "schedule_connection_pipe", incbatch);
    else if (schedule_connection == schedule_connection_batch)
        lprintf("schedule_connection is %s:%d", "schedule_connection_batch", incbatch);
    else if (schedule_connection == schedule_connection_balance)
        lprintf("schedule_connection is %s:%d", "schedule_connection_balance", incbatch);
    else if (schedule_connection == schedule_connection_latency)
        lprintf("schedule_connection is %s:%d", "schedule_connection_latency", incbatch);
    else
        lprintf("schedule_connection is %s:%d", "unknown", incbatch);

	switchtsc = tscmsec;
	currenttsc = readtsc();

	i = fast_socket(AF_INET, SOCK_STREAM, 0);
	if(i < 0) {
	    FIX_ERRNO(i);
	    lprintf("socket(AF_INET, SOCK_STREAM, 0): %m\n");
	    return -1;
	}
	ifc.ifc_len = 0;
	ifc.ifc_req = NULL;
	if(ioctl(i, SIOCGIFCONF, &ifc)==0) {
	    ifr = alloca(ifc.ifc_len>128?ifc.ifc_len:128);
	    ifc.ifc_req = ifr;
	    if(ioctl(i, SIOCGIFCONF, &ifc)==0)
		nifr = ifc.ifc_len / sizeof(struct ifreq);
	}
	fast_close(i);

	i=0;
	while(myconfig_get_multivalue("listen_port", i))
	    i++;
	if(i==0) i=1;

	i++; // idle pipe
	listener = shalloc(sizeof(struct listener)*i);
	if(listener==NULL) return -ENOMEM;

	for(i=0; (p=myconfig_get_multivalue("listen_port", i)); i++) {
	    if(*p=='/' || *p=='@')
		init_socket_unix(p);
	    else if(*(uint32_t *)p==*(uint32_t *)"cmsg" && (p[4]=='/' || p[4]=='@'))
	        init_socket_sendfd(p+4);
	    else
		init_socket_tcp(p, ifr, nifr);
	    if(stop) return -1;
	}

	if(i==0) init_socket_tcp("*:80", ifr, nifr);

	if(nlistening==0) {
		lprintf("No listen-port available\n");
		return -1;
	}

	if(nconns==1)
	    create_incoming_pipe();
	if(direct_accept==0) {
	    char *name;
	    if(direct_idle || tsc_idleswitch==0) {
	    	nevs = nlistening;
		    name = "listen";
	    } else {
	    	nevs = maxfds;
		    name = "ilisten";
		    create_idle_pipe();
	    }
	    if(pollmode) {
		    lepfd = fast_epoll_create(nevs);
		    nevs = MIN(nevs, epoll_batch_events);
            lprintf("direct_accept is %d, %s", direct_accept, "accept_connections_epoll");
		    register_thread(name, accept_connections_epoll, name);
		    epoll_add_listening(lepfd);
		    evs = shalloc(nevs * sizeof(struct epoll_event));
		    if(evs==NULL) return -ENOMEM;
	    }
	    #if WITH_RTSIG
	    else {
            lprintf("direct_accept is %d, %s", direct_accept, "accept_connections_rtsig");
		    register_thread(name, accept_connections_rtsig, name);
		    pfds = shalloc(nevs * sizeof(struct pollfd));
		    if(pfds==NULL) return -ENOMEM;
	    }
	    #endif
	}

	p=myconfig_get_value("incoming_blacklist");
	if(p && p[0])
		incblist = new_blacklist(p);

	maxidles = maxfds - 2*mconns - fdcache_max - 1000;
	return 0;
}

void close_idle_connections(struct list_head *head) {
	struct list_head *list;
	struct fdinfo *f;

	/* idle connection timeout */
	list_for_each_entry_safe_l(f, list, head, ilist) {
	    list_del_init(&f->ilist);
	    log_tcpinfo(f - fdinfo);
	    fast_close(f - fdinfo); /* CHECKED OK */
	}
}

void cleanup_sockets(void){
	if(lepfd > 0) {
	    fast_close(lepfd);
	    lepfd = 0;
	}
	if(pipe_idle > 0) {
	    fast_close(pipe_idle);
	    pipe_idle = 0;
	}
	if(pipe_incoming > 0) {
	    fast_close(pipe_incoming);
	    pipe_incoming = 0;
	}

	while(--nlistening >= 0) {
	    fast_close(listener[nlistening].fd);
	    if(listener[nlistening].path) {
		if(listener[nlistening].path[0]=='/')
		    fast_unlink(listener[nlistening].path);
	        free(listener[nlistening].path);
	    }
	}
}

static void exit_listener(void) {
	if(pipe2incoming > 0) {
	    fast_shutdown(pipe2incoming, SHUT_RDWR);
	    fast_close(pipe2incoming);
	    pipe2incoming = 0;
	}
#if 0
	if(pipe_incoming > 0)
	    fast_fcntl(pipe_incoming, F_SETFL, O_RDONLY|O_NONBLOCK);
#endif

	if(!direct_idle && tsc_idleswitch) {
	    close_idle_connections(&idle_list);
	}
}

static struct worker * schedule_connection_balance(int fd) {
#ifdef PROFILE_SUPPORT
	uint64_t tsc = readtsc();
#endif
	int f;
	struct worker *wt;
	char dummy[1];

	ISDSTAT(atomic_inc(&countermap->totalcon));
	for(incthread=0, inctotal=0, wt=NULL; incthread < nworks; incthread++) {
		f = worker[incthread].inc_head - worker[incthread].inc_tail;
		if(f==0) continue;
		if(f < 0) f += nconns1;
		if(f > inctotal) {
		    inctotal = f;
		    wt = worker + incthread;
		}
	}
	if(wt == NULL) {
	    /* connection overflow */
	    ISDSTAT(atomic_inc(&countermap->overflow));
	    fast_close(fd);
	    overflow++;
	    return NULL;
	}

#ifdef PROFILE_SUPPORT
	fdinfo[fd].tsc = tsc;
#endif
	ISDSTAT(atomic_inc(&countermap->workcon));
	barrier();
	ADD_LIST_ITEM(fd, wt->inc_list, wt->inc_tail, nconns1);
#if WITH_RTSIG
	if(pollmode==0) kill(wt->mypid, SIGALRM);
	else
#endif
	fast_write(wt->epwake, dummy, 1);
	return wt;
}

static struct worker * schedule_connection_latency(int fd) {
#ifdef PROFILE_SUPPORT
	uint64_t tsc = readtsc();
#endif
	int f1, f2;
	struct worker *wt;
	char dummy[1];

	ISDSTAT(atomic_inc(&countermap->totalcon));
	
	int n;
	inctotal=0x7FFFFFFF;
	wt=NULL;
	for(n=0; n<nworks; n++) {
		incthread = (incthread+1) % nworks;
		f1 = worker[incthread].inc_tail - worker[incthread].inc_head;
		if(f1!=0) {
		    f2 = worker[incthread].inc_tail - worker[incthread].inc_pend;
		    if(f1 < 0) f1 += nconns1;
		    if(f2 < 0) f2 += nconns1;
		    f1 = f1 + f2 * incbatch;
		    if(f1 < inctotal) {
				inctotal = f1;
				wt = worker + incthread;
		    }
		}
	}

	if(wt == NULL || wt->inc_tail==wt->inc_head) {
	    /* connection overflow */
	    ISDSTAT(atomic_inc(&countermap->overflow));
	    fast_close(fd);
	    overflow++;
	    return NULL;
	}
	inctotal = wt->id;

#ifdef PROFILE_SUPPORT
	fdinfo[fd].tsc = tsc;
#endif
	ISDSTAT(atomic_inc(&countermap->workcon));
	barrier();
	ADD_LIST_ITEM(fd, wt->inc_list, wt->inc_tail, nconns1);
#if WITH_RTSIG
	if(pollmode==0) kill(wt->mypid, SIGALRM);
	else
#endif
	fast_write(wt->epwake, dummy, 1);
	return wt;
}

static struct worker * schedule_connection_batch(int fd) {
	uint64_t tsc = readtsc();
	int thread0;
	struct worker *wt;
	char dummy[1];

	ISDSTAT(atomic_inc(&countermap->totalcon));
	if(inctotal >= incbatch || tsc-currenttsc >= switchtsc) {
	    currenttsc = tsc;
	    incthread = (incthread+1) % nworks;
	}
	thread0 = incthread;
	while(wt=worker+incthread, wt->inc_head == wt->inc_tail) {
	    incthread = (incthread+1) % nworks;
	    inctotal = 0;
	    if(incthread == thread0) {
			/* WRAPPED, connection overflow */
			ISDSTAT(atomic_inc(&countermap->overflow));
			fast_close(fd);
			overflow++;
			return NULL;
	    }
	}
	inctotal++;
#ifdef PROFILE_SUPPORT
	fdinfo[fd].tsc = tsc;
#endif
	ISDSTAT(atomic_inc(&countermap->workcon));
	barrier();
	ADD_LIST_ITEM(fd, wt->inc_list, wt->inc_tail, nconns1);
#if WITH_RTSIG
	if(pollmode==0) kill(wt->mypid, SIGALRM);
	else
#endif
	fast_write(wt->epwake, dummy, 1);
	return wt;
}

static struct worker * schedule_connection_pipe(int fd) {
	ISDSTAT(atomic_inc(&countermap->totalcon));

#ifdef PROFILE_SUPPORT
	fdinfo[fd].tsc = readtsc();
#endif
	if(fast_write(pipe2incoming, (char *)&fd, sizeof(fd)) != sizeof(int)) {
	    ISDSTAT(atomic_inc(&countermap->overflow));
	    fast_close(fd);
	    overflow++;
	    return NULL;
	}
	ISDSTAT(atomic_inc(&countermap->workcon));
	return NULL;
}

static inline void accept_tcp(int lfd, const int isepoll) {
	struct sockaddr_in addr;
	socklen_t len;
	int nfd;
	int in;

	for(in=0; in<incbatch; in++)
	{	
#if 0
		volatile int faultfds = atomic_read(&countermap->openfds);		
		//lprintf("faultfds is %d, guardfds and is %d", faultfds, guardfds);
		if (faultfds > guardfds) {
			stop_listener();
			exit_http();
			break;
		}
#endif

        nfd=fast_accept(lfd, (struct sockaddr *)&addr, (len=sizeof(addr),&len));        
        FAST_ERRNO(nfd);
	    thread_reached(thst);
        if (nfd < 0) {            
            lprintf("(%lu,%lu)->accept error: %s", (unsigned long)getpid(), (unsigned long)pthread_self(), strerror(-nfd)); // EMFILE,ENFILE,EBADF            
            if ((-ECONNABORTED == nfd) || (-EINTR == nfd) || (-EAGAIN == nfd) || (-EWOULDBLOCK == nfd)) {
                break; //continue;
            }
            else {
				stop_listener();
                exit_http();
            }
        }
	    if(incblist && match_blacklist(incblist, addr.sin_addr.s_addr)) {
	    	fast_close(nfd);
	    } else {
		    check_new_fd(nfd);                      
            if (nfd < 0) {
				stop_listener();
                exit_http();
                break;
            }
		    if(isepoll)
		        new_fdinfo_epoll(nfd, addr.sin_addr.s_addr);
#if WITH_RTSIG
		    else
		        new_fdinfo_rtsig(nfd, addr.sin_addr.s_addr);
#endif
    		schedule_connection(nfd);
	    }
	}
}

#if WITH_RTSIG
static void accept_tcp_rtsig(int lfd) { accept_tcp(lfd, 0); }
#endif
static void accept_tcp_epoll(int lfd) { accept_tcp(lfd, 1); }

#if __BYTE_ORDER != __LITTLE_ENDIAN
#define LBIP	0x0100007F
#else
#define LBIP	0x7F000001
#endif
static inline void accept_unix(int lfd, const int isepoll) {
	int nfd;
	int in;

	for(in=0; in<incbatch; in++)
	{
        nfd=fast_accept(lfd, NULL, NULL);
        FAST_ERRNO(nfd);
	    thread_reached(thst);
        if (nfd < 0) {            
            lprintf("accept error: %s", strerror(-nfd)); // EMFILE,ENFILE,EBADF            
            if ((-ECONNABORTED == nfd) || (-EINTR == nfd) || (-EAGAIN == nfd) || (-EWOULDBLOCK == nfd)) {
                break; //continue;
            }
            else {
                exit_http();
            }
        }
	    check_new_fd(nfd);
        if (nfd < 0) {
            exit_http();
            break;
        }
       	if(isepoll)
		new_fdinfo_epoll(nfd, LBIP);
#if WITH_RTSIG
	    else
		new_fdinfo_rtsig(nfd, LBIP);
#endif
	    schedule_connection(nfd);
	}
}

#if WITH_RTSIG
static void accept_unix_rtsig(int lfd) { accept_unix(lfd, 0); }
#endif
static void accept_unix_epoll(int lfd) { accept_unix(lfd, 1); }

static inline void accept_sendfd(int lfd, const int isepoll) {
	struct msghdr msg = { 0 };
	char buf[CMSG_SPACE(sizeof(int)) + CMSG_SPACE(sizeof(struct ucred))];
	struct iovec iov[1];
	struct sockaddr addr;
	int n;

	msg.msg_iov = iov;
	msg.msg_iovlen = 1;
	msg.msg_flags = 0;
	iov->iov_base = &addr;
	iov->iov_len  = sizeof(addr);

	msg.msg_control = buf;
	msg.msg_controllen = sizeof buf;


	int in;
	for(in=0; in<incbatch && (n=fast_recvmsg(lfd, &msg, MSG_TRUNC|MSG_DONTWAIT))>=0; in++)
	{
	    thread_reached(thst);
	    int nfd=-1, uid=-1, gid=-1;
	    struct cmsghdr *cmsg;
	    uint32_t a;

	    /* verify Ancillary data */
	    for(cmsg=CMSG_FIRSTHDR(&msg); cmsg; cmsg=CMSG_NXTHDR(&msg, cmsg)) {
		if(cmsg->cmsg_level != SOL_SOCKET)
		    continue;
		if(cmsg->cmsg_type == SCM_RIGHTS) {
		    if(cmsg->cmsg_len >= CMSG_LEN(sizeof(int))) {
		    	int k = (cmsg->cmsg_len - CMSG_LEN(sizeof(int)))/sizeof(int);
			int *fdptr = (int *)CMSG_DATA(cmsg);
			nfd = fdptr[0];
			for(;k>0;k--)
				fast_close(*++fdptr);
		    }
		} else if(cmsg->cmsg_type == SCM_CREDENTIALS) {
		    if(cmsg->cmsg_len == CMSG_LEN(sizeof(struct ucred))) {
		    	struct ucred *uc = (struct ucred *)CMSG_DATA(cmsg);
			uid = uc->uid;
			gid = uc->gid;
		    }
		}
	    }

	    if(nfd < 0)
	    	continue;

	    /* verify address */
	    a = 0;
	    if(n==0 || (n==sizeof(uint32_t) && (a=*(uint32_t *)&addr)==0))
	    {
	        socklen_t l;
		if(a==0 && fast_getpeername(nfd, &addr, (l=sizeof(addr), &l)) < 0) {
			fast_close(nfd);
			continue;
		}
		n = l;
	    }
	    if(a==0 && n>=sizeof(addr.sa_family)) {
		switch(addr.sa_family) {
		    case AF_INET:
			if(n != sizeof(struct sockaddr_in)) {
			    fast_close(nfd);
			    continue;
			}
			a = ((struct sockaddr_in *)&addr)->sin_addr.s_addr;
			break;
		    case AF_UNIX:
			a = LBIP;
			break;
		    default:
		    	fast_close(nfd);
			continue;
		}
	    }

	    if(incblist && match_blacklist(incblist, a)) {
	    	fast_close(nfd);
	    } else {
		if(so_sndbuf)
		    fast_setsockopt(nfd, SOL_SOCKET, SO_SNDBUF, &so_sndbuf, sizeof(int));
		if(so_rcvbuf)
		    fast_setsockopt(nfd, SOL_SOCKET, SO_RCVBUF, &so_rcvbuf, sizeof(int));
		check_new_fd(nfd);
		if(isepoll)
		    new_fdinfo_epoll(nfd, a);
#if WITH_RTSIG
		else
		    new_fdinfo_rtsig(nfd, a);
#endif
		schedule_connection(nfd);
	    }
	}
}

#if WITH_RTSIG
static void accept_sendfd_rtsig(int lfd) { accept_sendfd(lfd, 0); }
#endif
static void accept_sendfd_epoll(int lfd) { accept_sendfd(lfd, 1); }

static inline void accept_pipefd_idle(int fd, const int isepoll) {
	int n0;

	do {
	    int buf[64];

	    thread_reached(thst);
	    n0 = fast_read(fd, (char *)buf, sizeof(buf)) / sizeof(int);
	    uint64_t tsc = readtsc();
	    uint32_t tsc4 = TSCRND(tsc+tsc_keepalive)+1;
	    int n;
	    for(n=0; n<n0; n++) {
		thread_reached(thst);
		int nfd;
	    	if(isfd(nfd=buf[n]) && is_stub(nfd, idlestub)) {
		    thread_reached(thst);
		    if(list_empty(&fdinfo[nfd].ilist)) {
		        char dummy;
			int len = fast_recv(nfd, &dummy, 1, MSG_PEEK|MSG_DONTWAIT);
			FAST_ERRNO(len);
			if(len==1) {
			    if(isepoll==0 && nconns==1)
				fast_fcntl(nfd, F_SETFL, O_RDWR|O_NONBLOCK);
			    atomic_dec(&idlecon);
			    ISDSTAT(atomic_inc(&countermap->idleresume));
			    set_stub(nfd, NULL);
			    schedule_connection(nfd);
			} else if(len == -EAGAIN) {
			    fdinfo[nfd].tsc4 = tsc4;
			    list_add_tail(&fdinfo[nfd].ilist, &idle_list);
			    if(isepoll) {
				struct epoll_event ev;
				ev.events = POLLIN | EPOLLONESHOT;
				ev.data.fd = nfd; 
				fast_epoll_ctl(lepfd, EPOLL_CTL_ADD, nfd, &ev);
			    } else {
				fast_fcntl(nfd, F_SETOWN, pid_idle);
			    }
			} else {
			    set_stub(nfd, NULL);
			    log_tcpinfo(nfd);
			    barrier();
			    fast_close(nfd);
			}
		    }
		}
	    }
	} while(n0==64);
}

#if WITH_RTSIG
static void accept_pipefd_idle_rtsig(int lfd) { accept_pipefd_idle(lfd, 0); }
#endif
static void accept_pipefd_idle_epoll(int lfd) { accept_pipefd_idle(lfd, 1); }

static inline void accept_incoming(int fd) {
	struct fdinfo_listen *info = (struct fdinfo_listen *)(fdinfo+fd);
	listener[info->listenid].func(fd);
}

static inline int idle_resume(int fd, int events) {
	int len;
	char dummy;

	fdinfo[fd].conn = NULL;
	/* idle connection */
	list_del_init(&fdinfo[fd].ilist);

	atomic_dec(&idlecon);
	if((events & (POLLERR|POLLHUP))) {
	    log_tcpinfo(fd);
	    barrier();
	    fast_close(fd);
	    return 0;
	}
	len = fast_recv(fd, &dummy, 1, MSG_PEEK|MSG_DONTWAIT);
	FAST_ERRNO(len);
	if(len == -EINTR || len == -EAGAIN)
	    return 0;
	if(len <= 0) {
	    log_tcpinfo(fd);
	    barrier();
	    fast_close(fd);
	    return 0;
	}
	ISDSTAT(atomic_inc(&countermap->idleresume));
	return fd;
}

static inline void idle_timer(void) {
	uint64_t tsc = readtsc();
	struct fdinfo *f;
	struct list_head *list;

	/* idle connection timeout */
	list_for_each_entry_safe_l(f, list, &idle_list, ilist) {
	    int fd = f - fdinfo;
	    if(bugcheck(!is_stub(fd, idlestub))) {
	    	lprintf("%s(%d): non-idle fd inside idle list, fd=%d\n", __FILE__, __LINE__, fd);
		fixing_idle_list(&idle_list, idlestub);
		break;
	    }
	    if(f->tsc4>TSCRND(tsc) && atomic_read(&idlecon)<maxidles)
		break;
	    atomic_dec(&idlecon);
	    list_del_init(&f->ilist);
	    f->conn = NULL;
	    log_tcpinfo(fd);
	    barrier();
	    fast_close(fd);
	}
}

#if WITH_RTSIG
static int accept_connections_rtsig(void *name) {
	int fd;
	int i;
	struct fdinfo *f;
	int npfds;
	struct timespec tv;
	int loopdelay;
	sigset_t sset;
	siginfo_t si;
	
	nice(myconfig_get_intval("listen_thread_priority", 0));
	loopdelay = myconfig_get_intval("listen_thread_loop_delay", 0);
	if(loopdelay > 100) loopdelay = 100 *1000000;
	if(loopdelay < 0) loopdelay = 0;
	else loopdelay *= 1000000;

	sigemptyset(&sset);
	sigaddset(&sset, SIGIO);
	sigaddset(&sset, SIGALRM);
	sigaddset(&sset, rtsigno);
	sigprocmask(SIG_BLOCK, &sset, NULL);

	pid_idle = fast_gettid();

	kill(pid_idle, SIGIO);

	/* wait all workers startup */
	for(i=0; i<nworks; i++) {
	    while(!stop && worker[i].mypid==0) {
		tv.tv_sec = 0;
		tv.tv_nsec = 10000000;
		fast_nanosleep(&tv, &tv);
	    }
	}

	rtsig_add_pollfd(pfds);
	rtsig_add_listening(pid_idle);
	npfds = 0;
	const int has_idle = !direct_idle && tsc_idleswitch;
	thst = get_threadstat();
	while(!stop) {
	    if(overflow) {
	    	uint64_t tsc = readtsc();
	    	if(tsc > overflowtsc) {
		    lprintf("%s(%d:%lu): %d connection overflowed\n",
			    __FILE__, __LINE__, (unsigned long)pthread_self(), overflow);
		    overflowtsc = tsc + 10*tscsec;
		    overflow = 0;
		}
	    } else if(loopdelay) {
		tv.tv_sec = 0;
		tv.tv_nsec = loopdelay;
		fast_nanosleep(&tv, &tv);
	    }

	    npfds = 0;
	    tv.tv_sec = POLL_TIMEOUT/1000;
	    tv.tv_nsec = (POLL_TIMEOUT%1000)*1000000;
	    if((i=sigtimedwait(&sset, &si, &tv))==rtsigno) {
		if(si.si_code > 0) {
		    pfds[0].fd = si.si_fd;
		    pfds[0].revents = si.si_band &(POLLIN|POLLHUP|POLLERR);
		    npfds = 1;
		}
	    } else if(i==SIGIO) {
	        thread_reached(thst);
	    	uint64_t tsc0;
		if(si.si_code==SI_USER || si.si_code==SI_TKILL) {
		    tsc0 = 0;
		} else {
		    tsc0 = readtsc();
		}
		tv.tv_sec = 0;
		tv.tv_nsec = 0;
		while(sigtimedwait(&sset, &si, &tv)==SIGIO)
		    /*  */;
		/* slot 0 overwrite by sigtimedwait */
		pfds[0].fd = listener[0].fd;
		npfds = nlistening;
		list_for_each_entry(f, &idle_list, ilist)
		{
		    pfds[npfds].fd = f - fdinfo;
		    pfds[npfds].events = POLLIN;
		    npfds++;
		}
		if(tsc0)
			lprintf("listen: RT signal queue overflow %"F64"d\n", readtsc()-tsc0);
		/* ADD PFDS */
	        thread_reached(thst);
		if(fast_poll(pfds, npfds, POLL_TIMEOUT) <= 0)
			npfds = 0;
	    }

	    thread_reached(thst);
	    for(i=0; i<npfds; i++) {
		thread_reached(thst);
		fd = pfds[i].fd;
		if(is_stub(fd, listenstub)) {
		    /* listen fd, incoming available */
		    accept_incoming(fd);
		} else if(is_stub(fd, idlestub)) {
		    if(idle_resume(fd, pfds[i].events)) {
		    	if(nconns==1) {
			    fast_fcntl(fd, F_SETOWN, 0);
			    fast_fcntl(fd, F_SETFL, O_RDWR|O_NONBLOCK);
			}
			schedule_connection(fd);
		    }
		}
		/* spurious event */
	    }

	    if(has_idle) idle_timer();
	}

	exit_listener();
	return 0;
}
#endif

static int accept_connections_epoll(void *name) {
	int fd;
	int i, n;
	//struct timespec tv;
	//int loopdelay;
	
	nice(myconfig_get_intval("listen_thread_priority", 0));
	loopdelay = myconfig_get_intval("listen_thread_loop_delay", 0);
	if(loopdelay > 100) loopdelay = 100 *1000000;
	if(loopdelay < 0) loopdelay = 0;
	else loopdelay *= 1000000;
    lprintf("loopdelay is %d", loopdelay);
    lprintf("Thread named %s ID is %d:%lu", (char*)name, (int)getpid(), (unsigned long)pthread_self());

	const int has_idle = !direct_idle && tsc_idleswitch;
	thst = get_threadstat();
	while(!stop) {
	    if(overflow) {
	    	uint64_t tsc = readtsc();
	    	if(tsc > overflowtsc) {
		        lprintf("%s(%d:%lu): %d connection overflowed\n",
			        __FILE__, __LINE__, (unsigned long)pthread_self(), overflow);
		        overflowtsc = tsc + 10*tscsec;
		        overflow = 0;                
		    }
	    }		
		delay_loop();
	    
	    n = fast_epoll_wait(lepfd, evs, nevs, POLL_TIMEOUT);
	    thread_reached(thst);
	    for(i=0; i<n; i++) {
		    thread_reached(thst);
	        fd = evs[i].data.fd;
		    if(is_stub(fd, listenstub)) {
		        /* listen fd, incoming available */
		        accept_incoming(fd);
		    } else if(is_stub(fd, idlestub)) {
		        if(idle_resume(fd, evs[i].events)) {
			        /* 2.4 epoll patch require unused evs */
			        fast_epoll_ctl(lepfd, EPOLL_CTL_DEL, fd, evs);
			        schedule_connection(fd);
		        }
		    }
		/* spurious event */
	    }

	    if(has_idle) idle_timer();
	}

	exit_listener();
	return 0;
}

void stop_listener() {
	while (nlistening>=0) {
		close(listener[nlistening].fd);		
		listener[nlistening].fd = -1;
		--nlistening;
	}
}

