#ifndef _H_ENTITY_H_
#define _H_ENTITY_H_

#include <endian.h>
#include <sys/types.h>
#include "autoconfig.h"
#include "list.h"
#include "atomic.h"

struct entity_hash;
struct worker;
struct entity;
struct filecount;

/* overlay: fdinfo */
struct fdentity {
	struct entity_hash *entity;
	const char *mime;
	off64_t size;
	time_t mtime;
#if FILECOUNT_SUPPORT
	struct filecount *fcid;
#endif
	int32_t zfd;
};
#define fdent(fd) ((struct fdentity *)(fdinfo+(long)(fd)))

struct mementity {
	uint32_t fd;
#if FILECOUNT_SUPPORT
	struct filecount *fcid;
#endif
	time_t mtime;
	int32_t size;
	int32_t zsize;
	const char *mime;
	off64_t offset[0];
	char data[0];
};

extern int init_mimetypes_hash(void);

extern int entity_access_method;
extern int init_entity_access_method(void);
extern int init_entity_access_control(void);
extern int allow_access_chroot(const char *, char *);
extern int allow_access_realroot(int, char *);
extern void update_entity_info(struct entity_hash *);
extern void sort_entity_hits(struct entity_hash **, int, int);
extern void split_entity_hits(struct entity_hash **, int, int);
extern int (*get_entity_internal)(struct worker *, const char *, void **);
extern void (*put_entity_internal)(struct worker *, void *);
extern const char *get_mime_type(register char *, int *);
extern int get_entity_nocache(struct worker *, const char *, void **);
extern void put_entity_nocache(struct worker *, void *);

extern int init_fdcache_mode(void);
extern int init_fdcache_mode_lockless(void);
extern int init_fdcache_mode_global(void);
extern int init_fdcache_global(void);
extern int init_fdcache_lockless(void);
extern void free_fdcache_global(void);
extern void free_fdcache_lockless(void);

#define OE_BAD		0
#define OE_DIR		1
#define OZ_TRY		1
#define OE_FRESH	2

extern int open_fdentity(const char *, struct worker *);
extern void close_fdentity(int fd);
extern int update_fdentity(const char *, struct fdentity *, int, struct worker *);
extern int update_mementity(const char *, struct mementity *, struct worker *);
extern int dup_fdentity(int fd);

extern unsigned int ioperf_avg;
extern unsigned int ioperf_cur;
extern int ioperf_init(void);
extern int gzmode;
extern int compress_order;

#define COMPRESS_FIRST_TYPE_NUMBER_MAX 100
#define COMPRESS_FIRST_TYPE_LENGTH_MAX 16
struct compress_first_type_array {
    int count;
    char type[COMPRESS_FIRST_TYPE_NUMBER_MAX][COMPRESS_FIRST_TYPE_LENGTH_MAX];
};
extern struct compress_first_type_array* compress_first_array;

//#define USE_ENTITY_TRACE
#ifdef USE_ENTITY_TRACE
#define ENTITY_TRACE(track) print_entity_trace(track,__FILE__,__LINE__,__FUNCTION__)
extern void print_entity_trace(const char* track, const char* file, int line, const char* function);
#else
#define ENTITY_TRACE(track)
#endif // USE_FDCACHE_TRACE

#endif
