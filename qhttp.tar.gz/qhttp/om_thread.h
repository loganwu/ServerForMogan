/**
* @file  om_thread.h
* @brief Timed get some stat items
*
* @author yijian
* @date 2008-03-12
* @{
 */
#ifndef __OM_THREAD_H
#define __OM_THREAD_H

#include <pthread.h>
#ifdef __cplusplus
extern "C" {
#endif

struct om_net_dev_param {
    volatile int count;
    volatile unsigned long* t_bytes1;
    volatile unsigned long* t_bytes2;
    volatile unsigned long* t_bytes_deta;
    volatile unsigned long* r_bytes1;
    volatile unsigned long* r_bytes2;
    volatile unsigned long* r_bytes_deta;
};

extern unsigned char start_om_thread_flag;
extern struct om_net_dev_param net_dev_param;
    
int start_om_thread();
void stop_om_thread();
typedef void (*logic_func_def)();
void register_before_logic(logic_func_def logic_func);
void register_after_logic(logic_func_def logic_func);

#ifdef __cplusplus
}
#endif
#endif // __OM_THREAD_H
