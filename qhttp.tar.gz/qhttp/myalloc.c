#define __H_MY_ALLOC_H_
#include <malloc.h>
#include <stdint.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <limits.h>
#include "autoconfig.h"
#include "log.h"
#include "shmem.h"

#if DEBUG_MALLOC
static void *(*old_malloc_hook)(size_t, const void *);
static void *(*old_realloc_hook)(void *, size_t, const void *);
static void *(*old_memalign_hook)(size_t, size_t, const void *);
static void (*old_free_hook)(void *, const void *);
static void *my_malloc(size_t, const void *);
static void *my_realloc(void *, size_t, const void *);
static void *my_memalign(size_t, size_t, const void *);
static void my_free(void *, const void *);
static const int csl = 8;
static pthread_mutex_t lock = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;

static void savehook(void) {
	old_malloc_hook = __malloc_hook;
	old_realloc_hook = __realloc_hook;
	old_memalign_hook = __memalign_hook;
	old_free_hook = __free_hook;
}

static void hook(void) {
	__malloc_hook = my_malloc;
	__realloc_hook = my_realloc;
	__memalign_hook = my_memalign;
	__free_hook = my_free;
	pthread_mutex_unlock(&lock);
}

static void unhook(void) {
	pthread_mutex_lock(&lock);
	__malloc_hook = old_malloc_hook;
	__realloc_hook = old_realloc_hook;
	__memalign_hook = old_memalign_hook;
	__free_hook = old_free_hook;
}

static const char nosym[] = "-nosym-";
struct syminfo {
	const char *file;
	const char *sym;
	const char *func;
	unsigned long line;
};

struct tracer {
	struct tracer *next;
	struct syminfo sym;
	void *addr;
	unsigned int size;
	unsigned char csl;
	unsigned char inuse;
	unsigned char ignore;
};

#define SLOTS 4097
static struct tracer *freelist;
static struct tracer *hashlist[SLOTS];
#if USE_TLS
static __thread struct syminfo *gsym __attribute__((TLS_MODEL));
#define GSYM gsym
#define SGSYM(x)	gsym = (x)
void myalloc_init(void) {}
#else
static struct syminfo *gsym;
static pthread_key_t gsymkey;
static int gsyminited;
#define GSYM	(gsyminited ? (struct syminfo *)pthread_getspecific(gsymkey) : gsym)
#define SGSYM(x)	if(gsyminited) pthread_setspecific(gsymkey, (x)); else gsym = (x)
void myalloc_init(void) {
	pthread_key_create(&gsymkey, NULL);
	gsyminited=1;
}
#endif

static void syminfo_by_src(struct syminfo *sym, const char *func, const char *fn, unsigned ln) {
	sym->func = func;
	sym->file = fn;
	sym->sym = NULL;
	sym->line = ln;
};

static void syminfo_by_addr(struct syminfo *sym, const char *func, const void *addr) {
	sym->func = func;

	Dl_info info;
#if LINK_AS_STATIC
#define dladdr(x, y) 0
#endif
	if(dladdr(addr, &info)) {
		if(info.dli_sname==NULL) {
		    sym->file = info.dli_fname;
		    sym->sym = nosym;
		    sym->line = addr - info.dli_fbase;
		} else {
		    sym->file = info.dli_fname;
		    sym->sym = info.dli_sname;
		    sym->line = addr - info.dli_saddr;
		}
	} else {
		sym->file = NULL;
		sym->sym = NULL;
		sym->line = (unsigned long)addr;
	}
};

#define ISMOD(x)	((x)->sym==nosym)
#define ISSYM(x)	((x)->sym!=NULL)
#define ISADR(x)	((x)->file==NULL)
#define SYMFMT	"%s+%s+0x%lx: %s"
#define SYMARG(x)  (x)->file, (x)->sym, (x)->line, (x)->func
#define SRCFMT "%s(%ld): %s"
#define SRCARG(x)  (x)->file, (x)->line, (x)->func
#define MODFMT "%s+0x%lx: %s"
#define MODARG(x)  (x)->file, (x)->line, (x)->func
#define ADRFMT "0x%lx: %s"
#define ADRARG(x)  (x)->line, (x)->func

#define SYMPRINTF(sym, format, arg...)			\
	{						\
	    if(ISMOD(sym))				\
		lprintf(MODFMT format,MODARG(sym),arg);	\
	    else if(ISSYM(sym))				\
		lprintf(SYMFMT format,SYMARG(sym),arg);	\
	    else if(ISADR(sym))				\
		lprintf(ADRFMT format,ADRARG(sym),arg);	\
	    else					\
		lprintf(SRCFMT format,SRCARG(sym),arg);	\
	}


static void csinit(void *ptr, int len) {
	uint32_t seed = PTR2UINT(ptr);
	uint32_t *u = ptr;
	for(len /= sizeof(uint32_t); len; len--)
		*u++ = rand_r(&seed);
}

static int cscheck(void *ptr, int len) {
	uint32_t seed = PTR2UINT(ptr);
	uint32_t *u = ptr;
	for(len /= sizeof(uint32_t); len; len--)
	    if(*u++ != rand_r(&seed)) return -1;
	return 0;
}

static void trace_alloc(void *result, int size, int csl, const struct syminfo *sym)
{
	if(result==NULL) return;

	int h = (unsigned long)result % SLOTS;
	struct tracer *t = hashlist[h];
	while(t) {
	    if(result==t->addr)
	    	break;
	    t = t->next;
	}
	if(t==NULL) {
		if(freelist==NULL) {
			t = malloc(sizeof(struct tracer)*1024);
			int i;
			for(i=0; i<1024; i++) {
				t[i].next = freelist;
				freelist = t+i;
			}
		}
		t = freelist;
		freelist = t->next;
		t->next = hashlist[h];
		hashlist[h] = t;
	} else if(t->inuse) {
	    SYMPRINTF(sym, "(%d) = 0x%lx return address already used\n",
		    size, (unsigned long)result);
	}
	t->sym = *sym;
	t->addr = result;
	t->inuse = 1;
	t->ignore = 0;
	t->size = size;

	t->csl = csl;

	csinit(result + size, csl);

}

static void trace_free(void *ptr, const struct syminfo *sym)
{
	if(ptr==NULL) return;

	int h = (unsigned long)ptr % SLOTS;
	struct tracer *t = hashlist[h];
	while(t) {
	    if(ptr==t->addr)
	    	break;
	    t = t->next;
	}
	if(t==NULL) {
	    SYMPRINTF(sym, "(0x%lx): invalid addr\n", (unsigned long)ptr);
	} else if(t->inuse) {
	    if(cscheck(ptr+t->size, t->csl)!=0) {
		SYMPRINTF(&t->sym, "(%d) = 0x%lx: BUFFER OVERFLOW\n",
			t->size, (unsigned long)ptr);
		csinit(ptr + t->size, t->csl);
	    }
	    t->inuse = 0;
	    t->sym = *sym;
	} else {
	    SYMPRINTF(sym, "(0x%lx): addr already freed\n", (unsigned long)ptr);
	}

}

void *NONFREE(void *ptr) {
	if(ptr==NULL) return NULL;
	pthread_mutex_lock(&lock);
	int h = (unsigned long)ptr % SLOTS;
	struct tracer *t = hashlist[h];
	while(t) {
	    if(ptr==t->addr) {
		if(t->inuse) t->ignore = 1;
		break;
	    }
	    t = t->next;
	}
	pthread_mutex_unlock(&lock);
	return ptr;
}

void dump_non_free(void){
	struct tracer *t;
	int i;
	for(i=0; i<SLOTS; i++) {
	    for(t=hashlist[i]; t; t=t->next) {
		if(t->inuse) {
		    if(!t->ignore) 
		    {
			SYMPRINTF(&t->sym, "(%d) = 0x%lx addr not-freed\n",
				t->size, (unsigned long)t->addr);
		    }
		    if(cscheck(t->addr+t->size, t->csl)!=0) {
			SYMPRINTF(&t->sym, "(%d) = 0x%lx: BUFFER OVERFLOW\n",
				t->size, (unsigned long)t->addr);
		    }
		}
	    }
	}
}

void myalloc_check(void){
	struct tracer *t;
	int i;
	for(i=0; i<SLOTS; i++) {
	    for(t=hashlist[i]; t; t=t->next) {
		if(t->inuse && cscheck(t->addr+t->size, t->csl)!=0) {
		    SYMPRINTF(&t->sym, "(%d) = 0x%lx: BUFFER OVERFLOW\n",
			    t->size, (unsigned long)t->addr);
		}
	    }
	}
}

static void *my_malloc(size_t size, const void *caller) {
	int l = csl;
	unhook();

	struct syminfo lsym[1];
	struct syminfo *sym = GSYM;
	if(sym==NULL) syminfo_by_addr(sym = lsym, "malloc", caller);

	void *result = malloc(size+l);
	trace_alloc(result, size, l, sym);
	hook();
	return result;
}

static void *my_realloc(void *ptr, size_t size, const void *caller) {
	int l = csl;
	unhook();

	struct syminfo lsym[1];
	struct syminfo *sym = GSYM;
	if(sym==NULL) syminfo_by_addr(sym = lsym, "malloc", caller);

	trace_free(ptr, sym);
	void *result = realloc(ptr, size+l);
	trace_alloc(result, size, l, sym);
	hook();
	return result;
}

static void *my_memalign(size_t alignment, size_t size, const void *caller) {
	int l = csl;
	unhook();

	struct syminfo lsym[1];
	struct syminfo *sym = GSYM;
	if(sym==NULL) syminfo_by_addr(sym = lsym, "malloc", caller);

	void *result = memalign(alignment, size+l);
	trace_alloc(result, size, l, sym);
	hook();
	return result;
}

static void my_free(void *ptr, const void *caller) {
	unhook();

	struct syminfo lsym[1];
	struct syminfo *sym = GSYM;
	if(sym==NULL) syminfo_by_addr(sym = lsym, "malloc", caller);
	trace_free(ptr, sym);
	free(ptr);
	hook();
}

void *my_malloc_debug(size_t size, const char *fn, unsigned ln) {
	struct syminfo sym[1];
	syminfo_by_src(sym, "malloc", fn, ln);
	SGSYM(sym);

	void *result = malloc(size);

	SGSYM(NULL);
	return result;
}

void *my_realloc_debug(void *ptr, size_t size, const char *fn, unsigned ln) {
	struct syminfo sym[1];
	syminfo_by_src(sym, "realloc", fn, ln);
	SGSYM(sym);

	void *result = realloc(ptr, size);
	SGSYM(NULL);
	return result;
}

void *my_memalign_debug(size_t alignment, size_t size, const char *fn, unsigned ln) {
	struct syminfo sym[1];
	syminfo_by_src(sym, "memalign", fn, ln);
	SGSYM(sym);

	void *result = memalign(alignment, size);
	SGSYM(NULL);
	return result;
}

void my_free_debug(void *ptr, const char *fn, int ln) {
	struct syminfo sym[1];
	syminfo_by_src(sym, "free", fn, ln);
	SGSYM(sym);

	free(ptr);
	SGSYM(NULL);
}

void *my_calloc_debug(size_t s, size_t n, const char *fn, unsigned ln) {
	struct syminfo sym[1];
	syminfo_by_src(sym, "calloc", fn, ln);
	SGSYM(sym);

	void *result = calloc(s, n);
	SGSYM(NULL);
	return result;
}

char *my_strdup_debug(const char *str, const char *fn, unsigned ln) {
	struct syminfo sym[1];
	syminfo_by_src(sym, "strdup", fn, ln);
	SGSYM(sym);

	char *result = strdup(str);
	SGSYM(NULL);
	return result;
}

char *my_cfn_debug(const char *str, const char *fn, unsigned ln) {
	struct syminfo sym[1];
	syminfo_by_src(sym, "strdup", fn, ln);
	SGSYM(sym);

	char *result = canonicalize_file_name(str);
	SGSYM(NULL);
	return result;
}

static void myalloc_inithook(void) {
	pthread_mutex_lock(&lock);
	savehook();
	hook();
}

void (*__malloc_initialize_hook)(void) = myalloc_inithook;

#else
void dump_non_free(void){ }
#endif

void report_mallinfo(void) {
	struct mallinfo mi = mallinfo();
	cprintf("mallinfo.   arena: %d\n", mi.arena);
	cprintf("mallinfo. ordblks: %d\n", mi.ordblks);
	cprintf("mallinfo.  smblks: %d\n", mi.smblks);
	cprintf("mallinfo.   hblks: %d\n", mi.hblks);
	cprintf("mallinfo. usmblks: %d\n", mi.usmblks);
	cprintf("mallinfo. fsmblks: %d\n", mi.fsmblks);
	cprintf("mallinfo.uordblks: %d\n", mi.uordblks);
	cprintf("mallinfo.fordblks: %d\n", mi.fordblks);
	cprintf("mallinfo.keepcost: %d\n", mi.keepcost);
}

#if 0 // NOT WORK
static void *hmptr;
static int hmsize;
void *myalloc_morecore(int size) {
	void *p = NULL;
	if(hmptr && hmsize >= size) {
	    p = hmptr;
	    hmptr += size;
	    hmsize -= size;
	} else if(hugepagesize){
	    int n = (size + hugepagesize - 1)/hugepagesize;
	    hmptr = huge_mmap(n*hugepagesize);
	    if(hmptr) {
		p = hmptr;
		hmptr += size;
		hmsize = n*hugepagesize - size;
	    }
	}
	if(p==NULL) p = __default_morecore(size);
	cprintf("__morecore(%d) = %p\n", size, p);
	return p;
}
void *(*__morecore) __MALLOC_PMT ((ptrdiff_t __size)) = myalloc_morecore;
#endif
