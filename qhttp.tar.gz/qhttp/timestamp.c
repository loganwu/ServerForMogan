#include "autoconfig.h"
#include "timestamp.h"
#include "compat_ctype.h"
#include "global.h"

static char tzstr[6] __init__;

const char * const weekname[] = {
    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
};
const char * const monthname[] = {
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};


const char weekstr[] =
"Sun,Mon,Tue,Wed,Thu,Fri,Sat,";

const char mdaystr[] =
" 00  01  02  03  04  05  06  07  08  09 "
" 10  11  12  13  14  15  16  17  18  19 "
" 20  21  22  23  24  25  26  27  28  29  30  31  32 ";

const char monthstr[] =
"Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec ";
static const char monthstr1[] =
"Jan/Feb/Mar/Apr/May/Jun/Jul/Aug/Sep/Oct/Nov/Dec/";

const char yearstr[] =
"1970197119721973197419751976197719781979"
"1980198119821983198419851986198719881989"
"1990199119921993199419951996199719981999"
"2000200120022003200420052006200720082009"
"2001200120122003201420152016201720182019"
"2002200120222003202420252026202720282029"
"2003200120322003203420352036203720382039";

const char secondstr[] =
"00010203040506070809"
"10111213141516171819"
"20212223242526272829"
"30313233343536373839"
"40414243444546474849"
"50515253545556575859";

char * time2alogstr(char *str, time_t tsrc) {
	struct tm tm;
	tsrc -= timezone;
	gmtime_r(&tsrc, &tm);

	*str++ = '0' + tm.tm_mday/10;
	*str++ = '0' + tm.tm_mday%10;
	*str++ = '/';
	*(uint32_t *)str = ((uint32_t *)monthstr1)[tm.tm_mon];
	str += 4;
	*(uint32_t *)str = ((uint32_t *)yearstr)[tm.tm_year-70];
	str += 4;
	*str++ = ':';
	*str++ = '0' + tm.tm_hour/10;
	*str++ = '0' + tm.tm_hour%10;
	*str++ = ':';
	*str++ = '0' + tm.tm_min/10;
	*str++ = '0' + tm.tm_min%10;
	*str++ = ':';
	*str++ = '0' + tm.tm_sec/10;
	*str++ = '0' + tm.tm_sec%10;
	*(uint32_t *)str = *(uint32_t *)tzstr;
	*(uint16_t *)(str+4) = *(uint16_t *)(tzstr+4);
	return str+6;
}

char * time2logstr(char *str, time_t tsrc) {
	struct tm tm;

	tsrc -= timezone;
	gmtime_r(&tsrc, &tm);
	tm.tm_mon ++;

	*(uint32_t *)str = ((uint32_t *)yearstr)[tm.tm_year-70];
	str += 4;
	*str++ = '0' + tm.tm_mon/10;
	*str++ = '0' + tm.tm_mon%10;
	*str++ = '0' + tm.tm_mday/10;
	*str++ = '0' + tm.tm_mday%10;
	*str++ = '0' + tm.tm_hour/10;
	*str++ = '0' + tm.tm_hour%10;
	*str++ = '0' + tm.tm_min/10;
	*str++ = '0' + tm.tm_min%10;
	*str++ = '0' + tm.tm_sec/10;
	*str++ = '0' + tm.tm_sec%10;
	return str;
}

time_t str2time(const char *str) {
#define BAD	0
#define GC	(c=*tstr++)
	const unsigned char *tstr = (const unsigned char *)str;
	char c;
	int year = -1, month, day = -1, sec;

	while(GC != ' ')
		if(!c) return BAD;
	if(is_digit(GC)) {
		day = c - '0';
		if(is_digit(GC)) {
			day = day * 10 + c - '0';
			GC;
		}
		if(c!=' ' && c!='-') return BAD;
		GC;
	}
	switch(c) {
		case 'A': /*Apr,Aug*/
			GC;
			if(c=='p') {
				if(GC != 'r') return BAD;
				month = 2; break;
			} else if(c=='u') {
				if(GC != 'g') return BAD;
				month = 6; break;
			}
			return BAD;
		case 'D': /*Dec*/
			if(GC != 'e') return BAD;
			if(GC != 'c') return BAD;
			month = 10; break;
		case 'F': /*Feb*/
			if(GC != 'e') return BAD;
			if(GC != 'b') return BAD;
			month = 12; break;
		case 'J': /*Jan,Jun,Jul*/
			GC;
			if(c=='a') {
				if(GC != 'n') return BAD;
				month = 11; break;
			} else if(c != 'u') {
				return BAD;
			}
			GC;
			if(c == 'n') {
				month = 4; break;
			} else if(c=='l') {
				month = 5; break;
			}
			return BAD;
		case 'M': /*Mar,May*/
			if(GC != 'a') return BAD;
			GC;
			if(c=='r') {
				month = 1; break;
			} else if(c=='y') {
				month = 3; break;
			}
			return BAD;
		case 'N': /*Nov*/
			if(GC != 'o') return BAD;
			if(GC != 'v') return BAD;
			month = 9; break;
		case 'O': /*Oct*/
			if(GC != 'c') return BAD;
			if(GC != 't') return BAD;
			month = 8; break;
		case 'S': /*Sep*/
			if(GC != 'e') return BAD;
			if(GC != 'p') return BAD;
			month = 7; break;
		default: return BAD;
	}
	GC; if(c!=' ' && c!='-') return BAD;
	GC; if(c==' ') GC;
	if(day==-1) {
		day = c - '0';
		if(is_digit(GC)) {
			day = day * 10 + c - '0';
			GC;
		}
	} else {
		year = c - '0';
		if(is_digit(GC)) {
			year = year * 10 + c - '0';
			if(is_digit(GC)) {
				year = year * 10 + c - '0';
				if(is_digit(GC)) {
					year = year * 10 + c - '0';
					GC;
				}
			}
		}
	}
	if(c!=' ') return BAD;
	GC; if(!is_digit(c)) return BAD;
	sec = (c-'0') * 36000;
	GC; if(!is_digit(c)) return BAD;
	sec += (c-'0') * 3600;
	GC; if(c!=':') return BAD;
	GC; if(!is_digit(c)) return BAD;
	sec += (c-'0') * 600;
	GC; if(!is_digit(c)) return BAD;
	sec += (c-'0') * 60;
	GC; if(c!=':') return BAD;
	GC; if(!is_digit(c)) return BAD;
	sec += (c-'0') * 10;
	GC; if(!is_digit(c)) return BAD;
	sec += c-'0';
	GC; if(c!=' ') return BAD;
	if(year==-1) {
		if(!is_digit(GC)) return BAD;
		year = (c-'0') * 1000;
		if(!is_digit(GC)) return BAD;
		year += (c-'0') * 100;
		if(!is_digit(GC)) return BAD;
		year += (c-'0') * 10;
		if(!is_digit(GC)) return BAD;
		year += c-'0';
	}
	if(year < 70)
		year += 32;
	else if(year < 100)
		year -= 68;
	else if(year < 1970)
		return BAD;
	else if(year < 2040)
		year -= 1968;
	else
		return BAD;
	if(month > 10) year--;
	year = year * 365 + year/4 + month*520/17 + day;
	return year * 86400 + sec - 60652800;
}

int init_timestamp(void) {
	int m;

	tzset();

	tzstr[0] = ' ';
	m = timezone / 60;
	if(m < 0) {
		tzstr[1] = '+';
		m = -m;
	} else {
		tzstr[1] = '-';
	}
	tzstr[2] = '0' + m/600; m %= 600;
	tzstr[3] = '0' + m/60; m %= 60;
	tzstr[4] = '0' + m/10; m %= 10;
	tzstr[5] = '0' + m;
	now = fast_time();

	return 0;
}

struct tm *localtime_r (const time_t *timer, struct tm *tp) {
	time_t adj = *timer - timezone;
	return gmtime_r(&adj, tp);
}
