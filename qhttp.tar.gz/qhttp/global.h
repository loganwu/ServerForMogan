#ifndef _GLOBAL_H_
#define _GLOBAL_H_
#include <stdio.h>
#include <sched.h>
#include "autoconfig.h"
#include "conn.h"
#include "atomic.h"
#include "tsc.h"

/* SYSTEM INFO */
#if INLINE_SYSCALL
extern long linuxgate;
extern int gatevalue;
#endif

extern int path_max;
#if THROTTLE_SUPPORT
extern uint64_t tsc1k;
extern uint64_t tsc125msec;
#endif
extern int tzhour;
extern char tzsign;
extern int tzmin;

/* CONFIG */
extern int mconns;
extern int nworks;
extern int nconns;
extern int nconns1;
extern int recvbufsz;
extern int sendbufsz;
extern int workbufsz;
extern int maxurllen;
extern int maxhostlen;
#if WITH_RTSIG
extern int pollmode;
#else
#define pollmode 1
#endif
extern int rtsigno;
extern int pipe_idle;
extern int pipe_incoming;
extern int epoll_batch_events;
extern int direct_accept;
extern int direct_idle;
extern int defer_accept;
extern int linger_close;
extern int maxidles;
extern atomic_t idlecon;
extern uint64_t tsc_recv;
extern uint64_t tsc_send;
extern uint64_t tsc_keepalive;
extern uint64_t tsc_linger;
extern uint64_t tsc_idleswitch;
extern int tsc4_request;
extern int nreq_keepalive;
extern int timeout_keepalive;
extern int maxpostsize;
#define LOG_DISABLED	0
#define LOG_ERROR	2
#define STAT_DIGEST	10
#define LOG_DIGEST	11
#define LOG_OBJECT	12
#define LOG_TRANSMIT	13
#define LOG_URL		14
extern int logmode;
extern int strip_query_string;
extern int fdcache_max;

extern int patch_cork;
#if PLUGIN_SUPPORT
extern int has_plugin;
#else
#define has_plugin 0
#endif
extern int need_filemon;
extern int main_epfd;

#if COOKIE_SUPPORT
extern struct cookie *cookieinfo;
extern int cookiesize;
extern int cookie_in_sendbuf __init__;
extern int need_panel_auth(void);
#endif

extern int url_in_sendbuf __init__;

/* SERVER STATE */
extern int verbose;
extern int developer;
extern int running;
extern struct worker *worker;
extern struct vhost *vhostlist;
extern int decode_relay_ip;

extern atomic_t sparse_workers;
extern atomic_t startup_workers;
extern int min_sparse;
extern int max_sparse;

extern unsigned int ioperf_exp;

extern time_t now;

extern char *banner_software;
extern int banner_software_len;
extern char *banner_address;
extern int banner_address_len;

extern void exit_http();
extern void detect_vdso(void);
#endif
#include "detect.h"
