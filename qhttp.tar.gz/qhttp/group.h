#ifndef __H_GROUP_H__
#define __H_GROUP_H__

#include "autoconfig.h"
#include "relay.h"
#include "list.h"

#define MAX_GROUPNAME_LENGTH	15
#define MAX_FORWARD_TARGETS	255
#define MAX_GLOBAL_TARGETS	65536


#define TS_FREE		0	/* FREE SLOT */
#define TS_DISCARD	1	/* FREE IN PROGRESS */

#define TS_STATIC	2	/* STATIC SLOT */

#define TS_INITIAL	5	/* DYNAMIC: INITIAL IN PROGRESS */
#define TS_DYNAMIC	6	/* DYNAMIC: HEALTH */
#define TS_DEAD		7	/* DYNAMIC: DEAD */

struct namemap;
struct target {
	union {
		struct forward_target core;
		struct {
			/* flags, total 16 bits */
			uint8_t has_counter:1;
			uint8_t connect_timeout:3;
			uint8_t state:3;
			uint8_t reserved:1;
			uint8_t alivecnt:4;
			uint8_t reserved2:1;
			uint8_t reserved3:1;
			uint8_t reserved4:1;

			uint16_t port;
			uint32_t addr;
			void *callback;
			void *response;
			/* counters, optional is has_counter==0 */
			int count_inuse;
			int count_access;
			int count_error;
		};
	};
	/* above is standard forward group elements */
	uint16_t tid;
	uint16_t gid;

	union {
		struct {
			uint16_t mconns;	/* max inuse connections */
			uint16_t econns;	/* effective inuse connections */
		};	/* except FREE,DISCARD */

		struct target *next;	/* index list, by FREE,DISCARD */
	};

	time_t ts;
	int fd;
	int error;
};

typedef struct target target_t;

struct vhostmap;
struct group {
	uint16_t gid;
	uint8_t nhosts;
	uint8_t mhosts;

	uint8_t retry:3;
	uint8_t sched:3;
	uint8_t debugmsg:2;
	uint8_t child:1;
	uint8_t sfmode:1;
	uint8_t actived:1;
	uint8_t append_url:1;
	uint8_t reserved:4;

	char name[MAX_GROUPNAME_LENGTH+1];
	union {
		char *filename;
		struct group *parent;
	};
	struct target **tlist;
	struct forward_scheduler * volatile scheduler;
	struct sticky *sticky;
	char *blistname;
	struct blacklist *black;
	char *error_page;
	struct group *error_group;
	struct namemap *vhostmap;
};

typedef struct group group_t;

struct forward_scheduler {
	void (*cleaner)(void *);
	ftarget_t *(*find_target)(struct forward_scheduler *, uint32_t, ftarget_t *);
};

#define SCHED_RANDOM	0
#define SCHED_ADAPTIVE	1
#define SCHED_DYNAMIC	2

extern struct target **target_table;
extern struct group **group_table;
static inline struct target *target_at(int i) { return target_table[i]; }
static inline int target_index(struct target *t) { return t->tid; }

static inline  struct group *group_at(int i) { return group_table[i]; }
extern struct group *find_forward_group(const char *);
extern int verify_all_groups(void);
extern int init_relay_groups(void);
extern ftarget_t * schedule_target(struct group *, uint32_t);
extern int no_target_callback(struct callback_data *);
extern int group_callback(struct callback_data *, struct group *);

extern struct target *target_at(int);
extern struct target *new_target(struct group *);
extern void free_target(struct target *);
extern void verify_target(struct target *);
extern void verify_result(struct target *, int);
extern void check_dynamic_target(struct target *);
extern void check_free_targets(void *);
extern void set_target_table(void *);

extern struct forward_scheduler *new_scheduler_rand(struct group *g);
extern struct forward_scheduler *new_scheduler_arand(struct group *g);
extern struct forward_scheduler *new_scheduler_drand(struct group *g);

extern struct sticky *new_sticky_table(int);
extern void *get_sticky(struct sticky *, uint32_t);
extern void set_sticky(struct sticky *, uint32_t, void *);
extern void prune_sticky(struct sticky *, void *);
extern void free_sticky(struct sticky *);

#endif
