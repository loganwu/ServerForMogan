/**
* @file  redirect.c
* @brief redirect by CPU and rate etc.
*
* @author yijian
* @date 2008-03-13
* @{
 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "qhttpd_api.h"
#include "util.h"
#include "pattern.h"
#include "om_thread.h"

#define SRC_HOST_COUNT_MAX 10
#define HOST_LENGTH_MAX   99
// Flux
#define REDIRECT_FLUX_MAX 1000000
#define REDIRECT_FLUX_MIN 1
#define REDIRECT_FLUX_DEF 200000
// Fluxin
#define REDIRECT_FLUXIN_MAX 1000000
#define REDIRECT_FLUXIN_MIN 1
#define REDIRECT_FLUXIN_DEF 200000
// Rate
#define REDIRECT_RATE_MAX 100
#define REDIRECT_RATE_MIN 1
#define REDIRECT_RATE_DEF 1

struct redirect_param {
    int flux;    
    int fluxin;
    int ethx;
    int rate;
    int ratecnt;
    struct {
        int count;
        struct {
            int poll;
            int count;
            char name[HOST_LENGTH_MAX+1];
            struct {                
                char name[HOST_LENGTH_MAX+1];
            }*dest_host;
        }src_host[SRC_HOST_COUNT_MAX];
    }hostinfo;
};

int redirect_verbose = 0;
unsigned long verbose_count = 0;
extern char* choose_host(struct redirect_param* param, const char* host);
int redirect_url(cbdata_t *cb) {    
    /* If-Modified-Since */
    if (cb->has_ims) return RC_CONTINUE;	

    struct redirect_param* param = cb->priv;        
    if (net_dev_param.r_bytes_deta[param->ethx] > param->fluxin) {
        param->rate = ((net_dev_param.r_bytes_deta[param->ethx]-param->fluxin)*10) / net_dev_param.r_bytes_deta[param->ethx] ;
		param->ratecnt = (param->ratecnt >= 65535) ? 1 : ++param->ratecnt;
    }
    else {
        return RC_CONTINUE;
    }            
    if (param->rate < (param->ratecnt%10)) return RC_CONTINUE;
                 
    char* name = choose_host(param, cb->host);
    if (NULL == name) {
        //lprintf("Needn't redirect for %s not match", cb->host);
        return RC_CONTINUE;
    }

    snprintf(cb->buf, cb->buflen-1, "http://%s%s", name, cb->url);
    cb->buf[cb->buflen-1] = 0;
    cb->url = cb->buf;

    if (redirect_verbose) {
        lprintf("%s:%d, <%lu> flux is %lu, redirect %s to %s", 
            __FILE__, __LINE__, ++verbose_count,
            net_dev_param.t_bytes_deta[param->ethx],
            cb->host, name);
    }
	return RC_REDIRECT_TMP;
}

void plugin_load(int argc, const char *const*argv){        
    int idx = 0;
    struct redirect_param* param = (struct redirect_param *)calloc(1, sizeof(struct redirect_param));
           
    redirect_verbose = myconfig_get_intval("redirect_verbose", 0);
    
    // redirect_flux
    param->flux = myconfig_get_intval("redirect_flux", REDIRECT_FLUX_DEF);
    if (param->flux < REDIRECT_FLUX_MIN) param->flux = REDIRECT_FLUX_MIN;
    if (param->flux > REDIRECT_FLUX_MAX) param->flux = REDIRECT_FLUX_MAX;
    lprintf("redirect_flux is %d", param->flux);

    // redirect_fluxin
    param->fluxin = myconfig_get_intval("redirect_fluxin", REDIRECT_FLUXIN_DEF);
    if (param->fluxin < REDIRECT_FLUXIN_MIN) param->fluxin = REDIRECT_FLUXIN_MIN;
    if (param->fluxin > REDIRECT_FLUXIN_MAX) param->fluxin = REDIRECT_FLUXIN_MAX;
    lprintf("redirect_fluxin is %d", param->fluxin);

    // ratecnt
    param->ratecnt = 0;
    
    // redirect_rate
    param->rate = myconfig_get_intval("redirect_rate", REDIRECT_RATE_DEF);
    if (param->rate < REDIRECT_RATE_MIN) param->rate = REDIRECT_RATE_MIN;
    if (param->rate > REDIRECT_RATE_MIN) param->rate = REDIRECT_RATE_MIN;
    if (param->rate < 1) param->rate = 1;
    lprintf("redirect_rate is %d", param->rate);
    
    // redirect_ethx
    const char* str = myconfig_get_value("redirect_ethx");    
    if (NULL == str) {
        param->ethx = 0;
        lprintf("redirect_ethx is %s", "eth0");
    }
    else {
        lprintf("redirect_ethx is %s", str);
        for (idx=0; idx<net_dev_param.count; ++idx) {
            char ethx[8];
            snprintf(ethx, sizeof(ethx)-1, "eth%d", idx);
            if (!strcmp(ethx, str)) {
                param->ethx = idx;
                break;
            }
        }
    }

    // redirect_host
    int j, n;
    const char *p0;
    char *p = NULL;
    char *field[100];
    // redirect.host=www.qq.com,www1.qq.com,www2.qq.com
    for (idx=0; (p0=myconfig_get_multivalue("redirect_host", idx)); ++idx) {        
        if(p) free(p);
        if (idx >= SRC_HOST_COUNT_MAX) break;
        p = strdup(p0);
        if((n = str_explode(",", p, field, 100)) < 2) continue;

        ++param->hostinfo.count;
        param->hostinfo.src_host[idx].poll = 0;
        strncpy(param->hostinfo.src_host[idx].name, field[0], HOST_LENGTH_MAX);
        
        param->hostinfo.src_host[idx].dest_host = calloc(n-1, HOST_LENGTH_MAX+1);
        for(j=1; j<n; j++) {
            //lprintf("%s:%d, %s", __FILE__, __LINE__, field[j]);
            ++param->hostinfo.src_host[idx].count;
            strncpy(param->hostinfo.src_host[idx].dest_host[j-1].name, field[j], HOST_LENGTH_MAX);            
        }
    }
        
    if (p) free(p);
	register_url_filter( NULL, 0, redirect_url, (void *)param);
}

char* choose_host(struct redirect_param* param, const char* host)
{
    int i;
    char* name = NULL;
    for (i=0; i<param->hostinfo.count; ++i) {
        //lprintf("%s:%d, %s", __FILE__, __LINE__, param->hostinfo.src_host[i].name);
        if (!strcmp(param->hostinfo.src_host[i].name, host)) {            
            name = param->hostinfo.src_host[i].dest_host[param->hostinfo.src_host[i].poll].name;
            ++param->hostinfo.src_host[i].poll;
            if (param->hostinfo.src_host[i].poll >= param->hostinfo.src_host[i].count)
                param->hostinfo.src_host[i].poll = 0;
            break;
        }
    }
    return name;
}
