/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include "realconfig.h"
#if RELAY_SUPPORT
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "compat_errno.h"

#include "autoconfig.h"
#include "global.h"
#include "shmem.h"
#include "thread.h"
#include "log.h"
#include "task.h"
#include "group.h"
#include "util.h"

static unsigned int ntargets;
struct target **target_table;
static struct target *free_target_list;
static struct target *delay_list;
static struct target *discard_list;
static struct target **delay_tail = &delay_list;

struct target *new_target(struct group *g) {
	struct target *t;
	
	if(free_target_list) {
	    t = free_target_list;
	    free_target_list = t->next;
	} else if(ntargets<65535) {
	    t = shalloc(sizeof(struct target));
	    if(t==NULL)
	    	return NULL;
	    target_table[++ntargets] = t;
	    t->tid = ntargets;
	} else
	    return NULL;


	memset(&t->core, 0, sizeof(t->core));
	t->has_counter = 1;
	t->state = TS_STATIC;
	t->ts = 0;
	t->fd = 0;
	t->error = 0;
	t->mconns = 0;
	t->econns = 0;
	t->gid = g->gid;
	t->callback = (void *)1;
    
	return t;
}

void free_target(struct target *t) {
	t->state = TS_DISCARD;
	t->ts = now + 60;
	t->next = 0;
	if(t->fd > 0) {
	    remove_sigio_callback(t->fd);
	    fast_close(t->fd);
	    t->fd = 0;
	}
	*delay_tail = t;
	delay_tail = &t->next;
}

void check_free_targets(void *priv){
	struct target *t;
	struct target **ta;

	while(delay_list) {
		if(now < delay_list->ts)
			break;
		t = delay_list;
		delay_list = t->next;
		if(delay_list==NULL)
			delay_tail = &delay_list;
		if(atomic_read(&t->core.count_inuse) == 0) {
			t->next = free_target_list;
			free_target_list = t;
		} else {
			t->next = discard_list;
			discard_list = t;
		}
	}
	ta = &discard_list;
	while(*ta) {
		t = *ta;
		if(atomic_read(&t->core.count_inuse) == 0) {
			*ta = t->next;
			t->next = free_target_list;
			free_target_list = t;
		} else {
			ta = &t->next;
		}
	}
}

static void target_alive(struct target *t) {
	if(t->state == TS_DEAD) {
	    char buf[16];
	    ip2str(buf, t->addr)[0] = '\0';
	    t->alivecnt++;
	    if(t->alivecnt >= 10) {
		t->state = TS_DYNAMIC;
		lprintf("ftarget %s:%d alive\n", buf, ntohs(t->port));
	    }
	} else {
	    t->state = TS_DYNAMIC;
	}
}

static void target_dead(struct target *t, int err) {
	if(t->state!=TS_DEAD) {
	    char buf[16];
	    ip2str(buf, t->addr)[0] = '\0';
	    errno = err;
	    lprintf("ftarget %s:%d dead: %m\n", buf, ntohs(t->port));
	}

	t->alivecnt = 0;
	t->state = TS_DEAD;
	t->ts = now;
}

static void target_result(struct target *t, int err) {
	if(t->fd <= 0) return; /* spurious event */
	remove_sigio_callback(t->fd);
	fast_close(t->fd);
	t->fd = 0;
	if(err==0) {
		target_alive(t);
	} else {
		target_dead(t, err);
	}
}

void verify_result(struct target *t, int band) {
	int err;
	int te;

	te = now - t->ts;
	if(band==-ETIMEDOUT || te>timeout_connect)
		err = ETIMEDOUT;
	else {
		socklen_t len = sizeof(err);
		fast_getsockopt(t->fd, SOL_SOCKET, SO_ERROR, &err, &len);
		if(err == EINPROGRESS)
			return;
	}

	target_result(t, err);
}

void verify_target(struct target *t) {
	struct sockaddr_in addr;
	int err;

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = t->addr;
	addr.sin_port = t->port;
	t->fd = fast_socket(AF_INET, SOCK_STREAM, 0);
	if(t->fd == 0) {
		lprintf("\7Someone close stdin\n");
		return;
	}
	if(t->fd < 0) {
		lprintf("\7Cannot create socket: %m\n");
		return;
	}
	register_sigio_callback(t->fd, (void(*)(void *,int))verify_result, t);
	fast_fcntl(t->fd, F_SETFL, O_RDWR|O_NONBLOCK|O_ASYNC);
	if(t->state == TS_STATIC)
		t->state = TS_INITIAL;
	t->ts = now;

	err = fast_connect(t->fd, (const struct sockaddr *)&addr, sizeof(addr));
	if(err < 0) FIX_ERRNO(err);
	if(err == -EINPROGRESS)
		return;
	target_result(t, -err);
}

void check_dynamic_target(struct target *t) {
	int te;

	switch(t->state) {
	    case TS_INITIAL:
		verify_result(t, 0);
		break;
	    case TS_DEAD:
	    	te = now - t->ts;
		if(t->fd > 0) {
		    if(te > timeout_connect)
		        target_result(t, ETIMEDOUT);
		} else if(te >= 10)
		    verify_target(t);
		break;
	    case TS_DYNAMIC:
		{
		    int ca, ce;
		    ca = atomic_read(&t->core.count_access);
		    if(ca<10)
		    	break;
		    ce = atomic_read(&t->core.count_error);
		    atomic_sub(ca, &t->core.count_access);
		    atomic_sub(ce, &t->core.count_error);
		    if(ce*10 >= ca*9) {
		    	target_dead(t, t->error?t->error:ETIMEDOUT);
		    } else if(ce==0 && ca>0) {
			t->econns = t->mconns;
		    } else {
			t->econns = t->econns * (ca-ce)/ca;
		    }
		}
		break;
	}
}

#endif
