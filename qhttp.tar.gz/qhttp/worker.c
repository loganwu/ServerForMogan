/* headers {{{1 */
#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <math.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/poll.h>
#include "timestamp.h"
#include "compat_errno.h"
#include "compat_thread.h"

#include "autoconfig.h"

#include "myconfig.h"
#include "global.h"
#include "conn.h"
#include "daemon.h"
#include "listen.h"
#include "http.h"
#include "thread.h"
#include "log.h"
#include "fault.h"
#include "profile.h"
#include "shmem.h"
#include "relay.h"
#include "sysctl.h"
#include "task.h"
#include "lock.h"
#include "entity.h"
#include "stat.h"
#include "watchdog.h"

#ifndef SI_TKILL
#define SI_TKILL        -6              /* sent by tkill system call */
#endif

/*}}}1*/

/* globals {{{1 */
#if WITH_RTSIG
static int routine_rtsig(struct worker *wt);
static int routine_rtsig_idle(struct worker *wt);
static int routine_rtsig_direct(struct worker *wt);
#endif
static int routine_epoll(struct worker *wt);
static int routine_epoll_idle(struct worker *wt);
static int routine_epoll_direct(struct worker *wt);
static int routine_epoll_direct_rr(struct worker *wt);
static int routine_single(struct worker *wt);

static int refresh_events;
static int loopdelay;
static int nepoll_events;
/* }}}1 */

/* init_notify_pipe() {{{1 */
static inline void init_notify_pipe(struct worker *wt) {
	int fd[2];
	pipe(fd);
	wt->epwake = fd[1];
	wt->epwait = fd[0];
	fast_fcntl(fd[0], F_SETFL, O_RDONLY|O_NONBLOCK);
	fast_fcntl(fd[1], F_SETFL, O_WRONLY|O_NONBLOCK);
	fast_fcntl(fd[0], F_SETFD, FD_CLOEXEC);
	fast_fcntl(fd[1], F_SETFD, FD_CLOEXEC);
}
/* }}}1 */

/* init_worker_mode() {{{1 */
int init_worker_mode(void) {
	double a;
	int fd, h, s;
	sigset_t sset;

	rtsigno = allocate_rtsig(0);
	signal(rtsigno, SIG_DFL);
	sigemptyset(&sset);
	sigaddset(&sset, rtsigno);
	sigprocmask(SIG_BLOCK, &sset, NULL);

#if WITH_RTSIG
	pollmode = has_epoll > 0;
	if(has_epoll < 0) {
	    if((threadmode & CLONE_THREAD)) {
		/* support rtsig w/ thread group is very dangerouus */
		lprintf("\7PANIC: SYS_epoll is required in NPTL mode\n");
		return -1;
	    } else {
		lprintf("\7WARNING: Disable SYS_epoll is not recommended.\n");
	    }
	} else if(has_epoll==0 && (threadmode&CLONE_THREAD)) {
	    lprintf("\7PANIC: strange kernel support NPTL but not SYS_epoll\n");
	    return -1;
	}
#else
	if(has_epoll<=0) {
	    lprintf("\7PANIC: SYS_epoll is required in this build\n");
	    return -1;
	}
#endif

	if(pollmode) {
	    lprintf("Event   interface: epoll\n");
	    epoll_batch_events = myconfig_get_intval("epoll_batch_events", 1024);
	    if(epoll_batch_events <= 0) epoll_batch_events = 1;
	} else {
	    lprintf("Event   interface: realtime signal\n");
	}

	maxurllen = myconfig_get_intval("maximum_url_length", 1024);
	if(maxurllen > (stack_block_size-stack_guard_size)/4) {
		lprintf("\7WARNING: maximum_url_length %d too large, reduce to %d\n",
			maxurllen, (stack_block_size-stack_guard_size)/4);
		maxurllen = (stack_block_size-stack_guard_size)/4;
	}
	if(maxurllen < 64) {
		lprintf("\7WARNING: maximum_url_length %d too small, increase to 64\n",
			maxurllen);
		maxurllen = 64;
	}
	if(maxurllen > 16384) maxurllen = 16384;
	
	maxhostlen = myconfig_get_intval("maximum_hostname_length", 64);
	/* don't set maxhostlen large than 128 */
	if(maxhostlen > maxurllen || maxhostlen > 128) {
		lprintf("\7WARNING: maximum_hostname_length %d too large, reduce to %d\n",
			maxhostlen, maxurllen>128?128:maxurllen);
		maxhostlen = maxurllen>128 ? 128 : maxurllen;
	}

	if(maxhostlen < 32) {
		lprintf("\7WARNING: maximum_hostname_length %d too small, increase to 32\n",
			maxhostlen);
		maxhostlen = 32;
	}

	recvbufsz = myconfig_get_intval("recv_buffer_size", 2048);
	if(recvbufsz < 2*maxurllen || recvbufsz < 512) {
		lprintf("\7WARNING: recv_buffer_size %d too small, increase to %d\n",
			recvbufsz, maxurllen<256?512:2*maxurllen);
		recvbufsz = maxurllen<256? 512: 2*maxurllen;
	}
	if(recvbufsz >= 65536) recvbufsz = 65535;
	sendbufsz = myconfig_get_intval("send_buffer_size", has_plugin?4096:2048);
	if(sendbufsz < maxurllen+1024) {
		lprintf("\7WARNING: send_buffer_size %d too small, increase to %d\n",
			sendbufsz, maxurllen+1024);
		recvbufsz = maxurllen + 1024;
	}
	if(sendbufsz >= 65536) sendbufsz = 65535;

	workbufsz = myconfig_get_intval("working_buffer_size", 4096);
	if(workbufsz < 4096) {
		lprintf("\7WARNING: working_buffer_size %d too small, increase to %d\n",
			workbufsz, 4096);
		workbufsz = 4096;
	}

	mconns = myconfig_get_intval("maximum_connections", 10000);
	if(mconns > (16<<20))
		mconns = 16<<20;
	if(mconns < 10)
		mconns = 10;
	direct_accept = myconfig_get_intval("direct_accept", 0);
	nworks = myconfig_get_intval("working_threads", ncpus-(direct_accept?0:(ht>1)));
	if(nworks >= 60000) nworks = 60000;
	if(nworks < 1) nworks = 1;
	if(nworks > mconns) nworks = mconns;
	if(threads_max > 0) {
		h = threads_max - 1;
		if(direct_accept==0)
			h--;
		if((threadmode & CLONE_THREAD)== 0)
			h--;
	} else {
		h = nworks+1;
	}
	fd = sysctl_get_value("/proc/loadavg", 4);
	if(h > sys_threads_max - fd - 100)
		h = sys_threads_max - fd - 100;
	s = h;
	if(s > 4*sys_threads_max/5) {
		s = 4*sys_threads_max/5;
		if(s >= 20000) {
		    fd = 1000;
		} else if(s>=10000) {
		    fd = 500;
		} else if(s>=5000) {
		    fd = 100;
		} else if(s>1000) {
		    fd = 50;
		} else {
		    fd = 10;
		}
		
		s -= s%fd;
	}

	if(nworks > h) {
		lprintf("\7WARNING: Too many working threads %d, reduce to %d\n", nworks, s);
		if(mconns>=nworks)
			nworks = mconns = s;
		else
		    nworks = s;
	}
	if(nworks > s) {
		lprintf("\7WARNING: Working threads %d may touch system limit %d\n",
			nworks, sys_threads_max);
	}
	nconns = (mconns + nworks - 1) / nworks;
	mconns = nconns * nworks;
	if(nworks==1 && tsc_keepalive==0)
		direct_accept = 1;
	direct_idle = nconns==1 ? 0 : direct_accept ? 1 :
	    myconfig_get_intval("direct_idle", nworks <= ncpus);
    lprintf("direct_idle is %d", direct_idle);

	nconns1 = nconns + 1;
	lprintf("Total connections: %d x %d = %d\n", nconns, nworks, mconns);

	linger_close = nconns==1 ? 0 : myconfig_get_intval("lingering_close", 0);
    lprintf("lingering_close is %d", linger_close);
	decode_relay_ip = myconfig_get_intval("decode_relay_ip", 0);
	if(nconns==1) {
	    min_sparse = myconfig_get_intval("minimum_sparse_threads", 100);
	    max_sparse = myconfig_get_intval("maximum_sparse_threads", 500);
	    if(max_sparse < 100)
		max_sparse = 100;
	    if(max_sparse > nworks)
		max_sparse = nworks;
	    if(min_sparse + 100 < max_sparse)
		min_sparse = max_sparse / 2;
	    cprintf("Sparse threads: minimum %d, maximum %d\n", min_sparse, max_sparse);
	}

	url_in_sendbuf = has_plugin==0 ? 1 : myconfig_get_intval("url_in_sendbuf", 0);
#if COOKIE_SUPPORT
	cookie_in_sendbuf = has_plugin==0 ? 1 : myconfig_get_intval("cookie_in_sendbuf", 0);
#endif

	tsc_recv = myconfig_get_intval("recv_timeout", 15);
	tsc_send = myconfig_get_intval("send_timeout", 60);
	if(tsc_send < tsc_recv) tsc_send= tsc_recv;
	tsc4_request= myconfig_get_intval("request_timeout", 60);
	tsc_recv *= tscsec;
	tsc_send *= tscsec;
	tsc4_request = SECRND(tsc4_request)+1;
    lprintf("request_timeout is %d", tsc4_request);

	timeout_keepalive = myconfig_get_intval("keepalive_timeout", 15);
	if(timeout_keepalive < 5) timeout_keepalive = 0;
    lprintf("keepalive_timeout is %d", timeout_keepalive);

	tsc_keepalive = timeout_keepalive * tscsec;
	a = myconfig_get_decimal("idle_switch_timeout");
	if(isnan(a) || a < 0)
		tsc_idleswitch = tscsec;
	else if(isinf(a))
		tsc_idleswitch = tsc_keepalive/2;
	else
		tsc_idleswitch = (uint64_t)(a*tscsec);    	
	if(tsc_idleswitch>tsc_keepalive/2) tsc_idleswitch = tsc_keepalive/2;
    lprintf("idle_switch_timeout is %llu", tsc_idleswitch);

	tsc_keepalive -= tsc_idleswitch;
	tsc_linger = myconfig_get_intval("linger_close", 0);
	if(tsc_linger>=1 && tsc_linger<15)
		tsc_linger = 15;
	tsc_linger *= tscsec;
	if(tsc_keepalive && tsc_linger > tsc_keepalive) {
		tsc_linger = tsc_keepalive;
	}
    lprintf("linger_close is %llu", tsc_linger);

	nreq_keepalive = myconfig_get_intval("keepalive_request", 0);
	if(nreq_keepalive<=0) nreq_keepalive = 0x40000000;
    lprintf("keepalive_request is %d", nreq_keepalive);

	unsigned usize;

	usize = 0;
	if(url_in_sendbuf==0)
	    usize += maxurllen+1 + maxhostlen + 1;
#if COOKIE_SUPPORT
	if(cookiesize==0)
	    cookie_in_sendbuf = 0;
	if(cookie_in_sendbuf==0)
	    usize += cookiesize;
	else if(cookiesize + maxurllen + 1024 > sendbufsz) {
	    sendbufsz = cookiesize + maxurllen + 1024;
	    lprintf("INFO: Increase send buffer size to %d\n", sendbufsz);
	}
#endif
	if(maxurllen + 1024 > sendbufsz) {
	    sendbufsz = maxurllen + 1024;
	    lprintf("INFO: Increase send buffer size to %d\n", sendbufsz);
	}

	SHMEM_NEEDED(mconns, sizeof(struct conn));
	SHMEM_NEEDED(mconns, recvbufsz+1);
	SHMEM_NEEDED(mconns, sendbufsz+1);
	SHMEM_NEEDED(mconns, usize);

	usize = sendbufsz+1;
	if(url_in_sendbuf)
	    usize = url_in_sendbuf = usize - (maxurllen+1) - (maxhostlen+1);
#if COOKIE_SUPPORT
	if(cookie_in_sendbuf)
	    usize = cookie_in_sendbuf = usize - cookiesize;
#endif

	SHMEM_NEEDED(nworks, sizeof(struct worker)); /* worker */
	SHMEM_NEEDED(nworks, workbufsz+1); /* working buf */
	if(entity_access_method==0 && has_plugin)
	    SHMEM_NEEDED(nworks, path_max); /* fnbuf */
	if(nconns>1)
	    SHMEM_NEEDED(nworks, path_max);	/* aclbuf */

	if(direct_accept==0)
	    SHMEM_NEEDED(mconns+nworks, sizeof(int)); /* worker->inc_list */

	if(pollmode) {
	    nepoll_events = MIN(nconns, epoll_batch_events);
	    SHMEM_NEEDED(nworks * nepoll_events, sizeof(struct epoll_event));
	    /* worker->pev */
	} else if(direct_idle) {
	    SHMEM_NEEDED(maxfds*nworks, sizeof(struct pollfd)); /* worker->pfd */
	} else {
	    SHMEM_NEEDED(mconns+nworks, sizeof(struct pollfd)); /* worker->pfd */
	}
	return 0;
}
/* }}}1 */

/* init_worker() {{{1 */
static int init_worker(struct worker *wt) {
	int i;
	int usize = 0;
	if(url_in_sendbuf==0)
	    usize += maxurllen+1+maxhostlen+1;
#if COOKIE_SUPPORT
	if(cookie_in_sendbuf==0)
	    usize += cookiesize;
#endif

	wt->idleconn.netfd = 0;
	wt->idleconn.thread = wt;
#if TRACE_FD
	snprintf(wt->idleconn.name, 16, "idle%d", wt->id);
#endif
	if(direct_idle)
	    wt->idleconn.proc = resume_idle_connection;
	else
	    wt->idleconn.proc = resume_linger_connection;

	wt->workbuf = shalloc1(workbufsz+1);
	if(wt->workbuf==NULL) return -ENOMEM;
	//if(entity_access_method==0 && has_plugin) {
	    wt->fnbuf = shalloc1(path_max);
	    if(wt->fnbuf==NULL) return -ENOMEM;
	//}
	if(nconns>1) {
	    wt->aclbuf = shalloc1(path_max);
	    if(wt->aclbuf==NULL) return -ENOMEM;
	}

	INIT_LIST_HEAD(&wt->timer_idle);
	INIT_LIST_HEAD(&wt->timer_recv);
	INIT_LIST_HEAD(&wt->timer_send);
	INIT_LIST_HEAD(&wt->timer_req);
	INIT_LIST_HEAD(&wt->pending);
#if THROTTLE_SUPPORT
	for(i=0; i<sizeof(wt->suspend)/sizeof(wt->suspend[0]); i++)
	    INIT_LIST_HEAD(wt->suspend+i);
#endif
#if RELAY_SUPPORT
	INIT_LIST_HEAD(&wt->timer_relay);
	INIT_LIST_HEAD(&wt->timer_connect);
#endif

	wt->conn = shallocz(sizeof(struct conn)*nconns);
	if(wt->conn==NULL) return -ENOMEM;

	for(i=0; i<nconns; i++) {
#if COOKIE_SUPPORT
        wt->conn[i].cookiestr = NULL;
#endif
	    wt->conn[i].netfd = -1;
#if RELAY_SUPPORT
        wt->conn[i].relayfd = -1;        
        wt->conn[i].netfd_old = -1;
        wt->conn[i].ftarget = calloc(1, sizeof(struct forward_target));
        wt->conn[i].ftarget_old = wt->conn[i].ftarget;
        wt->conn[i].proxyfd = 0;
        wt->conn[i].cachedsize = 0;
        wt->conn[i].cachedoffset = 0;
        wt->conn[i].need_relay = 0;
#endif
	    wt->conn[i].thread = wt;
#if TRACE_FD
	    snprintf(wt->conn[i].name, 16, "conn%d.%d", wt->id, i);
#endif
	    wt->conn[i].recvbuf = shalloc1(recvbufsz+1);
	    wt->conn[i].sendbuf = shalloc1(sendbufsz+1);
	    if(url_in_sendbuf) {
	        wt->conn[i].url = wt->conn[i].sendbuf + url_in_sendbuf;
	        wt->conn[i].host = wt->conn[i].url + maxurllen + 1;
	    } else {
		wt->conn[i].url = shalloc1(maxurllen+1);
		wt->conn[i].host = shalloc1(maxhostlen+1);
	    }
#if COOKIE_SUPPORT
	    if(cookiesize) {
		if(cookie_in_sendbuf)
		    wt->conn[i].cookie = wt->conn[i].sendbuf + cookie_in_sendbuf;
		else
		    wt->conn[i].cookie = shalloc1(cookiesize);
	    }
#endif
	    wt->conn[i].freenext = wt->conn + i + 1;
	    INIT_LIST_HEAD(&wt->conn[i].timer_io);
	    INIT_LIST_HEAD(&wt->conn[i].timer_req);
	}
	wt->freeconn = wt->conn;
	wt->conn[nconns-1].freenext = NULL;

	INIT_LIST_HEAD(&wt->linger_list);
	if(direct_idle)
	    INIT_LIST_HEAD(&wt->idle_list);

	wt->tsc_timer = readtsc();

	if(nconns>1) {
	    if(pollmode) {
		if(direct_idle) {
		    i = maxfds;
		    wt->epfd = fast_epoll_create(i);
		} else {
		    i = nconns1;
#if RELAY_SUPPORT
		    wt->epfd = fast_epoll_create(i*3);
#else
		    wt->epfd = fast_epoll_create(i*2);
#endif
		}
		if(wt->epfd < 0) {
			FIX_ERRNO(wt->epfd);
			lprintf("epoll_create(%d): %m\n", i);
			return -1;
		}

		if(nepoll_events > 2) {
		    wt->pev = shalloc(sizeof(struct epoll_event)*nepoll_events);
		    if(wt->pev==NULL) return -ENOMEM;
		}
	    }
#if WITH_RTSIG
	    else {
		if(direct_idle) {
		    i = maxfds;
		} else {
#if RELAY_SUPPORT
		    i = nconns1;
#else
		    i = nconns1 * 2;
#endif
		}
		wt->pfd = shalloc(sizeof(struct pollfd)*i);
		if(wt->pfd==NULL) return -ENOMEM;
	    }
#endif

	    if(direct_accept==0) {
		wt->inc_list = shalloc(sizeof(int)*nconns1);
		if(wt->inc_list == NULL) return -ENOMEM;
		wt->inc_head = nconns;
		wt->inc_tail = 0;
		wt->inc_pend = 0;
		if(pollmode) init_notify_pipe(wt);
	    }
	}

	wt->tsc_now = readtsc();
#if THROTTLE_SUPPORT
	wt->tsc01 = (int)(wt->tsc_now/tsc125msec);
#endif
	wt->ts_date = fast_time();
	gmtimestr(wt->ts_date, wt->datestr);


	return 0;
}
/* }}}1 */

/* init_worker_threads() {{{1 */
int init_worker_data(void) {
	int i, rv;
	int (*routine)(void *) = NULL;
        
	refresh_events = myconfig_get_intval("recheck_connection_state", 0);

	if(nconns==1)
		routine = (int(*)(void *))routine_single;
	else if(pollmode) {
	    if(nworks==1)
		i = 0;
	    else if(nworks > ncpus)
		i = 1;
	    else
		i = myconfig_get_intval("epoll_accept_rr", 0);

	    routine =
		direct_accept ? ( i ? (int(*)(void *))routine_epoll_direct_rr :
				  (int(*)(void*))routine_epoll_direct ):
		    direct_idle ? (int(*)(void*))routine_epoll_idle :
			(int(*)(void*))routine_epoll;
	}            
#if WITH_RTSIG
	else if(routine==NULL)
	    routine =
		direct_accept ? (int(*)(void*))routine_rtsig_direct :
		direct_idle ? (int(*)(void*))routine_rtsig_idle :
		(int(*)(void *))routine_rtsig;
#endif

#define LOG_ROUTINE_NAME
#ifdef LOG_ROUTINE_NAME
    if ((int)routine == (int)routine_epoll)
        lprintf("direct_accept is %d, %s", direct_accept, "routine_epoll");
    else if ((int)routine == (int)routine_single)
        lprintf("direct_accept is %d, %s", direct_accept, "routine_single");
#if WITH_RTSIG
    else if ((int)routine == (int)routine_rtsig)
        lprintf("direct_accept is %d, %s", direct_accept, "routine_rtsig");
#endif
    else if ((int)routine == (int)routine_epoll_direct)
        lprintf("direct_accept is %d, %s", direct_accept, "routine_epoll_direct");
    else if ((int)routine == (int)routine_epoll_direct_rr)
        lprintf("direct_accept is %d, %s", direct_accept, "routine_epoll_direct_rr");
    else if ((int)routine == (int)routine_epoll_idle)
        lprintf("direct_accept is %d, %s", direct_accept, "routine_epoll_idle");    
    else
        lprintf("direct_accept is %d, %s", direct_accept, "others");
#endif // LOG_ROUTINE_NAME
    
	worker = shallocz(sizeof(struct worker) * nworks);
	if(worker==NULL) return -ENOMEM;

	for(i=0; i<nworks; i++) {
		char name[16];

		worker[i].id = i;
		if((rv=init_worker(worker+i)) < 0) return rv;

		sprintf( name,
			"%s%s%d",
			direct_accept ? "d" : direct_idle ? "i" : "",
			nconns==1 ? "dyn" : pollmode ? "epoll" : "rtsig",
			worker[i].id);
        lprintf("direct_idle is %d, %s", direct_idle, name);
		if((rv=register_thread(name, routine, worker+i)) < 0)
			return rv;
	}


	loopdelay = myconfig_get_intval("worker_thread_loop_delay", 0);
	if(loopdelay > 100) loopdelay = 100 *1000000;
	if(loopdelay < 0) loopdelay = 0;
	else loopdelay *= 1000000;
	return 0;
}
/* }}}1*/

/* stop_worker_threads() {{{1 */
void stop_worker_threads(void) {
	int i, j;
	for(i=0; i<nworks; i++) {
		for(j=0; j<nconns; j++) {
			if(worker[i].conn[j].netfd > 0) {
#if RELAY_SUPPORT
			    if(worker[i].conn[j].relaymode)
				close_relay_connection(worker[i].conn+j);
			    else
#endif
			    close_connection(worker[i].conn+j);
			}
		}
		if(direct_idle)
		    close_idle_connections(&worker[i].idle_list);
		if(nconns > 1) {
		    if(pollmode) {
			if(direct_accept==0 && worker[i].epwake > 0)
			    fast_close(worker[i].epwake);
			if(direct_accept==0 && worker[i].epwait > 0)
			    fast_close(worker[i].epwait);
			if(worker[i].epfd > 0)
			    fast_close(worker[i].epfd);
		    }
		}
	}
}
/* }}}1*/

/* check_timestamp() {{{1 */
static inline void check_timestamp(struct worker *wt) {
	wt->tsc_now = readtsc();
	if(wt->tsc_now < wt->tsc_timer) return;
	wt->tsc_timer = wt->tsc_now + tscsec;

	now = fast_time();
	if(now != wt->ts_date) {
	    wt->ts_date = now;
	    gmtimestr(now, wt->datestr);
	    run_worker_task(wt);
	}
}
/* }}}1*/

/* try_init_connection() {{{1 */
static inline struct conn *try_init_connection(struct worker *wt, int fd) {
	struct conn *c;
	if(wt->freeconn == NULL) {
	    if(list_empty(&wt->timer_idle)) {
		ISDSTAT(atomic_inc(&countermap->overflow));
		lprintf("%s(%d): Connection overflow\n", __FILE__, __LINE__);
		fdinfo[fd].conn = NULL;
		barrier();
		fast_close(fd); /* CHECKED OK */        
		return NULL;
	    }
	    c = list_entry(wt->timer_idle.next, struct conn, timer_io);
	    direct_idle_connection(c);
	}
	return init_connection(wt, fd);
}
/* }}}1*/

/* recheck_events() {{{1 */
static inline int check_events(int fd, int events) {
	if(refresh_events==0) return events;
	if(events & (POLLERR|POLLHUP|POLLNVAL))
		return events;
	struct pollfd pfd;
	pfd.fd = fd;
	pfd.events = events;
	fast_poll(&pfd, 1, 0);
	return pfd.revents | events;
}
/* }}}1*/

/* resume_connection() {{{1 */
static inline void resume_connection(struct worker *wt, int fd, int events) {
	if(fdinfo[fd].conn==NULL || fdinfo[fd].conn->thread!=wt) {
	    /* spurious event detector */
	    if(verbose)cprintf("spurious events\n");
	    return;
	}
	fdinfo[fd].conn->proc(fd, check_events(fd, events));
}
/* }}}1*/

/* resume_linger_connection() {{{1 */
void resume_linger_connection(int fd, int events) {
	struct worker *wt = fdinfo[fd].conn->thread;
	/* lingering close */
	if((events & POLLIN)) {
	    int count = 100;
	    int len=0;
	    while(--count>0 && (len=fast_recv(fd, wt->workbuf, 4096, MSG_DONTWAIT))==4096)
		/* NULL LOOP BODY*/;
	    if(len!=0 && count!=0)
	    	return;
	}
	if((events & (POLLHUP|POLLERR))) {
	    atomic_dec(&idlecon);
	    list_del_init(&fdinfo[fd].ilist);
	    fdinfo[fd].conn = NULL;
	    log_tcpinfo(fd);
	    barrier();
	    fast_close(fd); /* CHECKED OK */        
	}
}
/* }}}1*/

/* resume_idle_connection() {{{1 */
void resume_idle_connection(int fd, int events) {
	struct worker *wt = fdinfo[fd].conn->thread;
	struct conn *c;
	int len = 0;
	/* IDLE resume */

	if(unlikely(fdinfo[fd].nreq==-1)) {
	    /* lingering close */
	    if((events & POLLIN)) {
		int count = 100;
		while(--count>0 && (len=fast_recv(fd, wt->workbuf, 4096, MSG_DONTWAIT))==4096)
		    /* NULL LOOP BODY*/;
		if(len==0||count==0) events |= POLLHUP;
	    }
	    if(!(events & (POLLHUP|POLLERR))) return;
	}

	wt->idle_cnt--;
	atomic_dec(&idlecon);
	list_del_init(&fdinfo[fd].ilist);

	if((events & (POLLERR|POLLHUP)))
	{
	    fdinfo[fd].conn = NULL;
	    log_tcpinfo(fd);
	    barrier();
	    fast_close(fd); /* CHECKED OK */        
	}
	else {
	    if((c=try_init_connection(wt, fd)) != NULL)
	    {
		c->events = POLLIN;
		ISDSTAT(atomic_inc(&countermap->idleresume));
		ISDSTAT(atomic_inc(&countermap->workcon));
		wt->inc_negative++;
		resume_http_connection(fd, events);
	    }
	}
}
/* }}}1*/

/* suspend_connection() {{{1 */
#if THROTTLE_SUPPORT
void suspend_connection(struct conn *c) {
	struct worker *wt = c->thread;
	int t, n;

	t = (int)(c->send_tsc/tsc125msec);
	n = t - wt->tsc01;
	if(unlikely(n < 0)) {
	    n = 0;
	} else if(unlikely(n >= 16)) {
	    n = 15;
	}
	list_move_tail(&c->timer_io, wt->suspend + ((n+wt->tsc01)&15));
}
/* }}}1*/

/* calc_poll_timeout() {{{1 */
static /*inline*/ int calc_poll_timeout(struct worker *wt) {
	if(!list_empty(&wt->pending)) return 0;

	uint64_t tsc = readtsc();
	int to = 0;
	int now01 = (tsc/tsc125msec) & 15;
	int i01 = wt->tsc01 & 15;

	while(1) {
	    if(!list_empty(wt->suspend + i01))
		return 0;
	    if(i01==now01) break;
	    i01 = (i01+1) & 15;
	}

	i01 = (i01+1) & 15;
	to += 150;

	do {
	    if(!list_empty(wt->suspend + i01))
		break;
	    i01 = (i01+1) & 15;
	    to += 150;
	} while(i01 != now01);
	if(to > 150*13) to = 150*13;
	return to;
}
#else
static inline int calc_poll_timeout(struct worker *wt) {
	return list_empty(&wt->pending) ? POLL_TIMEOUT : 0;
}
#endif
/* }}}1*/

/* check_pending() {{{1 */
static inline void check_pending(struct worker *wt) {
	if(!list_empty(&wt->pending)) {
	    struct conn *c;
	    struct list_head pending;

	    pending.next = wt->pending.next;
	    pending.prev = wt->pending.prev;
	    pending.next->prev = &pending;
	    pending.prev->next = &pending;
	    INIT_LIST_HEAD(&wt->pending);
	    do {
		thread_reached(wt->thst);
		c = list_entry(pending.next, struct conn, timer_io);
		resume_connection(wt, c->netfd, c->resume?POLLIN|POLLOUT:POLLIN);
	    } while(!list_empty(&pending));
	}
#if THROTTLE_SUPPORT
	int tscid = 0;
	while(1) {
	    struct list_head *list;
	    struct conn *c;

	    list_for_each_entry_safe_l(c, list, wt->suspend+(wt->tsc01&15),
				       timer_io)
	    {
		thread_reached(wt->thst);
		resume_connection(wt, c->netfd, POLLOUT);
		tscid = 0;
	    }
	    
	    if(tscid==0)
	    	tscid = (int)(readtsc()/tsc125msec);
	    if(tscid == wt->tsc01) break;
	    wt->tsc01++;
	}
#endif
}
/* }}}1*/

/* check_idleswitch() {{{1 */
static inline void check_idle_switch(struct worker *wt) {
	struct list_head *list;
	struct conn *c;

	if(tsc_idleswitch==0) {
	    list_for_each_entry_safe_l(c, list, &wt->timer_idle, timer_io) {
		if(c->tsc_io >= wt->tsc_now)  break;
		thread_reached(wt->thst);
		close_connection(c);
	    }
	} else {
	    list_for_each_entry_safe_l(c, list, &wt->timer_idle, timer_io) {
		if(c->tsc_io >= wt->tsc_now)  break;
		thread_reached(wt->thst);
		if(idle_connection(c)) break;
	    }
	}
}
/* }}}1*/

/* check_direct_idleswitch() {{{1 */
static inline void check_direct_idle_switch(struct worker *wt) {
	struct list_head *list;
	struct conn *c;

	if(tsc_idleswitch==0)
	    list_for_each_entry_safe_l(c, list, &wt->timer_idle, timer_io) {
		thread_reached(wt->thst);
		direct_idle_connection(c);
	    }
	else
	    list_for_each_entry_safe_l(c, list, &wt->timer_idle, timer_io) {
		if(c->tsc_io >= wt->tsc_now)  break;
		thread_reached(wt->thst);
		direct_idle_connection(c);
	    }
}
/* }}}1*/

void fixing_idle_list(struct list_head *ilist, const struct baseconn *stub) {
	struct list_head *plist;
	struct list_head *list;
	for(plist = ilist, list = ilist->prev;
		list != ilist;
		plist = list,
		list = list->prev)
	{
		struct fdinfo *f = list_entry(list, struct fdinfo, ilist);
		if(f->conn != stub) break;
	}
	if(list != ilist) {
		plist->prev = ilist;
		ilist->next = plist;
	}
}

/* check_timeout() {{{1 */
static inline void check_timeout(struct worker *wt) {
	struct list_head *list;
	struct fdinfo *f;
	struct conn *c;

	list_for_each_entry_safe_l(c, list, &wt->timer_recv, timer_io) {
	    if(c->tsc_io >= wt->tsc_now)  break;
	    thread_reached(wt->thst);
	    close_connection(c);
	}

	list_for_each_entry_safe_l(c, list, &wt->timer_send, timer_io) {
	    if(c->tsc_io >= wt->tsc_now)  break;
	    thread_reached(wt->thst);
	    close_connection(c);
	}
	
	list_for_each_entry_safe_l(c, list, &wt->timer_req, timer_req) {
	    if(c->tsc4_req >= TSCRND(wt->tsc_now))  break;
	    thread_reached(wt->thst);
	    close_connection(c);
	}
	
	/* linger connection timeout */
	if(linger_close)
	list_for_each_entry_safe_l(f, list, &wt->linger_list, ilist) {
	    int fd = f - fdinfo;
	    if(bugcheck(!is_stub(fd, &wt->idleconn))) {
	    	lprintf("%s(%d): non-linger fd inside linger list, fd=%d\n", __FILE__, __LINE__, fd);
		fixing_idle_list(&wt->linger_list, &wt->idleconn);
		break;
	    }
	    if(f->tsc4>TSCRND(wt->tsc_now) && atomic_read(&idlecon)<maxidles)
		break;
	    thread_reached(wt->thst);
	    ISDSTAT(atomic_dec(&idlecon));
	    list_del_init(&f->ilist);
	    f->conn = NULL;
	    log_tcpinfo(fd);
	    barrier();
	    fast_close(fd); /* CHECKED OK */
	}
#if RELAY_SUPPORT
	list_for_each_entry_safe_l(c, list, &wt->timer_relay, timer_io) {
	    if(c->tsc_io >= wt->tsc_now)  break;
	    thread_reached(wt->thst);
	    close_relay_connection(c);
	}

	list_for_each_entry_safe_l(c, list, &wt->timer_connect, timer_io) {
	    if(c->tsc_io >= wt->tsc_now)  break;
	    thread_reached(wt->thst);
	    relay_timeout(c);
#if 0
	    if(wt->pending.prev == &c->timer_io)
		resume_connection(wt, c->netfd, POLLIN|POLLOUT);
#endif
	}
#endif
}
/* }}}1*/

/* check_idle_timeout() {{{1 */
static inline void check_idle_timeout(struct worker *wt) {
    	struct list_head *list;
	struct fdinfo *f;

	/* idle connection timeout */
	if(!direct_idle) return;
	list_for_each_entry_safe_l(f, list, &wt->idle_list, ilist) {
	    int fd = f - fdinfo;
	    if(bugcheck(!is_stub(fd, &wt->idleconn))) {
	    	lprintf("%s(%d): non-idle fd inside idle list, fd=%d\n", __FILE__, __LINE__, fd);
		fixing_idle_list(&wt->idle_list, &wt->idleconn);
		break;
	    }
	    if(f->tsc4 > TSCRND(wt->tsc_now) && atomic_read(&idlecon)<maxidles)
		break;
	    thread_reached(wt->thst);
	    atomic_dec(&idlecon);
	    wt->idle_cnt--;
	    list_del_init(&f->ilist);
	    f->conn = NULL;
	    log_tcpinfo(fd);
	    barrier();
	    fast_close(fd); /* CHECKED OK */
	}
}
/* }}}1*/

/* profile functions {{{1 */
#if PROFILE_SUPPORT
static inline void init_poll(struct worker *wt){
	wt->polltsc = readtsc();
}
static inline void after_poll(struct worker *wt){
	wt->polltsc = readtsc();
}
static inline void before_poll(struct worker *wt){
	wt->profile[PROFILE_TOTAL] += readtsc() - wt->polltsc;
}
#endif
/* }}}1*/

#if WITH_RTSIG
/* build_pollfd_worker() {{{1 */
static inline int build_pollfd_worker(struct worker *wt, int n) {
	int i;

	for(i=0; i<nconns; i++) {
	    if(wt->conn[i].netfd==-1) continue;
	    wt->pfd[n].fd = wt->conn[i].netfd;
	    wt->pfd[n].events = wt->conn[i].events;
	    n++;
#if RELAY_SUPPORT
	    if(!wt->conn[i].relaymode) continue;
	    wt->pfd[n].fd = wt->conn[i].relayfd;
	    wt->pfd[n].events = wt->conn[i].relayevents;
	    n++;
#endif
	}
	return n;
}
/* }}}1*/

/* build_pollfd_idle() {{{1 */
static inline int build_pollfd_idle(struct worker *wt, int n) {
	struct fdinfo *f;
	list_for_each_entry(f, &wt->idle_list, ilist) {
	    wt->pfd[n].fd = f - fdinfo;
	    wt->pfd[n].events = POLLIN;
	    n++;
	}
	return n;
}
/* }}}1*/

/* accept_connections_rtsig_direct() {{{1 */
static void accept_connections_rtsig_direct(struct worker *wt, int lfd) {
    	struct sockaddr_in addr;
	struct conn *c;
    	int fd=0, cnt=0;
	extern int incbatch;

	/* incoming available */
	while(!stop && wt->freeconn && cnt<incbatch) {
	    socklen_t len;
	    fd=fast_accept(lfd, (struct sockaddr *)&addr,(len=sizeof(addr),&len));        
        FAST_ERRNO(fd);
        thread_reached(wt->thst);
        if(fd < 0) {                                              
            if ((-ECONNABORTED == fd) || (-EINTR == fd) || (-EAGAIN == fd) || (-EWOULDBLOCK == fd)) {
                break;
            }
            else {
				lprintf("accept error: %s", strerror(-fd)); // EMFILE,ENFILE,EBADF 
                exit_http();
                break;
            }
        }
	    
	    cnt++;        
	    if(incblist && match_blacklist(incblist, addr.sin_addr.s_addr)) {
	    	fast_close(fd); /* CHECKED OK */
		    continue;
	    }        

	    check_new_fd(fd);
	    ISDSTAT(atomic_inc(&countermap->totalcon));
	    fast_fcntl(fd, F_SETOWN, wt->mypid);
	    new_fdinfo_rtsig(fd, addr.sin_addr.s_addr);
	    if((c=try_init_connection(wt, fd))!=NULL) {
		    ISDSTAT(atomic_inc(&countermap->workcon));        
		    list_move_tail(&c->timer_io, &wt->pending);
	    }
	}
	if(nworks > 1) {
	    fast_fcntl(lfd, F_SETOWN, wt->nextpid);
	    if(fd >= 0 && cnt >= incbatch)
	    {
		    union sigval v;
		    v.sival_int = lfd;
		    sigqueue(wt->nextpid, rtsigno, v);
	    }
	}
	check_pending(wt);
}
/* }}}1*/

static int routine_rtsig(struct worker *wt) {
#define WORKER_METHOD 0
#include "worker_rtsig.c"
}

static int routine_rtsig_idle(struct worker *wt) {
#define WORKER_METHOD 1
#include "worker_rtsig.c"
}

static int routine_rtsig_direct(struct worker *wt) {
#define WORKER_METHOD 2
#include "worker_rtsig.c"
}
#endif // WITH_RTSIG

static int routine_epoll(struct worker *wt) {
#define WORKER_METHOD 0
#include "worker_epoll.c"
}

/* routine_epoll_direct() {{{1 */
static int routine_epoll_idle(struct worker *wt) {
#define WORKER_METHOD 1
#include "worker_epoll.c"
}
/* }}}1*/

/* accept_connections_epoll_direct() {{{1 */
static inline void accept_connections_epoll_direct(struct worker *wt, int lfd) {
	/* incoming available */
	while(!stop) {
	    struct sockaddr_in addr;
	    struct conn *c;
	    int fd;
	    socklen_t len;

	    fd=fast_accept(lfd, (struct sockaddr *)&addr,(len=sizeof(addr),&len));
        FAST_ERRNO(fd);
        thread_reached(wt->thst);
        if(fd < 0) {                                              
            if ((-ECONNABORTED == fd) || (-EINTR == fd) || (-EAGAIN == fd) || (-EWOULDBLOCK == fd)) {
                break;
            }
            else {                
				lprintf("accept error: %s", strerror(-fd)); // EMFILE,ENFILE,EBADF 
				exit_http();
                break;
            }
        }
	            
	    if(incblist && match_blacklist(incblist, addr.sin_addr.s_addr)) {
	    	fast_close(fd); /* CHECKED OK */
			continue;
	    }
                
	    check_new_fd(fd);
	    ISDSTAT(atomic_inc(&countermap->totalcon));
	    new_fdinfo_epoll(fd, addr.sin_addr.s_addr);
	    if((c=try_init_connection(wt, fd))!=NULL) {
		ISDSTAT(atomic_inc(&countermap->workcon));
		resume_http_connection(fd, check_events(fd, POLLIN));
	    }
	}
}
/* }}}1*/

static int routine_epoll_direct(struct worker *wt) {
#define WORKER_METHOD 2
#include "worker_depoll.c"
}

/* accept_connections_epoll_direct_rr() {{{1 */
static inline void accept_connections_epoll_direct_rr(struct worker *wt, int lfd) {
  	struct sockaddr_in addr;
	struct conn *c;
    int fd=0, cnt=0;
	struct epoll_event ev;
	extern int incbatch;

	/* incoming available */
	while(!stop && wt->freeconn && cnt<incbatch) {
	    socklen_t len;
	    fd=fast_accept(lfd, (struct sockaddr *)&addr,(len=sizeof(addr),&len));
        FAST_ERRNO(fd);
        thread_reached(wt->thst);
        if(fd < 0) {                                              
            if ((-ECONNABORTED == fd) || (-EINTR == fd) || (-EAGAIN == fd) || (-EWOULDBLOCK == fd)) {
                break;
            }
            else {
				lprintf("accept error: %s", strerror(-fd)); // EMFILE,ENFILE,EBADF
                exit_http();
                break;
            }
        }         
	    cnt++;
        
	    if(incblist && match_blacklist(incblist, addr.sin_addr.s_addr)) {
	    	fast_close(fd); /* CHECKED OK */
	    	continue;
	    }        

	    check_new_fd(fd);
	    ISDSTAT(atomic_inc(&countermap->totalcon));
	    new_fdinfo_epoll(fd, addr.sin_addr.s_addr);
	    if((c=try_init_connection(wt, fd))!=NULL) {
		ISDSTAT(atomic_inc(&countermap->workcon));
		list_move_tail(&c->timer_io, &wt->pending);
	    }
	}

	ev.events = POLLIN|EPOLLET;
	ev.data.fd = lfd;
	fast_epoll_ctl(wt->epfd, EPOLL_CTL_DEL, lfd, &ev);
	fast_epoll_ctl(wt->epwake, EPOLL_CTL_ADD, lfd, &ev);
	check_pending(wt);
}
/* }}}1*/

static int routine_epoll_direct_rr(struct worker *wt) {
#define WORKER_METHOD 2
#include "worker_depoll.c"
}

/* routine_single() {{{1 */
static pthread_mutex_t singlelock = PTHREAD_MUTEX_INITIALIZER;
static int routine_single(struct worker *wt) {
	struct conn *c = wt->conn;

#if PROFILE_SUPPORT
	init_poll(wt);
#endif

	nice(5);
	atomic_dec(&startup_workers);
	while(!stop) {
	    int n;

	    if(wt->freeconn) { /* idle */
#if PROFILE_SUPPORT
		before_poll(wt);
#endif
		n = 0;
		if(atomic_read(&sparse_workers) >= max_sparse)
			break;
		atomic_inc(&sparse_workers);
		if(pthread_mutex_lock(&singlelock)==0)
		{
		    n = fast_recv(pipe_incoming, (char *)&c->netfd, sizeof(c->netfd), 0);
		    pthread_mutex_unlock(&singlelock);
		}
		atomic_dec(&sparse_workers);
#if PROFILE_SUPPORT
		after_poll(wt);
#endif

		if(n==sizeof(c->netfd)) {
		    init_connection(wt, c->netfd);
		    resume_http_connection(c->netfd, check_events(c->netfd, POLLIN));
		}
		continue;
	    }

#if PROFILE_SUPPORT
	    before_poll(wt);
#endif
	    /* FIXME */
	    uint64_t tsc = readtsc();
	    if(tsc < c->tsc_io) {
		n = (c->tsc_io - tsc)/tscmsec;
		n += n/100;
	    } else
	    	n = 0;

	    wt->pfd0[0].fd = c->netfd;
	    wt->pfd0[0].events = c->events;
#if RELAY_SUPPORT
	    if(c->relaymode) {
		wt->pfd0[1].fd = c->relayfd;
		wt->pfd0[1].events = c->relayevents;
		n = fast_poll(wt->pfd0, 2, n < 0 ? 0 : n);
	    } else
#endif
	    {
		n = fast_poll(wt->pfd0, 1, n < 0 ? 0 : n);
	    }
#if PROFILE_SUPPORT
	    after_poll(wt);
#endif
	    check_timestamp(wt);
	    if(n>0) {
		if(wt->pfd0[0].revents) {
		    resume_connection(wt, c->netfd, wt->pfd0[0].revents);
		}
#if RELAY_SUPPORT
		if(c->relaymode && wt->pfd0[1].revents) {
		    resume_connection(wt, c->relayfd, wt->pfd0[1].revents);
		}
#endif
		while(!list_empty(&wt->pending)) {
		    list_del_init(&c->timer_io);
		    resume_connection(wt, c->netfd, c->resume?POLLIN|POLLOUT:POLLIN);
		}
	    }
	    check_idle_switch(wt);
	    check_timeout(wt);
	}
	return 0;
}
/* }}}1*/

