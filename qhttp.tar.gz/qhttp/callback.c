/* vim: set sw=4 ai :*/

/*
 * MACRO:
 *	FORWARD_PROCESS
 *	RESPONSE_PROCESS
 */

    int cache = rv & 0xC0000000;

    rv = rv & ~0xC0000000;

    switch(cache) {
	case RF_PUBLIC:
	    c->cachemode = CACHE_PUBLIC;
	    break;
	case RF_PRIVATE:
	    c->cachemode = CACHE_PRIVATE;
	    break;
	case RF_NOCACHE:
	    c->cachemode = CACHE_NOCACHE;
	    break;
    }

    if((rv&RF_FORWARD_MASK) && cp->ftarget==NULL)
	    rv = 500;

    if(rv==0) {
    	/* NOOP */;
    }
    else if((rv & RF_FORWARD_MASK)!=0) {
	    switch(rv) {
	        default:
    #ifdef RESPONSE_PROCESS
		    RESPONSE_PROCESS;
    #endif
		    http_error(c, 500, cp->url);
		    return 0;
    #if RELAY_SUPPORT
    #ifdef FORWARD_PROCESS
	        case RF_FORWARD_TARGET:
	        case RF_SFORWARD_TARGET:
	        case RF_FORWARD_GROUP:
		    FORWARD_PROCESS;
    #endif
    #endif
	    }
    }
    else {
    #ifdef RESPONSE_PROCESS
    	    RESPONSE_PROCESS;
    #endif
    #if THROTTLE_SUPPORT
	    if(cp->speed < 65536)
	        c->speed = cp->speed;
    #endif
	    c->expire = cp->expire;

	    switch(rv) {
    #if 0
	        case 100 ... 199:
	        case 206 ... 299:
	        case 308 ... 399:
	        case 418 ... 499:
	        case 511 ... 599:
    #endif
	        default:
		    http_error(c, 500, cp->url);
		    break;

	        case 200 ... 203:
		    http_send_content(c, cp->buf, cp->mime?:"text/html", cp->mtime, cp->datalen);
		    break;

	        case 204 ... 205:
		    http_send_content(c, cp->buf, NULL, 0, 0);
		    break;

	        case 300 ... 307:
	        case 400 ... 417:
	        case 500 ... 511:
		    http_error(c, rv, cp->url);
		    break;

    #if 0
	        case RF_VHOST:
	        case RF_HOST:
    #endif
	        case RF_URL:
		    http_response_url(c, cp->url);
		    break;

	        case RF_PATHNAME:
		    http_response_pathname(c, cp->buf);
		    break;

	        case RF_ENTITY:
		    if(isntfdptr(cp->entity)) {
		        http_error(c, 404, cp->url);
		    } else {
		        c->entity = cp->entity;
		        http_response(c);
		    }
		    break;

	        case RF_SUB_ENTITY:
		    if(isntfdptr(cp->entity) ||
			    cp->offset >= (isptr(cp->entity) ? ((struct mementity *)cp->entity)->size :
			        fdent(cp->entity)->size
			        )
		      ) {
		        http_error(c, 404, cp->url);
		    } else if(cp->datalen < 0) {
		        lprintf("plugin return RF_SUB_ENTITY with datalen=%d\n", cp->datalen);
		        http_error(c, 500, cp->url);
		    } else {
		        c->entity = cp->entity;
		        http_response_sub(c,
			        cp->mime?:"text/html", cp->mtime,
			        cp->offset, cp->datalen
			        );
		    }
		    break;

	        case RF_FILE_HANDLE:
		    rv = PTR2INT(cp->entity);
		    if(!isfd(cp->entity))
		    {
		        http_error(c, 404, cp->url);
		    } else if(cp->datalen < 0) {
		        lprintf("plugin return RF_FILE_HANDLE with datalen=%d\n", cp->datalen);
		        http_error(c, 500, cp->url);
		    } else {
		        http_response_fd(c, rv,
			        cp->mime?:"text/html", cp->mtime,
			        cp->offset, cp->datalen
			        );
		    }
	    }
	    return 0;
    }

#undef FORWARD_PROCESS
#undef RESPONSE_PROCESS
