/* vim: set sw=4 ai :*/
#include "myalloc.h"
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include "compat_thread.h"

#include "tsc.h"
#include "watchdog.h"
#include "myconfig.h"
#include "global.h"
#include "daemon.h"
#include "listen.h"
#include "priv.h"
#include "http.h"
#include "vhost.h"
#include "shmem.h"
#include "thread.h"
#include "log.h"
#include "fault.h"
#include "plugin.h"
#if COOKIE_SUPPORT
#include "cookie.h"
#endif
#include "relay.h"
#include "task.h"
#include "filemon.h"
#include "entity.h"
#include "filecount.h"
#include "stat.h"
#if RELAY_SUPPORT
#include "group.h"
#endif
#include "help.h"
#include "version.h"
#include "cgi.h"
#include "om_thread.h"

static void main_loop_rtsig(struct threadstat *thst) {
	struct timespec ts;
	int next_check = now;
	sigset_t sset;
	sigemptyset(&sset);
	sigaddset(&sset, SIGIO);
	sigaddset(&sset, rtsigno);
	sigprocmask(SIG_BLOCK, &sset, NULL);
	/* use signal instead poll: dnotify */
	/* assume signal queue never overflow */
	while(!stop){

#if DEBUG_MALLOC
	    myalloc_check();
#endif
	    siginfo_t si;
	    int signo;

	    ts.tv_nsec = 0;
	    if(nconns==1) {
		    ts.tv_sec = 1;
	    } else {
		    ts.tv_sec = next_check - now;
		    if(ts.tv_sec < 1) ts.tv_sec = 1;
	    }

	    signo = sigtimedwait(&sset, &si, &ts);
	    thread_reached(thst);
	    if(developer) {
		    if(is_front()==0)
		        stop = 1;
	    }
	    now = fast_time();
	    if(nconns==1)
		 check_dynamic_workers();

	    if(signo==rtsigno && si.si_code>0 && si.si_code<=POLL_HUP) {
		    thread_reached(thst);
		    run_sigio_callback(si.si_fd, si.si_band);
	    }

	    if(now < next_check)
	    	continue;
	    
        next_check += 10;
	    scan_logfiles(); /* scan log files */
	    ISDSTAT(statistics());

	    if(need_filemon==0) {
		    checking_monitor_files();
	    }

	    thread_reached(thst);
	    run_privilege_task();
	    thread_reached(thst);

	    if(developer || myconfig_get_intval("report_stack_usage", 0))
		    check_stack_usage();
	}
}

static void main_loop_epoll(struct threadstat *thst) {
	int next_check = now;
	struct epoll_event *ev = shalloc(epoll_batch_events*sizeof(struct epoll_event));

	while(!stop){

#if DEBUG_MALLOC
	    myalloc_check();
#endif
	    int to = 0;
	    if(nconns==1) {
		    to = 1000;
	    } else {
		    to = (next_check - now)*1000;
		    if(to < 1000) to = 1000;
	    }

	    int n = fast_epoll_wait(main_epfd, ev, epoll_batch_events, to);

	    thread_reached(thst);
	    if(developer) {
		    if(is_front()==0)
		        stop = 1;
	    }
	    now = fast_time();
	    if(nconns==1)
		    check_dynamic_workers();

	    int i;
	    for(i=0; i<n; i++) {
		    thread_reached(thst);
		    run_sigio_callback(ev[i].data.fd, ev[i].events);
	    }

	    if(now < next_check)
		    continue;
	    next_check += 10;

	    scan_logfiles(); /* scan log files */
	    ISDSTAT(statistics());

	    if(need_filemon==0)
		    checking_monitor_files();

	    thread_reached(thst);
	    run_privilege_task();
	    thread_reached(thst);

	    if(developer || myconfig_get_intval("report_stack_usage", 0))
		    check_stack_usage();
	}
}

int init_main_loop_mode(void) {

	if(has_epoll>0 && (has_inotify>0 || has_dnotify<=0))
		main_epfd = fast_epoll_create(maxfds);
	return 0;
}

int final_security_role(void) {
	if(fast_chdir(docroot)<0) return -1;
	if(need_chroot && fast_chroot(".") < 0) return -1;
	if(main_chown) set_security_role(ROLE_GUEST);
	return 0;
}

int main(int argc, char **argv) {
	int err = 0;
	struct threadstat *thst = NULL;

	extern uint64_t clocksource_os(void);
	uint64_t starting_time = clocksource_os();

#if INLINE_SYSCALL
	detect_vdso();
#endif
#if DEBUG_MALLOC
	myalloc_init();
#endif
	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);
	myconfig_init(argc, argv);
	show_developer_magic();
	check_developer_mode();
	detect_memory_mode();

	detect_kernel();
	print_version();

	init_timestamp();
	lprintf("Starting Server v%s (%s)...\n",
		qhttpd_version_string, qhttpd_compiling_date);
	daemon_start(argc, argv);

#if PLUGIN_SUPPORT
	has_plugin = myconfig_get_value("plugin") != NULL;
#endif

	if(has_sendfile64==0)
	    lprintf("\7sendfile64() detected, kernel v2.4.21 or above perfered\n");

	init_privilege(); // must be first
	init_entity_access_method(); // some component depend on access_method
	init_thread_mode();
	need_filemon = main_chown || need_chroot;

#define ICALL(x)	if((err=x()) < 0) goto error
	ICALL(init_tsc);
	ICALL(init_filemon_server);
	ICALL(start_watchdog);
	ICALL(init_fault_handler);
	ICALL(init_main_loop_mode);

	set_security_role(ROLE_ROOT); /* the first */

	ICALL(init_filemon_client);
	ICALL(init_worker_mode);
	ICALL(init_thread_stack);	/* affected by total worker */
	ICALL(init_fdlimit);		/* affected by worker mode */
#if COOKIE_SUPPORT
	ICALL(init_cookie_info);	/* affect shmem_size */
#endif
	ICALL(init_fdcache_mode);

	ICALL(init_shmem_data);
	ICALL(init_fdinfo_array); /* many facility depend on fdinfo */
	ICALL(init_thread_data);

	ISDSTAT(ICALL(init_statistics));
	ICALL(init_logging); /* must after filemon */
	ICALL(init_worker_data);
	ICALL(init_listen_socket);
	ICALL(init_mimetypes_hash);
	ICALL(init_vhost);
	ICALL(init_download_speed);
	ICALL(init_entity_access_control);
#if IOPERF_SUPPORT
	ICALL(ioperf_init);
#endif
	ICALL(init_fdcache_lockless);
	ICALL(init_fdcache_global);
#if FILECOUNT_SUPPORT
	ICALL(init_filecounting);
#endif
	ICALL(init_referer_domain);
	ICALL(init_response_messages);
#if RELAY_SUPPORT
	ICALL(init_relay_system);
	ICALL(init_relay_groups);
#endif

    // before: start_om_thread
    // after: load_plugins
    if (start_om_thread() < 0) goto out1;

#if PLUGIN_SUPPORT
	ICALL(load_plugins);
#endif
    
	ICALL(final_security_role);
#if RELAY_SUPPORT
	ICALL(verify_all_groups);
#endif
	thread_jumbo_title();
	running = 1;
#if USE_LINKSCRIPT
	extern char hsdata[], hedata[];
	mprotect(hsdata, hedata-hsdata, PROT_READ);
#endif

	init_cgi_vhost();
        
	thst = get_threadstat();
	if(start_work_threads(thst)<0) goto out1;
	if(!main_chown && nconns>1) set_security_role(ROLE_OWNER);
	if(verbose) {
	    lprintf("Startup  lantency: %"F64"d ms\n", (clocksource_os()-starting_time)/1000);
	    report_free_shmem();
	    report_mallinfo();
	}

	daemon_background();

	thread_reached(thst);
	scan_logfiles(); /* scan log files */
	thread_reached(thst);
	if(main_epfd > 0)
	    main_loop_epoll(thst);
	else
	    main_loop_rtsig(thst);
out1:

#if USE_LINKSCRIPT
	{
	    extern char hsdata[], hedata[];
	    mprotect(hsdata, hedata-hsdata, PROT_READ|PROT_WRITE);
	}
#endif
	running = 0;
	lprintf("Stopping Server v%s (%s)...\n",
		qhttpd_version_string, qhttpd_compiling_date);
	if(pipe_incoming)
	    fast_fcntl(pipe_incoming, F_SETFL, O_RDONLY|O_NONBLOCK);
    stop_om_thread();
	stop_threads(thst);
	stop_worker_threads();
	thread_reached(thst);
	cleanup_privilege_task();
	thread_reached(thst);
	run_shutdown_callback();
	thread_reached(thst);
#if PLUGIN_SUPPORT
	free_plugins();
#endif
	cleanup_sockets();

	cleanup_filemon();
	thread_reached(thst);
	free_fdcache_global();
	free_fdcache_lockless();
	scan_logfiles();
	thread_reached(thst);
	ISDSTAT(statistics());

#if COOKIE_SUPPORT
	free_cookie_info();
#endif
	free_vhost();
	free_referer_domain();
	if(main_epfd > 0)
	    fast_close(main_epfd);
	myconfig_cleanup();
	lprintf("Server Stopped\n");
	free_logging();
	free_shmem();
	thread_reached(thst);
	wait_filemon_server();
	ISDSTAT(free_statistics());
	dump_non_free();
	_exit(restart); // exit() cause very problem
	return restart;
error:
	if(err != -ENOMEM) return -1;
	fast_write(1, "\n\033[31m\033[1mNO ENOUGH MEMORY\033[0m\n", 31);
	return -1;
}
