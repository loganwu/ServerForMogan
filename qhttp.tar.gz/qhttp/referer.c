#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <regex.h>
#include <pthread.h>
#include "autoconfig.h"
#include "shmem.h"
#include "myconfig.h"
#include "util.h"
#include "vhost.h"
#include "log.h"
#include "global.h"

#define MAX_REFER_REDIRECT 100

struct lstr {
	const char *ptr;
	int len;
};

struct mapstr {
    char* key;
    char* value;
    int keylen;
    int valuelen;
    regex_t reg;
};

int referer_checking;
static int nreferers __init__ = 0;
static struct lstr *referer __init__ = NULL;
static char *refererstring  __init__= NULL;

// suffix
static int nsuffixes  __init__= 0;
static struct lstr *suffix __init__ = NULL;
static char *referersuffix  __init__= NULL;
// prefix
static int nprefixes  __init__= 0;
static struct lstr *prefix __init__ = NULL;
static char *refererprefix  __init__= NULL;
// redirect
static int nredirectes  __init__= 0;
static struct mapstr redirect[MAX_REFER_REDIRECT];

int init_referer_domain(void) {
	int i;

	refererstring = myconfig_get_value("referer_domain");
	if(refererstring==NULL) return 0;
	refererstring = shdup(refererstring);
	if(refererstring==NULL) return -ENOMEM;

	char *field[100];

	nreferers = str_explode(" \t\r\n,", refererstring, field, 100);
	referer = shalloc(nreferers * sizeof(struct lstr));
	for(i=0; i<nreferers; i++) {
	    referer[i].ptr = field[i];
	    referer[i].len = strlen(field[i]);
	    lprintf("referer_domain[%d] is %d:%p:%s", i, referer[i].len, referer[i].ptr, referer[i].ptr);
	}

	if(nreferers > 0)
	    referer_checking = myconfig_get_intval("referer_checking", 1);
	lprintf("referer_checking is %d", referer_checking);
    if (0 == referer_checking) return 0;

    // prefix
    refererprefix = myconfig_get_value("referer_allow_prefix");
	if(refererprefix) {
	    refererprefix = shdup(refererprefix);
	    nprefixes = str_explode(" \t\r\n,", refererprefix, field, 100);
	    prefix = shalloc(nprefixes * sizeof(struct lstr));
	    for(i=0; i<nprefixes; i++) {
		    prefix[i].ptr = field[i];
		    prefix[i].len = strlen(field[i]);
		    lprintf("prefix[%d] is %d:%p:%s", i, prefix[i].len, prefix[i].ptr, prefix[i].ptr);
	    }
	}
    
    // suffix
	referersuffix = myconfig_get_value("referer_allow_suffix");
	if(referersuffix) {
	    referersuffix = shdup(referersuffix);
	    nsuffixes = str_explode(" \t\r\n,", referersuffix, field, 100);
	    suffix = shalloc(nsuffixes * sizeof(struct lstr));
	    for(i=0; i<nsuffixes; i++) {
		    suffix[i].ptr = field[i];
		    suffix[i].len = strlen(field[i]);
		    lprintf("suffix[%d] is %d:%p:%s", i, suffix[i].len, suffix[i].ptr, suffix[i].ptr);
	    }
	}    

    // redirect    
    int rv;
    char *p;    
	for(rv=0;
      ((rv < MAX_REFER_REDIRECT) && (p=myconfig_get_multivalue("referer_redirect", rv)));
		rv++)
	{
            p = shdup(p);
            ++nredirectes;                        

            int n = str_explode(" \t\r\n,", p, field, 100);            
            if (n > 1) {            
                redirect[rv].key        = field[0];
                redirect[rv].keylen     = strlen(field[0]);
                redirect[rv].value      = field[1];
                redirect[rv].valuelen   = strlen(field[1]);                
                redirect[rv].value      = shdup(redirect[rv].value);
                lprintf("%s->%s", redirect[rv].key, redirect[rv].value);
                int errcode = regcomp(&redirect[rv].reg, redirect[rv].key, REG_EXTENDED|REG_NOSUB);
                if (errcode) {
                    char errbuf[512] = {0};
                    size_t errbuf_size = sizeof(errbuf)-1;
                    regerror(errcode, &redirect[rv].reg, errbuf, errbuf_size);
                    lprintf("regcomp \"%s\" error: %s", redirect[rv].key, errbuf);
                    regfree(&redirect[rv].reg);
                    return -1;
                }
            }
    }

	return 0;
}

void free_referer_domain(void) {
    int i;
    for (i=0; i<nredirectes; ++i)
        regfree(&redirect[i].reg);
}

// http://71.qq.com:3030/s1k.htm->
// url: /x.htm
// ref: http://71.qq.com/x.htm
int check_referer_domain(const char *url, const char *ref) {
	const char *p;
	int l, i;
    
	if(nreferers==0) return 1;
    if (NULL == url) return 0;
    if (NULL == ref) return 0;

    // Entry log
    //lprintf("%lu: url is \"%s\", and ref is \"%s\"", (unsigned long)pthread_self(), url, ref);

	/*check prefix*/	
	for(i=0; i<nprefixes; i++) {
        //lprintf("%lu: prefix[%d].ptr is %d:%p, url is %p", (unsigned long)pthread_self(), i, prefix[i].len, prefix[i].ptr, url);
	    if(!strncasecmp(prefix[i].ptr, url, prefix[i].len))
		    return 1;
	}
    /*check suffix*/
	l = strlen(url); url += l;
	for(i=0; i<nsuffixes; i++) {
        //lprintf("%lu: suffix[%d].ptr is %d:%p, url is %p", (unsigned long)pthread_self(), i, suffix[i].len, suffix[i].ptr, url);
	    if(l >= suffix[i].len &&
		    !strncasecmp(suffix[i].ptr, url-suffix[i].len, suffix[i].len))
		return 1;
	}

	/*check domain*/
	ref = strchr(ref, ':');
	if(ref==NULL) return 0;
	ref++; /* strip protocol */
	while(ref[0]=='/')ref++; /* prefix // */
	const char *colon = NULL;
	for(p=ref; *p; p++) {
	    if(*p=='/') break;
	    if(*p==':' && colon==NULL) colon = p;
	    if(*p=='@') {
		ref = p + 1; /* strip username */
		colon = NULL;
	    }
	}
	if(colon) p = colon;
	if(p!=ref && p[-1]=='.') p--; /* strip last . */
	l = p - ref;
    // l: 10
    // p: /x.htm

    if (NULL == ref) return 0;
	for(i=0; i<nreferers; i++) {
	    if(l==referer[i].len && !strncasecmp(referer[i].ptr, ref, l))
		return 1;
	    if(l > referer[i].len &&
		    ref[l-referer[i].len-1] == '.' &&
		    !strncasecmp(referer[i].ptr, ref+l-referer[i].len, referer[i].len))
		return 1;
	}
	return 0;
}

int redirect_refer(char** url) {
    int i;
    for (i=0; i<nredirectes; ++i) {        
        if (!regexec(&redirect[i].reg, *url, 0, NULL, 0)) {            
            //*url = redirect[i].value;
            if (redirect[i].valuelen <= maxurllen) {
                strcpy(*url, redirect[i].value);
                return 1;
            }    
            break;
        }
    }
    return 0;
}
