#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/signal.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "compat_ctype.h"
#include "compat_dnotify.h"
#include "compat_inotify.h"
#include "compat_errno.h"
#include "compat_stat64.h"
#include "bitops.h"

#include "autoconfig.h"

#include "myconfig.h"
#include "global.h"
#include "daemon.h"
#include "conn.h"
#include "vhost.h"
#include "namemap.h"
#include "util.h"
#include "log.h"
#include "shmem.h"
#include "profile.h"
#include "pattern.h"
#include "plugin.h"
#include "task.h"
#include "entity.h"
#include "stat.h"
#if RELAY_SUPPORT
#include "relay.h"
#include "cgi.h"
#include "malloc.h"
#include "group.h"
#endif

#if COMPAT_GLIBC
#undef __USE_FILE_OFFSET64
#endif
#include <dirent.h>

char* monitor_guard __init__;
int use_vhost __init__;
int fd_docroot __init__;
static time_t root_mtime = 0;
static DIR *rootdir;
static int use_ipbase_vhost __init__;
#if THROTTLE_SUPPORT
static int default_speed __init__;
#endif

struct valias {
	struct vhost *vhost;
	unsigned char flag;
}  __align1__;

static int nvhosts = 0;
static int nvalias = 0;
static struct namemap *aliasmap;
static struct vhost *vhostdef = NULL;
static struct vhost *vhostpre = NULL;
static struct valias *valiasdef = NULL;

static struct pattern *pat_expire __init__;
static int timeout_expire __init__;

static struct valias * add_valias(const char *alias, struct vhost *vhost, int report);
static void scan_vhost(void);
static void scan_vhost1(void *);
static void scan_vhost2(void *, int);
static int inotify_fd;
static void inotify_vhost(void *, int);
//static int get_dir_index(const char* vhostname, const char* dir, char* index, size_t len);

static int init_expire(void) {
	/* STACK-USAGE: 500 */
	char *field[100];
	char *p;
	int i, j, n, e;

	timeout_expire = myconfig_get_intval("expire_timeout", 0);
	pat_expire = create_pattern();

	for(i=0; (p=myconfig_get_multivalue("expire_prefix", i)); i++) {
		if((n = str_explode(NULL, p, field, 100)) < 2) continue;
		if(!is_digit(field[0][0])) continue;
		e = atoi(field[0]);

		for(j=1; j<n; j++)
			add_prefix_pattern(pat_expire, field[j], INT2PTR(e));
	}

	for(i=0; (p=myconfig_get_multivalue("expire_suffix", i)); i++) {
		if((n = str_explode(NULL, p, field, 100)) < 2) continue;
		if(!is_digit(field[0][0])) continue;

		e = atoi(field[0]);

		for(j=1; j<n; j++)
			add_suffix_pattern(pat_expire, field[j], INT2PTR(e));
	}

	for(i=0; (p=myconfig_get_multivalue("expire_pattern", i)); i++) {
		if((n = str_explode(NULL, p, field, 100)) < 2) continue;
		if(!is_digit(field[0][0])) continue;

		e = atoi(field[0]);

		for(j=1; j<n; j++)
			add_pattern(pat_expire, field[j], INT2PTR(e));
	}

	return timeout_expire;
}

int init_vhost(){
	if(docroot[0]=='/' && docroot[1]=='\0') {
		lprintf("\7\"document_root = /\" not allowed\n");
		return -1;
	}

	int rv;

    monitor_guard = myconfig_get_value("monitor_guard");
	maxpostsize = myconfig_get_intval("maximum_post_data_size", 16<<20);
	use_vhost = myconfig_get_intval("use_vhost", 0);
#if 0
	if(use_vhost==0) {
		if(myconfig_get_intval("log_first_directory", 0))
			use_vhost = 2;
	}
#endif
	strip_query_string = has_plugin==0 ? 1 : myconfig_get_intval("strip_query_string", 0);
	if(docroot==NULL) {
		lprintf("\7document_root not defined\n");
		return -1;
	}
	if(docroot[0] != '/') {
		lprintf("\7document_root must be full pathname\n");
		return -1;
	}

	if((fd_docroot = fast_open2(docroot, O_RDONLY|O_DIRECTORY)) < 0) {
		FIX_ERRNO(fd_docroot);
		lprintf("\7document_root: %s: %m\n", docroot);
		return -1;
	}

	if((rv=fast_chdir(docroot)) < 0) {
		FIX_ERRNO(rv);
		lprintf("\7chdir(\"%s\"): %m\n", docroot);
		return -1;
	}

	if(use_vhost) {
		aliasmap = CreateNameMap(1<<16, sizeof(struct valias));
		if(aliasmap==NULL)
			return -ENOMEM;
		if(main_epfd > 0) {
			inotify_fd = fast_inotify_init();
			if(inotify_fd > 0) {
				if(fast_inotify_add_watch(inotify_fd, docroot, IN_MOD_MASK)<0) {
					fast_close(inotify_fd);
					inotify_fd = 0;
				}
			}
		}

		if(inotify_fd > 0) {
			lprintf("Use inotify for vhost monitor\n");
			fast_fcntl(inotify_fd, F_SETFL, O_RDONLY|O_NONBLOCK);
			register_sigio_callback(inotify_fd, inotify_vhost, NULL);
		} else if(has_dnotify>0 && fast_fcntl(fd_docroot, F_NOTIFY, DN_CREATE|DN_DELETE|DN_RENAME|DN_MULTISHOT) >= 0) {
			lprintf("Use dnotify for vhost monitor\n");
			register_sigio_callback(fd_docroot, scan_vhost2, NULL);
		} else {
			register_privilege_task(scan_vhost1, NULL);
		}
		rootdir = opendir(docroot);
		valiasdef = add_valias("@default", NULL, 0);
		vhostdef = add_vhost("@default", VH_DISABLED|VH_DEFAULT);
		vhostpre = add_vhost("@pre", VH_DISABLED);
		use_ipbase_vhost = myconfig_get_intval("use_ipbase_vhost", 0);

#if ISDSTAT_SUPPORT
		char *p;
		for(rv=0;
				rv < MAXHOSTLOG &&
				(p=myconfig_get_multivalue("statistics_digest_host", rv));
				rv++)
		{
			char *f[2];
			struct vhost *vh;
			uint32_t msgid;

			switch(str_explode(" \t\r\n,", p, f, 2)) {
				case 0: break;
				case 1: f[1] = "@default";
				case 2: if(!is_digit(f[0][0]))
						break;
					msgid = strtoul(f[0], NULL, 0);
					vh = add_vhost(f[1], VH_DISABLED);
					if(countermap->hostnum==0)
						countermap->hostnum++;
					if(!strcmp(f[1], "@default")) {
						countermap->host[0].msgid = msgid;
						vh->statid = 0;
					} else  {
						countermap->host[countermap->hostnum].msgid = msgid;
						vh->statid = countermap->hostnum;
						countermap->hostnum++;
					}
					if(logmode < LOG_DIGEST)
						logmode = STAT_DIGEST;
			}
		}
#endif

		scan_vhost();
	} else {
		vhostdef = add_vhost("@default", VH_DEFAULT);
		vhostpre = add_vhost("@pre", VH_DISABLED);
	}

#if THROTTLE_SUPPORT
	default_speed = myconfig_get_intval("download_speed", 0);
#endif
	init_expire();
	return 0;
}

void free_vhost(void) {
	struct vhost *vh;

	while(vhostlist != NULL) {
		vh = vhostlist; vhostlist=vh->vhost;
		if(vh->logfd >= 0) {
			fast_close(vh->logfd);
		}
	}

	if(rootdir) {
		closedir(rootdir);
		rootdir = NULL;
	}

	if(fd_docroot > 0) {
		fast_close(fd_docroot);
		fd_docroot = 0;
	}

	if(inotify_fd > 0) {
		fast_close(inotify_fd);
		inotify_fd = 0;
	}

}

struct vhost *add_vhost(const char *vhost, int flag) {
	struct vhost *vh;
	int l;

	for(vh = vhostlist; vh; vh=vh->vhost) {
		if(!strcmp(vh->name, vhost)) {
			if( (flag & VH_UPDATED) ) vh->flag |= flag;
			return vh;
		}
	}
	l = strlen(vhost) + 1;
	vh = shalloc(sizeof(struct vhost)+l);
	if(vh==NULL) {
		lprintf("Add vhost %s failed, no enough memory\n", vhost);
		return NULL;
	}
	vh->logfd = -1;
#ifdef PLUGIN_SUPPORT
	vh->plugin = NULL;
#endif
	memcpy(vh->name, vhost, l);
	vh->vhost = vhostlist;
	vh->flag = flag;
	atomic_set(&vh->req, 0);
#if HAS_ATOMIC8
	atomic8_set(&vh->bytes, 0);
#else
	atomic_set(&vh->bytes, 0);
	atomic_set(&vh->kbytes, 0);
#endif
	vh->statid = 0;
	vhostlist = vh;
	nvhosts++;
	if(flag & VH_UPDATED)
		lprintf("Create vhost %s\n", vhost);
	return vh;
}

static struct valias *add_valias(const char *alias, struct vhost *vh, int report) {
	struct valias *va;

	va = GetNameFromMap(aliasmap, alias);
	if(va) {
		if(va->vhost != vh) {
			va->vhost = vh;
			if(vh) lprintf("Alias vhost %s --> %s\n", alias, vh->name);
		}
		va->flag = VH_UPDATED;
		return va;
	}
	va = AddNameToMap(aliasmap, alias);
	if(va==NULL) {
		lprintf("Alias vhost %s failed, no enough memory\n", alias);
		return NULL;
	}
	va->vhost = vh;
	va->flag = VH_UPDATED;
	if(vh && report)lprintf("Alias vhost %s --> %s\n", alias, vh->name);
	nvalias++;
	return va;
}

static inline struct vhost *get_vhost(const char *alias) {
	struct valias *va;
	va = GetNameFromMap(aliasmap, alias);
	if(va==NULL) return NULL;
	struct vhost *vh = va->vhost;
	if(vh==NULL || (vh->flag&VH_DISABLED)) return NULL;
	return vh;
}

/* this routine use alot of stack */
static void scan_vhost() {
	stat64_t rootstat;
	struct vhost *vh;
	struct valias *va;
	char *p;
	int n, linkdepth;
	struct dirent *de;

	if(fast_filestat(fd_docroot, &rootstat) != 0 ||
			rootstat.st_mtime == root_mtime) 
		return;
	root_mtime = rootstat.st_mtime;
	fast_fchdir(fd_docroot);
	if(rootdir)
		rewinddir(rootdir);
	else if(rootdir==NULL)
		return;
	while((de=readdir(rootdir)) != NULL)
	{
		if(de->d_name[0] == '.') continue;
		if(fast_linkstat(de->d_name, &rootstat) < 0) continue;
		if(strlen(de->d_name) > maxhostlen) continue;
		if(S_ISDIR(rootstat.st_mode)) {
			/* vhost */
			add_valias(de->d_name, add_vhost(de->d_name, VH_UPDATED), 0);
		} else if(S_ISLNK(rootstat.st_mode)) {
			/* alias */
			char linkbuf[4096];
			char linkhost[256+1];
			p = de->d_name;
			linkhost[0] = '\0';
			for(linkdepth=10, linkhost[0]='\0', p=de->d_name;
					linkdepth && (n=fast_readlink(p, linkbuf, 4096)) > 0;
					linkdepth--, p=linkhost)
			{
				linkbuf[n] = '\0';
				p = linkbuf;
				while(1) {
					if(p[0]=='/') p++;
					else if(p[0]=='.' && p[1]=='/') p+=2;
					else break;
				}
				if(p[0]=='\0') break;
				if(p[0]=='.') goto bad;
				n = strlen(p);
				if(n>0 && p[n-1]=='/') n--;
				p[n] = '\0';
				if(n > maxhostlen) break;
				memcpy(linkhost, p, n+1);
				if(fast_linkstat(de->d_name, &rootstat) < 0) goto bad;
				if(S_ISDIR(rootstat.st_mode)) break;
				if(!S_ISLNK(rootstat.st_mode)) goto bad;
			}
			if(linkhost[0]=='\0')
				add_valias(de->d_name, add_vhost(de->d_name,VH_UPDATED),0);
			else
				add_valias(de->d_name, add_vhost(linkhost, 0), 1);
		}
bad:
		continue;
	}

	n = 0; va = NULL;
	while((va=IterateNameMap(aliasmap, va, &n)) != NULL) {
		if((va->flag & VH_UPDATED)==0) {
			if(va->vhost) {
				lprintf("Remove alias %s\n", MapDataToName(aliasmap, va));
				va->vhost = NULL;
			}
		} else
			va->flag = 0;
	}

	for(vh = vhostlist; vh; vh=vh->vhost) {
		if((vh->flag & VH_UPDATED)==0) {
			if((vh->flag & VH_DISABLED)==0) {
				lprintf("Remove vhost %s\n", vh->name);
				vh->flag |= VH_DISABLED;
				delay_close(vh->logfd, 60);
				vh->logfd = -1;
			}
		} else {
			if((vh->flag & VH_DISABLED)) {
				lprintf("Create vhost %s\n", vh->name);
			}
			vh->flag &= ~(VH_DISABLED|VH_UPDATED);
		}
	}
}
static void scan_vhost1(void *unused) {
	scan_vhost();
}
static void scan_vhost2(void *unused, int unused2) {
	scan_vhost();
}
static void inotify_vhost(void *unused, int unused2) {
	char buf[512];
	while(fast_read(inotify_fd, buf, sizeof(buf)) > 0);
	scan_vhost();
}

inline struct vhost *default_vhost(void) {
	if(valiasdef && valiasdef->vhost) return valiasdef->vhost;
	if(vhostdef) return vhostdef;
	return NULL;
}

void resolv_vhost(struct conn *c) {
	struct vhost *vh = NULL;
	char host[50];

	if(c->host[0]!='\0') vh = get_vhost(c->host);
	if(vh==NULL && use_ipbase_vhost) {
		struct sockaddr addr;
		socklen_t len;
		int p;
		char *s;
		fast_getsockname(c->netfd, &addr, (len=sizeof(addr), &len));
		if(addr.sa_family==AF_INET) {
			s = ip2str(host, ((struct sockaddr_in *)&addr)->sin_addr.s_addr);
			p = ntohs(((struct sockaddr_in *)&addr)->sin_port);
			if( p != 80 ) {
				*s++ = ':';
				s = uint2str(s, p);
			}
			*s = '\0';
			vh = get_vhost(host);
		} else if(addr.sa_family==AF_UNIX) {
			vh = get_vhost("127.0.0.1");
		}
#ifdef AF_INET6
		else if(addr.sa_family==AF_INET6) {
			inet_ntop(AF_INET6, &((struct sockaddr_in6 *)&addr)->sin6_addr,
					host, 40);
			p = ntohs(((struct sockaddr_in6 *)&addr)->sin6_port);
			if( p != 80 ) {
				char *s = host + strlen(host);
				*s++ = ':';
				s = uint2str(s, p);
				*s = '\0';
			}
			vh = get_vhost(host);
		}
#endif
	}
	if(vh==NULL) vh = valiasdef->vhost;
	if(vh==NULL) vh = vhostdef;

	c->vhost = vh;
}

static inline void resolv_first_directory(struct conn *c) {
	struct vhost *vh = NULL;
	char *vhost;
	char *p;

	for(vhost=c->url; vhost[0]=='/'; vhost++);

	p = strchr(vhost, '/');
	if(p) {
		*p = '\0';
		vh = get_vhost(vhost);
		*p = '/';
	}

	if(vh==NULL) vh = valiasdef->vhost;
	if(vh==NULL) vh = vhostdef;

	c->vhost = vh;
}

/* valid host name characters and convert to lower case */
static const char validhostchar[256] = {
	['0']='0', ['1']='1', ['2']='2', ['3']='3', ['4']='4',
	['5']='5', ['6']='6', ['7']='7', ['8']='8', ['9']='9',

	['a']='a', ['b']='b', ['c']='c', ['d']='d', ['e']='e',
	['f']='f', ['g']='g', ['h']='h', ['i']='i', ['j']='j',
	['k']='k', ['l']='l', ['m']='m', ['n']='n', ['o']='o',
	['p']='p', ['q']='q', ['r']='r', ['s']='s', ['t']='t',
	['u']='u', ['v']='v', ['w']='w', ['x']='x', ['y']='y', ['z']='z',

	['A']='a', ['B']='b', ['C']='c', ['D']='d', ['E']='e',
	['F']='f', ['G']='g', ['H']='h', ['I']='i', ['J']='j',
	['K']='k', ['L']='l', ['M']='m', ['N']='n', ['O']='o',
	['P']='p', ['Q']='q', ['R']='r', ['S']='s', ['T']='t',
	['U']='u', ['V']='v', ['W']='w', ['X']='x', ['Y']='y', ['Z']='z',

	['.']='.', ['-']='-', ['_']='-', [':']=':',
};

/* isspace & NUL */
static const uint32_t hostendmask[8] = {
	[0] = 0x00003e01, /* 00-1F */
	[1] = 0x00000001, /* 20-3F */
};

void save_vhost(struct conn *c, char *line) {
	char *p=c->host;
	while(p<c->host+maxhostlen && validhostchar[*(unsigned char *)line])
		*p++ = validhostchar[*(unsigned char *)(line++)];
	if(test_bit(*(unsigned char *)line, hostendmask)) {
		*p = '\0';
		if(p >= c->host+4 && *(uint32_t *)(p-3) == *(uint32_t *)":80")
			*(p-3) = '\0';
	} else
		c->host[0] = '\0';
}

int decode_url(const char *vhostname, const char *url, char *filename, int len) {
	char *p;
    const char *urlp = url;
	char *e = filename + len;
	int ch;

	/* url[0] and filename[0] always be '/' */
	p = filename;
	*p++ = '/';
	while(p<e && (ch=*url++)) {
		if(ch=='?' || ch=='&') break;
		if(ch=='%') {
			if(is_xdigit(url[0]) && is_xdigit(url[1])) {
				if(is_digit(url[0]))
					ch = url[0] - '0';
				else
					ch = (url[0]|0x20) - 'a' + 10;
				if(is_digit(url[1]))
					ch = (ch<<4) + url[1] - '0';
				else
					ch = (ch<<4) + (url[1]|0x20) - 'a' + 10;
				url += 2;
			}
		}
		if(ch=='/') {
			/* p always > filename & started with '/' */
			if(p[-1]=='/') {
				/* // */
				p--;
			} else if(p[-1]=='.') {
				if(p[-2]=='/') {
					/* /./ */
					p -= 2;
				} else if(p[-2]=='.' && p[-3]=='/') {
					/* /../ */
					p -= 3;
					if(p > filename)
						while(*--p != '/')
							/* NULL */;
				}
			}
		}
		*p++ = ch;
	}
	if(p[-1]=='.'){
		/* /. */
		if(p[-2]=='/')
			p--;
		else if(p[-2]=='.' && p[-3]=='/') {
			/* /.. */
			p -= 3;
			if(p > filename)
				while(--p > filename && *p != '/')
					/* NULL */;
			p++;
		}
	}

	if(p[-1]=='/' && e-p >= 10) {
        // ***BEGIN*** Added by yijian on 2007-11-09
        int index_len;
        char index[DIRINDEX_MAX+1];
        index_len = get_dir_index(vhostname, urlp, index, sizeof(index)-1);
        if (0 == index_len) {
            strncpy(index, "index.html", DIRINDEX_MAX);	
            index_len = sizeof("index.html")-1;
        }
        memcpy(p, index, index_len+1); // include a terminated character
        //memcpy(p, "index.html", sizeof("index.html"));
        // ***END*** Added by yijian on 2007-11-09
    } else {    
		*p = '\0';
    }

	return 0;
}

int get_pure_dir(const char* dir, size_t dir_len, char* pure_dir)
{
    size_t i = 0;
    if ('/' == dir[dir_len-1]) {
        strcpy(pure_dir, dir);
        return dir_len;
    }
    for (i=1; i<dir_len; ++i) {
        if (('?' == dir[i]) && ('/' == dir[i-1])) {
            strncpy(pure_dir, dir, i);
            pure_dir[i] = 0;
            return i;
        }
    }

    return 0;
}

// ***BEGIN*** Added by yijian on 2007-11-09
int get_dir_index(const char *vhostname, const char* dir, char* index, size_t len)
{    
    struct stat st;
    size_t dir_len;
    size_t pure_dir_len;
    char *indexp;
    const char *dirindexp = dirindex;
    char pure_dir[DIRINDEX_MAX+1];
    char index_filename[DIRINDEX_FILENAME_MAX+1];
    
    //lprintf("directory indexs is %s.", dirindex);
    //lprintf("directory root is %s.", docroot);
    //lprintf("directory is %s.", dir);

    indexp = index;
    dir_len = strlen(dir);
    //if (dir[dir_len-1] != '/') return 0;
    pure_dir_len = get_pure_dir(dir, dir_len, pure_dir);
    if (0 == pure_dir_len) return 0;        
    
    do
    {        
        if ((0 == *dirindexp) || (',' == *dirindexp)) {
            *indexp = 0;
            if ((1 == use_vhost) || (1 == relay_mode)) {
                snprintf(index_filename, sizeof(index_filename)-1, "%s%s%s", vhostname, pure_dir, index);
            }
            else {            
                //snprintf(index_filename, sizeof(index_filename)-1, "%s%s%s", docroot, dir, index);
                snprintf(index_filename, sizeof(index_filename)-1, "%s%s", pure_dir, index);
            }
            if (0 == stat(index_filename, &st)) {
                if (S_ISREG(st.st_mode)) {
                    //lprintf("the directory index file is %s.", index_filename);
                    return (indexp - index);
                }
            }

            //lprintf("the directory index file %s not exist: %s.", index_filename, strerror(errno));
            if (0 == *dirindexp) break;

            ++dirindexp;
            indexp = index;
        }
        else {
            *indexp = *dirindexp;
            ++indexp;
            ++dirindexp;
        }
    } while(indexp-index <= len); 

    return 0;
}
// ***END*** Added by yijian on 2007-11-09

void init_callback_data(struct conn *c, cbdata_t *cbdp) {
#if THROTTLE_SUPPORT
	cbdp->speed = default_speed;
#else
	cbdp->speed = 0;
#endif
	cbdp->expire = c->expire;
	cbdp->mtime = 0;
	cbdp->offset = 0;
	cbdp->addr = fdinfo[c->netfd].addr;
	cbdp->tid = c->thread->id;
	cbdp->host = c->urloverwriten ? NULL : c->host;
	cbdp->url = c->urloverwriten ? NULL : c->url;
	cbdp->entity = NULL;
#if COOKIE_SUPPORT
	if(c->header_parsed && !cookie_in_sendbuf)
		cbdp->cookie = c->cookie;
	else
		cbdp->cookie = NULL;
#else
	cbdp->cookie = NULL;
#endif
	cbdp->priv = NULL;
	cbdp->mime = NULL;
	cbdp->method = c->method;
	cbdp->has_ims = c->imstime && c->ims==IMS;
	cbdp->has_iums = c->imstime && c->ims==IUMS;
	cbdp->has_ir = c->imstime && c->ims==IR;
	cbdp->reason = 0;
	cbdp->ftarget = NULL;
	cbdp->buf = c->thread->workbuf;
	cbdp->buflen = workbufsz;
	cbdp->datalen = 0;
#if RELAY_SUPPORT
	cbdp->retry = c->relaymode ? c->relay_retry : 0;
#else
	cbdp->retry = 0;
#endif

	if(entity_access_method==0) {
		cbdp->buf += docrootlen;
		cbdp->buflen -= docrootlen;
	}
	if(c->header_parsed==0 && use_vhost==1) {
		cbdp->dirlen = strlen(c->vhost->name) + 1;
		cbdp->buf[0] = '/';
		memcpy(cbdp->buf+1, c->vhost->name, cbdp->dirlen);
		cbdp->buf[cbdp->dirlen] = '/';
		cbdp->buf[cbdp->dirlen+1] = '\0';
	} else {
		cbdp->dirlen = 0;
		*(uint16_t *)cbdp->buf = *(uint16_t *)"/";
	}
}

# if PLUGIN_SUPPORT
int call_plugin_list(struct conn *c, struct vhost *vhost, cbdata_t *cbdp) {
	struct filtercb *f;
	int rv;

	memset(cbdp, 0, sizeof(cbdata_t));
#if THROTTLE_SUPPORT
	cbdp->speed = default_speed;
#else
	cbdp->speed = 0;
#endif

	cbdp->expire = c->expire;
	for(f=vhost->plugin, rv=0; rv==0 && f!=NULL; f=f->next) {
		cbdp->mtime = 0;
		cbdp->offset = 0;
		cbdp->addr = fdinfo[c->netfd].addr;
		cbdp->tid = c->thread->id;
		cbdp->host = c->host;
		cbdp->url = c->url;
		cbdp->entity = NULL;
#if COOKIE_SUPPORT
		if(c->header_parsed)
			cbdp->cookie = c->cookie;
		else
			cbdp->cookie = NULL;
#else
		cbdp->cookie = NULL;
#endif
		cbdp->priv = f->priv;
		cbdp->mime = NULL;
		cbdp->method = c->method;
		cbdp->has_ims = c->imstime && c->ims==IMS;
		cbdp->has_iums = c->imstime && c->ims==IUMS;
		cbdp->has_ir = c->imstime && c->ims==IR;
		cbdp->reason = 0;

		cbdp->buf = c->thread->workbuf;
		cbdp->buflen = workbufsz;
		cbdp->datalen = 0;

		if(c->header_parsed==0 && use_vhost==1) {
			cbdp->dirlen = strlen(c->vhost->name) + 1;
			cbdp->buf[0] = '/';
			memcpy(cbdp->buf+1, c->vhost->name, cbdp->dirlen);
			cbdp->buf[cbdp->dirlen] = '/';
			cbdp->buf[cbdp->dirlen+1] = '\0';
		} else {
			cbdp->dirlen = 0;
			*(uint16_t *)cbdp->buf = *(uint16_t *)"/";
		}

		rv = f->func(cbdp);
		if((rv & 0x3FFFFFFF)){
			return rv;
		}
	}
	return 0;
}
#endif

int get_compress_order(struct conn *c, char *filename, size_t filename_len) {
    if (compress_order < 3) return compress_order;
    
    int i;
    for (i=0; i<compress_first_array->count; ++i) {
        size_t type_len = strlen(compress_first_array->type[i]);
        if (filename_len > type_len) {        
            if ('.' == *(filename+filename_len-type_len-1)) {
                if (!strcmp(filename+filename_len-type_len, compress_first_array->type[i])) {                    
                    return 1;
                }
            }
        }
    }
    return 0;
}

void http_response_pathname(struct conn *c, char *filename) {
	static void * const entjump[] = {
		&&ent_200, &&ent_404, &&ent_301, &&ent_503, &&ent_500
	};
	int rv;
    int state;
    int filename_len;
    int compress_first;
	
    state = 0;        
    filename_len = strlen(filename);
    compress_first = get_compress_order(c, filename, filename_len);
        
GET_AGAIN:   
    if (1 == compress_first) {
        if ((0 == state) && (0x0001 == (c->compress_arithmetic & 0x00ff))) {
            strcpy(filename+filename_len, ".gzip");
            state = 1;
        }
        else if ((state < 2) && (0x0100 == (c->compress_arithmetic & 0xff00))) {
            strcpy(filename+filename_len, ".deflate");
            state = 2;
        }
        else {
            state = 3;
        }
    }

    PROFILE_START;
	rv = get_entity_internal(c->thread, filename, &c->entity);    
	PROFILE_CONN(PROFILE_GET_ENTITY);
    if (-1 == rv) {
        if (1 == compress_first) {
            if (state < 2) goto GET_AGAIN;
        }
        else if (2 == compress_first) {
            //filename_len = (0 == filename_len) ? strlen(filename) : filename_len;
            if ((0 == state) && (0x0001 == (c->compress_arithmetic & 0x00ff))) {
                strcpy(filename+filename_len, ".gzip");
                state = 1;
                goto GET_AGAIN;
            }
            if ((state < 2) && (0x0100 == (c->compress_arithmetic & 0xff00))) {
                strcpy(filename+filename_len, ".deflate");
                state = 2;
                goto GET_AGAIN;
            }
        }
    }
	else if(rv > 0 || rv < -3) {        
		lprintf("get_entity_internal() return invalid value %d\n", rv);
		rv = -4;
	}
    else if (0 == rv) {
        if (1 == state)
            c->compress_flag = 1;
        else if (2 == state)
            c->compress_flag = 2;
        else
            c->compress_flag = 0;
    }
	goto *entjump[-rv];

ent_200: 
	http_response(c);
	return;
ent_404:
    //lprintf("%s:%d open %s error: %s", __FILE__, __LINE__, filename, strerror(errno));
    if (need_relay(c->url))
        c->need_relay = 1;
    else
	    http_error(c, 404, c->url);
	return;
ent_301:
	http_redirect_directory(c);
	return;
ent_503:
	http_error(c, 503, c->url);
	return;
ent_500:
	http_error(c, 500, c->url);
	return;
}

void http_response_url(struct conn *c, char *url) {
	char * filename;        
	int plen = entity_access_method ? 0 : docrootlen;

	filename = c->thread->workbuf + plen;
	if(use_vhost==1) {
		if(c->vhost==NULL)
			c->vhost = default_vhost();
		filename[0] = '/';
		filename = stpcpy(filename+1, c->vhost->name);
	}

    if (1 == relay_mode)
        decode_url(c->host, url, filename, 4096-maxhostlen-plen);
	else
        decode_url(c->vhost->name, url, filename, 4096-maxhostlen-plen);
    if (need_relay(url)) {      
        char fullname[PATH_MAX+1] = {0};
        snprintf(fullname, PATH_MAX, "/%s%s", c->host, filename);            
        http_response_pathname(c, fullname);
    }
    else {
        http_response_pathname(c, c->thread->workbuf+plen);
    }    
}

int process_request(struct conn *c) {

	if(c->vhost==NULL) {
		switch(use_vhost) {
			case 0: c->vhost = vhostdef; break;
			case 1: resolv_vhost(c); break;
			case 2: resolv_first_directory(c); break;
		}
		atomic_inc(&c->vhost->req);
	}



	c->expire = PTR2INT(match_url_pattern(pat_expire, c->url,
				INT2PTR(timeout_expire)));

	if(relay_mode == 0)
	{
		int rv;
		struct forward_target *t=NULL;

		rv = relay_cgi(c,t);
		if(RF_FORWARD_TARGET == rv)
		{
			if(construct_http_header(c, c->url)<0) { 
				http_error(c, 500, c->url); 
				return 0; 
			} 
            c->ftarget = c->ftarget_old;
			forward_connection(c,c->ftarget,rv);
			return c->netfd <= 0 || c->relaymode || c->state == 0;
		}
	}

#ifdef PLUGIN_SUPPORT
	if(c->vhost->plugin) {

		struct callback_data cp[1];

		int rv;


		PROFILE_START;

		rv = call_plugin_list(c, c->vhost, cp);
		PROFILE_CONN(PROFILE_PLUGIN);

#ifdef FORWARD_PROCESS
#undef FORWARD_PROCESS
#endif

#define FORWARD_PROCESS \
		if(construct_http_header(c, cp->url)<0) { \
			http_error(c, 500, c->url); \
			return 0; \
		} \
		forward_connection(c, cp->ftarget, rv); \
		return c->netfd <= 0 || c->relaymode || c->state==0;

#include "callback.c"

	}
#endif

	http_response_url(c, c->url);
    return (1 == c->need_relay) ? 110 : 0;
}

#ifdef PLUGIN_SUPPORT
	int try_relay_connection(struct conn *c, char *trailer, int tlen) {
		if(vhostpre->plugin==0)
			return -1;

		int rv;
		struct callback_data cp[1];

		PROFILE_START;
		rv = call_plugin_list(c, vhostpre, cp);
		PROFILE_CONN(PROFILE_PLUGIN);

#define FORWARD_PROCESS	\
		c->vhost = default_vhost(); \
        c->target = c->ftarget_old; \
        c->ftarget = c->ftarget_old; \
        if (construct_http_header(c, cp->url)<0) { \
			http_error(c, 500, cp->url); \
			return 0; \
        } \
		forward_connection(c, cp->ftarget, rv); \
		return c->netfd <= 0 || c->relaymode || c->state==0;
#include "callback.c"
		return -1;
	}
#endif
