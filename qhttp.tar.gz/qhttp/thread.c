/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <alloca.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <string.h>
#include <sys/wait.h>
#include <sched.h>
#include <pthread.h>
#include <dlfcn.h>
#include <features.h>
#include "compat_thread.h"
#include "compat_rlimit.h"
#include "compat_futex.h"

#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "thread.h"
#include "priv.h"
#include "log.h"
#include "daemon.h"
#include "fault.h"
#include "lock.h"
#include "log.h"
#include "sysctl.h"
#include "task.h"
#include "shmem.h"
#include "util.h"
#include "entity.h"
#include "watchdog.h"

int threadmode __init__;
static int curid = 0;
static int maxid;
struct thread mainthread;
static struct thread **threadlist __init__;
#if USE_TLS
__thread int mythreadid __attribute__((TLS_MODEL));
#else
static pthread_key_t mythreadkey;
#endif

int threads_max __init__ = -1;
int sys_threads_max __init__ = -1;
unsigned long mainstack __init__;
int main_stack_size __init__ = 0x800000;
int stack_block_size __init__ = 0x10000;
int thread_stack_min __init__ = 16384;
#define stack_block_mask (~(stack_block_size-1))
#define stack_size_mask (stack_block_size-1)
#define stack_info_offset (stack_block_size-sizeof(struct thread))
int stack_guard_size __init__ = 4096;
static int stack_in_shmem __init__ = 0;
static int stack_prot __init__ = 0;
int stack_used = 0;

#if COMPAT_GLIBC && !__x86_64__
static int (*fn_pthread_attr_setstack)(pthread_attr_t *, void *, size_t) __init__;
static int (*fn_pthread_attr_setstackaddr)(pthread_attr_t *, void *) __init__;
#endif

static struct thread **freethreads;
static int totalfree;

atomic_t sparse_workers;
atomic_t startup_workers;
int min_sparse = 100;
int max_sparse = 500;

int register_thread(const char *name, int (*entry)(void *),void *arg) {
	struct thread *th;
	char *stack = NULL;
    lprintf("register thread named %s", name);

	if(stack_in_shmem) {
	    stack = shalign(stack_block_size, 32);
	    if(stack==NULL) return -ENOMEM;
	} else {
#if DBEUG_MALLOC
	    stack = mmap(NULL, stack_block_size+8192, stack_prot, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
	    if(BADADDR(stack)) return -ENOMEM;
	    mprotect(stack, stack_guard_size+4096, PROT_NONE);
	    stack += 4096;
	    mprotect(stack+stack_block_size, 4096, PROT_NONE);
#else
	    stack = mmap(NULL, stack_block_size, stack_prot, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
	    if(BADADDR(stack)) return -ENOMEM;
	    if(stack_guard_size)
		mprotect(stack, stack_guard_size, PROT_NONE);
#endif
	}

	if(curid >= maxid) {
	    lprintf("%s: Too many thread registered\n", name);
	    return -1;
	}

	th = shalloc(sizeof(struct thread));
	if(th==NULL) return -ENOMEM;
	threadlist[curid++] = th;

	strncpy(th->name, name, 15);
	th->name[15] = '\0';
	th->entry = entry;
	th->arg = arg;
	th->id = curid;
	th->pid = 0;
	th->tid = 0;
	th->rv = -1;
	th->state = THREAD_STOPPING;
	th->stack = stack;
	return 0;
}

static int thread_entry(struct thread *th) {
#if USE_TLS
	mythreadid = th->id;
#else
	pthread_setspecific(mythreadkey, th);
#endif
	th->pid = fast_gettid();
	th->state = THREAD_RUNNING;
	set_security_role(ROLE_GUEST);
	if(has_unshare > 0)
	    fast_unshare(CLONE_FS);
	th->rv = th->entry(th->arg);
	th->state = THREAD_EXITED;
	pthread_exit(INT2PTR(th->rv));
	return th->rv;
}

const char *thread_name(int pid) {
	int i;
	if(pid==0)
		pid = fast_gettid();
	for(i=0; i<curid; i++) {
		if(threadlist[i]->pid == pid)
			return threadlist[i]->name;
	}
	return NULL;
}

struct thread *get_thread_by_pid(int pid) {
	int i;

	if(pid==0) pid = fast_gettid();
	if(threadlist==NULL)
		return &mainthread;
	for(i=0; i<curid; i++) {
		if(threadlist[i]->pid == pid)
			return threadlist[i];
	}
	return NULL;
}

#if USE_TLS
inline struct thread *get_my_thread(void) {
	return mythreadid==0 ? &mainthread : threadlist[mythreadid];
}

#else
inline struct thread *get_my_thread(void) {
	struct thread *th = pthread_getspecific(mythreadkey);
	return th ? : &mainthread;
}

int get_thread_id(void) {
	struct thread *th = get_my_thread();
	return th->id;
}
#endif


int rand(void){
	struct thread *th = get_my_thread();
	return rand_r(&th->seed);
}

void srand(unsigned int seed){
	struct thread *th = get_my_thread();
	th->seed = seed + th->tid;
}

int allocate_rtsig(int index) {
	int (*fn_allocate_rtsig)(int) = NULL;
#if !LINK_AS_STATIC
	fn_allocate_rtsig = dlsym(RTLD_DEFAULT, "__libc_allocate_rtsig");
#endif
	return fn_allocate_rtsig ? fn_allocate_rtsig(1) : SIGRTMIN+4+index;
}

static int start_thread_posix(struct thread *th) {
    	pthread_attr_t attr;
    	pthread_t tid;
	int rc;

	th->rv = -1;

	pthread_attr_init(&attr);
#if COMPAT_GLIBC && !__x86_64__
	if(fn_pthread_attr_setstack) {
	    fn_pthread_attr_setstack(&attr, th->stack, stack_block_size);
	} else {
	    pthread_attr_setstacksize(&attr, stack_block_size);
	    fn_pthread_attr_setstackaddr(&attr, th->stack+stack_block_size);
	}
#else
	pthread_attr_setstack(&attr, th->stack, stack_block_size);
#endif
	if((rc=pthread_create(&tid, &attr, (void*(*)(void*))thread_entry, th)) != 0)
	{
	    errno = rc;
	    lprintf("\7%s: pthread_create(): %m\n", th->name);
	    return -1;
	}
	th->tid = tid;
	return 0;
}

static void wait_thread_posix(struct thread *th) {
	void *addr = NULL;
	pthread_join(th->tid, &addr);
}

#if COMPAT_GLIBC
static inline void *nextsym(const char *name, const char *ver, int check) {
	void *addr = NULL;
	if(ver)
	    addr = dlvsym(RTLD_NEXT, name, ver);
	else
	    addr = dlsym(RTLD_NEXT, name);
	if(addr==NULL) {
		if(check) {
		    if(ver)
		    lprintf("Unsupported glibc: Symbol '%s' version %s not found\n", name, ver); 
		    else
		    lprintf("Unsupported glibc: Symbol '%s' not found\n", name); 
		    fast_exit(0);
		}
	}
	return addr;
}
#endif

static int shift_round(int val) {
	int m;
	if((val&(val-1))==0)
		return val;

	for(m=1; val; val>>=1, m<<=1)
	{ }
	return m;
}

int init_thread_mode(void) {
	char *p = myconfig_get_value("thread_mode");

	threadmode = CLONE_FILES | CLONE_VM | CLONE_FS | CLONE_SIGHAND;

	sys_threads_max = sysctl_get_value("/proc/sys/kernel/threads-max", 0);

	threads_max = sysconf(_SC_THREAD_THREADS_MAX);

#ifndef _CS_GNU_LIBPTHREAD_VERSION
#define _CS_GNU_LIBPTHREAD_VERSION 3
#endif
	int n = confstr(_CS_GNU_LIBPTHREAD_VERSION, NULL, 0);
	if(n > 0) {
	    p = alloca(n);
	    confstr (_CS_GNU_LIBPTHREAD_VERSION, p, n);
	    if(strstr(p, "NPTL"))
		threadmode |= CLONE_THREAD;
	    else if(!strstr(p, "linuxthread")) {
		lprintf("Unsupported thread library: %s\n", p);
		fast_exit(0);
	    }
	}

#if !LINK_AS_STATIC
	/* force loading libgcc_s.so in NPTL mode */
	if((threadmode & CLONE_THREAD))
	    dlopen("libgcc_s.so.1", RTLD_NOW|RTLD_GLOBAL);
#endif

	thread_stack_min = sysconf(_SC_THREAD_STACK_MIN);
	if(thread_stack_min <= 0)
	    thread_stack_min = 16384;

#if COMPAT_GLIBC && !__x86_64__
	fn_pthread_attr_setstack = nextsym("pthread_attr_setstack", "GLIBC_2_3_3", 0);
	if(fn_pthread_attr_setstack==NULL)
	    fn_pthread_attr_setstack = nextsym("pthread_attr_setstack", "GLIBC_2.2", 0);
	if(fn_pthread_attr_setstack==NULL)
	    fn_pthread_attr_setstackaddr = nextsym("pthread_attr_setstackaddr", "GLIBC_2.1", 1);
#endif

	strcpy(mainthread.name, "main");
	mainthread.state = THREAD_RUNNING;

	lprintf("pthread interface: %s\n",
		(threadmode&CLONE_THREAD) ? "NPTL" : "linuxthread");

	mainthread.pid = fast_gettid();

#if USE_TLS
	mythreadid = 0;
#else
	pthread_key_create(&mythreadkey, NULL);
	pthread_setspecific(mythreadkey, &mainthread);
#endif
	return 0;
}

int init_thread_stack(void) {
	struct rlimit rl;
	unsigned int cur;
	memset(&rl, 0, sizeof(rl));
	fast_getrlimit(RLIMIT_STACK, &rl);

	/* determine main stack size */
	main_stack_size = myconfig_get_intval("main_stack_size", 0);
	if(main_stack_size == 0)
	    main_stack_size = rl.rlim_cur;
	main_stack_size = shift_round(main_stack_size);
	cur = (unsigned long)&rl;
	mainstack = cur & ~(main_stack_size-1);
	if(cur-mainstack < main_stack_size/2) {
	    main_stack_size <<= 1;
	    mainstack = cur & ~(main_stack_size-1);
	}
	if(main_stack_size == 0)
	    main_stack_size = (8 << 20);
	if(main_stack_size > rl.rlim_cur) {
	    rl.rlim_cur = main_stack_size;
	    rl.rlim_max = main_stack_size;
	    if(fast_setrlimit(RLIMIT_STACK, &rl)<0) {
		lprintf("Cannot increase main stack size to %d%s\n",
			main_stack_size, pretty(main_stack_size));
		fast_exit(0);
	    }
	}

	if(!has_plugin && !developer) {
	    stack_guard_size = 0;
	    stack_block_size = 16384;
	} else {
	    stack_guard_size = myconfig_get_intval("stack_guard_size", 4096);
	    stack_guard_size = shift_round(stack_guard_size);
	    stack_block_size = myconfig_get_intval("thread_stack_size", 65536);
	}
	cur = stack_block_size - stack_guard_size;
	if(cur < 8192+path_max*2) {
		stack_block_size = 8192+path_max*2+stack_guard_size;
		cur = 8192+path_max*2;
	}
	if(entity_access_method==0 && cur < 8192+path_max*4) {
		stack_block_size = 8192+path_max*4+stack_guard_size;
	}
	if(stack_block_size < thread_stack_min)
	    stack_block_size = thread_stack_min;
	stack_block_size = shift_round(stack_block_size);
	if(stack_block_size <= stack_guard_size)
	    stack_block_size = stack_guard_size * 2;
#if !COMPAT_GLIBC
	if(stack_block_size - stack_guard_size <= 4096)
	    stack_block_size *= 2;
#endif

	if(stack_guard_size)
	mmap((void *)mainstack, stack_guard_size,
		PROT_NONE, MAP_PRIVATE|MAP_ANONYMOUS|MAP_FIXED, -1, 0);

	stack_prot = myconfig_get_intval("executable_stack", 0) ? PROT_READ|PROT_WRITE|PROT_EXEC : PROT_READ|PROT_WRITE;
#if !DEBUG_MALLOC
	if(stack_guard_size==0 && (stack_prot&PROT_EXEC)==0) {
	    stack_in_shmem = 1;
	    SHMEM_NEEDED(nworks, stack_block_size);
	    if(direct_accept==0) SHMEM_NEEDED(1, stack_block_size);
	}
#endif
	SHMEM_NEEDED(nworks+16, sizeof(struct thread *));
	SHMEM_NEEDED(nworks+16, sizeof(struct thread));

	if(verbose) {
	    lprintf("Main  stack  size: %d%s\n", main_stack_size, pretty(main_stack_size));
	    lprintf("Thread stack size: %d%s\n", stack_block_size, pretty(stack_block_size));
	    lprintf("Stack guard  size: %d%s\n", stack_guard_size, pretty(stack_guard_size));
	}
	return 0;
}

int init_thread_data(void) {
	maxid = nworks + 16;
	threadlist = shalloc(maxid * sizeof(struct threadlist *));
	if(threadlist==NULL) return -ENOMEM;
	threadlist[curid++] = &mainthread;
	return 0;
}

void check_dynamic_workers(void) {
	int i;
	cprintf("WORKERS: SPARSE %d STARTING %d\n",
		atomic_read(&sparse_workers),
		atomic_read(&startup_workers)
	       );
	for(i=1; i<=nworks; i++) {
	    if(threadlist[i]->state == THREAD_STOPPED)
	    {
		wait_thread_posix(threadlist[i]);
		threadlist[i]->state = THREAD_STANDBY;
		freethreads[totalfree++] = threadlist[i];
		if(totalfree > nworks) {
		    cprintf("WARNING: FREETHREADS OVERFLOW\n");
		}
	    }
	}
	for(i=0; i<100 &&
		atomic_read(&sparse_workers) + atomic_read(&startup_workers) < min_sparse &&
		totalfree > 0; i++)
	{
	    struct thread *th = freethreads[--totalfree];
	    th->state = THREAD_STARTING;
	    atomic_inc(&startup_workers);
	    if(start_thread_posix(th) < 0) {
		atomic_dec(&startup_workers);
		th->state = THREAD_STANDBY;
		freethreads[totalfree++] = th;
		break;
	    }
	}
}

int start_work_threads(struct threadstat *thst) {
	int i;
	int n = 0;

	if(nconns==1) {
		freethreads = shalloc(sizeof(void *)*nworks);
		totalfree = nworks;
		for(i=0; i<nworks; i++) {
			freethreads[i] = threadlist[nworks-i];
			freethreads[i]->state = THREAD_STANDBY;
		}
	}
	for(i= nconns==1?mconns+1:1; i<curid; i++) {
		threadlist[i]->state = THREAD_STARTING;
		thread_reached(thst);
		if(start_thread_posix(threadlist[i])<0) {
		    lprintf("\7ERROR: Some threads cannot start, Exitting\n");
		    fast_exit_group(-1);
		    fast_exit(-1);
		    return -ENOMEM;
		}
		n++;
	}
	if(nconns==1)
	    check_dynamic_workers();
	if(verbose) cprintf("Started   Threads: %d%s\n", n, pretty(n));
	return 0;
}

void stop_threads(struct threadstat *thst) {
	int i;
	long prev=0, next=0;
	int v=stack_block_size;
	const int free_stack = 0; // free stack cause many problem

	for(i=1; i<curid; i++) {
	    if(threadlist[i]->state==THREAD_RUNNING) {
		thread_reached(thst);
		pthread_kill(threadlist[i]->tid, SIGALRM);
	    }
	}

	for(i=1; i<curid; i++) {
		thread_reached(thst);
		if(threadlist[i]->state==THREAD_RUNNING)
		    threadlist[i]->state = THREAD_STOPPING;
		if(threadlist[i]->state!=THREAD_UNUSED && threadlist[i]->state!=THREAD_STANDBY)
		    wait_thread_posix(threadlist[i]);
		threadlist[i]->state = THREAD_UNUSED;
	}
	for(i=1; i<curid; i++) {
		long cur = (long)threadlist[i]->stack;
		if(developer || verbose) {
			int j;
			for(j=stack_guard_size; j<stack_block_size; j+=sizeof(long)) {
				if(*(long *)(cur+j))
					break;
			}
			if(j < v) v = j;
		}
		if(cur==prev) {
			prev -= stack_block_size;
		} else if(cur==next) {
			next += stack_block_size;
		} else {
		    if(next-prev >= 2*stack_block_size) {
		        prev += stack_block_size;
			if(free_stack)
			    munmap((void *)prev, next-prev);
		    }
		    prev = cur - stack_block_size;
		    next = cur + stack_block_size;
		}
	}
	if(next-prev >= 2*stack_block_size) {
	    prev += stack_block_size;
	    if(free_stack)
		munmap((void *)prev, next-prev);
	}
	stack_used = stack_block_size - v;
	if(verbose)
	    lprintf("Thread stack used: %d, free %d\n", stack_used, v-stack_guard_size);
	if(stack_guard_size)
	    munmap((void *)mainstack, stack_guard_size);
	curid = 1;
}

void check_stack_usage(void) {
	int i, j;
	int v=stack_block_size;
	long cur;

	for(i=1; i<curid; i++) {
		if(threadlist[i]==NULL) continue;
		cur = (long)threadlist[i]->stack;
		for(j=stack_guard_size; j<stack_block_size; j+=sizeof(long)) {
		    if(*(long *)(cur+j))
			break;
		}
		if(j < v) v = j;
	}
	stack_used = stack_block_size - v;
	lprintf("Thread stack used: %d, free %d\n", stack_block_size-v, v-stack_guard_size);
}

void thread_jumbo_title(void) {
    return; // Added by yijian on 2007-11-06
    	char *title = alloca(40+(curid-nworks)*17);
	char *p;
	int i;

	p = stpcpy(title, "tws_http: main");
	if((threadmode & CLONE_THREAD)==0) {
	    p = stpcpy(p, ",tm");
	}
	if(curid > 1) {
	    *p++ = ',';
	    p = stpcpy(p, threadlist[1]->name);
	}
	if(curid > nworks && nworks > 1) {
	    *p++ = '-';
	    p = uint2str(p, nworks-1);
	}
	for(i=nworks+1; i<curid; i++) {
	    if(threadlist[i]==NULL) continue;
	    *p++ = ',';
	    p = stpcpy(p, threadlist[i]->name);
	}
	daemon_set_title(title);
}

void enomem(void) {
	fast_write(1, "\n\033[31m\033[1mNO ENOUGH MEMORY\033[0m\n", 31);
	fast_exit(ENOMEM);
	_exit(ENOMEM);
}

