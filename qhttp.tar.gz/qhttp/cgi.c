#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "qhttpd_api.h"
#include "relay.h"
#include "util.h"
#include "malloc.h"
#include "conn.h"
extern const char *dirindex;

#define FORWARDMAP_MAX 48

struct forwardmap{
	char vhost[128];	
	char upath[128];
    char prefix[128];
    int prefix_len;
};

static struct forwardmap mp[FORWARDMAP_MAX];
extern int get_dir_index(const char *vhostname, const char* dir, char* index, size_t len);

int relay_check(struct conn *c)
{

	int i;
	for(i=0;i<FORWARDMAP_MAX;i++){
		if(mp[i].vhost[0] == '\0'){
			return 0;
		}

		if(strcmp(mp[i].vhost,c->host) == 0 && strncmp(mp[i].prefix,c->url,mp[i].prefix_len)==0){
			return 1;
		}

	}
	return 0;
}

int is_shtml(struct conn *c)
{
    char* url= c->url;
	size_t len = strlen(url);

    if ('/' == url[len-1]) {
        int index_len;
        char index[DIRINDEX_MAX+1];
        if (need_relay(c->url))
            index_len = get_dir_index(c->host, c->url, index, sizeof(index)-1);
        else
            index_len = get_dir_index(c->vhost->name, c->url, index, sizeof(index)-1);
        return (0 == index_len) ? 1 : 0;
    }
	
	if( strcmp( url, "/" ) == 0 )
	{
		const char* urlp = dirindex + strlen(dirindex) -sizeof(".shtml") + 1;    //����directory_indexΪ.shtmlʱ����ʱ�����������ֻ������һ��index����û�пո�����
		if(strncmp( urlp, ".shtml", sizeof(".shtml") ) == 0 )
			return 1;
	}

	if (len <= sizeof(".shtml")) return 0;

	const char* urlp = url+len+1-sizeof(".shtml");
	if(strncmp( urlp, ".shtml", sizeof(".shtml") ) == 0 )
		return 1;

	return 0;
}

int relay_cgi(struct conn *c,struct forward_target *g) 
{

	int i;
	for(i=0;i<FORWARDMAP_MAX;i++){
		if(mp[i].vhost[0] == '\0'){
			return RC_CONTINUE;
		}

		//if(strcmp(mp[i].vhost,c->host) == 0 && strncmp(mp[i].prefix,c->url,strlen(mp[i].prefix))==0){
        if ( ((strncmp(mp[i].prefix,c->url,mp[i].prefix_len)==0) || (is_shtml(c)))
			&& (strcmp(mp[i].vhost,c->host) == 0)) {
			//g=malloc(sizeof(struct forward_target));
            g = c->ftarget_old;
			if(g == NULL)
				return RC_CONTINUE;
			g->port = 0;
			//g->addr = str2ip(UNIX_DOMAIN_IP,NULL);
            g->addr = UNIX_DOMAIN_IP;
			g->upath=mp[i].upath;
#if PLUGIN_SUPPORT
			c->ftarget = g;
#endif
			return RF_FORWARD_TARGET;
		}
	}

	return RC_CONTINUE;
}

void init_cgi_vhost()
{
	int i, j, n;
	const char *s;
	char key[128];
	char upath[128];
	char *delim=";";

	n = 0;

	memset(mp,0,sizeof(mp));
	for(i=0; n<FORWARDMAP_MAX && i < FORWARDMAP_MAX ; i++) {

		memset(key,0,sizeof(key));
		memset(upath,0,sizeof(upath));
		sprintf(key,"group%d_unix_sock_file",i);
		s=myconfig_get_value(key);
		if(s!=NULL){
			memcpy(upath,s,strlen(s));
		}else{
			break;
		}

		memset(key,0,sizeof(key));
		sprintf(key,"group%d_cgi_map",i);

		for(j = 0; n < FORWARDMAP_MAX && (s=myconfig_get_multivalue(key, j));j++){
			s=strtok((char *)s,delim);
			if(s != NULL){
				memcpy(mp[n].vhost,s,strlen(s));
			}
			s=strtok(NULL,delim);
			if(s != NULL){
                mp[n].prefix_len = strlen(s);
				memcpy(mp[n].prefix,s,strlen(s));
			}
			memcpy(mp[n].upath,upath,strlen(upath));
			n++;
		}
	}
}

