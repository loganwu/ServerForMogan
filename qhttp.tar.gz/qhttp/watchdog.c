#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#if !INLINE_SYSCALL
#include <string.h>
#include <sys/shm.h>
#endif // INLINE_SYSCALL

#include "autoconfig.h"
#include "compat_sysvipc.h"
#include "compat_thread.h"
#include "filemon.h"
#include "myconfig.h"
#include "daemon.h"
#include "thread.h"
#include "log.h"
#include "global.h"
#include "help.h"
#include "watchdog.h"

struct threadmap {
	int mthreads;
	int nthreads;
	int semkey;
	int semkey2;
	struct threadstat threadlist[0];
};

static struct threadmap *threadmap;
static int deadlock_count = 1;
static int use_tkill;
int watchdog_pid __init__;

struct threadstat *get_threadstat(void) {
	if(threadmap==NULL) return NULL;
	int id = get_thread_id();
	if(id >= threadmap->mthreads) return NULL;
	if(id >= threadmap->nthreads) threadmap->nthreads = id+1;
	struct threadstat *ts = threadmap->threadlist+id;
	ts->badcnt = 0;
	atomic_set(&ts->tickcnt, 1);
	ts->tid = fast_gettid();
	return ts;
}

static void init_threadmap(void) {
	threadmap = mmap(NULL, 16<<10,
		PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANONYMOUS, -1, 0);
	if(threadmap==MAP_FAILED)
		threadmap = NULL;
	else {
		threadmap->mthreads = ((16<<10)-sizeof(struct threadmap))
					/ sizeof(struct threadstat);
		threadmap->nthreads = 0;
		deadlock_count = myconfig_get_intval("deadlock_timeout", 60);
		deadlock_count = MAX(MIN(deadlock_count, 3600), 10);
		deadlock_count = (deadlock_count+9)/10 - 1;
		int pid = fast_getpid();
		use_tkill = fast_tkill(pid, 0) == 0;
	}
}

void send_semkey_to_watchdog(int key) {
	if(threadmap==NULL) return;
	if(threadmap->semkey==0)
		threadmap->semkey = key;
	else if(threadmap->semkey2==0)
		threadmap->semkey2 = key;
}

void remove_semkey_from_watchdog(int key) {
	if(threadmap==NULL) return;
	if(key == threadmap->semkey)
		threadmap->semkey = 0;
	else if(key == threadmap->semkey2)
		threadmap->semkey2 = 0;
}

static void check_threadmap(void) {
	if(threadmap==NULL) return;
	int i;
	for(i=0; i<threadmap->nthreads; i++) {
		const int tid = threadmap->threadlist[i].tid;
		if(tid==0) continue;
		const int cnt = atomic_read(&threadmap->threadlist[i].tickcnt);
		atomic_sub(cnt, &threadmap->threadlist[i].tickcnt);
		if(cnt) threadmap->threadlist[i].badcnt = 0;
		else if(threadmap->threadlist[i].badcnt >= deadlock_count) {
			threadmap->threadlist[i].badcnt++;
			cprintf("thread %d tid %d deadlocked\n", i, tid);
			if(use_tkill) fast_tkill(tid, SIGSEGV);
			else kill(tid, SIGSEGV);
			fast_nanosleep(&(const struct timespec){ .tv_sec = 1, .tv_nsec = 0 }, NULL);
			if(use_tkill) fast_tkill(tid, SIGKILL);
			else kill(tid, SIGKILL);
		} else {
			threadmap->threadlist[i].badcnt++;
		}
	}
}

static void handler10sec(int signo) {
	check_threadmap();
	alarm(10);
}

static int record_pid()
{
    char* pid_filename = NULL;    
    pid_filename = alloca(strlen(bindir)+sizeof("/bin/.http.pid")+3);
    sprintf(pid_filename, "%s/%s", bindir, ".http.pid");

    int nprnt = 0;        
    FILE* fp = fopen(pid_filename, "w+");
    if (NULL == fp) {
        lprintf("can't open %s", pid_filename);
        return -1;
    }

    lprintf("tws_http PID file is %s", pid_filename);
    nprnt = fprintf(fp, "%d", getpid());
    fclose(fp);
    return nprnt;
}

int start_watchdog(void) {
	int pid;
	int status = 0;

    if (record_pid() < 0) {
        return -1;
    }

	if(developer && myconfig_get_intval("disable_watchdog", 0))
	    return 0;

	init_threadmap();

	if((pid=fork())==-1) {
	    lprintf("fork(): %m\n");
	    return -1;
	}

	if(pid==0) {
	    watchdog_pid = fast_getppid();
	    mainthread.pid = fast_gettid();
	    return 0; /* main process */
	}

	init_filemon_watchdog();

	daemon_set_title("tws-watchdog");
	daemon_set_name("tws-watchdog");
	signal(SIGCHLD, SIG_DFL);
	signal(SIGSEGV, SIG_DFL);
	signal(SIGBUS, SIG_DFL);
	signal(SIGILL, SIG_DFL);
	signal(SIGFPE, SIG_DFL);
	signal(SIGABRT, SIG_DFL);
	daemon_close_output();

	signal(SIGALRM, handler10sec);
	alarm(10);
	while(waitpid(pid, &status, 0)!=pid) {
	    if(is_front()==0)
	    	stop = 1;
	    if(stop)
	    	kill(pid, SIGTERM);
	}

	if(status)
	    cprintf("main process exit status: %x\n", status);
	if(status && (WEXITSTATUS(status)!=255 || WIFSIGNALED(status)))
	    restart = 1;
	if(threadmap && threadmap->semkey)
#if INLINE_SYSCALL
		fast_semctl(threadmap->semkey, 1, IPC_RMID, 0);
#else
		fast_semctl(threadmap->semkey, IPC_RMID, 0);
#endif // INLINE_SYSCALL
	wait_filemon_server();
	daemon_stop();
	exit(0);
	return 0;
}

