/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include "myalloc.h"
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <linux/sockios.h>
#include <math.h>
#include "compat_ctype.h"

#include "autoconfig.h"
#include "compat_errno.h"
#include "myconfig.h"
#include "fdinfo.h"
#include "util.h"
#include "list.h"
#include "log.h"

static uint32_t r5hash(const char *p) {
	uint32_t h = 0;
	while(*p) {
		h = h * 11 + (*p<<4)+(*p>>4);
		p++;
	}
	return h;
}

struct myconfig {
	list_head_t list;
	uint32_t hash;
	char *val;
	int intval;
	char key[0];
};

static struct list_head myhash[256] __init__;
static const char sep[256] = { [' ']=1, ['.']=1, ['-']=1, ['_']=1 };
#define SEP(x,y) sep[*((unsigned char *)(x) + (y))]
static const char initbindir[] = "/";
const char *bindir __init__ = initbindir;
const char *confdir __init__ = NULL;
const char *logdir __init__ = NULL;
const char *datadir __init__ = NULL;
const char *docroot __init__ = NULL;
const char *dirindex __init__ = NULL;
int docrootlen __init__ = 0;
static int __init__ nomsg;
static int include_depth __init__;

// ***BEGIN*** Added by yorkwang for file cache on 2008-01-25
static regex_t fcache_url_pattern_i;
regex_t *fcache_url_pattern __init__ = NULL;
// ***END*** Added by yorkwang for file cache on 2008-01-25

// ***BEGIN*** Added by yorkwang for relay on 2008-01-31
int relay_mode __init__ = 0;
// ***END*** Added by yorkwang for relay on 2008-01-31

extern int myconfig_delete_value(const char *pre, const char *key0);

static void update_confdir_from_filename(const char *filename) {
	char *p;
	char *realname;
	realname = canonicalize_file_name(filename);
	if(realname==NULL)
		return;
	if((p = strrchr(realname, '/'))==NULL) {
		free(realname);
		return;
	}
	*p = '\0';
	if(confdir)
	    free((char *)confdir);
	confdir = realname;
}

static int myconfig_loadfile0(const char *file) {
	char *buf;
	int n, nx;
	int len;
	char *p, *pn, *k, *v;
	char *section = "";

	n = fast_open2(file, O_RDONLY);
    if(n < 0) {
        FAST_ERRNO(n);
        lprintf("\7open %s ERROR: %s", file, strerror(-n));
        return -1;
    }

	len = fast_lseek(n, 0L, SEEK_END);
	fast_lseek(n, 0L, SEEK_SET);

	buf = mmap(0, len+1, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
	if(BADADDR(buf)) {        
        lprintf("\7mmap %s ERROR: %s", file, strerror(errno));
	    fast_close(n);
	    return -1;
	}
    nx=fast_read(n, buf, len);
    fast_close(n);
	if(nx<0) {
        FAST_ERRNO(nx);
        lprintf("\7read %s ERROR: %s", file, strerror(-nx));	    
	    return -1;
	}	

	buf[len] = '\0';
	p = buf;
	if(!nomsg) cprintf("LoadingConfigFile: %s\n", file);
	if(confdir==NULL)
		update_confdir_from_filename(file);
	while(p < buf+len) {
	    pn = strchr(p, '\n');
	    if(pn) *pn++ = '\0';
	    p += strspn(p, " \t\r"); /* skip leading blanks */
	    if(*p=='[') {
		    char *q = strchr(++p, ']');
		    if(q) {
		        while(SEP(q, -1))
			        q--;
		        *q++ = '-';
		        *q = '\0';
		        while(SEP(p, 0)) p++;
		        if(p[0]=='\0')
			        section="";
		        else
			        section = p;
		    }
	    } else if(*p && *p!='#' && *p!=';'){
	    	k = p;
		    p += strcspn(p, " \t\r=");
		    v = p; /* v is end of key */
		    p += strspn(p, " \t\r"); /* skip blanks between key and = */
		    n = 0;
		    if(*p=='=') {
			    while(*++p=='=')
				    n++;
				    /* n is multi = */
		    }
		    *v = '\0';
		    v = p + strspn(p, " \t\r");
		    p = pn ? pn - 2 : p+strlen(p)-1;
		    while(*p==' '||*p=='\t'||*p=='\r')
			    *p-- = '\0';	/* strip trailling blanks */

		    if(is_alnum(k[0]) || k[0]=='@') {
		        if(n)
		    	    myconfig_delete_value(section, k);
		        if(*v)
			        myconfig_put_value(section, k, v);
		    } else if(SEP(k,0) && (is_alnum(k[1]) || k[1]=='@')) {
		        if(n)
		    	    myconfig_delete_value("", k+1);
		        if(*v)
			        myconfig_put_value("", k+1, v);
		    }
	    }
	    p = pn;
	}
	munmap(buf, len+1);
	return 0;
}

static int myconfig_loadfile(const char *file) {
	struct ifreq ifr;
	const char *prefix = NULL;
	char *intf;
	char *realname;
	int namelen;
	int prelen;

	if(file[0]=='@') {
	    if(!strncmp(file+1, "bindir/", 7)) {
	    	prefix = bindir;
		file += 8;
	    } else if(!strncmp(file+1, "bin/", 4)) {
	    	prefix = bindir;
		file += 5;
	    } else if(!strncmp(file+1, "confdir/", 8)) {
		prefix = confdir ? confdir : bindir;
		file += 9;
	    } else if(!strncmp(file+1, "etc/", 4)) {
		prefix = confdir ? confdir : bindir;
		file += 5;
	    } else if(!(file=strchr(file, '/'))){
		return -1;
	    }
	} else if(file[0]!='/') {
	    prefix = confdir ? confdir : bindir;
	}
	if(prefix==NULL && file[0] != '/')
		prefix = "/";
	prelen = prefix ? strlen(prefix) : 0;
	namelen = strlen(file);
	intf = strrchr(file, '@');
	if(intf) {
	    int s;
	    namelen = intf - file;
	    intf++;
	    if(strlen(intf) > IFNAMSIZ)
	        return -1;
	    s = fast_socket(AF_INET, SOCK_STREAM, 0);
	    if(s < 0) return -1;
	    strcpy(ifr.ifr_name, intf);
	    ifr.ifr_flags = 0;
	    if(ioctl(s, SIOCGIFFLAGS, &ifr) < 0 ||
		    (ifr.ifr_flags&(IFF_UP|IFF_RUNNING|IFF_SLAVE)) !=
		    (IFF_UP|IFF_RUNNING))
	    {
		fast_close(s);
		return -1;
	    }
	    if(ioctl(s, SIOCGIFADDR, &ifr) < 0)
	    {
		fast_close(s);
		return -1;
	    }
	    fast_close(s);
	    if(ifr.ifr_addr.sa_family != AF_INET)
	    	return -1;
	}

	if(prefix==NULL && intf==NULL)
	    return myconfig_loadfile0(file);

	realname = alloca(prelen + 1 + namelen + (intf?15:0) + 1);
	if(prelen) {
		memcpy(realname, prefix, prelen);
		if(realname[prelen-1] != '/')
			realname[prelen++] = '/';
	}
	memcpy(realname + prelen, file, namelen+1);
	if(intf) {
		struct sockaddr_in *addr  = (struct sockaddr_in *)&ifr.ifr_addr;
		ip2str(realname + prelen + namelen, addr->sin_addr.s_addr)[0] = '\0';
	}
	return myconfig_loadfile0(realname);
}

static void update_dir_from_key(const char **nameptr, const char *file, int force) {
	const char *prefix = NULL;
	char *realname;
	int namelen;
	int prelen;

	if(file==NULL || file[0]=='\0') return;
	if(file[0]=='@') {
	    if(!strncmp(file+1, "bindir/", 7)) {
	    	prefix = bindir;
		file += 8;
	    } else if(!strncmp(file+1, "bin/", 4)) {
		prefix = bindir;
		file += 5;
	    } else if(!strncmp(file+1, "confdir/", 8)) {
		prefix = confdir ? confdir : bindir;
		file += 9;
	    } else if(!strncmp(file+1, "etc/", 4)) {
		prefix = confdir ? confdir : bindir;
		file += 5;
	    } else if(!(file=strchr(file, '/'))){
	        if(force) {
			realname = (char *)file;
			goto out;
		}
		return;
	    }
	} else if(file[0]!='/') {
	    prefix = bindir;
	}
	if(prefix==NULL && file[0] != '/')
		prefix = "/";
	prelen = prefix ? strlen(prefix) : 0;
	namelen = strlen(file);

	realname = alloca(prelen + 1 + namelen + 1);
	if(prelen) {
		memcpy(realname, prefix, prelen);
		if(realname[prelen-1] != '/')
			realname[prelen++] = '/';
	}
	memcpy(realname + prelen, file, namelen+1);
	file = realname;
	realname = canonicalize_file_name(file);
	if(realname==NULL) {
	    if(force) {
		if(*nameptr)
			free((char *)*nameptr);
		*nameptr = strdup(file);
	    }
	    return;
	}
out:
	if(*nameptr)
		free((char *)*nameptr);
	*nameptr = realname;
}

int myconfig_init(int argc, char **argv) {
	int i;
	char buf[4096], *p;

	/* INIT HASH TABLE */
	for( i=0; i<256; i++)
	    INIT_LIST_HEAD(myhash+i);

	/* resolv bindir */
	i = fast_readlink("/proc/self/exe", buf, 4095);
	if(i>0 && buf[0]=='/') {
	    buf[i] = '\0';
	    p = strrchr(buf+1, '/');
	    if(p) {
		*p = '\0';
		bindir = strdup(buf);
		*p = '/';
	    }
	    memcpy(buf+i, ".conf", 6);
	} else
	    buf[0] = '\0';

	if(argc>1) {
		p = argv[1];
		while(*p=='-')
			p++;
		if(!strcmp(p, "developer-magic")) {
			nomsg = 1;
		} else if(!strcmp(p, "developer_magic")) {
			nomsg = 1;
		} else if(!strncmp(p, "developer-magic=", 16)) {
			if(strtol(p+16, NULL, 0))
				nomsg = 1;
		} else if(!strncmp(p, "developer_magic=", 16)) {
			if(strtol(p+16, NULL, 0))
				nomsg = 1;
		} 
#if 0
        else if(!strncmp(p, "include=", 8)) {
			p+= 8;
			while(*p=='=') p++;
			myconfig_loadfile(p);
			argc--; argv++;
		} else if(!strncmp(p, "confdir=", 8)) {
			p+= 8;
			while(*p=='=') p++;
			update_dir_from_key(&confdir, p, 0);
			if(confdir)
			    myconfig_loadfile("tws_http.conf");
			argc--; argv++;
		}
#endif
	}

#if 0
	if(buf[0] && confdir==NULL) {
	    if(myconfig_loadfile0(buf)<0 &&
	    	myconfig_loadfile("@bindir/tws_http.conf") < 0 &&
	    	myconfig_loadfile("@bindir/../etc/tws_http.conf")
		)
	    	myconfig_loadfile("@bindir/../conf/tws_http.conf");
	}
#else
    if (-1 == myconfig_loadfile("@bindir/../conf/tws_http.conf"))
        fast_exit(-1);
#endif

	for(i=1; i<argc; i++) {
	    char *k;
	    k = argv[i];
	    while(*k=='-')
		k++;
	    if(*k=='\0'||*k==';'||*k=='#'||*k=='=')
	    	continue;
	    p = strchr(k, '=');
	    if(p==NULL) {
		myconfig_put_value("", k, "1");
	    } else {
	    	char *q;
		*p = '\0';
		q = p+1;
		if(*q=='=') {
			while(*q=='=')
				q++;
			myconfig_delete_value("", k);
		}
		if(*q)
		    myconfig_put_value("", k, q);
		*p = '=';
	    }
	}

	if(confdir==NULL)
	    confdir = bindir;

	if(datadir==NULL)
	    datadir = logdir;

    dirindex = myconfig_get_value("directory_index"); // Added by yijian on 2007-11-09 

	// ***BEGIN*** Added by yorkwang for file cache on 2008-01-25
	char  *pattern_string = myconfig_get_value("fcache_url_pattern");
	if (pattern_string)
	{
		int err = regcomp(&fcache_url_pattern_i, pattern_string, REG_EXTENDED|REG_NOSUB);
		if( err == 0)
			fcache_url_pattern = &fcache_url_pattern_i;
		else
		{
			char buf[256];
			int  len = regerror(err, &fcache_url_pattern_i, buf, 255);
			buf[len] = '\0';
			lprintf("regcomp fcache_url_pattern:%s error---%s\n", pattern_string, buf);
		}
	}
	// ***END*** Added by yorkwang for file cache on 2008-01-25

	// ***BEGIN*** Added by yorkwang for relay on 2008-01-31
	relay_mode = myconfig_get_intval("relay_mode", 0);
	// ***END*** Added by yorkwang for relay on 2008-01-31

	p = myconfig_get_value("logdir");
	update_dir_from_key(&logdir, p, 1);
	p = myconfig_get_value("datadir");
	update_dir_from_key(&datadir, p, 1);
	p = myconfig_get_value("document_root");
	update_dir_from_key(&docroot, p, 1);
	if(docroot==NULL && !nomsg && !myconfig_get_intval("help", 0) &&
		!myconfig_get_intval("version", 0)) {
	    lprintf("\7document_root not set.\n");
	    fast_exit(-1);
	}
	docrootlen = docroot==NULL ? 0 : strlen(docroot);
	if(!nomsg && myconfig_get_intval("verbose", 0)) {
		cprintf("           bindir: %s\n", bindir?:"");
		cprintf("          confdir: %s\n", confdir?:"");
		cprintf("           logdir: %s\n", logdir?:"");
		cprintf("          docroot: %s\n", docroot?:"");
		cprintf("          datadir: %s\n", datadir?:"");
	}
	return 0;
}

int myconfig_put_value(const char *pre, const char *key0, const char *val) {
	list_head_t *hlist;
	struct myconfig *mc;
	int s, pl, lv;
	char *p;

	if(*pre=='\0') {
	    if(include_depth < 10 && !strcmp(key0, "include")) {
		include_depth++;
		myconfig_loadfile(val);
		include_depth--;
	    }
	    if(!strcmp(key0, "confdir")) {
		if(include_depth==0)
		    update_dir_from_key(&confdir, val, 0);
	    }
	}

	pl = strlen(pre);
	s = strlen(key0)+1;
	lv = strlen(val)+1;
	mc = (struct myconfig *)malloc(sizeof(struct myconfig)+pl+s+lv);
	if(mc == NULL)
		return -1;
	if(pl)
	    mc->val = mempcpy(mempcpy(mc->key,pre,pl), key0, s);
	else
	    mc->val = mempcpy(mc->key, key0, s);
	for(p=mc->key; *p; p++) {
		if(SEP(p, 0)) *p = '_';
		if(*p>='A'&&*p<='Z') *p += 'a'-'A';
	}

	mc->hash = r5hash(mc->key);
	hlist = myhash+(mc->hash&0xff);

	memcpy(mc->val, val, lv);
	mc->intval = -1;
	list_add(&mc->list, hlist);
	return 1;
}

int myconfig_delete_value(const char *pre, const char *key0) {
	list_head_t *hlist, *l;
	char *str;
	int s, pl;
	char *p;
	uint32_t hash;
	struct myconfig *m;

	pl = strlen(pre);
	s = strlen(key0)+1;
	str = alloca(pl+s);
	if(str == NULL)
		return -1;
	if(pl)
	    memcpy(mempcpy(str,pre,pl), key0, s);
	else
	    memcpy(str, key0, s);

	for(p=str; *p; p++)
		if(SEP(p,0)) *p = '_';

	hash = r5hash(str);
	hlist = myhash+(hash&0xff);
	list_for_each_entry_safe_l(m, l, hlist, list)		\
	{
	    if(m->hash==hash && !strcmp(m->key, str)) {
		list_del(&m->list);
		free(m);
	    }
	}
	return 1;
}

char * myconfig_get_value(const char *key) {
	uint32_t hash;
	list_head_t *hlist, *l;
	struct myconfig *mc;

	hash = r5hash(key);
	hlist = &(myhash[hash&0xff]);
	list_for_each(l, hlist)
	{
		mc = list_entry(l, struct myconfig, list);
		if(hash==mc->hash && !strcmp(key, mc->key))
			return mc->val;
	}
	return NULL;
}

char * myconfig_get_multivalue(const char *key, int index) {
	uint32_t hash;
	list_head_t *hlist, *l;
	struct myconfig *mc;

	hash = r5hash(key);
	hlist = &(myhash[hash&0xff]);
	list_for_each_prev(l, hlist)
	{
		mc = list_entry(l, struct myconfig, list);
		if(hash==mc->hash && !strcmp(key, mc->key)) {
			if(index==0)
				return mc->val;
			index--;
		}
	}
	return NULL;
}

int myconfig_get_intval(const char *key, int def) {
	uint32_t hash;
	list_head_t *hlist, *l;
	struct myconfig *mc;

	hash = r5hash(key);
	hlist = &(myhash[hash&0xff]);
	list_for_each(l, hlist)
	{
		mc = list_entry(l, struct myconfig, list);
		if(hash==mc->hash && !strcmp(key, mc->key))
		{
			if(mc->intval==-1) {
				if(is_digit(mc->val[0]) || 
					(mc->val[0]=='-' && is_digit(mc->val[1]))
				)
					mc->intval = atoi(mc->val);
				else if(!strcasecmp(mc->val, "On"))
					mc->intval = 1;
				else if(!strcasecmp(mc->val, "Off"))
					mc->intval = 0;
				else if(!strcasecmp(mc->val, "Yes"))
					mc->intval = 1;
				else if(!strcasecmp(mc->val, "No"))
					mc->intval = 0;
				else if(!strcasecmp(mc->val, "True"))
					mc->intval = 1;
				else if(!strcasecmp(mc->val, "False"))
					mc->intval = 0;
				else if(!strcasecmp(mc->val, "enable"))
					mc->intval = 1;
				else if(!strcasecmp(mc->val, "disable"))
					mc->intval = 0;
				else if(!strcasecmp(mc->val, "enabled"))
					mc->intval = 1;
				else if(!strcasecmp(mc->val, "disabled"))
					mc->intval = 0;
				else
					return def;
			}
			return mc->intval;
		}
	}
	return def;
}

unsigned long myconfig_get_size(const char *key, int def) {
	uint32_t hash;
	list_head_t *hlist, *l;
	struct myconfig *mc;

	hash = r5hash(key);
	hlist = &(myhash[hash&0xff]);
	list_for_each(l, hlist)
	{
		mc = list_entry(l, struct myconfig, list);
		if(hash==mc->hash && !strcmp(key, mc->key))
		{
		    if(!is_digit(mc->val[0])) return def;
		    char *pp;
		    unsigned long v = strtoul(mc->val, &pp, 0);
		    if(pp[0]=='B' || pp[0]=='b') {
		    } else if(pp[0]=='K' || pp[0]=='k') {
		    	v *= 1024;
		    } else if(pp[0]=='M' || pp[0]=='m') {
		    	v *= 1024*1024;
		    } else if(pp[0]=='G' || pp[0]=='g') {
		    	v *= 1024*1024*1024;
		    }
		    return v;
		}
	}
	return def;
}

double myconfig_get_decimal(const char *key) {
	uint32_t hash;
	list_head_t *hlist, *l;
	struct myconfig *mc;

	hash = r5hash(key);
	hlist = &(myhash[hash&0xff]);
	list_for_each(l, hlist)
	{
		mc = list_entry(l, struct myconfig, list);
		if(hash==mc->hash && !strcmp(key, mc->key))
		{
			double a1, a2;
			switch(sscanf(mc->val, "%lf/%lf", &a1, &a2)) {
				case 1: return a1;
				case 2: return a1/a2;
			}
			return NAN;
		}
	}
	return NAN;
}

int myconfig_cleanup(void) {
	list_head_t *l;
	struct myconfig *mc;
	int i;

	for( i=0; i<256; i++) {
		l=myhash[i].next;
		while(l != &myhash[i])
		{
			mc = list_entry(l, struct myconfig, list);
			l = l->next;
			free(mc);
		}
	}
	if(bindir != initbindir)
		free((char *)bindir);
	if(confdir) free((char *)confdir);
	if(logdir) free((char *)logdir);
	if(docroot) free((char *)docroot);
	if(datadir) free((char *)datadir);

	// ***BEGIN*** Added by yorkwang for file cache on 2008-01-25
	if(fcache_url_pattern)
		regfree(fcache_url_pattern);
	// ***END*** Added by yorkwang for file cache on 2008-01-25
	return 0;
}

