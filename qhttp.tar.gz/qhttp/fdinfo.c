/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/mman.h>
#include "compat_stat64.h"
#include "compat_rlimit.h"

#include "autoconfig.h"
#include "global.h"
#include "myconfig.h"
#include "conn.h"
#include "fdinfo.h"
#include "shmem.h"
#include "thread.h"
#include "log.h"
#include "sysctl.h"

int maxfds __init__ = 256;
int guardfds __init__ = 32;
static struct fdinfo fdinfo_static[256];
struct fdinfo *fdinfo __init__ = fdinfo_static;

#if TRACE_FD
const struct baseconn idlestub[1] = {{ "idle" }};
const struct baseconn listenstub[1] = {{ "listen" }};
const struct baseconn entitystub[1] = {{ "entity" }};
const struct baseconn systemstub[1] = {{ "system" }};
const struct baseconn sigiostub[1] = {{ "sigio" }};
const struct baseconn delaystub[1] = {{ "delay" }};
#else
const struct baseconn idlestub[1];
const struct baseconn listenstub[1];
const struct baseconn entitystub[1];
const struct baseconn systemstub[1];
const struct baseconn sigiostub[1];
const struct baseconn delaystub[1];
#endif

/*
 *  fd/ptr/errno... namespace
 *  	0,1,2	reserved for stdin/stdout/stderr, invalid for other fd
 *		in many condition, these value used as special error code
 *	>2 && <maxfds
 *		normal fd
 *	>=maxfds && <=~0xFFFUL
 *		memory pointer
 *      -1 -- -4095
 *		error code
 */
void init_fdlimit(void) {
    struct rlimit rlim;
	stat64_t st;
	int fd;
 
	lprintf(" 1<<16 = %d\n",  1<<16);
	lprintf(" 1<<17 = %d\n",  1<<17);
	lprintf("16<<20 = %d\n", 16<<20);
	lprintf(" 1<<20 = %d\n",  1<<20);

	//maxfds = mconns*3+1000;
	maxfds = mconns*10+10000;
	maxfds = myconfig_get_intval("maxfds", maxfds<(1<<17)?(1<<17):maxfds); // 1<<17 = 131072
	if(maxfds < 1<<16) maxfds = 1<<16; // 1<<16 = 65536
	if (maxfds < mconns*10) maxfds = mconns*10+10000;
	maxfds = (maxfds+pagesize-1) & ~(pagesize-1);	

	fd = sysctl_get_value("/proc/sys/fs/file-max", 0);
	if(fd < maxfds-100000 && fd < (16<<20)) { // 16<<20 = 16777216
	    sysctl_increase_value("/proc/sys/fs/file-max", maxfds+102400);
	    fd = sysctl_get_value("/proc/sys/fs/file-max", 0);
	    if(fd < maxfds) {
		    lprintf("\7Your system don't support %d file descriptors", maxfds);
		    fast_exit(-1);
	    }
	}
	lprintf("fd of /proc/sys/fs/file-max is %d", fd);
    
    /* raise open files */
    rlim.rlim_cur = maxfds;
    rlim.rlim_max = maxfds;
    if((fd=fast_setrlimit(RLIMIT_NOFILE, &rlim)) < 0) {
	    if(mconns <= 500000 && maxfds > (1<<20)) {
	        maxfds = 1<<20; // 1<<20 = 1048576
	        rlim.rlim_cur = maxfds;
	        rlim.rlim_max = maxfds;
	        if((fd=fast_setrlimit(RLIMIT_NOFILE, &rlim)) < 0) {
		        lprintf("\7Cannot increase file descriptors limit to %d", maxfds);
		        fast_exit(-1);
	        }
	    }
	}
    
    rlim.rlim_cur = maxfds;
    rlim.rlim_max = maxfds;
    fast_getrlimit(RLIMIT_NOFILE, &rlim);
	if (rlim.rlim_cur < maxfds) {
	    lprintf("\7Your system don't support %d file descriptors", maxfds);
	    fast_exit(-1);
	}
	if (rlim.rlim_cur > maxfds)
		maxfds = rlim.rlim_cur;
	if (maxfds & 7) maxfds = (maxfds|7)+1;
    
	SHMEM_NEEDED(maxfds, sizeof(struct fdinfo));
	rlim.rlim_cur = 0;
	rlim.rlim_max = 0;
	if(fast_getrlimit(RLIMIT_SIGPENDING, &rlim)>=0) {
	    if(rlim.rlim_cur < 8191) {
		    rlim.rlim_cur = 8191;
		    rlim.rlim_max = 8191;
		    fast_setrlimit(RLIMIT_SIGPENDING, &rlim);
	    }
	}

	if(maxfds >= pagesize) {
	    /* protecting fd mapped virtual address */
	    int mapsize = (maxfds + pagesize - 1) & ~(pagesize-1);
	    void *p = mmap(INT2PTR(pagesize), mapsize - pagesize,
		               PROT_NONE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
	    if(BADADDR(p) || p != INT2PTR(pagesize)) {
		    lprintf("\7maxfds %d too large", maxfds);
		    fast_exit(0);
	    }
	}

	/* protect fd 0/1/2, we use fd 0 as invalid fd */
	fd = fast_open2("/dev/null", O_RDWR);
	if(fast_filestat(0, &st) != 0 && fd != 0) dup2(fd, 0);
	if(fast_filestat(1, &st) != 0 && fd != 1) dup2(fd, 1);
	if(fast_filestat(2, &st) != 0 && fd != 2) dup2(fd, 2);
	if(fd > 2) {
	    fast_close(fd);
	}
	if (maxfds < mconns*10) {
		lprintf("\7maxfds is %d, and mconns is %d", maxfds, mconns);
		fast_exit(0);
	}

	guardfds = maxfds-mconns*6;
	lprintf("maxfds is %d", maxfds);
	lprintf("guardfds is %d", guardfds);		
}

int init_fdinfo_array(void) {
#if TRACE_FD
#define NEGFD	4096
#else
#define NEGFD	0
#endif
	fdinfo = shallocz(sizeof(struct fdinfo) * (NEGFD+maxfds));
	if(fdinfo==NULL) return -ENOMEM;
	fdinfo += NEGFD;
	memcpy(fdinfo, fdinfo_static, sizeof(fdinfo_static));
	return 0;
}

void free_fdinfo_array(void) {
}

int validate_file_handle(int fd, const char *fn, int ln) {
	//while(fd<2 || fdinfo[fd].conn) {
    if (fd<2 || fdinfo[fd].conn) {
	    lprintf(
#if TRACE_FD
		    "%s(%d): got unexpected closed %.16s fd %d by %s(%d)\n",
		    fn, ln,
		    fdinfo[fd].conn ? fdinfo[fd].conn->name : "unknown",
		    fd, fdinfo[fd].close_by_fn, fdinfo[fd].close_by_ln
#else
		    "%s(%d): got unexpected closed fd %d\n", fn, ln, fd
#endif
		   );        
		fd = dup(fd);
        exit_http();
        //break;
	}
	return fd;
}

void validate_events(int fd, int events, const char *fn, int ln) {
	if((events & ~(POLLIN|POLLOUT|POLLHUP|POLLERR))==0) return;
	lprintf(
#if TRACE_FD
		"%s(%d): %.16s fd=%d BAD events %x close by %s(%d)\n",
		fn, ln,
		fdinfo[fd].conn ? fdinfo[fd].conn->name : "unknown",
		fd, events, fdinfo[fd].close_by_fn, fdinfo[fd].close_by_ln
#else
		"%s(%d): fd=%d BAD events %x\n", fn, ln, fd, events
#endif
	       );
}

#if TRACE_FD
int close_debug(int fd, const char *fn, int ln) {
	if(fdinfo[fd].conn != NULL)
	    lprintf("%s(%d): closing inused %.16s fd=%d\n", fn, ln, fdinfo[fd].conn->name, fd);
	fdinfo[fd].close_by_fn = fn;
	fdinfo[fd].close_by_ln = ln;
#undef close
	int v = syscall(__NR_close, fd);
	if(v==-1) lprintf("%s(%d): closing bad %.16s fd=%d err %m\n", fn, ln, fdinfo[fd].conn->name, fd);
	return v;
}

#include <dlfcn.h>
int close(int fd) {
	void *addr = __builtin_return_address(0);
	const char *fn = "unknown";
	int ln = 0;
	Dl_info info;
#if !LINK_AS_STATIC
	if(dladdr(addr, &info)) {
	    if(info.dli_sname==NULL) {
		fn = info.dli_fname;
		ln = addr - info.dli_fbase;
	    } else {
		fn = info.dli_fname;
		ln = addr - info.dli_saddr;
	    }
	}
#endif

	close_debug(fd, fn, ln);
	return 0;
}
#endif
