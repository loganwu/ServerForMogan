#include "myalloc.h"
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <math.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <stdarg.h>
#include "bitops.h"
#include "compat_ctype.h"
#include "compat_errno.h"
#include "compat_stat64.h"

#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "conn.h"
#include "log.h"
#include "util.h"
#include "shmem.h"
#include "timestamp.h"
#include "task.h"
#include "daemon.h"
#include "filemon.h"
#include "stat.h"

static uint64_t rotatesize __init__= 0;
static time_t rotateinterval __init__= 0;
static time_t rotatetime = 0;
static char *logbuf = NULL;
static int loglen = 0;
static int logbuflen = 0;
static int console_disabled = 0;
static union {
    fd_set mask;
    char  padding[128];
} logcode;
static int lograte = 0;

#if IPINFO_SUPPORT
#define LOG_IPMAP	1
#define LOG_IPCOUNT	2
#define LOG_RTT		4
static struct {
    int flag;
    int shift;
    time_t rotate;
    atomic_t *count;
} ipinfo;
#endif

#define LOGFD_TIMEOUT	60
#define LOGFD_OMODE	(O_WRONLY|O_APPEND|O_CREAT|O_LARGEFILE)
#define LOGFD_CMASK	0666

static int mlogfd = 0;

#if PROFILE_SUPPORT
static void dump_profile(void *);
#endif
int init_logging(void) {
	char *p;
	int fd;

	mlogfd = -1;
	logmode = LOG_DISABLED;
	if(logdir==NULL) {
	    lprintf("logdir not defined, access logging disabled\n");
	} else if(logdir[0] != '/') {
	    lprintf("logdir must be full pathname, access logging disabled\n");
	    logdir = NULL;
	}
	else if((fd = fast_open2(logdir, O_RDONLY|O_DIRECTORY)) < 0) {
	    FIX_ERRNO(fd);
	    lprintf("logdir: %m, access logging disabled\n");
	    logdir = NULL;
	}
	else {
	    fast_close(fd);
	    if((p = myconfig_get_value("logmode")) != NULL) {
		if(!strcasecmp(p, "disabled"))
		    logmode = LOG_DISABLED;
		else if(!strcasecmp(p, "object"))
		    logmode = LOG_OBJECT;
		else if(!strcasecmp(p, "transmit"))
		    logmode = LOG_TRANSMIT;
		else if(!strcasecmp(p, "digest"))
		    logmode = LOG_DIGEST;
		else if(!strcasecmp(p, "error"))
		    logmode = LOG_ERROR;
		else
		    logmode = LOG_ERROR;
	    }

	    if(logmode==LOG_OBJECT||logmode==LOG_TRANSMIT) {
	    	/* init lograte */
	    	double a = myconfig_get_decimal("access_log_rate");
		if(!isnan(a) && !isinf(a)) {
		    lograte = 65536 - (int)(a*65536.0+0.5);
		    if(lograte >= 65536) {
		    	lprintf("access_log_rate is zero, disable access log\n");
			logmode = LOG_ERROR;
			lograte = 0;
		    } else if(lograte < 0)
		    	lograte = 0;
		}
		if(lograte)
		    lprintf("Access log rate is %d/65536\n", 65536-lograte);
	    }

	    if(logmode > LOG_DIGEST && url_in_sendbuf && has_plugin) {
		lprintf("URL in send buffer disabled because access log enabled\n");
	    	url_in_sendbuf = 0;
	    }

	    if((p=myconfig_get_value("log_response_code"))==NULL) {
	    	memset(&logcode, 0xff, sizeof(logcode));
	    } else {
	    	char *f[100];
		int i, n, c;

		n = str_explode(" \t\r\n,", p, f, 100);
		for(i=0; i<n; i++) {
		    if(!strcasecmp(f[i], "all"))
			memset(&logcode, 0xff, sizeof(logcode));
		    else if(!strcasecmp(f[i], "none"))
			memset(&logcode, 0, sizeof(logcode));
		    else if(!strcasecmp(f[i], "url-only")) {
			if(logmode > LOG_DIGEST) logmode = LOG_URL;
		    } else if(!strcasecmp(f[i], "url_only")) {
			if(logmode > LOG_DIGEST) logmode = LOG_URL;
		    } else if(is_digit(f[i][0])) {
		    	c = atoi(f[i]);
			if(c >= 100 && c <= 999)
				FD_SET(c, &logcode.mask);
		    } else if((f[i][0]=='~'||f[i][0]=='!') && is_digit(f[i][1])) {
		    	c = atoi(f[i]+1);
			if(c >= 100 && c <= 999)
				FD_CLR(c, &logcode.mask);
		    }
		}
	    }
	}

	rotatesize = myconfig_get_intval("log_rotate_size", 1024);
	if(rotatesize < 10) rotatesize = 10;
	rotatesize <<= 20;

	rotateinterval = 0;
	p = myconfig_get_value("log_rotate_interval");
	if(p) {
	    if(is_digit(p[0]))
		rotateinterval = atoi(p);
	    else if(!strcasecmp(p, "hourly"))
		rotateinterval = 60 * 60;
	    else if(!strcasecmp(p, "daily"))
		rotateinterval = 24 * 60 * 60;
	    else if(!strcasecmp(p, "weekly"))
		rotateinterval = 7 * 24 * 60 * 60;
	    else {
		lprintf("Unknown log_rotate_interval %s\n", p);
	    }
	}
	rotatetime = fast_time();
#if IPINFO_SUPPORT
	ipinfo.rotate = rotatetime;
	if( ipinfo.rotate % 86400 )
	    ipinfo.rotate += 86400 - ipinfo.rotate % 86400;
#endif
	if(rotateinterval < 60) {
	    rotateinterval = 365 * 24 * 60 * 60;
	    rotatetime = fast_time() + rotateinterval;
	} else {
	    if( rotatetime % rotateinterval )
		rotatetime += rotateinterval - rotatetime % rotateinterval;
	}
	if(logmode==LOG_DISABLED) {
	    if(logbuf != 0) {
		free(logbuf);
		logbuf = NULL;
		loglen = logbuflen = 0;
	    }
#if IPINFO_SUPPORT
	} else if(myconfig_get_intval("statistics_ipcount", 0)) {
	    ipinfo.flag = LOG_IPCOUNT;
	} else if(myconfig_get_intval("statistics_ipmap", 0)) {
	    ipinfo.flag = LOG_IPMAP;
#endif
	}
#if IPINFO_SUPPORT
	ipinfo.shift = 32 - myconfig_get_intval("ipaddress_bits", 24);
	if(ipinfo.shift < 8) ipinfo.shift = 8;
	if(ipinfo.shift > 24) ipinfo.shift = 24;
#endif

#if PROFILE_SUPPORT
	register_privilege_task(dump_profile, NULL);
#endif
	return 0;
}

void free_logging(void) {
	if(mlogfd > 0) {
	    if(loglen > 0) fast_write(mlogfd, logbuf, loglen);
	    fast_close(mlogfd);
	}
	if(logbuf) free(logbuf);
	logbuflen = 0;
	logbuf = NULL;
}

void disable_console(void) {
	console_disabled = 1;
}

#if IPINFO_SUPPORT
void log_tcpinfo(int fd) {
	if(ipinfo.count!=NULL) {
	    uint32_t addr;
	    addr = ntohl(fdinfo[fd].addr);
	    if(addr < 0xE0000000) {
		addr >>= ipinfo.shift;
	    	if(ipinfo.flag & LOG_IPMAP) {
		    set_bit(addr, ipinfo.count);
		} else {
		    atomic_inc(ipinfo.count+addr);
		}
	    }
	}

	if(0){
	    struct tcp_info ti;
	    socklen_t sol = sizeof(ti);
	    unsigned char *a = (unsigned char *)&fdinfo[fd].addr;
	    fast_getsockopt(fd, SOL_TCP, TCP_INFO, &ti, &sol);
	    if(ti.tcpi_rtt==0) return;
	    if(ti.tcpi_rtt<ti.tcpi_rttvar) ti.tcpi_rttvar = ti.tcpi_rtt;
	    cprintf("%5d %d.%d.%d.%d\n", ti.tcpi_rttvar/2500, a[0], a[1], a[2], a[3]);
	}
}
#endif

static const char * const methodstr[] = {
"GET ", "HEAD ", "POST ", "BAD "
};

void log_request(struct conn *c, uint32_t addr) {
	int fd;
	char *p, *u, ch;
	char *buf;

    if (NULL == c->vhost) return;
	fd = c->vhost->logfd;
	if(fd==-1) return;

	if(c->sendcode>999 || !FD_ISSET(c->sendcode, &logcode.mask))
		return;

	if(lograte && ((rand() & 0xFFFF) < lograte))
		return;
	if(logmode==LOG_URL) {
		int a;
		/* c->url always writable and has extra 1 byte */
		a = strlen(c->url);
#if DBEUG_MALLOC
		if(a>maxurllen) {
		    lprintf("%s(%d): url length %d overflow %d\n", __FILE__, __LINE__, a, maxurllen);
		} else
#endif
		{
		    c->url[a] = '\n';
		    fast_write(fd, c->url, a+1);
		    c->url[a] = '\0';
		}
		return;
	}

	/* STACK-USAGE: maxurllen+100 */
	buf = alloca(maxurllen+100);
	p = buf;
	p = ip2str(buf, addr);
	p = stpcpy(p, " - - [");
	p = time2alogstr(p, now);
	p = stpcpy(p, "] \"");
	p = stpcpy(p, methodstr[c->method]);
	u=c->url;
    #if ISDSTAT_SUPPORT
    if (*u != '/')
        ISDSTAT(atomic_inc(&countermap->errorreq));;
    #endif
	while((ch=(*u++))) {
	    if(ch=='"'||ch=='\\')
		*p++ = '\\';
	    *p++ = ch;
	}
	if(!c->no_header) {
		*(uint32_t *)p = *(uint32_t *)" HTT"; p+=4;
		*(uint32_t *)p = *(uint32_t *)"P/1."; p+=4;
		*p++ = c->http_v11 + '0';
	}
	*(uint16_t *)p = *(uint16_t *)"\" "; p += 2;
	*p++ = '0'+(c->sendcode/100)%10;
	*p++ = '0'+(c->sendcode/10)%10;
	*p++ = '0'+(c->sendcode)%10;
	*p++ = ' ';

	p = 
	ll2str(p, logmode==LOG_TRANSMIT ? c->sendlen + c->logsize : c->logsize);
#if IOPERF_SUPPORT
	if(ioperf_exp) {
	    p = stpcpy(p, " io=");
	    long usec = (double)c->iowait/tscusecf;
	    p = int2str(p, usec);
	}
#endif
	*p++ = '\n';
	fast_write(fd, buf, p - buf);
}

static int rotate_logfile(int fd, const char *filename, int omode, int cmask) {
	int n;

	n = rotate_global_file(filename, omode, cmask);
	if(n > 0) {
	    delay_close(fd, LOGFD_TIMEOUT);
	    return n;
	}
	return fd;
}

void scan_logfiles(void) {
	/* STACK-USAGE: 300 */
	char logname[128];
	stat64_t st;
	struct vhost *vh;
	time_t tsc;
	int need_rotate = 0;

	int req;
#if HAS_ATOMIC8
	long bytes;
	long bytes0 = 0;
#else
	int kbytes;
	int bytes;
	int kbytes0 = 0;
	int bytes0 = 0;
#endif
	//int req0 = 0;


	tsc = fast_time();

	if(logmode == LOG_DISABLED) goto out0;
#if IPINFO_SUPPORT
	if ((ipinfo.flag&(LOG_IPMAP|LOG_IPCOUNT)) &&
		(ipinfo.count==NULL || tsc > ipinfo.rotate))
	{
	    int fd = -1;
	    sprintf(logname, "@logdir/%s-%d.dat",
		    ipinfo.flag&LOG_IPMAP?"ipmap":"ipcount",
		    32-ipinfo.shift);

	    if(ipinfo.count) {
		ipinfo.rotate += 86400;
		fd = rotate_global_file(logname, O_RDWR|O_CREAT, LOGFD_CMASK);
	    }

	    if(fd < 0) {
	    	fd = open_global_file(logname, O_RDWR|O_CREAT, LOGFD_CMASK);
	    }
	    if(fd > 0) {
	    	int size;

		if(ipinfo.flag & LOG_IPMAP)
		    size = 0x1C000000 >> ipinfo.shift;
		else
		    size = 0x1C000000 >> (ipinfo.shift-5);

	    	if(ftruncate(fd, size)==0) {
		    void *map;
		    map = mmap((void *)ipinfo.count, size, PROT_READ|PROT_WRITE,
			    ipinfo.count ? MAP_SHARED|MAP_FIXED : MAP_SHARED,
			    fd, 0);
		    if(!BADADDR(map))
			ipinfo.count = map;
		}
		fast_close(fd);
	    }
	}
#endif

	while (tsc > rotatetime) {
	    rotatetime += rotateinterval;
	    need_rotate = 1;
	}

	if(mlogfd<=0) {
	    mlogfd = open_global_file("@logdir/tws_http.log", LOGFD_OMODE, LOGFD_CMASK);
	    if(mlogfd > 0 && loglen > 0) {
		fast_write(mlogfd, logbuf, loglen);
		loglen = 0;
	    }
	}

	if(mlogfd>0 &&
	   (need_rotate || fast_filestat(mlogfd, &st) != 0 || st.st_size >= rotatesize)) {
	    mlogfd = rotate_logfile(mlogfd, "@logdir/tws_http.log", LOGFD_OMODE, LOGFD_CMASK);
	}
out0:

	for(vh = vhostlist; vh; vh=vh->vhost) {
	    req = atomic_read(&vh->req);
	    atomic_sub(req, &vh->req);
	    //req0 += req;
#if HAS_ATOMIC8
	    bytes = atomic8_read(&vh->bytes);
	    atomic8_sub(bytes, &vh->bytes);
#else
	    kbytes = atomic_read(&vh->kbytes);
	    bytes = atomic_read(&vh->bytes);
	    atomic_sub(kbytes, &vh->kbytes);
	    atomic_sub(bytes, &vh->bytes);
	    kbytes0 += kbytes;
#endif
	    bytes0 += bytes;
#if ISDSTAT_SUPPORT
	    if(logmode>=STAT_DIGEST){
	        atomic_add(req, &countermap->host[vh->statid].nreq);
#if HAS_ATOMIC8
	        atomic8_add(bytes, &countermap->host[vh->statid].bytes);
#else
	        atomic_add(kbytes+(bytes>>10), &countermap->host[vh->statid].kbytes);
	        atomic_add((bytes&0x3FF), &countermap->host[vh->statid].bytes);
#endif
	    }
#endif

	    if(logmode==LOG_DIGEST) {
#if HAS_ATOMIC8
		if(bytes != 0)
		    lprintf("DIGEST %d %"F64"d %s\n", req, bytes, vh->name);
#else
		if(bytes != 0 || kbytes != 0) {
		    kbytes += bytes >> 10;
		    bytes &= 0x3FF;
		    lprintf("DIGEST %d %"F64"d %s\n", req,
			    (((uint64_t)kbytes)<<10)+bytes,
			    vh->name);
		}
#endif
		continue;
	    } else if(logmode < LOG_DIGEST)
		continue;

	    if(vh->logfd<=0 && (vh->flag & (VH_NOLOG|VH_DISABLED))==0) {
		if(vh->flag & VH_DEFAULT)
		    memcpy(logname, "@logdir/access.log", sizeof("@logdir/access.log"));
		else
		    sprintf(logname, "@logdir/access-%s.log", vh->name);
		vh->logfd = open_global_file(logname, LOGFD_OMODE, LOGFD_CMASK);
	    }
	    if(vh->logfd>0 &&
	       (need_rotate || fast_filestat(vh->logfd, &st) != 0 ||
		st.st_size >= rotatesize)

	      )
	    {
		if(vh->flag & VH_DEFAULT) {
		    vh->logfd = rotate_logfile(vh->logfd, "@logdir/access.log", LOGFD_OMODE, LOGFD_CMASK);
		} else {
		    sprintf(logname, "@logdir/access-%s.log", vh->name);
		    vh->logfd = rotate_logfile(vh->logfd, logname, LOGFD_OMODE, LOGFD_CMASK);
		}
	    }
	}
#if ISDSTAT_SUPPORT
#if HAS_ATOMIC8
	atomic8_add(bytes0, &countermap->bytes);
#else
	kbytes0 += bytes0 >> 10;
	bytes0 &= 0x3FF;
	atomic_add(kbytes0, &countermap->kbytes);
	atomic_add(bytes0, &countermap->bytes);
#endif
#endif
}

static void lwrite(char *buf, int len, int lo) {
	time2logstr(buf, fast_time());
	buf[14] = ' ';
	if(buf[len-1] != '\n') buf[len++] = '\n';
	if(logmode!=LOG_DISABLED) {
	    if(mlogfd > 0) {
			if(loglen > 0) fast_write(mlogfd, logbuf, loglen);
			loglen = 0;
			fast_write(mlogfd, buf, len);
	    } else if(running==0 && stop==0) {
		if(logbuflen - loglen <= len) {
		    /* expand logbuf */
		    if(logbuf==NULL) {
			logbuf = malloc(4096);
			if(logbuf==NULL) goto err;
			logbuflen = 4096;
		    } else {
			char *newbuf = malloc(logbuflen << 1);
			if(newbuf==NULL) goto err;
			logbuflen <<= 1;
			memcpy(newbuf, logbuf, loglen);
			free(logbuf);
			logbuf = newbuf;
		    }
		}
		memcpy(logbuf + loglen, buf, len);
		loglen += len;
	    }
	}
err:
	if(console_disabled || lo) return;
	fast_write(1, buf+15, len-15);
}

#undef LOGBUFSIZE
#if PLUGIN_SUPPORT
#define LOGBUFSIZE 2048
#else
#define LOGBUFSIZE 1024
#endif
void lputs(const char *string) {
	/* STACK-USAGE: LOGBUFSIZE */
	char buf[LOGBUFSIZE];
	int l;
	l = strlen(string);
	if(l > sizeof(buf)-15-1) l = sizeof(buf)-15-1;
	memcpy(buf+15, string, l);
	lwrite(buf, l+15, 0);
}

void lprintf(const char *format, ...) {
	/* STACK-USAGE: LOGBUFSIZE */
	va_list ap;
	char buf[LOGBUFSIZE];
	int l;
	int red = 0;

	if(format[0]=='\7') {
		fast_write(1, "\033[31m\033[1m", 9);
		format++;
		red = 1;
	}
	va_start(ap, format);
	l = vsnprintf(buf+15, sizeof(buf)-15, format, ap);
	l += 15; if(l >= sizeof(buf)) l = sizeof(buf)-1;
	va_end(ap);
	lwrite(buf, l, 0);
	if(red)
		fast_write(1, "\033[0m", 4);
}

void loprintf(const char *format, ...) {
	/* STACK-USAGE: LOGBUFSIZE */
	va_list ap;
	char buf[LOGBUFSIZE];
	int l;

	va_start(ap, format);
	l = vsnprintf(buf+15, sizeof(buf)-15, format, ap);
	l += 15; if(l >= sizeof(buf)) l = sizeof(buf)-1;
	va_end(ap);
	lwrite(buf, l, 1);
}

void vlprintf(const char *format, va_list ap) {
	/* STACK-USAGE: LOGBUFSIZE */
	char buf[LOGBUFSIZE];
	int l;
	l = vsnprintf(buf+15, sizeof(buf)-15, format, ap);
	l += 15; if(l >= sizeof(buf)) l = sizeof(buf)-1;
	lwrite(buf, l, 0);
}

void cputs(const char *string) {
	if(console_disabled) return;
	fast_write(1, string, strlen(string));
}

void cprintf(const char *format, ...) {
	va_list ap;
	/* STACK-USAGE: LOGBUFSIZE */
	char buf[LOGBUFSIZE];
	int l;

	if(console_disabled) return;
	va_start(ap, format);
	l = vsnprintf(buf, sizeof(buf), format, ap);
	if(l >= sizeof(buf)) l = sizeof(buf)-1;
	va_end(ap);

	fast_write(1, buf, l);
}

void vcprintf(const char *format, va_list ap) {
	/* STACK-USAGE: LOGBUFSIZE */
	char buf[LOGBUFSIZE];
	int l;

	if(console_disabled) return;
	l = vsnprintf(buf, sizeof(buf), format, ap);
	if(l >= sizeof(buf)) l = sizeof(buf)-1;
	fast_write(1, buf, l);
}

void lflush(void) {
	if(running) return;
	if(mlogfd < 0) return;
	if(loglen <= 0) return;
	fast_write(mlogfd, logbuf, loglen);
	loglen = 0;
}

#if PROFILE_SUPPORT
static const char * const opname[] = {
    "total",
    "close connection",
    "send header",
    "send file",
    "recv data",
    "flush data",
    "get entity",
    "put entity",
    "init entity",
    "open file",
    "stat file",
    "plugin",
};
static const char * const latname[] = {
    "schedule",
    "recv",
    "send",
    "working",
    "transfer",
};

static void dump_profile(void *priv) {
	/* STACK-USAGE: <300 */
	static uint64_t dumptsc;
	uint64_t profile[PROFILE_PLUGIN+1];
	uint64_t cnt;
	int i, j;

	uint64_t tsc = readtsc();
	if(dumptsc==0) dumptsc = tsc + tscmin;
	if(tsc < dumptsc) return;
	dumptsc = tsc + 10 * tscmin;

	memset(profile, 0, sizeof(profile));
	cnt = 0;
	for(i=0; i < nworks; i++) {
		cnt += worker[i].reqcnt;
		for(j=0; j <= PROFILE_PLUGIN; j++)
			profile[j] += worker[i].profile[j];
		cnt += worker[i].reqcnt;
	}

	cnt >>= 1;
	if(cnt==0) cnt = 1;

	for(i=0; i<=PROFILE_PLUGIN; i++) {
	    lprintf("PROFILE %lld %lld %s\n",
		    profile[i]*1000/profile[0],
		    profile[i]/cnt,
		    opname[i]);
	}

}
#endif

