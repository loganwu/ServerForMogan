
#include <stdint.h>

extern int has_inotify;
extern int has_dnotify;
extern int has_epoll;
extern int has_futex;
#if __WORDSIZE<64
extern int has_sendfile64;
#else
#define has_sendfile64 1
#endif
extern int has_threadgroup;
extern int has_unshare;
extern int has_openat;
extern int has_splice;
extern int has_fadvise;
extern int pipe_buffer_size;

#define SYS_UNUSABLED	-2
#define SYS_DISABLED	-1
#define SYS_NOT_SUPPORTED 0
#define SYS_SUPPORTED 1
#define SYS_SUPPORTED_32 2
#define SYS_SUPPORTED_64 3
#define SYS_SUPPORTED64_32 4
#define SYS_SUPPORTED64_64 5

#if VARY_PAGE_SIZE
extern void init_pagesize(void);
extern int pagesize;
#else
#define pagesize 4096
#endif
extern int physical_memory_size(void);
extern void detect_shmmax(void);
extern int read_hugepage_info(void);
extern void detect_kernel(void);
