extern long sysctl_increase_value(const char *fn, long value);
extern long sysctl_decrease_value(const char *fn, long value);
extern long sysctl_set_value(const char *fn, long value);
extern long sysctl_get_value(const char *fn, int index);
extern int sysctl_get_multivalue64(const char *fn, int64_t *ptr, int num);

