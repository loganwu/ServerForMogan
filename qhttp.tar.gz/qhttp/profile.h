#ifdef PROFILE_SUPPORT

#include "tsc.h"

#define PROFILE_START	{ tsc_t ps_0 = readtsc();
#define PROFILE_CONN(x)	 c->thread->profile[x] += readtsc() - ps_0; }
#define PROFILE_WORKER(x) 	 wt->profile[x] += readtsc() - ps_0; }

#define PROFILE_TOTAL		0
#define PROFILE_CLOSE		1
#define PROFILE_SEND		2
#define PROFILE_SENDFILE	3
#define PROFILE_RECV		4
#define PROFILE_FLUSH		5
#define PROFILE_GET_ENTITY	6
#define PROFILE_PUT_ENTITY	7
#define PROFILE_INIT_ENTITY	8
#define PROFILE_OPEN_FILE	9
#define PROFILE_STAT_FILE	10
#define PROFILE_PLUGIN		11

#else
#define PROFILE_START /* */
#define PROFILE_CONN(x) /* */
#define PROFILE_WORKER(x) /* */

#endif
