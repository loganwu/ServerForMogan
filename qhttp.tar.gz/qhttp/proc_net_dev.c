/**
* @file  proc_net_dev.c
* @brief /proc/net/dev
*
* @author yijian
* @date 2008-03-12
* @{
 */
#include <time.h>
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "log.h"
#include "proc_net_dev.h"

#define LINE_LENGTH_MAX  255
#define BUFFER_SIZE_MAX  4095
#define GET_NAME(cur) \
if (cur == state) { \
   while (' ' == *pszLine) ++pszLine; \
   *namep = *pszLine; \
   ++namep; \
   ++pszLine; \
   \
   if ((' ' == *pszLine) || (':' == *pszLine)) { \
       *namep = '\0'; \
       ++pszLine; \
       state = 1; \
       pDevStruct->r_bytes = 0; \
   } \
   else if ((*pszLine > '0') && (*pszLine < '9')) { \
       pDevStruct->seq = *pszLine - '0'; \
   } \
}
#define GET_INT_VALUE(cur,fieldname) \
else if (cur == state) { \
    while (' ' == *pszLine) ++pszLine; \
    \
    pDevStruct->fieldname *= 10; \
    pDevStruct->fieldname += *pszLine - '0'; \
    \
    ++pszLine; \
    if (' ' == *pszLine) { \
        ++pszLine; \
        state = cur+1; \
    } \
}

#ifdef __cplusplus
extern "C" {
#endif

int get_line(int fd, char* szLine, size_t uLineLength);
int parse_line(const char* szLine, struct dev_struct* pDevStruct);
int calc_dev_count(int fd);

int ProcNetDev_activate(struct ProcNetDev* pThis) {
    //if (pThis->m_fdDev) close(pThis->m_fdDev);
    pThis->m_fdDev = open("/proc/net/dev", O_RDONLY|O_NONBLOCK);
    if (pThis->m_fdDev > 0) {
        pThis->m_nDevCount = calc_dev_count(pThis->m_fdDev);
        if (pThis->m_nDevCount > 0) {
            pThis->m_pDevStruct = (struct dev_struct *)calloc(pThis->m_nDevCount, sizeof(struct dev_struct));
        }
        else {
            pThis->m_nDevCount = 0;
            pThis->m_pDevStruct = NULL;
        }
    }
    else {
        pThis->m_nDevCount = 0;
        pThis->m_pDevStruct = NULL;
    }
    
    return pThis->m_fdDev;
}

void ProcNetDev_deactivate(struct ProcNetDev* pThis) {
    if (pThis->m_fdDev > 0) {
        close(pThis->m_fdDev);
        pThis->m_fdDev = -1;
    }
    if (pThis->m_pDevStruct != NULL) {
        free(pThis->m_pDevStruct);
        pThis->m_pDevStruct = NULL;
    }
}

int ProcNetDev_getDevCount(struct ProcNetDev* pThis)
{
    return pThis->m_nDevCount;    
}

int ProcNetDev_parse(struct ProcNetDev* pThis)
{      
    if (-1 == pThis->m_fdDev) {
        pThis->m_fdDev = open("/proc/net/dev", O_RDONLY|O_NONBLOCK);
        if (-1 == pThis->m_fdDev) {            
            return -1;
        }
    }
    if (-1 == lseek(pThis->m_fdDev, 0, 0)) return -1;

    char* buffer = (char*)malloc(BUFFER_SIZE_MAX+1);    
    int rd = read(pThis->m_fdDev, buffer, BUFFER_SIZE_MAX);
    if (rd < 1) {
        int old_errno = errno;
        if (errno != EAGAIN) {
            close(pThis->m_fdDev);
            pThis->m_fdDev = -1;
        }
        free(buffer);
        errno = old_errno;
        return rd;
    }    
    
    int line_num = 0;    
    char* pszLine = NULL;
    char* pbuffer = buffer;
    buffer[rd] = 0;
    for (;;) {
        if (('\n' == *pbuffer) || ('\0' == *pbuffer)) {
            if ('\0' == *pbuffer) break; // "\n\0"
            else *pbuffer = 0;
            
            if (++line_num > 2) {                
                memset(&pThis->m_pDevStruct[line_num-3], 0, sizeof(pThis->m_pDevStruct[line_num-3]));
                parse_line(pszLine, &pThis->m_pDevStruct[line_num-3]);                
            }
            
            ++pbuffer; // Skip '\n'
            if (line_num > 1) pszLine = pbuffer;
        }        
        ++pbuffer;
    }
    
    free(buffer);
    return line_num-2;
}

int calc_dev_count(int fd)
{
    if (-1 == lseek(fd, 0, 0)) return -1;    
    
    char* buffer = (char*)alloca(BUFFER_SIZE_MAX+1);
    int rd = read(fd, buffer, BUFFER_SIZE_MAX);
    if (rd < 1) {        
        return rd;
    }

    buffer[rd] = 0;
    int num = 0;
    char* pbuffer = buffer;
    for (;;) {
        if ('\0' == *pbuffer) break; // "\n\0"
        if ('\n' == *pbuffer) ++num;
        ++pbuffer;
    }    
        
    if (-1 == lseek(fd, 0, 0)) return -1;
    return num-2;
}

void ProcNetDev_dump(struct ProcNetDev* pThis)
{
    int i = 0;
    for (i=0; i<pThis->m_nDevCount; ++i) {
        fprintf(stderr, ">>>>>>>>>>>>>>>>\n");
        fprintf(stderr, "SEQ         : %d\n",  pThis->m_pDevStruct[i].seq);
        fprintf(stderr, "NAME        : %s\n",  pThis->m_pDevStruct[i].name);
        fprintf(stderr, "r_bytes     : %lu\n", pThis->m_pDevStruct[i].r_bytes);
        fprintf(stderr, "r_packets   : %lu\n", pThis->m_pDevStruct[i].r_packets);
        fprintf(stderr, "r_errs      : %lu\n", pThis->m_pDevStruct[i].r_errs);
        fprintf(stderr, "r_drop      : %lu\n", pThis->m_pDevStruct[i].r_drop);
        fprintf(stderr, "r_fifo      : %lu\n", pThis->m_pDevStruct[i].r_fifo);
        fprintf(stderr, "r_frame     : %lu\n", pThis->m_pDevStruct[i].r_frame);
        fprintf(stderr, "r_compressed: %lu\n", pThis->m_pDevStruct[i].r_compressed);
        fprintf(stderr, "r_multicast : %lu\n", pThis->m_pDevStruct[i].r_multicast);
        fprintf(stderr, "t_bytes     : %lu\n", pThis->m_pDevStruct[i].t_bytes);
        fprintf(stderr, "t_packets   : %lu\n", pThis->m_pDevStruct[i].t_packets);
        fprintf(stderr, "t_errs      : %lu\n", pThis->m_pDevStruct[i].t_errs);
        fprintf(stderr, "t_drop      : %lu\n", pThis->m_pDevStruct[i].t_drop);
        fprintf(stderr, "t_fifo      : %lu\n", pThis->m_pDevStruct[i].t_fifo);
        fprintf(stderr, "t_colls     : %lu\n", pThis->m_pDevStruct[i].t_colls);
        fprintf(stderr, "t_carrier   : %lu\n", pThis->m_pDevStruct[i].t_carrier);
        fprintf(stderr, "t_compressed: %lu\n", pThis->m_pDevStruct[i].t_compressed);
    }
}

int get_line(int fd, char* szLine, size_t uLineLength)
{
    char* pszLine = szLine;    
    for (;;) {
        int rd = read(fd, pszLine, 1);
        if (rd > 0) {
            if ('\n' == *pszLine) break;
            
            ++pszLine;            
            if ((size_t)(pszLine - szLine) > uLineLength)
                break;
        }
        else if (0 == rd) {
            break;
        }
        else {
            return -1;
        }
    }
    
    if ('\n' == *(pszLine-1))
        --pszLine;
            
    *pszLine = '\0';    
    return (int)(pszLine-szLine);
}

//    0        1       2    3    4    5     6          7         8        9      10   11   12   13    14      15         16
// eth0:       0       0    0    0    0     0          0         0        0       0    0    0    0     0       0          0
int parse_line(const char* szLine, struct dev_struct* pDevStruct)
{
    int state = 0;
    const char* pszLine = szLine;
    char* namep = pDevStruct->name;
    for (;;) {
        GET_NAME(0)
        GET_INT_VALUE(1,  r_bytes)
        GET_INT_VALUE(2,  r_packets)
        GET_INT_VALUE(3,  r_errs)
        GET_INT_VALUE(4,  r_drop)
        GET_INT_VALUE(5,  r_fifo)
        GET_INT_VALUE(6,  r_frame)
        GET_INT_VALUE(7,  r_compressed)
        GET_INT_VALUE(8,  r_multicast)
        GET_INT_VALUE(9,  t_bytes)
        GET_INT_VALUE(10, t_packets)
        GET_INT_VALUE(11, t_errs)
        GET_INT_VALUE(12, t_drop)
        GET_INT_VALUE(13, t_fifo)
        GET_INT_VALUE(14, t_colls)
        GET_INT_VALUE(15, t_carrier)
        GET_INT_VALUE(16, t_compressed)
        if ('\0' == *pszLine) break;
    }

    return 0;
}

int milli_sleep(unsigned long milli)
{
    struct timespec req = { milli / 1000, (milli % 1000) * 1000000 };
    while ((-1 == nanosleep(&req, &req)) && (EINTR == errno)) /* EMTPY LOOP */;
    return 0;
}

#ifdef __cplusplus
}
#endif
