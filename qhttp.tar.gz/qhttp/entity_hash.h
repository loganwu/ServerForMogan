
#include "stddef.h"
#include "list.h"
#include "entity.h"

struct entity_hash {
#if TRACE_FD
	char name[16];
#endif
	struct list_head list; /* hash link */
	unsigned char hash[16];
	uint32_t tsc4;
	atomic_t count;		/* inuse count */
	unsigned int hits;	/* cache hits */
	uint8_t type;
	uint8_t flag;
	volatile uint8_t expired;
	volatile uint8_t expiring;
	union {
	    /* lockless: lru link by thread */
	    /* globallock: fdcache & memcache */
	    struct list_head lru;
	    /* sorting by last hit in lockless */
	    uint32_t sortid;
	    /* lockless: delay close */
	    uint32_t exp4;
	};
	/* lockless: fdcache & negcache */
	/* globallock: fdcache & negcache */
	struct list_head exp; /* exp link by thread */
	struct mementity mem[0];
	uint32_t fd;
};

enum {
	ET_UNUSED = 0,
	ET_LOCAL = 1,
	ET_NEGATIVE = 2,
	ET_GLOBAL = 3,
	ET_MEMORY = 4,
	ET_OFFSET = 5,
	ET_BAD = 8,
};

#define MCOVERHEAD (offsetof(struct entity_hash, mem)+sizeof(struct mementity))
#define FCOVERHEAD (offsetof(struct entity_hash, mem)+sizeof(struct mementity)+sizeof(off64_t))

static inline void *fd2ent(int fd) { return INT2PTR(fd); }
static inline struct mementity *mem2ent(struct entity_hash *h) { return h->mem; }
static inline void *hash2ent(struct entity_hash *h) {
	return (h->type&ET_MEMORY) ? mem2ent(h) : fd2ent(h->fd);
}
static inline struct entity_hash *ent2mem(void *e) { return list_entry(e, struct entity_hash, mem); }
static inline int hasheq(const unsigned char h1[16], const unsigned char h2[16]) {
	return	*(int64_t *)(h1+0) == *(int64_t *)(h2+0) &&
		*(int64_t *)(h1+8) == *(int64_t *)(h2+8);
}

static inline void hashcp(unsigned char h1[16], const unsigned char h2[16]) {
	*(int64_t *)(h1+0) = *(int64_t *)(h2+0);
	*(int64_t *)(h1+8) = *(int64_t *)(h2+8);
}


extern int tsc4_fdcache __init__;
extern int tsc4_fdcache1 __init__;
extern int tsc4_fdcache_negative __init__;
extern int cachelockmode __init__;
#define CLM_LOCKLESS	0
#define CLM_GLOBAL	1
#define CLM_SINGLE	2
#define CLM_FUTEX	3
#define CLM_MUTEX	4
#define CLM_SYSVSEM	5

