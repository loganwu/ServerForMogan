#include "util.h"

char *ll2str(char *p, int64_t ln) {
	int c;
	uint32_t n;

	if(ln<0) { *p++ = '-'; ln = -ln; }
	if((ln>>32)!=0) goto high;
	n = ln & 0xFFFFFFFFLL;

	if(n<10) { c = 1; goto len1; }
	if(n<100) { c = 2; goto len2; }
	if(n<1000) { c = 3; goto len3; }
	if(n<10000) { c = 4; goto len4; }
	if(n<100000) { c = 5; goto len5; }
	if(n<1000000) { c = 6; goto len6; }
	if(n<10000000) { c = 7; goto len7; }
	if(n<100000000) { c = 8; goto len8; }
	if(n<1000000000) { c = 9; goto len9; }
high:
	if(ln<10000000000LL) { c = 10; goto len10; }
	if(ln<100000000000LL) { c = 11; goto len11; }
	if(ln<1000000000000LL) { c = 12; goto len12; }
	if(ln<10000000000000LL) { c = 13; goto len13; }
	if(ln<100000000000000LL) { c = 14; goto len14; }
	if(ln<1000000000000000LL) { c = 15; goto len15; }
	if(ln<10000000000000000LL) { c = 16; goto len16; }
	if(ln<100000000000000000LL) { c = 17; goto len17; }
	if(ln<1000000000000000000LL) { c = 18; goto len18; }
	c = 19;
	p[18] = 0x30 | (ln%10); ln/=10;
len18:  p[17] = 0x30 | (ln%10); ln/=10;
len17:  p[16] = 0x30 | (ln%10); ln/=10;
len16:  p[15] = 0x30 | (ln%10); ln/=10;
len15:  p[14] = 0x30 | (ln%10); ln/=10;
len14:  p[13] = 0x30 | (ln%10); ln/=10;
len13:  p[12] = 0x30 | (ln%10); ln/=10;
len12:  p[11] = 0x30 | (ln%10); ln/=10;
len11:  p[10] = 0x30 | (ln%10); ln/=10;
len10:  p[9] = 0x30 | (ln%10); ln/=10;
	n = ln;
len9:	p[8] = 0x30 | (n%10); n/=10;
len8:	p[7] = 0x30 | (n%10); n/=10;
len7:	p[6] = 0x30 | (n%10); n/=10;
len6:	p[5] = 0x30 | (n%10); n/=10;
len5:	p[4] = 0x30 | (n%10); n/=10;
len4:	p[3] = 0x30 | (n%10); n/=10;
len3:	p[2] = 0x30 | (n%10); n/=10;
len2:	p[1] = 0x30 | (n%10); n/=10;
len1:	p[0] = 0x30 | n;
	return p+c;
}

