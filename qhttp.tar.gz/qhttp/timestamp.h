#include <time.h>

extern const char * const weekname[];
extern const char * const monthname[];

extern const char weekstr[];
extern const char mdaystr[];
extern const char monthstr[];
extern const char yearstr[];
extern const char secondstr[];

struct __tstr {
	uint32_t wname;
	uint32_t mday;
	uint32_t mname;
	uint32_t year;
	char s[1]; 
	uint16_t hour;
	char c1[1];
	uint16_t min;
	char c2[1];
	uint16_t sec;
	uint32_t gmt;
	char n[1];
} __attribute__((packed));

/* this routine 10 times faster than gmtime_r + sprintf */
static inline void gmtimestr(time_t tsrc, char *str) {
	struct __tstr *t = (struct __tstr *)str;

#if SYS_GMTIME
	struct tm tm;
	gmtime_r(&tsrc, &tm);
	t->wname = ((uint32_t *)weekstr)[tm.tm_wday];
	t->mday = ((uint32_t *)mdaystr)[tm.tm_mday];
	t->mname = ((uint32_t *)monthstr)[tm.tm_mon];
	t->year = ((uint32_t *)yearstr)[tm.tm_year-70];
	t->s[0] = ' ';
	t->hour = ((uint16_t *)secondstr)[tm.tm_hour];
	t->c1[0] = ':';
	t->min = ((uint16_t *)secondstr)[tm.tm_min];
	t->c2[0] = ':';
	t->sec = ((uint16_t *)secondstr)[tm.tm_sec];
	t->gmt = *(uint32_t *)" GMT";
	t->n[0] = '\0';
#else
	int year, month;

	t->sec = ((uint16_t *)secondstr)[tsrc%60];
	tsrc /= 60;

	t->min = ((uint16_t *)secondstr)[tsrc%60];
	tsrc /= 60;

	t->hour = ((uint16_t *)secondstr)[tsrc%24];
	tsrc /= 24;

	t->wname = ((uint32_t *)weekstr)[(tsrc+4)%7];

	tsrc += 365*2-59;

	year = (tsrc*4+3) / (365*4+1);
	tsrc = tsrc - year*365 - year/4 + 31;

	month = tsrc * 17 / 520;
	tsrc = tsrc - month * 520 / 17;

	t->mday = ((uint32_t *)mdaystr)[tsrc];

	if(month < 11) {
		month++;
		year -= 2;
	} else {
		month -= 11;
		year--;
	}

	t->mname = ((uint32_t *)monthstr)[month];
	t->year = ((uint32_t *)yearstr)[year];

	t->s[0] = ' ';
	t->c1[0] = ':';
	t->c2[0] = ':';
	t->gmt = *(uint32_t *)" GMT";
	t->n[0] = '\0';
#endif
}

extern char * time2alogstr(char *str, time_t tsrc);
extern char * time2logstr(char *str, time_t tsrc);
extern time_t str2time(const char *str);
