#include <sys/cdefs.h>

__BEGIN_DECLS

#include <stdarg.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdint.h>

#undef __attr_const__
#define __attr_const__ __attribute__((__const__))

#undef __attr_cdecl__
#if __x86_64__
#define __attr_cdecl__ /* */
#else
#define __attr_cdecl__ __attribute__((__cdecl__))
#endif

#undef __attr_regparm__
#define __attr_regparm__(x) __attribute__((__regparm__(x)))

#undef __attr_pure__
#if __GNUC__ == 2 && __GNUC_MINOR__ < 96
#define __attr_pure__	/* */
#else
#define __attr_pure__	__attribute__((__pure__))
#endif

#undef __attr_nonnull__
#if __GNUC__ == 2 && __GNUC_MINOR__ < 96
#define __attr_nonnull__(x)	/* */
#else
#if __GNUC_MINOR__ < 3
#define __attr_nonnull__(x)	/* */
#else
#define __attr_nonnull__(x) __attribute__((__nonnull__(x)))
#endif
#endif

#undef __attr_printf__
#define __attr_printf__(x,y) __attribute__((__format__(printf,x,y)))

#undef __attr_malloc__
#if __GNUC__ == 2 && __GNUC_MINOR__ < 96
#define __attr_malloc__	/* */
#else
#define __attr_malloc__ __attribute__((__malloc__))
#endif

typedef void *entity_t;

/* this structure may extended in future version */ 
typedef
struct callback_data {
	int32_t tid;	/* 0..config_working_threads-1 */
	void *priv;
	const char *host;
	char *url;	/* config_maxurllen */
	char *buf;	/* buflen */
	int32_t buflen;	/* 4096 */
	int32_t dirlen;
	const char *mime;	/* NULL */
	int32_t datalen;
	entity_t entity; /* entity from get_entity */
	const char *cookie;
	uint32_t addr;
	uint32_t speed; /* K/s, 0=unlimited */
	uint32_t expire; /* Expire/max-age */
	int64_t offset;	/* partial entity */
	time_t mtime;		/* last modified */
	void *ftarget;
	int16_t reason;
	uint8_t method;
	uint8_t retry;
	int8_t has_ims:1; /* If-Modified-Since */
	int8_t has_iums:1; /* If-Unmodified-Since */
	int8_t has_ir:1; /* If-Range */
	int32_t flags_reserved:29;
} cbdata_t;

struct forward_target {
	/* flags, total 16 bits */
	uint8_t  has_counter:1;
	uint8_t  connect_timeout:4;
	uint16_t reserved:11;
	uint16_t port;
	uint32_t addr;
	int (*callback)(struct callback_data *);
	int (*response)(struct callback_data *);
	/* counters, optional is has_counter==0 */
	volatile int count_inuse;
	volatile int count_access;
	volatile int count_error;
	char *upath;
};

/*filter callback*/
typedef int (*cbfunc_t)(cbdata_t *)__attr_cdecl__ __attr_regparm__(0);
/*shutdown/privilege task callback*/
typedef void (*cbtask_t)(void *)__attr_cdecl__ __attr_regparm__(0);

#define RF_ENTITY	0x400		/*return opened file/entity */
#define RF_SUB_ENTITY	0xC00
#define RF_FILE_HANDLE	0x1400
#define RF_PATHNAME	0x800		/*return pathname in buf*/
#define RF_URL		0x1000		/*return target url in url */
#define RF_VHOST	0x2000		/*NOT IMPLEMENTED*/
#define RF_HOST		0x4000		/*NOT IMPLEMENTED*/
#define RF_FORWARD_TARGET	0x10400	/*forward to another host */
#define RF_SFORWARD_TARGET	0x10800	/*store-forward to another host */
#define RF_FORWARD_GROUP	0x10C00	/*forward to host group */
#define RF_PRIVATE	0x40000000	/*Cache-Control: private */
#define RF_NOCACHE	0x80000000	/*Cache-Control: no-cache */
#define RF_PUBLIC	0xC0000000	/*Cache-Control: public */

#define RC_CONTINUE	0		/* contine next filter */
#define RC_OK		200		/* return context in buf/mime/datalen */
#define RC_REDIRECT	301		/* redirect to url */
#define RC_REDIRECT_TMP	302		/* redirect to url */
#define RC_DENIED	403		/* permission denied, forbidden */
#define RC_NOT_FOUND	404		/* file not found */
#define RC_SERVER_ERROR	500		/* server internal error */
#define RC_NOT_SUPPORT	501		/* method not support */
#define RC_OVERLOADED	503		/* server overloaded */

#define HTTP_METHOD_GET 	0
#define HTTP_METHOD_POST	1
#define HTTP_METHOD_HEAD	2

extern const char config_syscall_method[];
extern const char config_thread_mode[];
extern const int config_largefile_support;
extern const int config_rcvbufsz;
extern const int config_sndbufsz;
extern const int config_maxurllen;
extern const int config_maxhostlen;
extern const int config_maxfds;
extern const int config_ncpus;
extern const int config_maximum_connections;
extern const int config_use_vhost;
extern const char *config_poll_mode;
extern const int config_working_threads;
extern const uint64_t tsc_per_msec;
extern const uint64_t tsc_per_sec;
extern const uint64_t tsc_per_min;
extern const uint64_t tsc_per_hour;

/* interface, only plugin_load is mandantory */
extern void plugin_preload(void) __attribute__((constructor));	/*optional*/
extern void plugin_finish(void) __attribute__((destructor));	/*optional*/

__attr_cdecl__ __attr_regparm__(0)
extern void plugin_load(int argc, const char * const *argv);

/* API */
/* printf replacement */
__attr_cdecl__ __attr_nonnull__(1) __attr_printf__(1,2) __attr_regparm__(0)
extern void cprintf(const char *fmt,...);

/* send to master logfile(httpd.log) and stdout */
__attr_cdecl__ __attr_nonnull__(1) __attr_printf__(1,2) __attr_regparm__(0)
extern void lprintf(const char *fmt,...);

/* decode url to filename, resolve escape, strip /./ and /../ and query string */
__attr_cdecl__ __attr_nonnull__(1) __attr_nonnull__(2) __attr_regparm__(0)
extern int decode_url(const char *vhostname, const char *url, char *filename, int len);

/* task before server exit, called in reverse order */
__attr_cdecl__ __attr_nonnull__(1) __attr_regparm__(0)
extern int register_shutdown_callback(cbtask_t cb, void *cbpriv);

/* task in privilege context, calling interval is 10sec or less */
__attr_cdecl__ __attr_nonnull__(1) __attr_regparm__(0)
extern int register_privilege_task(cbtask_t cb, void *cbpriv);

/* filter process URL */
__attr_cdecl__ __attr_nonnull__(3) __attr_regparm__(0)
extern int register_url_filter(const char *host, int order, cbfunc_t cb, void *cbpriv);

/* read integer value */
__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(0)
extern int myconfig_get_intval(const char *key, int default_value);

/* read string value */
__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(0)
extern const char * myconfig_get_value(const char *key);

/* read multi-line value */
__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(0)
extern const char * myconfig_get_multivalue(const char *key, int index);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_nonnull__(2)  __attr_regparm__(0)
extern const char *getparam( char const * const * argv, char const *param);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_nonnull__(2)  __attr_regparm__(0)
extern int getintparam( char const * const argv, char const *param, int defval);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(0)
extern int cookie_offset(char const * name);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(0)
extern int cookie_maxlength(char const * name);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(0)
extern int cookie_auth_uin(char const * cookie, int expire);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(2) __attr_regparm__(0)
extern int panel_auth(int panel_uin, char const * panel_key, int expire);

/* only call from working thread / url filter */
__attr_cdecl__ __attr_nonnull__(1) __attr_nonnull__(2)  __attr_regparm__(0)
extern int get_entity(const char *filename, entity_t *ent);

/* must call from same working thread as get_entity() */
__attr_cdecl__ __attr_regparm__(0)
extern void put_entity(entity_t);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(1)
extern int entity_expired(entity_t);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(1)
extern int entity_size32(entity_t ent);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(1)
extern int64_t entity_size64(entity_t ent);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(1)
extern int entity_fileno(entity_t ent);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(1)
extern const char * entity_addr(entity_t ent);

__attr_cdecl__ __attr_nonnull__(1) __attr_nonnull__(2) __attr_regparm__(0)
extern int entity_read(entity_t ent, char *buf, int len, int offset);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(1)
extern time_t entity_timestamp(entity_t ent);

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(1)
extern const char *entity_mime_type(entity_t *ent);

__attr_cdecl__ __attr_regparm__(2) __attr_nonnull__(1) __attr_nonnull__(2)
void entity_set_mime_type(entity_t ent, const char *mimetype);

static inline int64_t entity_size(entity_t ent) { return entity_size64(ent); }

__attr_cdecl__ __attr_pure__ __attr_nonnull__(1) __attr_regparm__(1)
extern void *entity_private(entity_t ent);

__attr_cdecl__ __attr_nonnull__(1) __attr_regparm__(2)
extern void entity_set_private(entity_t ent, void *val);

__attr_cdecl__ __attr_nonnull__(1) __attr_regparm__(0)
extern void entity_updateinfo(entity_t ent);

__attr_cdecl__ __attr_malloc__ __attr_regparm__(0)
extern void *shalloc(int);

__attr_cdecl__ __attr_malloc__ __attr_regparm__(0)
extern char *shdup(char *);

__attr_cdecl__ __attr_nonnull__(1) __attr_regparm__(0)
extern void *find_forward_group(const char *);

__attr_cdecl__ __attr_nonnull__(1) __attr_regparm__(0)
extern int open_global_file(const char *, int, int);

__attr_cdecl__ __attr_nonnull__(1) __attr_regparm__(0)
extern int rotate_global_file(const char *, int, int);

#if __WORDSIZE==64
struct stat;
__attr_cdecl__ __attr_nonnull__(1) __attr_regparm__(0)
extern int register_file_monitor(const char *,
		void (*)(int, void *, struct stat *), void *);
#else
struct stat64;
__attr_cdecl__ __attr_nonnull__(1) __attr_regparm__(0)
extern int register_file_monitor(const char *,
		void (*)(int, void *, struct stat64 *), void *);
#endif

__attr_cdecl__ __attr_nonnull__(2) __attr_regparm__(0)
extern int register_sigio_callback(int, void(*)(void*, int), void *);

__attr_cdecl__ __attr_regparm__(0)
extern int delay_close(int, int);

__attr_cdecl__ __attr_nonnull__(1) __attr_regparm__(0)
extern int delay_execute(void(*)(void *), void *, int);

__attr_cdecl__ __attr_regparm__(0)
extern int msglog(const char *, uint32_t, time_t, const void *, int);

__attr_cdecl__ __attr_regparm__(0)
extern int vmsgprintf(const char *, uint32_t, time_t, const char *, va_list);

__attr_cdecl__ __attr_nonnull__(4) __attr_regparm__(0)
extern int msgprintf(const char *, uint32_t, time_t, const char *, ...);

__attr_cdecl__ __attr_regparm__(0)
extern int change_referer_control(int);

__attr_cdecl__ __attr_regparm__(0) __attr_nonnull__(2) __attr_nonnull__(3)
extern int str_explode(const char *, char *, char *[], int);

__END_DECLS
