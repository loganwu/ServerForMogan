#ifndef _H_DAEMON_H
#define _H_DAEMON_H

volatile extern int stop;
volatile extern int restart;
extern int daemon_start(int, char **);
extern void daemon_close_output(void);
extern int daemon_background(void);
extern void daemon_stop(void);
extern void daemon_set_title(const char *title);
extern void daemon_set_name(const char *title);
extern void daemon_emergent_restart(int signo);
#endif
