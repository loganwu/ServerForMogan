struct pattern;

extern struct pattern *create_pattern(void);
extern void add_prefix_pattern(struct pattern *, const char *, void *);
extern void add_suffix_pattern(struct pattern *, const char *, void *);
extern void add_pattern(struct pattern *, const char *, void *);
extern void *match_pattern(struct pattern *, const char *, void *);
extern void *match_url_pattern(struct pattern *, const char *, void *);
