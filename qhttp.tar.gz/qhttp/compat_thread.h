#ifndef __H_COMPAT_THREAD_H_
#define __H_COMPAT_THREAD_H_

#include <unistd.h>
#include "syscall.h"
#include "realconfig.h"

#ifndef __WALL
#define __WALL                0x40000000
#endif

#ifndef CLONE_THREAD
#define CLONE_THREAD 0x10000
#endif

#if !COMPAT_GLIBC && __GLIBC_PREREQ(2,4)
#include <sched.h>
#define sys_unshare unshare
#else
static inline int sys_unshare(int flags) {
	return syscall(__NR_unshare, flags);
}
#endif

#if !INLINE_SYSCALL
static inline int fast_gettid(void) {
	return syscall(__NR_gettid);
}
static inline int fast_tkill(int tid, int signo) {
	return syscall(__NR_tkill, tid, signo);
}
static inline int fast_tgkill(int tgid, int tid, int signo) {
	return syscall(__NR_tgkill, tgid, tid, signo);
}
static inline int fast_exit_group(int status) {
	return syscall(__NR_exit_group, status);
}
static inline int fast_set_tid_address(int *tidptr) {
    return syscall(__NR_set_tid_address, tidptr);
}
#endif

#endif
