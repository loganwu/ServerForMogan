#ifndef __TWS_HTTP_STAT_H
#define __TWS_HTTP_STAT_H
#include "realconfig.h"

#if ISDSTAT_SUPPORT
#include "atomic.h"
#define MAXHOSTLOG	100
struct counters {
	volatile int stop;
	atomic_t totalcon;
	atomic_t totalreq;
	atomic_t workcon;
    atomic_t currcon;
	atomic_t overflow;
	atomic_t idleswitch;
	atomic_t idleresume;
	atomic_t pipereq;
    atomic_t fcachefds;
    atomic_t ccachefds;
    atomic_t proxyfds;
    atomic_t relayerror;
    atomic_t fcachematch;
    atomic_t errorreq;
    atomic_t error404;
    atomic_t error550;
    atomic_t error551;
#if HAS_ATOMIC8
	atomic8_t bytes;
#else
	atomic_t kbytes;
	atomic_t bytes;
#endif
	atomic_t openfds;
	atomic_t opencnt;
        uint16_t ioperf;
        uint16_t ioperf_avg;
	uint16_t hostnum;
	struct {
		uint32_t msgid;
		atomic_t nreq;
#if HAS_ATOMIC8
		atomic8_t bytes;
#else
		atomic_t kbytes;
		atomic_t bytes;
#endif
	} host[MAXHOSTLOG+1];
};

extern char *statfile;
extern int statfd;
extern struct counters *countermap;
extern int init_statistics(void);
extern void pipe_statistics_data(int);
extern void free_statistics(void);
extern void statistics(void);

extern void fdtracer_open(int fd, int update, unsigned long thread, const char* srcfile, const char* file, int line);
extern void fdtracer_close(int fd, unsigned long thread, const char* file, int line);

#define ISDSTAT(x) x
//#define ENABLE_FDTRACE
#ifdef ENABLE_FDTRACE
#include <pthread.h>
#define FDTRACER_OPEN(fd,update,thread,srcfile) fdtracer_open(fd,update,thread,srcfile,__FILE__,__LINE__)
#define FDTRACER_CLOSE(fd,thread) fdtracer_close(fd,thread,__FILE__,__LINE__)
#else
#define FDTRACER_OPEN(x,b,y,z) /* */
#define FDTRACER_CLOSE(x,y) /* */
#endif // ENABLE_FDTRACE
#else
#define ISDSTAT(x) /* */
#define FDTRACER_OPEN(x,y,z) /* */
#define FDTRACER_CLOSE(x,y) /* */
#endif

#endif // __TWS_HTTP_STAT_H
