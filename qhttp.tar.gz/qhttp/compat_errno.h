#ifndef __COMPAT_ERRNO_H
#define __COMPAT_ERRNO_H
#include "realconfig.h"
#if INLINE_SYSCALL
#define FAST_ERRNO(x)	/* */
#else
#include <errno.h>
#define FAST_ERRNO(x)	(x = (long)x==-1?-errno:x)
#endif
#define FIX_ERRNO(x)	(errno=-(x))
#endif // __COMPAT_ERRNO_H
