/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include "compat_ctype.h"
#include "compat_stat64.h"
#include "compat_sendfile64.h"

#include "autoconfig.h"
#if PLUGIN_SUPPORT
#include "myconfig.h"
#include "util.h"
#include "global.h"
#include "log.h"
#include "plugin.h"
#include "vhost.h"
#include "entity.h"
#include "shmem.h"
#include "thread.h"
#include "profile.h"

int config_pagesize;
#if INLINE_SYSCALL
const char config_syscall_method[] = "inline";
#else
const char config_syscall_method[] = "libc";
#endif
char config_thread_mode[32];
const int config_largefile_support = 1;
#if THROTTLE_SUPPORT
const int config_throttle_support = 1;
#else
const int config_throttle_support = 0;
#endif
int config_rcvbufsz;
int config_sndbufsz;
int config_maxurllen;
int config_maxhostlen;
int config_maxfds;
int config_ncpus;
int config_maximum_connections;
int config_use_vhost;
char *config_poll_mode;
int config_working_threads;
int config_strip_query_string;
uint64_t tsc_per_msec;
uint64_t tsc_per_sec;
uint64_t tsc_per_min;
uint64_t tsc_per_hour;

extern void * loadlib(const char *libfile, int argc, char **argv);
extern void closelib(const char *libfile, int argc, char **argv);

struct plugin {
	char *buf;
	int argc;
	void *lib;
	struct plugin *next;
	char *argv[0];
} *plugin_list = NULL;

static int plugin_loaded = 0;
static int default_order;


int load_plugins(void) {
	if(has_plugin==0) return 0;

	int i, j;
	char *p0;
	char *p;
	void *lib;
	int argc;
	char *argv[100];
	struct plugin *plugin;

	strcpy(config_thread_mode, "posix");
	config_rcvbufsz = recvbufsz;
	config_sndbufsz = sendbufsz;
	config_maxurllen = maxurllen;
	config_maxhostlen = maxhostlen;
	config_maxfds = maxfds;
	config_pagesize = pagesize;
	config_ncpus = ncpus;
	config_maximum_connections = mconns;
	if(use_vhost==1)
		config_use_vhost = use_vhost==1;
	if(pollmode)
	    config_poll_mode = "epoll";
	else
	    config_poll_mode = "rtsignal";
	config_working_threads = nworks;
	config_strip_query_string = strip_query_string;
	tsc_per_msec = tscmsec;
	tsc_per_sec = tscsec;
	tsc_per_min = tscmin;
	tsc_per_hour = tschour;

	for(i=0; (p0=myconfig_get_multivalue("plugin",i)); i++) {
		if(p0[0]=='\0') continue;
		p = shdup(p0);
		if(p==NULL) return -ENOMEM;
		argc = str_explode(NULL, p, argv, 99);
		if(argc==0) continue;
		argv[argc] = NULL;
		default_order = 100;
		for(j=0; j<argc; j++) {
			if(!strncmp(argv[j], "order=", 6)) {
				default_order = atoi(argv[j]+6);
				break;
			}
		}
		if(default_order<=0) default_order = 100;
		lib = loadlib(argv[0], argc, argv);
		if(lib==NULL) return -1;

		plugin = shallocz(sizeof(struct plugin)+(argc+1)*sizeof(char *));
		if(plugin==NULL) return -ENOMEM;
		plugin->buf = p;
		plugin->argc = argc;
		memcpy(plugin->argv, argv, (argc+1)*sizeof(char *));
		plugin->lib = lib;
		plugin->next = plugin_list;
		plugin_list = plugin;
		lprintf("Filter Loaded: %s\n", p0);
	}

	plugin_loaded = 1;
	return 0;
}

void free_plugins(void) {
	struct plugin *p;
	while(plugin_list) {
		p = plugin_list;
		plugin_list = p->next;
		closelib(p->lib, p->argc, p->argv);
	}
}

static inline int add_filtercb(struct filtercb **hdr, int order, cbfunc_t cb, void *cbpriv) {
	struct filtercb *f, *p;

	f = shalloc(sizeof(struct filtercb));
	if(f==NULL) return -ENOMEM;

	if(order <= 0) order = 100;
	f->order = order;
	f->func = cb;
	f->priv = cbpriv;

	while( (p = *hdr) ) {
		if(p->order <= order) {
			hdr = &p->next;
		} else {
			f->next = p;
			*hdr = f;
			return 0;
		}
	}

	f->next = NULL;
	*hdr = f;
	return 0;
}

int register_url_filter(const char *host, int order, cbfunc_t cb, void *cbpriv) {
	struct vhost *vh;

	if(plugin_loaded) return -1;
	if(cb==NULL) return 0;
	if(host==NULL || host[0]=='\0')
		host = "@default";
	else if(strlen(host) > maxhostlen)
		return -1;
	vh = add_vhost(host, VH_DISABLED);
	return add_filtercb(&vh->plugin, order, cb, cbpriv);
}

const char *getparam( char const * const * argv, char const *param) {
	int plen;
	if(param==NULL || param[0]=='\0') return NULL;
	for(plen = strlen(param); argv[0]; argv++) {
		if(!strncasecmp(argv[0], param, plen) && argv[0][plen]=='=')
			return argv[0] + plen + 1;
	}
	return NULL;
}

int getintparam( char const * const *argv, char const *param, int defval) {
	int plen;
	if(param==NULL || param[0]=='\0') return defval;
	for(plen = strlen(param); argv[0]; argv++) {
		if(!strncasecmp(argv[0], param, plen) && argv[0][plen]=='=')
		{
			param = argv[0] + plen + 1;
			if(is_digit(param[0]) || 
				(param[0]=='-' && is_digit(param[1]))
			  )
				return atoi(param);
			else if(!strcasecmp(param, "On"))
				return 1;
			else if(!strcasecmp(param, "Off"))
				return 0;
			else if(!strcasecmp(param, "Yes"))
				return 1;
			else if(!strcasecmp(param, "No"))
				return 0;
			else if(!strcasecmp(param, "True"))
				return 1;
			else if(!strcasecmp(param, "False"))
				return 0;
			else if(!strcasecmp(param, "enable"))
				return 1;
			else if(!strcasecmp(param, "disable"))
				return 0;
			else if(!strcasecmp(param, "enabled"))
				return 1;
			else if(!strcasecmp(param, "disabled"))
				return 0;
			else
				break;
		}
	}
	return defval;
}

#if USE_TLS
static __thread struct worker * myworker __attribute__((TLS_MODEL));
void set_worker_key(struct worker *wt) {
	myworker = wt;
}
#else

static pthread_key_t myworkerkey;
static pthread_once_t myworkeronce = PTHREAD_ONCE_INIT;

static void create_worker_key(void) {
	pthread_key_create(&myworkerkey, NULL);
}
void set_worker_key(struct worker *wt) {
	pthread_once(&myworkeronce, create_worker_key);
	pthread_setspecific(myworkerkey, wt);
}
#endif

int get_entity(const char *filename, void **pent) {
#if USE_TLS
	struct worker *wt = myworker;
#else
	struct worker *wt = pthread_getspecific(myworkerkey);
#endif
	if(wt==NULL) return -1;
	int rv;
	PROFILE_START;
	rv = get_entity_internal(wt, filename, pent);
	PROFILE_WORKER(PROFILE_GET_ENTITY);
	return rv;
}

void put_entity(void *ent) {
#if USE_TLS
	struct worker *wt = myworker;
#else
	struct worker *wt = pthread_getspecific(myworkerkey);
#endif
	if(wt==NULL) return;
	PROFILE_START;
	put_entity_internal(wt, ent);
	PROFILE_WORKER(PROFILE_PUT_ENTITY);
}

__attr_cdecl__ __attr_regparm__(1)
off64_t entity_size64(void *ent) {
	return  isntfdptr(ent) ? -1 : isptr(ent) ? ((struct mementity *)ent)->size : fdent(ent)->size;
}

__attr_cdecl__ __attr_regparm__(1)
int entity_size32(void *ent) {
	off64_t size = entity_size64(ent);
	if(size >= 0x80000000LL) return -1;
	return size;
}

__attr_cdecl__ __attr_regparm__(1)
int entity_fileno(void *ent) {
	return  isfd(ent) ? PTR2INT(ent) : -1;
}

__attr_cdecl__ __attr_regparm__(1)
const char * entity_addr(void *ent) {
	if(!isptr(ent)) return NULL;
	struct mementity *ent1 = ent;
	if(isfd(ent1->fd)) return NULL;
	return ent1->data;
}

__attr_cdecl__ __attr_regparm__(0)
int entity_read(void *ent, char *buf, int len, int offset) {
	if(isntfdptr(ent))
		return 0;
	if(isfd(ent))
		return fast_pread(PTR2INT(ent), buf, len, offset);
	struct mementity *ent1 = ent;
	if(offset < 0 || offset > ent1->size) return 0;
	if(offset + len > ent1->size) len = ent1->size - offset;
	if(isfd(ent1->fd)) 
		return fast_pread(ent1->fd, buf, len, ent1->offset[0] + offset);
	memcpy(buf, ent1->data + offset, len);
	return len;
}

__attr_cdecl__ __attr_regparm__(1)
time_t entity_timestamp(void *ent) {
	return isntfdptr(ent) ? 0 : isptr(ent) ? ((struct mementity *)ent)->mtime : fdent(ent)->mtime;
}

__attr_cdecl__ __attr_regparm__(1)
const char *entity_mime_type(void *ent) {
	return isntfdptr(ent) ? NULL : isptr(ent) ? ((struct mementity *)ent)->mime : fdent(ent)->mime;
}

__attr_cdecl__ __attr_regparm__(2)
void entity_set_mime_type(void *ent, const char *mimetype) {
	isptr(ent) ? ((struct mementity *)ent)->mime = mimetype :
	isfd(ent) ?  fdent(ent)->mime = mimetype: 0;
}

__attr_cdecl__ __attr_regparm__(1)
void *entity_private(void *ent) {
	return NULL;
}

__attr_cdecl__ __attr_regparm__(2)
void entity_set_private(void *ent, void *val) {
}

__attr_cdecl__ __attr_regparm__(0)
void entity_updateinfo(void * ent) {
	stat64_t st;

	if(isfd(ent)) {
	    fast_filestat(PTR2INT(ent), &st);
	    fdent(ent)->size = st.st_size;
	    fdent(ent)->mtime = st.st_mtime;
	}
}

__attr_cdecl__ __attr_regparm__(0)
int change_referer_control(int control) {
	int old = referer_checking;
	if(control >= 0 && control <= 2)
		referer_checking = control;
	return old;
}

#if 0
int _str_explode(const char *, char *, char *[], int)
	__attribute__((alias("str_explode")));
#endif
#endif
