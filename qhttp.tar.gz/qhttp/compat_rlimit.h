#ifndef __COMPAT_RLIMIT_H_
#define __COMPAT_RLIMIT_H_

#include <features.h>
#include <sys/resource.h>
#if !__x86_64__
#include "realconfig.h"
#if !COMPAT_GLIBC && __GLIBC_PREREQ(2,2)
#else
#include <unistd.h>
#include "syscall.h"
#define getrlimit compat_getrlimit
#define setrlimit compat_setrlimit
static inline int compat_getrlimit(int resource, struct rlimit *rlim){
#ifdef __NR_ugetrlimit
	return syscall(__NR_ugetrlimit, resource, rlim);
#else
	return syscall(__NR_getrlimit, resource, rlim);
#endif
}
static inline int compat_setrlimit(int resource, const struct rlimit *rlim) {
	return syscall(__NR_setrlimit, resource, rlim);
}

#endif
#endif

#ifndef RLIMIT_SIGPENDING
#define RLIMIT_SIGPENDING	11
#endif

#endif
