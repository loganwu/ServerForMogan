#include "myalloc.h"
#include <string.h>
#include "namemap.h"
#include "task.h"

struct nameslot {
	struct nameslot *next;
	char name[0];
};

struct namemap {
	unsigned int valsz;
	unsigned int hashbase;
	int num;
	char ***fasttbl;
	struct nameslot *hashtbl[0];
};

static unsigned int hash_string(const char *p) {
	unsigned int h = 0;
	char c;
	while((c=*p++))
	    h = h * 17 + c;
	return h;
}
struct namemap *CreateNameMap(unsigned int hashbase, unsigned int valsz) {
	struct namemap *map = calloc(1, sizeof(struct namemap) * sizeof(void *)*hashbase);
	map->valsz = valsz;
	map->hashbase = hashbase;
	return map;
};

void *AddNameToMap(struct namemap *map, const char *name) {
	if(map==NULL) return NULL;
	int nl = strlen(name);
	char *ptr = malloc(map->valsz+sizeof(struct nameslot) + nl + 1);
	memset(ptr, 0, map->valsz);
	struct nameslot *ns = (struct nameslot *)(ptr + map->valsz);
	memcpy(ns->name, name, nl+1);
	int h = hash_string(name) % map->hashbase;
	ns->next = map->hashtbl[h];
	map->hashtbl[h] = ns;
	map->num++;

	if(map->fasttbl) {
		delay_free(map->fasttbl, 60);
		map->fasttbl = NULL;
	}
	return ptr;
}

void *GetNameFromMap(struct namemap *map, const char *name) {
	if(map==NULL) return NULL;
	int h = hash_string(name) % map->hashbase;
	if(map->fasttbl) {
		char **list = map->fasttbl[h];
		if(list) {
			int *cnt = (int *)(map->fasttbl + map->hashbase);
			int n0 = 0;
			int n1 = cnt[h];
			while(n0 <= n1) {
				int m = (n0+n1)/2;
				int c = strcmp(name, list[m]);
				if(c < 0) {
					n1 = m -1;
				} else if(c==0) {
					return list[m] - sizeof(struct nameslot) - map->valsz;
				} else {
					n0 = m + 1;
				}
			}
		}
	} else {
		struct nameslot *ns;
		for(ns = map->hashtbl[h]; ns; ns=ns->next) {
			if(!strcmp(name, ns->name))
				return (char *)ns - map->valsz;
		}
	}
	return NULL;
}

static int hashtblcmp(const void *a, const void *b) {
	return strcmp(*(const char **)a, *(const char **)b);
}

int BuildFastNameMap(struct namemap *map) {
	if(map->fasttbl) return 0;
	/* idx */
	char ***tbl = malloc(
			map->hashbase * sizeof(char **) +
			map->hashbase * sizeof(int) +
			map->num * sizeof(char *)
			);
	if(tbl==NULL) return -1;
	int *cnt = (int *)(tbl + map->hashbase);
	/* off */
	char **ptr = (char **)(cnt + map->hashbase);

	memset(tbl, 0, map->hashbase * sizeof(char **));
	memset(cnt, 0, map->hashbase * sizeof(int));

	int i;
	for(i=0; i<map->hashbase; i++) {
		if(map->hashtbl[i]==NULL) continue;
		int n;
		struct nameslot *ns;
		for(ns = map->hashtbl[i], n = 0; ns; ns=ns->next, n++)
			ptr[n] = ns->name;
		if(n>1) qsort(ptr, n, sizeof(char *), hashtblcmp);
		tbl[i] = ptr;
		cnt[i] = n-1;
		ptr += n;
	}
	map->fasttbl = tbl;
	return 1;
}

static void nullfunc(void *dummy){}
void FreeNameMap(struct namemap *map, void(*cleanfunc)(void *)) {
	int h;
	if(cleanfunc==NULL) cleanfunc = nullfunc;
	for(h = 0; h < map->hashbase; h++) {
		struct nameslot *ns;
		for(ns = map->hashtbl[h]; ns; ns=ns->next) {
			void *ptr = (char *)ns - map->valsz;
			cleanfunc(ptr);
			free(ptr);
		}
	}
	free(map);
}

void *IterateNameMap(struct namemap *map, void *ptr, int *idx) {
	struct nameslot *ns;
	if(ptr==NULL) {
		*idx = -1;
		ns = NULL;
	} else {
		ns = (struct nameslot *)((char *)ptr + map->valsz);
		ns = ns->next;
	}
	while(ns==NULL) {
		if(++*idx >= map->hashbase) return NULL;
		ns = map->hashtbl[*idx];
	}
	return (char *)ns - map->valsz;
}

const char *MapDataToName(struct namemap *map, void *ptr) {
	return ptr + map->valsz + sizeof(struct nameslot);
}

