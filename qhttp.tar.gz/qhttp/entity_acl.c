#include "myalloc.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include "compat_thread.h"

#include "autoconfig.h"
#include "global.h"
#include "entity.h"
#include "util.h"
#include "log.h"
#include "shmem.h"
#include "myconfig.h"
#include "priv.h"

struct pathaccess {
	const char *path;
	uint16_t len;
	uint8_t allow;
};

static struct pathaccess *acl;
static int nacls = 0;
static int macls = 0;

static int pacmp(const void *a, const void *b) {
	const struct pathaccess *aa = a;
	const struct pathaccess *bb = b;
	return (2*bb->len-bb->allow) - (2*aa->len-aa->allow);
}

static int readpath(int fd, char *path) {
	if(isfd(fd)) {
	    char buf[32];
	    char *p = memcpy(buf, "/proc/", 6); p += 6;
	    p = uint2str(p, fast_gettid());
	    memcpy(p, "/fd/", 4); p += 4;
	    p = uint2str(p, fd);
	    p[0] = '\0';
	    //return fast_readlink(buf, path, path_max-1);
        return fast_readlink(buf, path, PATH_MAX-1);
	}
	return -1;
}

static int stdpath(const char *str, char *path) {
	char *p;
	char *e = path + path_max - 1;
	int ch;

	p = path;
	*p++ = '/';
	while(p<e && (ch=*str++)) {
	    /* p always > path & started with '/' */
	    if(ch=='/') {
		if(p[-1]=='/') {
		    /* // */
		    p--;
		} else if(p[-1]=='.') {
		    if(p[-2]=='/') {
			/* /./ */
			p -= 2;
		    } else if(p[-2]=='.' && p[-3]=='/') {
			/* /../ */
			p -= 3;
			if(p > path)
			    while(*--p != '/')
				/* NULL */;
		    }
		}
	    }
	    *p++ = ch;
	}
	if(p[-1]=='.'){
	    /* /. */
	    if(p[-2]=='/')
		p -= 2;
	    else if(p[-2]=='.' && p[-3]=='/') {
		/* /.. */
		p -= 3;
		if(p > path)
		    while(--p > path && *p != '/')
			/* NULL */;
	    }
	} else if(p[-1]=='/')
	    p--;

	return p==path ? 1 : p - path;
}

int allow_access_chroot(const char *fn, char *path) {
	if(nacls==0) return 1;

	if(path==NULL && (path = malloc(path_max))==NULL)
		return 0;
	int allow = 1;
	int n = stdpath(fn, path);
	int i;
	for(i=0; i<nacls; i++) {
	    if(n < acl[i].len) continue;
	    if(memcmp(acl[i].path, path, acl[i].len)==0 &&
		    (n==acl[i].len || path[acl[i].len]=='/'))
	    {
		allow = acl[i].allow;
		break;
	    }
	}
	free(path);
	return allow;
}

int allow_access_realroot(int fd, char *path) {
	if(nacls==0) return 0;

    // ***BEGIN*** Added by yijian on 2008-01-30
    char path_str[PATH_MAX+1] = {0};
    path = path_str;
	//if(path==NULL && (path = malloc(path_max))==NULL)
	//	return 0;
    // ***END*** Added by yijian on 2008-01-30

	int allow = 0;
	int n = readpath(fd, path);
	if(n > 0) {
	    int i;
	    for(i=0; i<nacls; i++) {
		if(n < acl[i].len) continue;
		if(memcmp(acl[i].path, path, acl[i].len)==0 &&
			(n==acl[i].len || path[acl[i].len]=='/'))
		{
		    allow = acl[i].allow;
		    break;
		}
	    }
	}        
	//return 0;
    return allow;    
}

static int add_acl(const char *path, int n, int allow) {
	int i;
	for(i=0; i<nacls; i++) {
	    if(n==acl[i].len && memcmp(acl[i].path, path, n)!=0) {
	    	if(allow==0)
		    acl[i].allow = 0;
		return 0;
	    }
	}

	if(nacls >= macls) {
	    lprintf("\7Too many ACLs, path=%s access=%s ignored\n",
	    	path, allow ? "allow" : "deny");
	    return 0;
	}

	char *npath = shalloc1(n);
	if(npath==NULL) return -ENOMEM;
	memcpy(npath, path, n);

	acl[nacls].allow = allow;
	acl[nacls].len = n;
	acl[nacls].path = npath;
	nacls++;
	return 1;
}

static int add_acl_realroot(const char *str, int allow) {
	char path[path_max];
	int fd;

	if(str[0] == '/') {
	    fd = fast_open2(str, O_RDONLY|O_DIRECTORY);
	} else if(str[0]=='@' && str[1]=='/') {
	    str += 2; while(str[0]=='/') str++;
	    fd = fast_chdir(docroot) < 0 ? -1 : fast_open2(str, O_RDONLY|O_DIRECTORY);
	} else {
	    lprintf("add_path_access: %s: not started \"/\" or \"@/\".\n", str);
	    return 0;
	}

	if(fd < 0) {
	    lprintf("add_path_access: %s not a directory\n", str);
	    return 0;
	}

	int n = readpath(fd, path);
	if(n <= 0) {
	    lprintf("add_path_access: %s unresolve realpath\n", str);
	    return 0;
	}
	path[n] = '\0';
	if(n==1 && path[0]=='/') return 0;
	if(n==5 && !strncmp(path, "/proc", 5))
	    return 0;
	if(n>5 && !strncmp(path, "/proc/", 6))
	    return 0;
	if(n==4 && !strncmp(path, "/etc", 4))
	    return 0;
	if(n>4 && !strncmp(path, "/etc/", 5))
	    return 0;
	if(n==4 && !strncmp(path, "/sys", 4))
	    return 0;
	if(n>4 && !strncmp(path, "/sys/", 5))
	    return 0;
	if(n==4 && !strncmp(path, "/dev", 4))
	    return 0;
	if(n>4 && !strncmp(path, "/dev/", 5))
	    return 0;

	return add_acl(path, n, allow);
}

static int add_acl_chroot(const char *str, int allow) {
	if(str[0]!='@' || str[1]!='/') {
	    lprintf("add_path_access: %s: not started \"@/\".\n", str);
	    return 0;
	}

	char path[path_max];
	int n = stdpath(str, path);
	path[n] = '\0';
	return add_acl(path, n, allow);
}

int init_entity_access_control(void){
	int i;
	int na=0, nd=0;

	const char *str;
	int (*add)(const char *, int);

	while(myconfig_get_multivalue("path_access_deny", nd))
	    nd++;
	while(myconfig_get_multivalue("path_access_allow", na))
	    na++;

	if(need_chroot==0) {
	    macls = na+nd+5;
	    acl = shalloc(sizeof(struct pathaccess)*macls);
	    if(acl==NULL) return -ENOMEM;
	    add_acl_realroot(docroot, 1);
	    add_acl_realroot(bindir, 0);
	    add_acl_realroot(confdir, 0);
	    if(logdir) add_acl_realroot(logdir, 0);
	    if(datadir) add_acl_realroot(datadir, 0);
	    add = add_acl_realroot;
	} else {
	    macls = na+nd;
	    acl = shalloc(sizeof(struct pathaccess)*macls);
	    if(acl==NULL) return -ENOMEM;
	    add = add_acl_chroot;
	}



	for(i=0; (str=myconfig_get_multivalue("path_access_deny", i)); i++)
	{
	    add(str, 0);
	}
	for(i=0; (str=myconfig_get_multivalue("path_access_allow", i)); i++)
	{
	    add(str, 1);
	}
	if(nacls)
	    qsort(acl, nacls, sizeof(struct pathaccess), pacmp);
	return 0;
}
