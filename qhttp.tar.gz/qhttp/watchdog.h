
#include "atomic.h"
struct threadstat {
	int tid;
	atomic_t tickcnt;
	atomic_t reqcnt;
	int badcnt;
};

extern int watchdog_pid;
static inline void thread_reached(struct threadstat *ts) {
	if(ts)atomic_inc(&ts->tickcnt);
}
extern struct threadstat *get_threadstat(void);
extern int start_watchdog(void);
