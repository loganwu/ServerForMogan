#include <stddef.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>

#include "autoconfig.h"
#include "conn.h"
#include "list.h"
#include "shmem.h"
#include "memcache.h"
#include "log.h"

struct mch {
	uint32_t psize;
	uint32_t csize:31;
	uint8_t inuse:1;
	struct list_head list;
};

#if __WORDSIZE==64
#define MCLSTSZ	1024
#define MCBLKSZ	256
#else
#define MCLSTSZ	2048
#define MCBLKSZ	128
#endif

static struct list_head *memcache_freelist;
static struct list_head memcache_blocklist;
const unsigned int memcache_blocksize = MCBLKSZ;
unsigned int memcache_maxsize = 0;
unsigned int memcache_overhead = 0;
unsigned int memcache_freesize;

void *memcache_alloc(int size) {
	size = (size+memcache_overhead+MCBLKSZ-1) & ~(MCBLKSZ-1);

	int n;
	for(n=size/MCBLKSZ; n<MCLSTSZ; n++)
		if(!list_empty(memcache_freelist+n)) break;
	if(n==MCLSTSZ) {
		if(list_empty(memcache_freelist))
			return NULL;
		n = 0;
	}

	struct mch *ent;
	ent = list_entry(memcache_freelist[n].next, struct mch, list);
	list_del_init(&ent->list);
	memcache_freesize -= size;
	ent->inuse = 1;
	if(ent->csize==size) return &ent->list;
	struct mch *ent1 = (struct mch *)((char *)ent + size);
	struct mch *ent2 = (struct mch *)((char *)ent + ent->csize);
	ent1->csize = ent->csize - size;
	ent1->psize = size;
	ent->csize = size;
	ent2->psize = ent1->csize;
	n = ent1->csize / MCBLKSZ;
	if(n >= MCLSTSZ) n = 0;
	ent1->inuse = 0;
	list_add(&ent1->list, memcache_freelist+n);
	return &ent->list;
}

void memcache_free(void * ent0) {
	struct mch *ent = list_entry(ent0, struct mch, list);
	int n;

	if(ent->csize & (MCBLKSZ-1) || ent->csize==0) {
		lprintf("free BAD entity, csize=%x\n", ent->csize);
		return;
	}

	memcache_freesize += ent->csize;
	struct mch *ent1 = (struct mch *)((char *)ent - ent->psize);
	struct mch *ent2 = (struct mch *)((char *)ent + ent->csize);
	if(ent1->inuse==0) {
		list_del(&ent1->list);
		ent1->csize += ent->csize;
		ent = ent1;
		if(ent2->inuse==0) {
		    list_del(&ent2->list);
		    ent->csize += ent2->csize;
		    ent2 = (struct mch *)((char *)ent + ent->csize);
		}
		ent2->psize = ent->csize;
	} else {
		ent->inuse = 0;
		if(ent2->inuse==0) {
		    list_del(&ent2->list);
		    ent->csize += ent2->csize;
		    ent2 = (struct mch *)((char *)ent + ent->csize);
		    ent2->psize = ent->csize;
		}
	}
	n = ent->csize / MCBLKSZ;
	if(n >= MCLSTSZ) n = 0;
	ent->inuse = 0;
	list_add(&ent->list, memcache_freelist+n);
}

void memcache_set_overhead(int overhead) {
	memcache_overhead = offsetof(struct mch, list) + overhead;
	memcache_maxsize = (1<<16) - memcache_overhead;
	lprintf("memcache_overhead is %u", memcache_overhead);
	lprintf("memcache_maxsize is %u", memcache_maxsize);
	lprintf("memcache_blocksize is %d", memcache_blocksize);
}

int memcache_create(int totalsize) {
	int i, n;
	struct mch *ent;

	INIT_LIST_HEAD(&memcache_blocklist);
	memcache_freelist = shalloc(sizeof(struct list_head)*MCLSTSZ);
	if(memcache_freelist==NULL) return -ENOMEM;
	for(i=0; i<MCLSTSZ; i++)
	    INIT_LIST_HEAD(memcache_freelist+i);

	for(n = totalsize, i=256; n; n-=i) {
	    if(i>n) i = n;
	    ent=try_mmap(i<<20);
	    if(ent==NULL) break;
	    ent->inuse = 1;
	    ent->psize = 0;
	    ent->csize = i<<20;
	    list_add(&ent->list, &memcache_blocklist);
	    ent = (struct mch *)((char *)ent + MCBLKSZ);
	    ent->inuse = 0;
	    ent->psize = MCBLKSZ;
	    ent->csize = (i<<20)-2*MCBLKSZ;
	    memcache_freesize += ent->csize;
	    list_add(&ent->list, memcache_freelist);
	    ent = (struct mch *)((char *)ent+(i<<20)-2*MCBLKSZ);
	    ent->inuse = 1;
	    ent->psize = (i<<20) - 2*MCBLKSZ;
	    ent->csize = 0;
	}
	return n ? -ENOMEM : 0;
}

void memcache_destroy() {
	if(memcache_blocklist.next)
	    while(!list_empty(&memcache_blocklist)) {
	    	struct mch *ent = list_entry(memcache_blocklist.next, struct mch, list);
		list_del(&ent->list);
		munmap(ent, ent->csize);
	    }
}
