#include "autoconfig.h"
#include <stdlib.h>
#include <dlfcn.h>

const char __invoke_dynamic_linker__[] __attribute__ ((section (".interp"))) =
#if __x86_64__
	"/lib64/ld-linux-x86-64.so.2"
#else
	"/lib/ld-linux.so.2"
#endif
	;

extern int main(int argc, char **argv);

void _so_start(char *arg1,...) {
	char **argv;
	char ***argvp;
	unsigned long argc;

	argvp = dlsym(RTLD_DEFAULT, "_dl_argv");
	if(argvp!=NULL) {
		argv = *argvp;
		argc = (unsigned long)argv[-1];
	} else {
		argv = &arg1;
#if __x86_64__
		argv++;
#endif
		if((argc=(unsigned long)argv[0]) < 0x10000)
			argv++;
		else if((argc=(unsigned long)argv[1]) < 0x10000 && argc >= 1)
			argv+=2;
		else
			argc = (unsigned long)argv[-1];
	}
	fast_exit(main(argc, argv));
}

