#ifndef __COMPAT_SENDFILE64_H_
#define __COMPAT_SENDFILE64_H_

#include <unistd.h>
#include "syscall.h"
#include "realconfig.h"
static inline int sys_sendfile64(int fd, int src, off64_t *off, size_t count) {
	return syscall(__NR_sendfile64, fd, src, off, count);
}
static inline int sys_pread64(int fd, char *buf, size_t count, off64_t off) {
#ifdef __NR_pread64
	return syscall(__NR_pread64, fd, buf, count, off);
#else
	return syscall(__NR_pread, fd, buf, count, off);
#endif
}
#if !INLINE_SYSCALL
#define fast_sendfile64 sys_sendfile64
#endif

#endif
