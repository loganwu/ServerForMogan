const char qhttpd_version_string[] = "3.1.1";
const char qhttpd_compiling_date[] = __DATE__;
