/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include <stdlib.h>
#include <asm/ioctls.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include "compat_ctype.h"
#include "compat_rlimit.h"

#include "autoconfig.h"
#include "global.h"
#include "myconfig.h"
#include "log.h"
#include "sysctl.h"
#include "shmem.h"
#include "thread.h"
#include "entity_hash.h"
#include "util.h"
#include "version.h"
#if RELAY_SUPPORT
#include "relay.h"
#include "group.h"
#endif
#include "memcache.h"
#include "filecache.h"

#define STATE(x, y)	[x+2] = y
static const char *statestr[] = {
	STATE(-2, "UNUSED"),
	STATE(-1, "DISABLED"),
	STATE(0, "NOT-SUPPORTED"),
	STATE(1, "SUPPORTED"),
};

#define state(x) statestr[x+2]

void print_version(void) {
	verbose = myconfig_get_intval("verbose", 0);
	if(myconfig_get_intval("version", 0)==0 &&
		myconfig_get_intval("help", 0)==0)
	    return;

	struct rlimit rlim;
	int i;
	char buf[30];

	cprintf("TWS v%s (%s)\n", qhttpd_version_string, qhttpd_compiling_date);
	cprintf("Copyright 2007-2008 TENCENT Inc.\n\n");

#ifndef _CS_GNU_LIBPTHREAD_VERSION
#define _CS_GNU_LIBPTHREAD_VERSION 3
#endif
	i = confstr(_CS_GNU_LIBPTHREAD_VERSION, NULL, 0);
	if(i <= 0) {
	i=fast_readlink("/lib/libpthread.so.0", buf, sizeof(buf));
	buf[i]='\0';
	if(i>3 && *(uint32_t *)(buf+i-3)==*(uint32_t *)".so")
		buf[i-3] = '\0';
	if(!strncmp(buf, "libpthread-0.", 13))
        cprintf(" LIBPTHREAD_VERSION = linuxthreads-%s?\n", buf+11);
	else
        cprintf(" LIBPTHREAD_VERSION = pre-linuxthreads-0.10\n");
	} else {
		//char buf[i];
		confstr (_CS_GNU_LIBPTHREAD_VERSION, buf, sizeof(buf));
        cprintf(" LIBPTHREAD_VERSION = %s\n", buf);
		
	}
	
	i = sysconf(_SC_THREAD_THREADS_MAX);
	if(i>0) {
        cprintf("PTHREAD_THREADS_MAX = %d%s\n", i, pretty(i));
	} else
        cprintf("  POSIX_THREADS_MAX = unlimited\n");

	i = sysctl_get_value("/proc/sys/kernel/threads-max", 0);
        cprintf(" SYSTEM_THREADS_MAX = %d%s\n", i, pretty(i));

	i = sysctl_get_value("/proc/loadavg", 4);
        cprintf("SYSTEM_THREADS_USED = %d%s\n", i, pretty(i));

	i = sysconf(_SC_THREAD_STACK_MIN);
        cprintf("  PTHREAD_STACK_MIN = %d%s\n", i, pretty(i));

#if INLINE_SYSCALL
#if __x86_64__
	cprintf("            SYSCALL = inline\n");
#else
	cprintf("            SYSCALL = inline:%s\n",
	       gatevalue==0 ? "emulate":
	       (gatevalue&0xFFFF)==0x80CD ? "int80":"fast");
#endif
#elif COMPAT_GLIBC
	cprintf("            SYSCALL = compat\n");
#else
	cprintf("            SYSCALL = libc\n");
#endif
#if PLUGIN_SUPPORT
	cprintf("     PLUGIN_SUPPORT = 1 (ENABLED)\n");
#else
	cprintf("     PLUGIN_SUPPORT = 0 (DISABLED)\n");
#endif
#if COOKIE_SUPPORT
	cprintf("     COOKIE_SUPPORT = 1 (ENABLED)\n");
#else
	cprintf("     COOKIE_SUPPORT = 0 (DISABLED)\n");
#endif
	cprintf("  LARGEFILE_SUPPORT = 1 (ENABLED)\n");
	if(has_sendfile64==0)
	cprintf("                      (kernel version < 2.4.21, please upgrade)\n");
#if FILECOUNT_SUPPORT
	cprintf("  FILECOUNT_SUPPORT = 1 (ENABLED)\n");
#else
	cprintf("  FILECOUNT_SUPPORT = 0 (DISABLED)\n");
#endif
#if THROTTLE_SUPPORT
	cprintf("   THROTTLE_SUPPORT = 1 (ENABLED)\n");
#else
	cprintf("   THROTTLE_SUPPORT = 0 (DISABLED)\n");
#endif
#if RELAY_SUPPORT
	cprintf("      RELAY_SUPPORT = 1 (ENABLED)\n");
#else
	cprintf("      RELAY_SUPPORT = 0 (DISABLED)\n");
#endif
#if WITH_RTSIG
	cprintf("         WITH_RTSIG = 1 (ENABLED)\n");
#else
	cprintf("         WITH_RTSIG = 0 (epoll only)\n");
#endif
	cprintf("           PAGESIZE = %d%s\n",
		pagesize, pretty(pagesize));
	if(hugepagesize > 0) {
	cprintf("       HUGEPAGESIZE = %d%s\n",
		hugepagesize, pretty(hugepagesize));
	} else {
	cprintf("       HUGEPAGESIZE = NOT-SUPPORTED\n");
	}

	cprintf("   PIPE_BUFFER_SIZE = %d%s\n", pipe_buffer_size, pretty(pipe_buffer_size));

        if(fast_getrlimit(RLIMIT_SIGPENDING, &rlim)>=0) {
	cprintf("  RLIMIT_SIGPENDING = SUPPORTED\n");
	} else {
	cprintf("  RLIMIT_SIGPENDING = NOT-SUPPORTED\n");
	}

	cprintf("          SYS_futex = %s\n", state(has_futex));
	cprintf("          SYS_epoll = %s\n", state(has_epoll));
	cprintf("         SYS_openat = %s\n", state(has_openat));
	cprintf("         SYS_splice = %s\n", state(has_splice));
	cprintf("        SYS_dnotify = %s\n", state(has_dnotify));
	cprintf("        SYS_inotify = %s\n", state(has_inotify));
	cprintf("        SYS_unshare = %s\n", state(has_unshare));
	cprintf("        SYS_fadvise = %s\n",
		has_fadvise < 0 ? "DISABLED" :
		has_fadvise==0 ? "NOT-SUPPORTED" :
		has_fadvise==32 ? "SUPPORTED (64:32)" :
		"SUPPORTED (64:64)"
		);

#if __WORDSIZE < 64
	cprintf("     SYS_sendfile64 = %s\n", state(has_sendfile64));
#endif
	cprintf("   new CLONE_THREAD = %s\n", state(has_threadgroup));
#if PROFILE_SUPPORT	
	cprintf("    PROFILE_SUPPORT = 1 (ENABLED)\n");
#endif

	cprintf("      SYSTEM_MEMORY = %ldK%s\n", memtotal, prettyK(memtotal));
	i = physical_memory_size();
	cprintf("    PHYSICAL_MEMORY = %dK%s\n", i, prettyK(i));

	cprintf("LINEAR_MEMORY_SPACE = %ld%c\n",
#if __WORDSIZE==32
		memtop==0 ? 4 : (memtop & 0x3FFFFFFF) ? memtop>>20 : memtop>>30,
		(memtop & 0x3FFFFFFF) ? 'M' : 'G'
#else
		(memtop & 0x3FFFFFFF) ? memtop>>20 :
		(memtop & 0xFFFFFFFFFF) ? memtop>>30 : memtop>>40,

		(memtop & 0x3FFFFFFF) ? 'M' :
		(memtop & 0xFFFFFFFFFF) ? 'G' : 'T'
#endif
	       );
#if __WORDSIZE==32
	if(memhalf)
	    cprintf("         TOP_MEMORY = %lx\n", memhalf);
#endif

	if(verbose) {
	memcache_set_overhead(MCOVERHEAD);
	filecache_set_overhead(FCOVERHEAD);
#if __x86_64__
#define FS "%ld\n"
#else
#define FS "%d\n"
#endif
	cprintf("sizeof       thread = "FS, sizeof(struct thread));
	cprintf("sizeof       worker = "FS, sizeof(struct worker));
	cprintf("sizeof         conn = "FS, sizeof(struct conn));
	cprintf("sizeof       fdinfo = "FS, sizeof(struct fdinfo));
	cprintf("sizeof     fdentity = "FS, sizeof(struct fdentity));
	cprintf("sizeof   hashentity = "FS, sizeof(struct entity_hash));
	cprintf("sizeof    mementity = %d\n", memcache_overhead);
	cprintf("sizeof    offentity = %d\n", filecache_overhead);
#if RELAY_SUPPORT
	cprintf("sizeof       target = "FS, sizeof(struct target));
	cprintf("sizeof        group = "FS, sizeof(struct group));
#endif
	}
	exit(0);
}

static int pgid __init__;
static int ttyfd __init__;

int is_front(void) {
	pid_t id = pgid;
	if(fast_getppid()==1)
		return 0;
	ioctl(ttyfd, TIOCGPGRP, &id);
	if(id != pgid)
		return 0;
	return 1;
}

static unsigned int developer_magic(void) {
	unsigned int a;
	void addenv(const char *str) {
		char *p = getenv(str);
		if(p) for(; *p; p++) a = a*11+*p;
	}

	a = (fast_time() + 7200) / 86400;
	a *= 14539;
	addenv("SSH_CLIENT");
	addenv("SSH2_CLIENT");
	addenv("SSH_CONNECTION");
	rand_r(&a);
	return a;
}

void check_developer_mode() {
	char *p;
	unsigned int a;

	p = myconfig_get_value("developer");
	if(p==NULL || !is_xdigit(p[0]))
		return;

	a = strtoul(p, NULL, 16);
	if(a==developer_magic()) {
	    pgid = fast_getpgid(0);
	    ttyfd = fast_open2("/dev/tty", O_RDWR);
	    if(ttyfd > 0) {
	    	dup2(ttyfd, 0);
	    	dup2(ttyfd, 1);
	    	dup2(ttyfd, 2);
	    }
	    if(ttyfd < 0 || is_front()==0) {
	    	lprintf("\7WARNING: DEVELOPER MODE CAN'T RUN AS BACKGROUD JOB\n");
		fast_exit(0);
	    }
	    lprintf("\7WARNING: DEVELOPER MODE ENABLED.\n");
	    developer = 1;
	}
}

void show_developer_magic() {
	if(myconfig_get_intval("developer_magic", 0)) {
	    int fd;

	    if((fd = fast_open2("/dev/tty", O_WRONLY)) >= 0) {
	    	char buf[32];
	        sprintf(buf, "developer=%08x\n", developer_magic());
		fast_write(fd, buf, 19);
	    }
	    fast_exit(0);
	}
}
