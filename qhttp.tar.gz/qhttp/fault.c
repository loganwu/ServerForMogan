/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <ucontext.h>
#include <link.h>
#include "compat_rlimit.h"
#include "compat_thread.h"

#include "autoconfig.h"
#include "fault.h"
#include "myconfig.h"
#include "global.h"
#include "daemon.h"
#include "thread.h"
#include "log.h"
#include "util.h"
#include "task.h"
#include "priv.h"
#include "watchdog.h"

#ifndef SI_TKILL
#define SI_TKILL -6
#endif
const char *const signame[] = {
"SIG_0",
"SIGHUP",	"SIGINT",	"SIGQUIT",	"SIGILL",
"SIGTRAP",	"SIGABRT",	"SIGBUS",	"SIGFPE",
"SIGKILL",	"SIGUSR1",	"SIGSEGV",	"SIGUSR2",
"SIGPIPE",	"SIGALRM",	"SIGTERM",	"SIGSTKFLT",
"SIGCHLD",	"SIGCONT",	"SIGSTOP",	"SIGTSTP",
"SIGTTIN",	"SIGTTOU",	"SIGURG",	"SIGXCPU",
"SIGXFSZ",	"SIGVTALRM",	"SIGPROF",	"SIGWINCH",
"SIGIO",	"SIGPWR",	"SIGSYS",
"SIGRT_0",	"SIGRT_1",	"SIGRT_2",	"SIGRT_3",
"SIGRT_4",	"SIGRT_5",	"SIGRT_6",	"SIGRT_7",
"SIGRT_8",	"SIGRT_9",	"SIGRT_10",	"SIGRT_11",
"SIGRT_12",	"SIGRT_13",	"SIGRT_14",	"SIGRT_15",
"SIGRT_16",	"SIGRT_17",	"SIGRT_18",	"SIGRT_19",
"SIGRT_20",	"SIGRT_21",	"SIGRT_22",	"SIGRT_23",
"SIGRT_24",	"SIGRT_25",	"SIGRT_26",	"SIGRT_27",
"SIGRT_28",	"SIGRT_29",	"SIGRT_30",	"SIGRT_31",
"SIGRT_32"
};

static int allow_core_dump __init__;
static const char unknown[] = "unknown";

static void fault_catcher(int signo, siginfo_t *si, void *uc0){
#define uc ((struct ucontext *)uc0)
	struct thread *th;
	const char *name, *sname, *fname = NULL;
	int pid;

	if(si==NULL) return;
	prctl(PR_SET_DUMPABLE, allow_core_dump);
	pid = fast_gettid();
	th = get_thread_by_pid(pid);
	name = th ? th->name : unknown;
	sname = signame[signo];
	if(si->si_code > 0) {
	    signal(signo, SIG_DFL);
#define type(x,y) (x##_##y<<5|SIG##x)
	    switch((si->si_code << 5) | signo) {
		case type(ILL,ILLOPC): fname = "Illegal Opcode";	break;
		case type(ILL,ILLOPN): fname = "Illegal Operand";	break;
		case type(ILL,ILLADR): fname = "Illegal Addressing Mode";	break;
		case type(ILL,ILLTRP): fname = "Illegal Trap";		break;
		case type(ILL,PRVOPC): fname = "Priviledged Opcode";	break;
		case type(ILL,PRVREG): fname = "Priviledged Register";	break;
		case type(ILL,COPROC): fname = "Coprocessor Error";	break;
		case type(ILL,BADSTK): fname = "Internal Stack Error";	break;
		case type(FPE,INTDIV): fname = "Integer Divide by Zero";	break;
		case type(FPE,INTOVF): fname = "Integer Overflow";	break;
		case type(FPE,FLTDIV): fname = "Floating Point Divide by Zero"; break;
		case type(FPE,FLTOVF): fname = "Floating Point Overflow";	break;
		case type(FPE,FLTUND): fname = "Floating Point Underflow";	break;
		case type(FPE,FLTRES): fname = "Floating Point Inexact Result";	break;
		case type(FPE,FLTINV): fname = "Floating Point Invalid Operation";	break;
		case type(FPE,FLTSUB): fname = "Subscript Out of Range";	break;
		case type(SEGV,MAPERR):fname = "Address not Mapped to Object";	break;
		case type(SEGV,ACCERR):fname = "Invalid Permissions for Mapped Object";	break;
		case type(BUS,ADRALN): fname = "Invalid Address Alignment";	break;
		case type(BUS,ADRERR): fname = "Non-existent Physical Address";	break;
		case type(BUS,OBJERR): fname = "Object Specific Hardware Error";	break;
		case type(TRAP,BRKPT): fname = "Process Breakpoint";	break;
		case type(TRAP,TRACE): fname = "Process Trace Trap";	break;
	    }
	    if(fname) {
		lprintf("%s: %s, %s at 0x%lx\n", name, sname, fname, (long)si->si_addr);
	    } else {
		lprintf("%s: %s, Unknown Error at 0x%lx\n", name, sname, (long)si->si_addr);
	    }
	} else if(si->si_code == SI_USER || si->si_code == SI_TKILL) {
	    if(si->si_pid == pid) {
		lprintf("%s: %s from self\n", name, sname);
		if(signo != SIGABRT) {
		    signal(signo, SIG_DFL);
		    kill(pid, signo);
		    return;
		}
	    } else if(watchdog_pid && si->si_pid==watchdog_pid) {
		lprintf("%s: %s from watchdog, possible deadlock!\n",
			name, sname);
	    } else {
		lprintf("%s: %s from pid=%d uid=%d, IGNORED\n",
			name, sname, si->si_pid, si->si_uid);
	    }
	} else
	    return;

#if __x86_64__
#else
	extern char *arg_start;

	struct sigcontext *mc = (struct sigcontext *)&uc->uc_mcontext;
	lprintf("regs: eax=%08lx ebx=%08lx ecx=%08lx edx=%08lx\n",
			mc->eax, mc->ebx, mc->ecx, mc->edx);
	lprintf("regs: esi=%08lx edi=%08lx ebp=%08lx esp=%08lx\n",
			mc->esi, mc->edi, mc->ebp, mc->esp);
	lprintf("regs: eip=%08lx err=%08lx trp=%08lx flg=%08lx\n",
			mc->eip, mc->err, mc->trapno, mc->eflags);
	lprintf("regs: esp@sig=%08lx oldmask=%08lx cr2=%08lx\n",
			mc->esp_at_signal, mc->oldmask, mc->cr2);

#if LINK_AS_STATIC
#define dladdr(x, y) 0
#endif
	Dl_info di;
	unsigned long *esp = (unsigned long *) mc->esp;
	if((unsigned long)esp > mainstack)
	    esp = (unsigned long *)((unsigned long)esp | (main_stack_size-1));
	else if(th)
	    esp = (unsigned long *)(th->stack + stack_block_size - 1);
	else
	    esp = (unsigned long *)((unsigned long)esp + (stack_block_size-1));

	unsigned long *ebp = (unsigned long *) mc->ebp;
	if(dladdr((void *)mc->eip, &di)==0)
	    lprintf("trace: eip=%08lx ebp=%08lx\n", mc->eip, (unsigned long)ebp);
	else if(di.dli_sname==NULL)
	    lprintf("trace: eip=%08lx ebp=%08lx %x@%s\n", mc->eip, (unsigned long)ebp,
		    (void *)mc->eip - di.dli_saddr,
		    di.dli_fname==arg_start?"tws_http":di.dli_fname);
	else
	    lprintf("trace: eip=%08lx ebp=%08lx %s+%x@%s\n", mc->eip, (unsigned long)ebp,
		    di.dli_sname, (void *)mc->eip-di.dli_saddr,
		    di.dli_fname==arg_start?"tws_http":di.dli_fname);
	while(ebp > (unsigned long *)mc->esp && ebp < esp) {
	    if(dladdr((void *)ebp[1], &di)==0)
		lprintf("trace: eip=%08lx ebp=%08lx\n", ebp[1], ebp[0]);
	    else if(di.dli_sname==NULL)
		lprintf("trace: eip=%08lx ebp=%08lx %lx@%s\n", ebp[1], ebp[0],
			(long)((void *)ebp[1] - di.dli_saddr),
			di.dli_fname==arg_start?"tws_http":di.dli_fname);
	    else
		lprintf("trace: eip=%08lx ebp=%08lx %s+%lx@%s\n", ebp[1], ebp[0],
			di.dli_sname, (long)((void *)ebp[1]-di.dli_saddr),
			di.dli_fname==arg_start?"tws_http":di.dli_fname);
	    if((unsigned long *)ebp[0] < ebp) {
		if(ebp[0]) lprintf("trace: stack frame corrupt\n");
		break;
	    }
	    if(ebp <= (unsigned long *)ebp[0]) break;
	    ebp = (unsigned long *)ebp[0];
	}
#endif

	if(si->si_code == SI_USER || si->si_code == SI_TKILL) return;
	if(stop==0) {
	    restart = 2;
	    stop = 1;

        // Added by yijian on 2008-06-16
        if (!(threadmode&CLONE_THREAD))
            exit(11);
	}

	if(pid != mainthread.pid)
	{
	    if(th) {
	    	th->state = THREAD_KILLED;
		th->rv = signo;
	    }
	    fast_exit_group(-2);
	    _exit(-2);
	    return;
	}

	/* emergence restart */
	lprintf("Emergent Restart due to main thread crash\n");
	daemon_emergent_restart(signo);
}

#if PLUGIN_SUPPORT
const char * const sym_errno[] = { "errno", NULL };
const char * const sym_select[] = { "select", "pselect", NULL };
int check_symbol(void *dyn0, const char *file, const char * const sym[], int silent) {
	ElfW(Dyn) *dyn = dyn0;
	ElfW(Sym) *symtab = NULL;
	char *strtab = NULL;
	char *p;
	int strsz = 0, syment = sizeof(ElfW(Sym));
	int badcnt = 0;
	int i;
	void *vaddr = (void *)(~0xFFF & (long)dyn);

	for(; dyn->d_tag; dyn++) {
	    switch(dyn->d_tag) {
		case DT_STRTAB:
			if(dyn->d_un.d_ptr > 0x10000)
			    strtab = (void *)dyn->d_un.d_ptr;
			else
			    strtab = vaddr + dyn->d_un.d_ptr;
			break;
		case DT_SYMTAB:
			if(dyn->d_un.d_ptr > 0x10000)
			    symtab = (void *)dyn->d_un.d_ptr;
			else
			    symtab = vaddr + dyn->d_un.d_ptr;
			break;
		case DT_STRSZ:  strsz = dyn->d_un.d_val; break;
		case DT_SYMENT: syment = dyn->d_un.d_val; break;
	    }
	}
	if(strtab == NULL || symtab == NULL) goto out;
	if(syment != sizeof(ElfW(Sym))) {
	    if(silent==0) lprintf("%s: Bad Symblic Table\n", file);
	    badcnt++;
	    goto out;
	}
	for(; symtab->st_name < strsz ; symtab++) {
	    if(symtab->st_name==0) continue;
	    if(symtab->st_shndx!=0) continue;
	    p = strtab + symtab->st_name;
	    while(*p=='-') p++;
	    if(!strncmp(p, "libc_", 5)) p+=5;
	    if(!strncmp(p, "sysv_", 5)) p+=5;
	    if(!strncmp(p, "bsd_", 5)) p+=4;
	    if(!strncmp(p, "xpg_", 5)) p+=4;
#if PLUGIN_SUPPORT
	    if(silent==0 && !strcmp("printf", p)) {
		lprintf("%s: '%s' is not thread-safe, use 'cprintf' or 'lprintf' instead.\n",
			file, strtab+symtab->st_name);
		continue;
	    }
	    if(silent==0 && !strcmp("vprintf", p)) {
		lprintf("%s: '%s' is not thread-safe, use 'vlprintf' or 'vcprintf' instead.\n",
			file, strtab+symtab->st_name);
		continue;
	    }
	    if(silent==0 && !strcmp("puts", p)) {
		lprintf("%s: '%s' is not thread-safe, use 'cputs' or 'lputs' instead.\n",
			file, strtab+symtab->st_name);
		continue;
	    }
#endif
	    for(i=0; sym[i]; i++) {
		if(!strcmp(sym[i], p)) {
		    if(silent==0)
			lprintf("%s: Reference to '%s' not allowed\n",
				file, strtab+symtab->st_name);
		    badcnt++;
		}
	    }
	}
out:
	return badcnt;
}

static int (*fcn_dl_iterate_phdr)(
	int (*callback)(struct dl_phdr_info *info, size_t size, void *data),
	void *data);
static const ElfW(Phdr) *addr;
static int nocheck;
static int checkerrno = 0;
static int iterate(struct dl_phdr_info *info, size_t size, void *data) {
	const char *p;
	const ElfW(Phdr) *phdr = info->dlpi_phdr;
	int i;

	if(addr==info->dlpi_phdr) {
	    nocheck = 0;
	    return 0;
	} else if(nocheck) {
	    return 0;
	} else {
	    addr = phdr;
	}

	p = strrchr(info->dlpi_name, '/');
	if(p==NULL) p = info->dlpi_name; else p++;
	if(!checkerrno) {
		return 0;
	}
	for(i=0; i<info->dlpi_phnum; i++, phdr ++) {
	    if(phdr->p_type!=PT_DYNAMIC) continue;
	    if(check_symbol((void *)info->dlpi_addr + phdr->p_vaddr,
			p, sym_errno, 1) != 0)
	    {
		lprintf("%s: not thread-safe, please recompile with -D_REENTRANT\n",
			info->dlpi_name);
		fast_exit(-1);
	    }
	    if(check_symbol((void *)info->dlpi_addr + phdr->p_vaddr,
			p, sym_select, 1) != 0)
	    {
		lprintf("%s: select() can't handle large fds, use poll() instead.\n",
			info->dlpi_name);
		fast_exit(-1);
	    }
	}
	return 0;
}

void check_reentrant(void) {
	if(fcn_dl_iterate_phdr)
	    fcn_dl_iterate_phdr(iterate, NULL);
	checkerrno = 1;
	nocheck = 1;
}
#endif

#ifndef __WALL
#define __WALL                0x40000000
#endif
int init_fault_handler(void) {
	struct rlimit rlim;
	if(developer && myconfig_get_intval("enable_core_dump", 0)) {
	    /* core dump only work in early starting code,
	       system don't allow core dump after change uid */
	    rlim.rlim_cur = RLIM_INFINITY;
	    rlim.rlim_max = RLIM_INFINITY;
	    allow_core_dump = 1;
	    lprintf("\7WARNING: server core-dump enabled\n");
	} else {
	    /* disable core dump */
	    rlim.rlim_cur = 0;
	    rlim.rlim_max = 0;
	    allow_core_dump = 0;
	}
	fast_setrlimit(RLIMIT_CORE, &rlim);
	prctl(PR_SET_DUMPABLE, allow_core_dump);

#if PLUGIN_SUPPORT
	fcn_dl_iterate_phdr = dlvsym(RTLD_DEFAULT, "dl_iterate_phdr", "GLIBC_2.2.4");
#endif

	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_sigaction = fault_catcher;
	sa.sa_flags = SA_RESTART|SA_SIGINFO;
	sigaction(SIGSEGV, &sa, NULL);
	sigaction(SIGBUS, &sa, NULL);
	sigaction(SIGILL, &sa, NULL);
	sigaction(SIGABRT, &sa, NULL);
	sigaction(SIGFPE, &sa, NULL);
	//sigaction(SIGTRAP, &sa, NULL);

#if PLUGIN_SUPPORT
	check_reentrant();
#endif
	//dlopen(NULL, RTLD_NOW);
	return 0;
}
