#ifndef _H_COOKIE_H_
#define _H_COOKIE_H_
#if COOKIE_SUPPORT

struct cookie {
	struct cookie *next;
	int namelen;
	int hash;
	int maxlen;
	int offset;
	char name[0];
};

extern int init_cookie_info(void);
extern int decode_cookie(char *cbuf, char *data, int datasz);
extern int encode_cookie(char *buf, int len, const char *cookie);
extern int encode_cookie_overlay(char *buf, const char *cookie);
extern void free_cookie_info(void);
extern int add_cookie(const char *name, int size);
static inline void clear_cookie_buffer(char *buf) {
	struct cookie *c;
	for(c=cookieinfo; c; c=c->next)
		buf[c->offset] = '\0';
}

extern int cookie_offset(const char *name);
extern int cookie_maxlength(const char *name);
#else
static inline int init_cookie_info(void) { return 0; }
static inline void free_cookie_info(void) {}
static inline void clear_cookie_buffer(void) {}
#endif
#endif
