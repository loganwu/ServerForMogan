#include "myalloc.h"
#include <pthread.h>
#include "lock.h"

static int mutex_array_lock(mutex_t *m, int i) {
	pthread_mutex_t *f = (pthread_mutex_t *)(m+1);
	return pthread_mutex_lock(f+i);
}

static int mutex_array_unlock(mutex_t *m, int i) {
	pthread_mutex_t *f = (pthread_mutex_t *)(m+1);
	return pthread_mutex_unlock(f+i);
}

static int mutex_array_trylock(mutex_t *m, int i) {
	pthread_mutex_t *f = (pthread_mutex_t *)(m+1);
	return pthread_mutex_trylock(f+i);
}

static void mutex_array_destroy(mutex_t *m) {
	free(m);
}

mutex_t *CreatePosixMutex(int n) {
	mutex_t *m = malloc(sizeof(mutex_t)+sizeof(pthread_mutex_t)*n);
	if(m==NULL) return NULL;
	int i;
	pthread_mutex_t *f = (pthread_mutex_t *)(m+1);
	for(i=0; i<n; i++)
		pthread_mutex_init(f+i, NULL);
	m->lock = mutex_array_lock;
	m->unlock = mutex_array_unlock;
	m->trylock = mutex_array_trylock;
	m->destroy = mutex_array_destroy;

	return m;
}

