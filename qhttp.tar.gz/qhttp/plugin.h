#ifndef _H_PLUGIN_H_
#define _H_PLUGIN_H_

typedef struct callback_data {
	int32_t tid;
	void *priv;
	char *host;
	char *url;
	char *buf;
	int32_t buflen;
	int32_t dirlen;
	const char *mime;
	int32_t datalen;
	void *entity;
	char *cookie;
	uint32_t addr;
	uint32_t speed;
	uint32_t expire;
	off64_t offset;
	time_t mtime;
	void *ftarget;
	int16_t reason;
	uint8_t method;
	uint8_t retry;
	int8_t has_ims:1; /* If-Modified-Since */
	int8_t has_iums:1; /* If-Unmodified-Since */
	int8_t has_ir:1; /* If-Range */
	int32_t flags_reserved:29;
} cbdata_t;

typedef int (*cbfunc_t)(cbdata_t *);

#define RF_ENTITY	0x400
#define RF_SUB_ENTITY	0xC00
#define RF_FILE_HANDLE	0x1400
#define RF_PATHNAME	0x800
#define RF_CONTENT	0x1000
#define RF_URL		0x2000
#define RF_VHOST	0x4000
#define RF_HOST		0x8000
#define RF_FORWARD_MASK		0x10000
#define RF_FORWARD_TARGET	0x10400
#define RF_SFORWARD_TARGET	0x10800
#define RF_FORWARD_GROUP	0x10C00
#define RF_PRIVATE	0x40000000
#define RF_NOCACHE	0x80000000
#define RF_PUBLIC	0xC0000000

#define RC_CONTINUE	0
#define RC_OK		200
#define RC_REDIRECT	301
#define RC_REDIRECT_TMP	302
#define RC_DENIED	403
#define RC_NOT_FOUND	404

#define HTTP_METHOD_GET 	0
#define HTTP_METHOD_HEAD	1
#define HTTP_METHOD_POST	2

struct filtercb {
	struct filtercb *next;
	int order;
	cbfunc_t func;
	void *priv;
};

extern int load_plugins(void);
extern void free_plugins(void);
extern void set_library_path(void);
extern const char *getparam( char const * const * argv, char const *param);
extern int getintparam( char const * const *argv, char const *param, int defval);

#endif
