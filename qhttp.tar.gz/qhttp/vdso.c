/* vim: set sw=4 ai :*/
#include <stdlib.h>
#include <setjmp.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <sys/signal.h>
#include "autoconfig.h"
#include "fdinfo.h"
#include "log.h"

#if INLINE_SYSCALL

static const int linuxgate_int80 __attribute__((section(".text.vdso"))) = 0xc3c380cd;
long linuxgate __init__ = (long)&linuxgate_int80;
int gatevalue __init__ = 0;
static sigjmp_buf sjb;
static void trap_linuxgate(int signo) {
	siglongjmp(sjb, 1);
}

#if __x86_64__
#define TOPVDSO	0xFFFFFFFFFFE60400UL
#else
#define TOPVDSO	0xFFFFE400
#endif
void detect_vdso(void) {
	unsigned long gate = 0;
#if !LINK_AS_STATIC
	void *lib = dlopen("linux-gate.so.1", RTLD_NOW);
	gate = (unsigned long)dlsym(lib, "__kernel_vsyscall");
#endif
	if(gate==0) {
	    int fd = fast_open("/proc/self/maps", O_RDONLY, 0666);
	    char p[4096];
	    fast_read(fd, p, sizeof(p)-1);
	    fast_close(fd);
	    p[sizeof(p)-1] = '\0';
	    char *q = strstr(p, "[vdso]");
	    if(q) {
		while(q != p && *q != '\n') q--;
		gate = strtoul(q+1, NULL, 16) + 0x400;
	    }
	}
	if(gate==0)
	    gate = TOPVDSO;
	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = trap_linuxgate;
	sa.sa_flags = SA_ONESHOT|SA_NOMASK;
	sigaction(SIGSEGV, &sa, NULL);
	sigaction(SIGBUS, &sa, NULL);
	if(sigsetjmp(sjb,1)==0) {
		gatevalue = *(volatile int *)gate;
		linuxgate = gate;
	}
}

#endif

