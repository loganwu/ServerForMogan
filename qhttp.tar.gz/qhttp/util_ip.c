#include <stdlib.h>
#include <netinet/in.h>
#include "compat_ctype.h"

uint32_t str2ip(const char *str, const char **ptr) {
	uint32_t addr, temp;

	if(is_digit(str[0])==0)
		return INADDR_NONE;

	addr = strtoul(str, (char **)&str, 0);
	if(*str != '.') {
	    temp = addr >> 24;
	    if(temp==0 || temp >= 224)
		return INADDR_NONE;
	    addr = htonl(addr);
	} else if(is_digit(str[1])==0)
		return INADDR_NONE;
	else {
	    if(addr==0 || addr >= 224)
		return INADDR_NONE;
#if __BYTE_ORDER != __LITTLE_ENDIAN
	    addr <<= 24;
#endif
	    temp = strtoul(str+1, (char **)&str, 0);
	    if(*str != '.') {
	    	if(temp >= 1<<24)
			return INADDR_NONE;
#if __BYTE_ORDER == __LITTLE_ENDIAN
		addr += htonl(temp);
#else
		addr += temp;
#endif
	    } else if(is_digit(str[1])==0)
			return INADDR_NONE;
	    else {
		if(temp >= 256)
			return INADDR_NONE;
#if __BYTE_ORDER == __LITTLE_ENDIAN
		addr += temp<<8;
#else
		addr += temp<<16;
#endif

		temp = strtoul(str+1, (char **)&str, 0);
		if(*str != '.') {
		    if(temp >= 1<<16)
			return INADDR_NONE;
#if __BYTE_ORDER == __LITTLE_ENDIAN
		    addr += htonl(temp);
#else
		    addr += temp;
#endif
		} else if(is_digit(str[1])==0)
			return INADDR_NONE;
		else {
#if __BYTE_ORDER == __LITTLE_ENDIAN
		    addr += temp<<16;
#else
		    addr += temp<<8;
#endif
		    temp = strtoul(str+1, (char **)&str, 0);
		    if(temp >= 256)
			return INADDR_NONE;
#if __BYTE_ORDER == __LITTLE_ENDIAN
		    addr += temp<<24;
#else
		    addr += temp;
#endif
		}
	    }
	}

	if(ptr)
		*ptr = str;
	return addr;
}

char *ip2str(char *str, uint32_t ip) {
	unsigned char *c = (unsigned char *)&ip;
	if(c[0]>=100) {
		*str++ = '0' + c[0]/100;
		*str++ = '0' + (c[0]/10)%10;
		*str++ = '0' + c[0]%10;
	} else if(c[0]>=10) {
		*str++ = '0' + c[0]/10;
		*str++ = '0' + c[0]%10;
	} else
		*str++ = '0' + c[0];
	*str++ = '.';

	if(c[1]>=100) {
		*str++ = '0' + c[1]/100;
		*str++ = '0' + (c[1]/10)%10;
		*str++ = '0' + c[1]%10;
	} else if(c[1]>=10) {
		*str++ = '0' + c[1]/10;
		*str++ = '0' + c[1]%10;
	} else
		*str++ = '0' + c[1];
	*str++ = '.';

	if(c[2]>=100) {
		*str++ = '0' + c[2]/100;
		*str++ = '0' + (c[2]/10)%10;
		*str++ = '0' + c[2]%10;
	} else if(c[2]>=10) {
		*str++ = '0' + c[2]/10;
		*str++ = '0' + c[2]%10;
	} else
		*str++ = '0' + c[2];
	*str++ = '.';

	if(c[3]>=100) {
		*str++ = '0' + c[3]/100;
		*str++ = '0' + (c[3]/10)%10;
		*str++ = '0' + c[3]%10;
	} else if(c[3]>=10) {
		*str++ = '0' + c[3]/10;
		*str++ = '0' + c[3]%10;
	} else
		*str++ = '0' + c[3];

	return str;
}
