/**
* @file  proc_net_dev.h
* @brief /proc/net/dev
*
* @author yijian
* @date 2008-03-12
* @{
 */
#ifndef __PROC_NET_DEV_H
#define __PROC_NET_DEV_H

#ifdef __cplusplus
extern "C" {
#endif

struct dev_struct {
    int seq;
    char name[8]; //ethX    
    // Receive
    unsigned long r_bytes;
    unsigned long r_packets;
    unsigned long r_errs;
    unsigned long r_drop;
    unsigned long r_fifo;
    unsigned long r_frame;
    unsigned long r_compressed;
    unsigned long r_multicast;
    // Transmit
    unsigned long t_bytes;
    unsigned long t_packets;
    unsigned long t_errs;
    unsigned long t_drop;
    unsigned long t_fifo;
    unsigned long t_colls;
    unsigned long t_carrier;
    unsigned long t_compressed;    
};

struct ProcNetDev 
{
    int m_fdDev;
    int m_nDevCount;
    struct dev_struct* m_pDevStruct;
};

int ProcNetDev_activate(struct ProcNetDev* pThis);
void ProcNetDev_deactivate(struct ProcNetDev* pThis);
int ProcNetDev_getDevCount(struct ProcNetDev* pThis);
int ProcNetDev_parse(struct ProcNetDev* pThis);
void ProcNetDev_dump(struct ProcNetDev* pThis);

int milli_sleep(unsigned long milli);

#ifdef __cplusplus
}
#endif
#endif // __PROC_NET_DEV_H
