#include "myalloc.h"
#include <errno.h>
#include "compat_futex.h"

#include "futex.h"
#include "lock.h"

static inline uint32_t xchg(futex_t *p, uint32_t x) {
	__asm__ __volatile__("lock; xchgl %0,%1"
			:"=r" (x)
			:"m" (*p), "0" (x)
			:"memory");
	return x;
}

static inline uint32_t cmpxchg(futex_t *p,
	uint32_t c, uint32_t n)
{
	uint32_t o;
	__asm__ __volatile__("lock; cmpxchgl %1,%2"
			: "=a"(o)
			: "q"(n), "m"(*p), "0"(c)
			: "memory");
	return o;
}

static __inline__ int atomic_dec_return(futex_t *p)
{
	/* Modern 486+ processor */
	int i=-1;
	__asm__ __volatile__( "lock; xaddl %0, %1;"
			: "=r"(i)
			: "m"(*p), "0"(i));
	return i-1;
}

int futex_init(futex_t *lk) {
	*lk = 0;
	return 0;
}

int futex_lock(futex_t *lk) {
	int c;
	if((c=cmpxchg(lk, 0, 1)) != 0) {
		if(c!=2)
			c = xchg(lk, 2);
		while(c!=0) {
			c = fast_futex_wait((uint32_t *)lk, 2);
			c=xchg(lk, 2);
		}
	}
	return 0;
}

int futex_trylock(futex_t *lk) {
	if(cmpxchg(lk, 0, 1) != 0)
		return EBUSY;
	return 0;
}

int futex_unlock(futex_t *lk) {
	if(atomic_dec_return(lk) != 0) {
		*lk = 0;
		fast_futex_wake((uint32_t *)lk, 1);
	}
	return 0;
}

int futex_destroy(futex_t *lk) {
	return 0;
}


static int futex_array_lock(mutex_t *m, int i) {
	futex_t *f = (futex_t *)(m+1);
	return futex_lock(f+i);
}

static int futex_array_unlock(mutex_t *m, int i) {
	futex_t *f = (futex_t *)(m+1);
	return futex_unlock(f+i);
}

static int futex_array_trylock(mutex_t *m, int i) {
	futex_t *f = (futex_t *)(m+1);
	return futex_trylock(f+i);
}

static void futex_array_destroy(mutex_t *m) {
	free(m);
}

mutex_t *CreateLinuxFutex(int n) {
	mutex_t *m = malloc(sizeof(mutex_t)+sizeof(futex_t)*n);
	if(m==NULL) return NULL;
	int i;
	futex_t *f = (futex_t *)(m+1);
	for(i=0; i<n; i++)
		futex_init(f+i);
	m->lock = futex_array_lock;
	m->unlock = futex_array_unlock;
	m->trylock = futex_array_trylock;
	m->destroy = futex_array_destroy;

	return m;
}

