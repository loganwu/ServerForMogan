#ifndef __H_SYSCALL_H_
#define __H_SYSCALL_H_

#include <asm/unistd.h>

#if __x86_64__
#elif __i386__
#else
#error unknown CPU
#endif

#ifndef __NR_epoll_create
#ifdef __x86_64__
#define __NR_epoll_create       213
#else
#define __NR_epoll_create       254
#endif
#endif
#ifndef __NR_epoll_ctl
#define __NR_epoll_ctl		(__NR_epoll_create+1)
#endif
#ifndef __NR_epoll_wait
#define __NR_epoll_wait		(__NR_epoll_create+2)
#endif

#ifndef __NR_inotify_init
#ifdef __x86_64__
#define __NR_inotify_init 253
#else
#define __NR_inotify_init 291
#endif
#endif

#ifndef __NR_inotify_add_watch
#define __NR_inotify_add_watch (__NR_inotify_init+1)
#endif
#ifndef __NR_inotify_rm_watch
#define __NR_inotify_rm_watch (__NR_inotify_init+2)
#endif

#ifndef __NR_futex
#ifdef __x86_64__
#define __NR_futex 202
#else
#define __NR_futex 240
#endif
#endif

#ifndef __NR_tkill
#ifdef __x86_64__
#define __NR_tkill 200
#else
#define __NR_tkill 238
#endif
#endif
#ifndef __NR_tgkill
#ifdef __x86_64__
#define __NR_tgkill 234
#else
#define __NR_tgkill 270
#endif
#endif
#ifndef __NR_exit_group
#ifdef __x86_64__
#define __NR_exit_group 231
#else
#define __NR_exit_group 252
#endif
#endif

#ifndef __NR_unshare
#ifdef __x86_64__
#define __NR_unshare 272
#else
#define __NR_unshare 310
#endif
#endif

#ifndef __NR_set_tid_address
#ifdef __x86_64__
#define __NR_set_tid_address 218
#else
#define __NR_set_tid_address 258
#endif
#endif

#ifndef __NR_sendfile64
#ifdef __x86_64__
#define __NR_sendfile64	40
#else
#define __NR_sendfile64	239
#endif
#endif

#ifndef __NR_splice
#ifdef __x86_64__
#define __NR_splice	275
#else
#define __NR_splice	313
#endif
#endif

#ifndef __NR_vmsplice
#ifdef __x86_64__
#define __NR_vmsplice	278
#else
#define __NR_vmsplice	316
#endif
#endif

#include <sys/signal.h>
#ifndef SI_TKILL
#define SI_TKILL        -6              /* sent by tkill system call */
#endif

#ifndef __NR_openat
#ifdef __x86_64__
#define __NR_openat		257
#else
#define __NR_openat		295
#endif
#endif

#ifndef __NR_fadvise64
#ifdef __x86_64__
#define __NR_fadvise64		221
#else
#define __NR_fadvise64		250
#ifndef __NR_fadvise64_64
#define __NR_fadvise64_64	272
#endif

#endif
#endif

#endif
