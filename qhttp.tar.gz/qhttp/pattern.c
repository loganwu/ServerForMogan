/* vim: set sw=4 ai fdm=marker fmr={,} :*/
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

#include "autoconfig.h"
#include "shmem.h"
#include "pattern.h"

#define NUM	100

struct string {
	uint32_t hash;
	int len;
	char *str;
	union {
	    void *val;
	    struct string *slist;
	};
	struct string *next;
};

struct pattern {
	struct string *list;
};

static inline uint32_t hash_string(const char *str) {
	uint32_t hash = 0;
	char c;
	while((c=*str++)) hash = hash * 11 + c;
	return hash;
}

struct pattern *create_pattern(void) {
	struct pattern *p = shalloc(sizeof(struct pattern));
	p->list = NULL;
	return p;
}

static void add_pattern_ps(
	struct pattern *pat,
	const char *pre, int plen,
	const char *suf, int slen,
	void *val)
{
	struct string **ss = &pat->list;

	while((*ss) != NULL && (*ss)->len > plen)
	    ss = &((*ss)->next);

	while((*ss) != NULL && (*ss)->len == plen) {
	    if(plen==0 || strncmp((*ss)->str, pre, plen)==0) {
	        ss = &(*ss)->slist;
		while((*ss) != NULL && (*ss)->len > slen)
		    ss = &((*ss)->next);
		while((*ss) != NULL && (*ss)->len == slen) {
		    if(slen==0 || strncmp((*ss)->str, suf, slen)==0) {
		        (*ss)->val = val;
			return;
		    }
		    ss = &((*ss)->next);
		}
		struct string *s = shalloc(sizeof(struct string)+slen);
		s[0].hash = hash_string(suf);
		s[0].len = slen;
		s[0].str = (char *)(s+1);
		if(slen) memcpy(s[0].str, suf, slen);
		s[0].val = val;
		s->next = *ss;
		*ss = s;
		return;
	    }
	    ss = &((*ss)->next);
	}

	struct string *s = shalloc(sizeof(struct string)*2+plen+slen);
	if(s==NULL) return;

	s[0].hash = hash_string(pre);
	s[1].hash = hash_string(suf);
	s[0].len = plen;
	s[1].len = slen;
	s[0].str = (char *)(s+2);
	s[1].str = s[0].str + plen;
	if(plen)memcpy(s[0].str, pre, plen);
	if(slen)memcpy(s[1].str, suf, slen);
	s[0].slist = s+1;
	s[1].val = val;

	s[0].next = *ss;
	s[1].next = NULL;
	*ss = s;
}

void add_prefix_pattern(struct pattern *pat, const char *str, void *val) {
	if(str==NULL) str = "";
	add_pattern_ps(pat, str, strlen(str), "", 0, val);
}

void add_suffix_pattern(struct pattern *pat, const char *str, void *val) {
	if(str==NULL) str = "";
	add_pattern_ps(pat, "", 0, str, strlen(str), val);
}

void add_pattern(struct pattern *pat, const char *str, void *val) {
	if(str==NULL) str = "";
	int plen = strlen(str);
	char *s = strchr(str, '*');
	if(s==NULL)
	    add_pattern_ps(pat, str, plen, "", 0, val);
	else {
	    int slen = plen - 1 - (s-str);
	    plen = s-str;
	    add_pattern_ps(pat, str, plen, str+plen+1, slen, val);
	}
}

void *match(struct pattern *pat, const char *str, int l, void *dval) {
	int n;
	struct string *s;

	for(s=pat->list; s; s=s->next) {
		n = s->len;
		if(n > l) continue;
		if(n==0 || memcmp(str, s->str, n)==0) {
		    const char *str1 = str + l;
		    const int r = l - n;
		    struct string *t;
		    for(t=s->slist; t; t=t->next) {
			n = t->len;
			if(n > r) continue;
			if(n==0 || memcmp(str1-n, t->str, n)==0)
			    return t->val;
		    }
		}
	}

	return dval;
}

void *match_url_pattern(struct pattern *pat, const char *str, void *dval) {
	return match(pat, str, strcspn(str, "?& \t\r\n"), dval);
}

void *match_pattern(struct pattern *pat, const char *str, void *dval) {
	return match(pat, str, strlen(str), dval);
}

#if PLUGIN_SUPPORT
struct pattern *_create_pattern(void)
	__attribute__((alias("create_pattern")));
void _add_pattern(struct pattern *, const char *, void *)
	__attribute__((alias("add_pattern")));
void _add_prefix_pattern(struct pattern *, const char *, void *)
	__attribute__((alias("add_prefix_pattern")));
void _add_suffix_pattern(struct pattern *, const char *, void *)
	__attribute__((alias("add_suffix_pattern")));
void * _match_url_pattern(struct pattern *, const char *, void *)
	__attribute__((alias("match_url_pattern")));
void * _match_pattern(struct pattern *, const char *, void *)
	__attribute__((alias("match_pattern")));
#endif
