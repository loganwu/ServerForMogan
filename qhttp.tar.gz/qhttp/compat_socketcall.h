#ifndef __H_COMPAT_SOCKETCALL_H
#define __H_COMPAT_SOCKETCALL_H

#ifndef SYS_SOCKET
#define SYS_SOCKET	1		/* sys_socket(2)		*/
#endif
#ifndef SYS_BIND
#define SYS_BIND	2		/* sys_bind(2)			*/
#endif
#ifndef SYS_CONNECT
#define SYS_CONNECT	3		/* sys_connect(2)		*/
#endif
#ifndef SYS_LISTEN
#define SYS_LISTEN	4		/* sys_listen(2)		*/
#endif
#ifndef SYS_ACCEPT
#define SYS_ACCEPT	5		/* sys_accept(2)		*/
#endif
#ifndef SYS_GETSOCKNAME
#define SYS_GETSOCKNAME	6		/* sys_getsockname(2)		*/
#endif
#ifndef SYS_GETPEERNAME
#define SYS_GETPEERNAME	7		/* sys_getpeername(2)		*/
#endif
#ifndef SYS_SOCKETPAIR
#define SYS_SOCKETPAIR	8		/* sys_socketpair(2)		*/
#endif
#ifndef SYS_SEND
#define SYS_SEND	9		/* sys_send(2)			*/
#endif
#ifndef SYS_RECV
#define SYS_RECV	10		/* sys_recv(2)			*/
#endif
#ifndef SYS_SENDTO
#define SYS_SENDTO	11		/* sys_sendto(2)		*/
#endif
#ifndef SYS_RECVFROM
#define SYS_RECVFROM	12		/* sys_recvfrom(2)		*/
#endif
#ifndef SYS_SHUTDOWN
#define SYS_SHUTDOWN	13		/* sys_shutdown(2)		*/
#endif
#ifndef SYS_SETSOCKOPT
#define SYS_SETSOCKOPT	14		/* sys_setsockopt(2)		*/
#endif
#ifndef SYS_GETSOCKOPT
#define SYS_GETSOCKOPT	15		/* sys_getsockopt(2)		*/
#endif
#ifndef SYS_SENDMSG
#define SYS_SENDMSG	16		/* sys_sendmsg(2)		*/
#endif
#ifndef SYS_RECVMSG
#define SYS_RECVMSG	17		/* sys_recvmsg(2)		*/
#endif

static
inline int fast_socket(int family, int type, int proto)
{
	int arg[3] = { family, type, proto };
	return fast_socketcall(SYS_SOCKET, arg);
}

static
inline int fast_socketpair(int family, int type, int proto, int fd[2])
{
	int arg[4] = { family, type, proto, (int)fd };
	return fast_socketcall(SYS_SOCKETPAIR, arg);
}

static inline int
fast_getsockopt(
		  int fd, int lvl, int opt,
		  void *ptr, socklen_t *len
		 )
{
	int arg[5] = { fd, lvl, opt, (int)ptr, (int)len };
	return fast_socketcall(SYS_GETSOCKOPT, arg);
}

static inline int
fast_setsockopt(
		  int fd, int lvl, int opt,
		  const int *ptr, socklen_t len
		 )
{
	int arg[5] = { fd, lvl, opt, (int)ptr, len };
	return fast_socketcall(SYS_SETSOCKOPT, arg);
}

struct sockaddr;
static inline int fast_accept(int fd, struct sockaddr *ptr, socklen_t *len)
{
	int arg[3] = { fd, (int)ptr, (int)len };
	return fast_socketcall(SYS_ACCEPT, arg);
}

static
inline int fast_bind(int fd, const struct sockaddr *ptr, socklen_t len)
{
	int arg[3] = { fd, (int)ptr, len };
	return fast_socketcall(SYS_BIND, arg);
}

static
inline int fast_connect(int fd, const struct sockaddr *ptr, socklen_t len)
{
	int arg[3] = { fd, (int)ptr, len };
	return fast_socketcall(SYS_CONNECT, arg);
}

static
inline int fast_listen(int fd, int len)
{
	int arg[2] = { fd, len };
	return fast_socketcall(SYS_LISTEN, arg);
}

static inline
int fast_recv(int fd, char *buf, int len, int flag)
{
	int arg[4] = { fd, (int)buf, len, flag };
	return fast_socketcall(SYS_RECV, arg);
}

static inline
int fast_send(int fd, const char *buf, int len, int flag)
{
	int arg[4] = { fd, (int)buf, len, flag };
	return fast_socketcall(SYS_SEND, arg);
}

static inline
int fast_recvmsg(int fd, void *buf, int flag)
{
	int arg[3] = { fd, (int)buf, flag };
	return fast_socketcall(SYS_RECVMSG, arg);
}

static inline
int fast_sendmsg(int fd, const void *buf, int flag)
{
	int arg[3] = { fd, (int)buf, flag };
	return fast_socketcall(SYS_SENDMSG, arg);
}

static inline int fast_getsockname(int fd, struct sockaddr *ptr, socklen_t *len) {
	int arg[3] = { fd, (int)ptr, (int)len };
	return fast_socketcall(SYS_GETSOCKNAME, arg);
}

static inline int fast_getpeername(int fd, struct sockaddr *ptr, socklen_t *len) {
	int arg[3] = { fd, (int)ptr, (int)len };
	return fast_socketcall(SYS_GETPEERNAME, arg);
}

static inline int fast_shutdown(int fd, int rw) {
	int arg[3] = { fd, rw };
	return fast_socketcall(SYS_SHUTDOWN, arg);
}


#endif
