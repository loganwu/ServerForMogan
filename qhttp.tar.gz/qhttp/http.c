#include <sys/poll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/uio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <endian.h>
#include <sys/sendfile.h>
#include "compat_errno.h"
#include "compat_sendfile64.h"
#include "compat_ctype.h"

#include "autoconfig.h"

#include "global.h"
#include "util.h"
#include "http.h"
#include "vhost.h"
#include "log.h"
#include "entity.h"
#include "timestamp.h"
#include "cookie.h"
#include "profile.h"
#include "relay.h"
#include "md5.h"
#include "stat.h"
#include "filecount.h"
#include "cgi.h"
#include "malloc.h"
#include "myconfig.h"

#if THROTTLE_SUPPORT
static int default_speed __init__;
#endif

int init_download_speed()
{

#if THROTTLE_SUPPORT
	default_speed = myconfig_get_intval("download_speed", 0);
#endif
	return 0;
}

//add end

#if __WORDSIZE<64
static inline int slow_sendfile64(struct conn *c, int bytes) {
    int n, count = 0;

	if(likely(c->sendfd_start < 0x7FFFFFFFLL)) {
	    n = 0x7FFFFFFFLL - c->sendfd_start;
	    if(likely(n > bytes))
	    	n = bytes;
#if __BYTE_ORDER == __LITTLE_ENDIAN
	    count = fast_sendfile(c->netfd, c->sendfd, (off_t *)&c->sendfd_start, n);
#else
	    off_t start = c->sendfd_start;
	    count = fast_sendfile(c->netfd, c->sendfd, &c->sendfd_start, bytes);
	    c->sendfd_start = start;
#endif
	    if(likely(count < n))
	    	return count;
	    bytes -= count;
	}

	for(; bytes>0; c->sendlen=0) {
	    n = fast_pread(c->sendfd, c->sendbuf, sendbufsz, c->sendfd_start);
	    if(n < 0) {
		    if(count==0)
		        return n;
		    return count;
	    }
	    if(n==0)
		return count;
	    c->sendfd_start += n;
	    c->sendptr = 0;
	    c->sendlen = n;
	    n = fast_send(c->netfd, c->sendbuf, c->sendlen, MSG_DONTWAIT|MSG_NOSIGNAL);
	    if(n <= 0) {
		    if(count==0)
		        return n;
		    return count;
	    }
	    count += n; bytes -= n;
	    if(n!=c->sendlen) {
		    memmove(c->sendbuf, c->sendbuf+n, c->sendlen-n);
		    c->sendlen -= n;
		    break;
	    }
	}
	return count;
}
#endif

struct conn *init_connection(struct worker *wt, int fd) {
	struct conn *c;

	c = wt->freeconn;
	wt->freeconn = c->freenext;

	c->state = CS_WAIT_REQUEST;
	c->flag_all = 0;
	c->events = POLL_DEFER_ACCEPT;
#if COOKIE_SUPPORT
    if (c->cookiestr) {
        free(c->cookiestr);
        c->cookiestr = NULL; // Added by yijian on 2007-11-05
    }  
#endif
	c->recvptr = 0;
	c->recvlen = 0;
	c->recvbuf[0] = '\0';
	c->sendptr = 0;
	c->sendlen = 0;
	c->sendcode = 0;
	c->sendfd = 0; /* fd 0 as unused */
	c->entity = NULL;
	c->host[0] = '\0';
	c->vhost = NULL;
	c->url[0] = '\0';
	c->postsize = 0;
	c->logsize = 0;
	c->ims = 0;
	c->imstime = 0;
	c->range_start = 0;
	c->range_last = -1;
#if THROTTLE_SUPPORT
	c->speed = default_speed;
	c->send_tsc = tscsec;
#endif
#if IOPERF_SUPPORT
	c->iowait = 0;
#endif
#if COOKIE_SUPPORT
	clear_cookie_buffer(c->cookie);
#endif

	fdinfo[fd].conn = &c->baseconn;
	c->netfd = fd;
#if RELAY_SUPPORT
    c->relayfd = -1;
    c->netfd_old = -1;
    c->ftarget = NULL; ////
    c->need_relay = 0;
    c->compress_flag = 0;
    c->compress_arithmetic = 0;
#endif
	c->proc = resume_http_connection;

	c->tsc4_req = TSCRND(wt->tsc_now) + tsc4_request;
	list_add_tail(&c->timer_req, &wt->timer_req);

	return c;
}

void close_connection(struct conn *c) {
	struct worker *wt = c->thread;
	uint32_t addr;
	
	PROFILE_START;
    	
	addr = fdinfo[c->netfd].addr;
    fdinfo[c->netfd].conn = NULL;
	log_tcpinfo(c->netfd);
	barrier();
	fast_close(c->netfd); /* CHECKED: OK */
#if COOKIE_SUPPORT
	if(c->cookiestr){
		free(c->cookiestr);
		c->cookiestr = NULL;
	}
#endif
#if FILECOUNT_SUPPORT
	log_fcid(c->entity, c->sendlen + c->logsize, c->url, c->host);
#endif
	if(logmode > STAT_DIGEST && c->vhost != NULL)
	    log_request(c, addr);
	c->netfd = -1;
	ISDSTAT(atomic_dec(&countermap->workcon));
	if(c->entity){
		PROFILE_START;
		ENTITY_TRACE(NULL);
		put_entity_internal(c->thread, c->entity);
		PROFILE_CONN(PROFILE_PUT_ENTITY);
		c->entity = NULL;
	}
	list_del_init(&c->timer_io);
	list_del_init(&c->timer_req);
	c->freenext = wt->freeconn;
	wt->freeconn = c;
	if(wt->inc_negative>0)
	    wt->inc_negative--;
	else
	    NEXT_LIST_ITEM(wt->inc_head, nconns1);
	PROFILE_CONN(PROFILE_CLOSE);
}

int direct_idle_connection(struct conn *c) {
	struct worker * const wt = c->thread;
	int fd;

	list_del_init(&c->timer_io);
	list_del_init(&c->timer_req);

	fd = c->netfd;
	fdinfo[fd].conn = &wt->idleconn;

	c->netfd = -1;
	c->freenext = wt->freeconn;
	wt->freeconn = c;
	if(wt->inc_negative>0)
	    wt->inc_negative--;
	else
	    NEXT_LIST_ITEM(wt->inc_head, nconns1);

	ISDSTAT(atomic_dec(&countermap->workcon));
	atomic_inc(&idlecon);
	ISDSTAT(atomic_inc(&countermap->idleswitch));

	fdinfo[fd].tsc4 = TSCRND(readtsc() + tsc_keepalive) + 1;
	list_add_tail(&fdinfo[fd].ilist, &wt->idle_list);
	c->thread->idle_cnt++;
	return 0;
}

int idle_connection(struct conn *c) {
	struct worker * const wt = c->thread;
	int fd;

	if(direct_idle)
	    return direct_idle_connection(c);

	fd = c->netfd;
	INIT_LIST_HEAD(&fdinfo[fd].ilist);
	barrier();
	/* must be latest */
	set_stub(fd, idlestub);

	if(pollmode) {
	    struct epoll_event ev;
	    /* 2.4 epoll patch require unused ev */
	    if(nconns>1)
		    fast_epoll_ctl(wt->epfd, EPOLL_CTL_DEL, fd, &ev);
	}
#if WITH_RTSIG
	else {
	    if(nconns==1) {
		    fast_fcntl(fd, F_SETSIG, rtsigno);
		    fast_fcntl(fd, F_SETFL, O_RDWR|O_NONBLOCK|O_ASYNC);
	    } else
	    	fast_fcntl(fd, F_SETOWN, 0);
	}
#endif

	if(fast_write(pipe_idle, (char *)&fd, sizeof(int)) != sizeof(int))
	{
	    /* idle pipe overflow */
	    fdinfo[fd].conn = &c->baseconn;
	    c->thread = wt;
	    c->tsc_io = readtsc() + tsc_idleswitch;
	    list_move_tail(&c->timer_io, &c->thread->timer_idle);
	    return -1;
	}

	list_del_init(&c->timer_io);
	list_del_init(&c->timer_req);

	c->netfd = -1;
	c->freenext = wt->freeconn;
	wt->freeconn = c;
	if(wt->inc_negative>0)
	    wt->inc_negative--;
	else
	    NEXT_LIST_ITEM(wt->inc_head, nconns1);

	ISDSTAT(atomic_dec(&countermap->workcon));
	atomic_inc(&idlecon);
	ISDSTAT(atomic_inc(&countermap->idleswitch));
	return 0;
}

static int linger_connection(struct conn *c) {
	struct worker * const wt = c->thread;
	int fd;
	
	fd = c->netfd;
	fast_shutdown(fd, SHUT_WR);
	if(c->entity) {
	    PROFILE_START;
		ENTITY_TRACE(NULL);
	    put_entity_internal(wt, c->entity);
	    PROFILE_CONN(PROFILE_PUT_ENTITY);
	    c->entity = NULL;
	}

	list_del_init(&c->timer_io);
	list_del_init(&c->timer_req);

	fdinfo[fd].conn = &wt->idleconn;
	fdinfo[fd].nreq = -1;

	c->netfd = -1;
	c->freenext = wt->freeconn;
	wt->freeconn = c;
	if(wt->inc_negative>0)
	    wt->inc_negative--;
	else
	    NEXT_LIST_ITEM(wt->inc_head, nconns1);

	ISDSTAT(atomic_dec(&countermap->workcon));
	atomic_inc(&idlecon);

	fdinfo[fd].tsc4 = TSCRND(readtsc() + tsc_linger) + 1;
	list_add_tail(&fdinfo[fd].ilist, &wt->linger_list);
	return 0;
}


static inline int parse_range(char *rangestr, off64_t *s, off64_t *e) {
	off64_t v;
	if(strncasecmp(rangestr, "bytes=", 6) != 0)
		goto bad;
	rangestr += 6;
	if(is_digit(*rangestr)) {
	    v = strtoull(rangestr, &rangestr, 10);
	    if(v < 0) goto bad;
	    *s = v;
	} else
	    *s = 0;
	if(*rangestr++ != '-') goto bad;
	if(*rangestr=='\0' || *rangestr==' ' || *rangestr=='\t') {
	    if(*s==0) goto bad;
	    *e = -1;
	    return 1;
	}
	if(is_digit(*rangestr)) {
	    *e = strtoull(rangestr, &rangestr, 10);
	    if(*e < *s) goto bad;
	    if(*rangestr!='\0' && *rangestr!=' ' && *rangestr!='\t')
		goto bad;
	    return 1;
	}
bad:
	*s = 0;
	*e = -1;
	return 0;
}

#define SEND_ERROR \
	if(bytes!=-EINTR && bytes!=-EAGAIN) { \
		/*lprintf("[%s:%d]send error: %s", __FILE__, __LINE__, strerror(-bytes));*/ \
		return -1;  \
	}

#if HAS_ATOMIC8
#define LOG_SENT \
		c->logsize += bytes; \
		if(c->vhost) atomic8_add(bytes, &c->vhost->bytes);
#else
#define LOG_SENT \
		c->logsize += bytes; \
		if(c->vhost) { \
		    atomic_add(bytes & 0x3FF, &c->vhost->bytes); \
		    if((bytes>>10)) \
			atomic_add(bytes>>10, &c->vhost->kbytes); \
		}
#endif

static inline int flush_outgoing(struct conn *c) {
	register int bytes;

	if(c->sendfd==1) {
	    PROFILE_START;
	    bytes = fast_writev(c->netfd, c->sendiov, c->sendptr);
	    PROFILE_CONN(PROFILE_SEND);
	    FAST_ERRNO(bytes);
	    if(unlikely(bytes<0)) {
	    	SEND_ERROR;
	    } else if(likely(bytes>0)) {
	    	LOG_SENT;
		while(c->sendiov->iov_len <= bytes) {
		    bytes -= c->sendiov->iov_len;
		    c->sendiov++;
		    c->sendptr--;
		    if(c->sendptr==0) {
			    c->sendfd = 0;
			    return 0;
		    }
		}
		c->sendiov->iov_len -= bytes;
	    }
	    return 0;
	}

	if(c->sendptr < c->sendlen) {
	    PROFILE_START;
	    bytes = fast_send(c->netfd,
		    c->sendbuf+c->sendptr, c->sendlen-c->sendptr,
		    c->sendfd ? MSG_DONTWAIT|MSG_NOSIGNAL|MSG_MORE :
		    MSG_DONTWAIT|MSG_NOSIGNAL
		    );
	    PROFILE_CONN(PROFILE_SEND);
	    FAST_ERRNO(bytes);
	    if(unlikely(bytes<0)) {
	    	SEND_ERROR;
	    } else if(likely(bytes>0)) {
		    c->sendptr += bytes;
		    LOG_SENT;
	    }
	    if(c->sendptr < c->sendlen) return 0;
	}

	if(c->sendfd > 0) {
	    PROFILE_START;
#if THROTTLE_SUPPORT
	    if(c->speed > 0)
		    bytes = c->speed << 11;
	    else
#endif
		    bytes = 1<<30;
	    if(c->sendfd_end - c->sendfd_start < bytes)
		    bytes = c->sendfd_end - c->sendfd_start;
#if IOPERF_SUPPORT
	    if(ioperf_exp) {
		    uint64_t iostart=readtsc();
#endif
#if __WORDSIZE<64
		    if(likely(has_sendfile64>0))
		        bytes = fast_sendfile64(c->netfd, c->sendfd, &c->sendfd_start, bytes);
		    else
		        bytes = slow_sendfile64(c, bytes);
#else
		    bytes = fast_sendfile (c->netfd, c->sendfd, &c->sendfd_start, bytes);
#endif
#if IOPERF_SUPPORT
		    uint64_t iostop = readtsc() - iostart;
		    c->thread->ioperf_sum += iostop;
		    c->iowait += iostop;
	    } else
#endif
	    {
#if __WORDSIZE<64
		    if(likely(has_sendfile64>0))
		        bytes = fast_sendfile64(c->netfd, c->sendfd, &c->sendfd_start, bytes);
		    else
		        bytes = slow_sendfile64(c, bytes);
#else
		    bytes = fast_sendfile (c->netfd, c->sendfd, &c->sendfd_start, bytes);
#endif
	    }
	    PROFILE_CONN(PROFILE_SENDFILE);
	    FAST_ERRNO(bytes);
	    if(unlikely(bytes < 0)) {
	    	SEND_ERROR;
	    } else if(likely(bytes > 0)) {
#if THROTTLE_SUPPORT
		    if(c->speed) {
		        c->send_tsc += tsc1k * bytes / c->speed;
		        if(bytes==(c->speed<<11))
		    	    c->suspend = 1;
		        else
		    	    c->suspend = 0;
		    }
#endif
		    LOG_SENT;
		    if(c->sendfd_start >= c->sendfd_end) {
		        c->sendfd = 0;
		        return 0;
		    }
	    } else {
	    	/* UNEXPECTED END OF FILE */
	    	return -1;
	    }
	}
	return 0;
}

/* wierd but efficienct */
void resume_http_connection(int fd, int events) {
	/* jump table for state */
	static void * const statejump[5] = {
	    [CS_WAIT_REQUEST]  = &&waitrequest,
	    [CS_PARSE_REQUEST] = &&parserequest,
	    [CS_FLUSH_DATA]    = &&flushdata,
#if COOKIE_SUPPORT
	    [CS_PARTIAL_COOKIE]= &&partialcookie,
	    [CS_AFTER_COOKIE]  = &&aftercookie,
#endif
	};
	/* convert character to index */
	static const char firstcharindex[256] = {
	    [ 'c' ] = 1,   [ 'C' ] = 1,
	    [ 'h' ] = 2,   [ 'H' ] = 2,
	    [ 'i' ] = 3,   [ 'I' ] = 3,
	    [ 'k' ] = 4,   [ 'K' ] = 4,
	    [ 'r' ] = 5,   [ 'R' ] = 5,
	    [ 'a' ] = 6,   [ 'A' ] = 6,
	    [ 'e' ] = 7,   [ 'E' ] = 7,
	    [ 't' ] = 8,   [ 'T' ] = 8,
	    [ 'q' ] = 9,   [ 'Q' ] = 9,
	};
	/* tag table */
#define MAXFC	9
#define MAXTAG	19
#define TAGJUMP(c,l,t) [l*(MAXFC+1)+c] = &&tag_##t - &&parsenext
	static const int tagjump[(MAXFC+1)*(MAXTAG+1)] = {
	    /* *********** 12345678901234567890 */
	    TAGJUMP(1, 10, connection),
	    TAGJUMP(1, 12, content_type),
	    TAGJUMP(1, 14, content_length),
#if COOKIE_SUPPORT
	    TAGJUMP(1,  6, cookie),
#endif
	    TAGJUMP(2,  4, host),
	    TAGJUMP(3, 17, if_modified_since),
	    TAGJUMP(3, 19, if_unmodified_since),
	    TAGJUMP(3,  8, if_range),
	    TAGJUMP(4, 10, keep_alive),
	    TAGJUMP(5,  8, range_if),
	    TAGJUMP(5,  5, range),
	    TAGJUMP(5, 13, request_range),
	    TAGJUMP(5,  7, referer),
	    TAGJUMP(6, 15, accept_encoding),
	    TAGJUMP(7,  6, expect),
	    TAGJUMP(8, 17, transfer_encoding),
	    TAGJUMP(9,  4, qvia),
	};
	struct conn *c;
	int bytes;
	int n;
	char *line, *eol=NULL, *p, *tag = NULL;

	c = fd2conn(fd, baseconn);
	if(c->netfd != fd) {
	    lprintf("RESUME BAD HTTP CONNECTION fd=%d %d\n", fd, c->netfd);
	    return;
	}

#if TRACE_FD
	check_bad_events(fd, events);
#endif	

	c->thread->workconn = c;
	/* connection closed */
	if((events & (POLLERR|POLLHUP))) goto hangup;

	/* flush outgoing */
	if((events&POLLOUT)) {
#if THROTTLE_SUPPORT
		if(c->speed && readtsc() < c->send_tsc-tsc125msec) {
		    suspend_connection(c);
#if PROFILE_SUPPORT	
		    profile_conn_end(c);
#endif
		    return;
		}

#endif
		if(flush_outgoing(c)<0){
		    goto hangup;
		}
	}

	if((events & POLLIN)==0 && !c->pending && !c->resume) {
	    if(c->sendptr>=c->sendlen && c->sendfd==0) goto nextrequest;

#if THROTTLE_SUPPORT
	    if(c->suspend){
		    suspend_connection(c);
	    }else
#endif
	    {
		    c->tsc_io = readtsc() + tsc_send;
		    list_move_tail(&c->timer_io, &c->thread->timer_send);
	    }

	    return;
	}


//recvdata:
	if(recvbufsz > c->recvlen) {
	    PROFILE_START;
	    bytes = fast_recv(fd, c->recvbuf+c->recvlen, recvbufsz-c->recvlen, MSG_DONTWAIT);
	    PROFILE_CONN(PROFILE_RECV);
	    if(bytes==0) goto hangup;
	    if(bytes>0) {
		    c->recvlen += bytes;
		    c->pending = c->recvlen==recvbufsz;
	    } else {
		    FAST_ERRNO(bytes);
	    	if(bytes!=-EINTR && bytes!=-EAGAIN)
			    goto hangup;

	    	c->pending = 0;
		    if(!c->resume)
		        goto requestout;
	    }

	    c->recvbuf[c->recvlen] = '\0';
	}

parseline:
	line = c->recvbuf + c->recvptr;
	eol = strchr(line, '\n');
	if(c->resume) {
		c->resume = 0;
		if(c->header_parsed)
			goto flushdata;
	}
	if(likely(eol!=NULL)) {
	    c->recvptr = eol + 1 - c->recvbuf;
	    if(eol != line && eol[-1]=='\r')
		    *--eol = '\0';
	    else
		    *eol = '\0';
	}

	goto *statejump[c->state];

waitrequest:
	if(unlikely(eol==NULL)) {
	    /* incompleted line */
	    if(unlikely(c->recvptr==0 && c->recvlen==recvbufsz))
	    {
#if PROFILE_SUPPORT
		    c->thread->reqcnt ++;
#endif
		    /* buffer full, BAD PROTOCOL */;
		    http_error(c, 400, NULL);
		    goto flushdata0;
	    }

	    goto requestout;
	}

#if PROFILE_SUPPORT
	c->thread->reqcnt ++;
#endif

	if(!strncmp(line, "GET ", 4)) {
	    line += 4;
	    c->method = METHOD_GET;
	} else if(!strncmp(line, "HEAD ", 5)) {
	    line += 5;
	    c->method = METHOD_HEAD;
	} else if(!strncmp(line, "POST ", 5)) {
	    line += 5;
	    c->method = METHOD_POST;
	} else {
	    line[strcspn(line, " \t\r")] = '\0';
	    http_error(c, 501, line);
	    goto flushdata0;
	}

	if(unlikely(line[0] != '/')) {
	    http_error(c, 400, NULL);
	    goto flushdata0;
	}

	ISDSTAT(atomic_inc(&countermap->totalreq));

	tag = NULL;
	n = strcspn(line, " \t\r");
	p = line+n;

	if(unlikely(*p=='\0')) {
	    c->no_header = 1;
	} else {
	    while(*p==' '||*p=='\t'||*p=='\r') p++;

        if(p[0]=='\0') {
            c->no_header = 1;
        }		
        else {            
            if ( (*(uint32_t *)p != *(uint32_t *)"HTTP")
              || (p[4] != '/' || !is_digit(p[5]))
              || (p[6] != '.' || !is_digit(p[7]) )
              || (p[8] != '\0')
		    ) {
		        http_error(c, 400, NULL);
		        goto flushdata0;
	        }

	        if(p[5]>'1' || (p[5]=='1' && p[7]>='1')) {
	    	    c->http_v11 = 1;
		        if(timeout_keepalive)
			        c->keepalive = 1;
            }
	    }
	}
    if (1 == c->no_header) {
        http_error(c, 400, NULL);
        goto flushdata0;
    }

    // Comment-Begin by yijian on 20071103
	//if(strip_query_string) 
	//    n = strcspn(line, " \t\r?&");
    // Comment-End by yijian on 20071103
	if(unlikely(n > maxurllen)) {
	    line[maxurllen] = '\0';
	    http_error(c, 414, line);
	    goto flushdata0;
	}

	memcpy(c->url, line, n);
	c->url[n] = '\0';

	if(unlikely(c->no_header))
	    goto processrequest;
	c->state = CS_PARSE_REQUEST;
	goto parsenext;

#if COOKIE_SUPPORT

aftercookie:
	if(line[0]!=' ' && line[0]!='\t')
	    goto parserequest;
partialcookie:

	if(eol!=NULL) {
	    decode_cookie(c->cookie, line+7, 0);
	    c->state = CS_AFTER_COOKIE;
	    goto parsenext;
	} else if(c->recvptr==0 && c->recvlen==recvbufsz) {
	    /* long line */
	    c->recvptr = c->recvlen - decode_cookie(c->cookie, line+7, recvbufsz-7);
	    c->state = CS_PARTIAL_COOKIE;
	}

	goto requestout;
#endif

parserequest:
	if(unlikely(c->long_line)) {
	    /* skip long line */
	    if(eol==NULL) {
		    c->recvptr = c->recvlen = 0;
		    c->recvbuf[0] = '\0';
		    goto requestout;
	    }

	    c->long_line = 0;
	    goto parsenext;
	}

	if(unlikely(eol==NULL)) {
	    /* check long line */
	    if(unlikely(c->recvptr==0 && c->recvlen==recvbufsz)) {
#if COOKIE_SUPPORT
		    if(cookieinfo && !strncasecmp(line, "Cookie:", 7)) {
		        c->recvptr = c->recvlen - decode_cookie(c->cookie, line+7, recvbufsz-7);
		        c->state = CS_PARTIAL_COOKIE;
		    } else
#endif
		    {
		        c->long_line = 1;
		        c->recvptr = c->recvlen = 0;
		        c->recvbuf[0] = '\0';
		    }
	    }

	    goto requestout;
	}


	if(unlikely(line[0]=='\0')) goto processrequest;
#if 0
	/* omit repeated line processing, let jumptable remove it */
	if(unlikely(line[0]==' '||line[0]=='\t')) goto parsenext;
#endif


	/* parse tags */
	if(unlikely((p = strchr(line, ':')) == NULL)) goto parsenext;

	n = p - line;
	tag = line;
	tag[n] = '\0';
	line = p + 1;

	while(line[0]==' '||line[0]=='\t') line++;
	if(n > MAXTAG) goto parsenext;
	goto *(&&parsenext +
	    tagjump[n*(MAXFC+1) + firstcharindex[*(unsigned char *)tag]]);

tag_connection:
	if(!(timeout_keepalive && !strcasecmp(tag, "Connection")))
	    goto parsenext;

	if(!strncasecmp(line, "close", 5)) {
	    c->keepalive = 0;
	    c->keepalive_off = 1;
	} else if(!c->keepalive && !c->keepalive_off &&
		  !strncasecmp(line, "keep-alive", 10))
	{
	    if(fdinfo[fd].nreq < nreq_keepalive)
		c->keepalive = 1;
	}

	goto parsenext;
tag_content_type:

#if RELAY_SUPPORT
	if(!strcasecmp(tag, "Content-type")) {
		c->has_ct = 1;
		strncpy(c->sendbuf, line, 128);
	}
#endif
	goto parsenext;

tag_content_length:
	if(!strcasecmp(tag, "Content-length")) {
	    if(c->method!=METHOD_POST) {
		    c->keepalive = 0;
		    c->keepalive_off = 1;
	    }

	    c->has_cl = 1;
	    c->has_chunked = 0;
	    c->postsize = atoi(line);
	    if(c->postsize < 0 || c->postsize > maxpostsize) {
		    http_error(c, 413, c->url);
		    goto flushdata0;
	    }
	}

	goto parsenext;
#if COOKIE_SUPPORT

tag_cookie:

	// ***BEGIN*** Added by yijian on 2007-11-06
    if (c->cookiestr)
        free(c->cookiestr);

    size_t line_len = strlen(line);
    c->cookiestr=malloc(line_len+1);        			
	strcpy(c->cookiestr,line);
	c->cookiestr[line_len] = 0;
    // ***END*** Added by yijian on 2007-11-06

	if(cookieinfo && !strcasecmp(tag, "Cookie")) {
		decode_cookie(c->cookie, line, 0);
		c->state = CS_AFTER_COOKIE;
	}

	goto parsenext;
#endif
tag_host:

	if(!strcasecmp(tag, "Host")) {
	    save_vhost(c, line);
	}
	goto parsenext;

tag_keep_alive:
	if(!strcasecmp(tag, "Keep-Alive")) {
	    c->keepalive_header = 1;
	}
	goto parsenext;

tag_if_modified_since:
	if(!strcasecmp(tag, "If-Modified-Since")) {
	    c->imstime = str2time(line);
	    if(c->imstime)
		    c->ims = IMS;
	}
	goto parsenext;

tag_if_unmodified_since:
	if(!strcasecmp(tag, "If-UnModified-Since")) {
	    c->imstime = str2time(line);
	    if(c->imstime)
		    c->ims = IUMS;
	}
	goto parsenext;

tag_if_range:
	if(!strcasecmp(tag, "If-Range")) {
	    c->imstime = str2time(line);
	    if(c->imstime)
		    c->ims = IR;
	}
	goto parsenext;

tag_range_if:
	if(!strcasecmp(tag, "Range-If")) {
	    c->imstime = str2time(line);
	    if(c->imstime)
		    c->ims = IR;
	}
	goto parsenext;

tag_referer:
	if(referer_checking==0) {
	    c->referer_checked = 1;
	} else if(!strcasecmp(tag, "Referer")) {
	    if(check_referer_domain(c->url, line)) {
		    c->referer_checked = 1;
	    } else {            
            int code = redirect_refer(&c->url) ? 302: 450;
            http_error(c, code, c->url); 
		    goto flushdata0;
	    }
	}

	goto parsenext;
tag_range:

	if(!strcasecmp(tag, "Range")) {
range:
	    parse_range(line, &c->range_start, &c->range_last);
	}

	goto parsenext;
tag_request_range:

	if(!strcasecmp(tag, "Request-Range")) goto range;

	goto parsenext;
tag_accept_encoding:

	if(gzmode && !strcasecmp(tag, "Accept-Encoding")) {
        c->compress_arithmetic = 0;
        if (strstr(line, "gzip"))
            c->compress_arithmetic |= 0x0001;
        if (strstr(line, "deflate"))
            c->compress_arithmetic |= 0x0100;
        if (c->compress_arithmetic != 0)
            c->gzippable = 1;
#if 0
	    for(p=line; *p; ) {
	    	/* cheap way !strncasecmp(p, "gzip", 4) */
	        if((0x20202020 | *(uint32_t *)p) == *(uint32_t *)"gzip") {
		        c->gzippable = 1;
		        break;
		    }
		    for(;*p; p++) {
			    if(*p==',') {
				    for(p++; *p; p++)
					    if(*p!=' ' && *p!='\t') break;
				    break;
			    }
		    }
	    }
#endif
	}

	goto parsenext;
tag_expect:

	if(!strcasecmp(tag, "Expect")) {

		if(c->http_v11 && *(uint32_t *)line == *(uint32_t *)"100-") {
		    c->expect100 = 1;
		} else 
		    http_error(c, 417, NULL);

		goto flushdata0;
	}

	goto parsenext;
tag_transfer_encoding:

	if(!c->has_cl && !strcasecmp(tag, "Transfer-Encoding")) {

		if(!strncasecmp(line, "chunked", 7)) {
		    c->has_chunked = 1;
		    c->keepalive = 0;
		    c->keepalive_off = 1;
		} else
		    http_error(c, 501, "Transfer-Encoding");

		goto flushdata0;
	}

	goto parsenext;
tag_qvia:

	if(decode_relay_ip && !c->qvia && !strcasecmp(tag, "QVia")) {

	    unsigned char bin[21];
	    c->qvia = 1;
	    if(decode_hex(line, (char *)bin, 21)==20) {
		md5_t ctx;
		unsigned char via[16];
		MD5Init(&ctx);
		MD5Update(&ctx, (unsigned char *)QVPREFIX, sizeof(QVPREFIX)-1);
		MD5Update(&ctx, bin, 4);
		MD5Update(&ctx, (unsigned char *)QVSUFFIX, sizeof(QVPREFIX)-1);
		MD5Final(via, &ctx);
		if(
			*(uint32_t *)(bin+4)==*(uint32_t *)(via+0) &&
			*(uint32_t *)(bin+8)==*(uint32_t *)(via+4) &&
			*(uint32_t *)(bin+12)==*(uint32_t *)(via+8) &&
			*(uint32_t *)(bin+16)==*(uint32_t *)(via+12)
		  )
		  	fdinfo[c->netfd].addr = *(uint32_t *)bin;
	    }
	}

	goto parsenext;


processrequest:

	c->header_parsed = 1;
	list_del_init(&c->timer_req);


	if(referer_checking>1 && c->referer_checked==0) {
	    http_error(c, 451, c->url);
	    goto flushdata0;
	}

	if(c->method==METHOD_POST && !c->has_cl && !c->has_chunked) {
	    http_error(c, 411, c->url);
	    goto flushdata0;
	}
	/* process request, 1==relay 0==reply -1==continue */

    // if(process_request(c)>0) return;
    int nreq = process_request(c);	
    if (110 == nreq) {  
#if PLUGIN_SUPPORT
#if RELAY_SUPPORT
        //char* trailer = strstr(c->recvbuf, " HTTP");
        //int tlen = strlen(trailer);
        char* trailer = NULL;
        int tlen = 0;
        /* process request, 1==relay 0==reply -1==continue */
        //switch(try_relay_connection(c, line+n, eol-line-n))
        switch(try_relay_connection(c, trailer, tlen))
        {
        case 1:        
            if(c->vhost) atomic_inc(&c->vhost->req);
            return;
        case 0:        
            if(c->vhost) atomic_inc(&c->vhost->req);
            goto flushdata0;
        case -1: 
			http_error(c, 404, c->url);
			break;
	    }
#endif
#endif
    }
    else if (nreq > 0) return;

flushdata0:

	if(flush_outgoing(c)!=0) goto hangup;

flushdata:

	if(unlikely(c->header_parsed)) {
	    /* Header Parsed */
	    if(likely(c->postsize==0)) {
		    if(c->sendptr>=c->sendlen && c->sendfd==0) goto nextrequest;
	    } 
        else if(c->recvlen-c->recvptr >= c->postsize) {
	    	c->recvptr += c->postsize;
		    c->postsize = 0;
		    if(c->sendptr>=c->sendlen && c->sendfd==0) goto nextrequest;
	        } else {
	    	    c->postsize -= c->recvlen - c->recvptr;
	    	    c->recvptr = c->recvlen = 0;
		        c->recvbuf[0] = '\0';
	        }
	        goto requestout;
	    } else if(eol==NULL) {
	        if(c->recvptr == 0 && c->recvlen == recvbufsz) {
		        c->recvptr = 0;
		        c->recvlen = 1;
		        c->recvbuf[1] = '\0';
	        }
	        goto requestout;
	    } else if(line[0]=='\0') {
	        if(c->postsize==0 && c->sendptr>=c->sendlen && c->sendfd==0)
	    	    goto nextrequest;

	        c->header_parsed = 1;
	        list_del_init(&c->timer_req);
	    }

	goto parsenext;

nextrequest:

	if(c->keepalive==0) {
	    if(linger_close) {
		    linger_connection(c);
		    return;
	    } else
	    	goto hangup;
	}

	if(unlikely(c->recvlen > c->recvptr)) {
	    ISDSTAT(atomic_inc(&countermap->pipereq));
	}
	else if(c->tcpcork) {
	    PROFILE_START;
	    fast_setsockopt(fd, SOL_TCP, TCP_CORK, (n=0,&n), sizeof(n));
	    if(patch_cork)
		fast_setsockopt(c->netfd, SOL_TCP, TCP_NODELAY,
			    (n=1,&n), sizeof(n));
	    PROFILE_CONN(PROFILE_FLUSH);
	    c->tcpcork = 0;
	}


#if FILECOUNT_SUPPORT
	// ***BEGIN*** Modified by yorkwang for file count on 2008-02-18
	log_fcid(c->entity, c->sendlen + c->logsize, c->url, c->host);
	// ***END*** Modified by yorkwang for file count on 2008-02-18
#endif

	if(logmode > STAT_DIGEST && c->vhost != NULL)
	    log_request(c, fdinfo[fd].addr);
	fdinfo[fd].nreq++;
	c->flag_zero = 0;
	c->range_start = 0;
	c->range_last = -1;
	c->sendcode = 0;
	c->host[0] = '\0';
	c->url[0] = '\0';
	c->vhost = NULL;
	c->logsize = 0;
#if THROTTLE_SUPPORT
	c->speed = default_speed;

#endif
#if COOKIE_SUPPORT
	clear_cookie_buffer(c->cookie);
#endif

	if(c->entity) {
	    PROFILE_START;
		ENTITY_TRACE(NULL);
	    put_entity_internal(c->thread, c->entity);
	    PROFILE_CONN(PROFILE_PUT_ENTITY);
	    c->entity = NULL;
	}

	c->tsc4_req = TSCRND(c->thread->tsc_now) + tsc4_request;
	list_move_tail(&c->timer_req, &c->thread->timer_req);

parsenext:
	if(likely(eol != NULL)) goto parseline;
requestout:

	if(likely(c->recvptr != 0)) {
	    if(likely(c->recvptr==c->recvlen)) {
		    c->recvlen = 0;
	    } else {
		    memmove(c->recvbuf, c->recvbuf + c->recvptr, c->recvlen - c->recvptr);
		    c->recvlen -= c->recvptr;
	    }
	    c->recvptr = 0;
	}
	//if(bytes > 0) goto recvdata;

	c->tsc_io = readtsc();
	if(c->sendptr<c->sendlen || c->sendfd>0)
	{
	    if(c->header_parsed) {
		    events = POLLOUT;
	    } else {
		    events = POLLIN|POLLOUT;
	    }

#if THROTTLE_SUPPORT
	    if(c->suspend)
		    suspend_connection(c);
	    else
#endif
	    if(c->pending && (c->events & POLLIN))
	    {
	    	list_move_tail(&c->timer_io, &c->thread->pending);
	    } else
	    {
		    c->tsc_io += tsc_send;
		    list_move_tail(&c->timer_io, &c->thread->timer_send);
	    }

	}
	else if(c->pending) {
	    events = POLLIN;
	    list_move_tail(&c->timer_io, &c->thread->pending);
	}
	else if(c->state==CS_WAIT_REQUEST && c->recvlen==0)
	{
	    events = POLLIN;
	    c->tsc_io += direct_idle||tsc_idleswitch ? tsc_idleswitch : tsc_keepalive;
	    list_move_tail(&c->timer_io, &c->thread->timer_idle);
	}
	else
	{
	    events = POLLIN;
	    c->tsc_io += tsc_recv;
	    list_move_tail(&c->timer_io, &c->thread->timer_recv);
	}

	if(pollmode) {
	    if(nconns>1) {
		    struct epoll_event ev;
		    ev.events = events|EPOLLET;
		    ev.data.fd = fd;
		    if((c->events == POLL_DEFER_ACCEPT)) {
		        fast_epoll_ctl(c->thread->epfd, EPOLL_CTL_ADD, fd, &ev);
		    } else if(events != c->events) {
		        fast_epoll_ctl(c->thread->epfd, EPOLL_CTL_MOD, fd, &ev);
		    }
	    }
	    c->events = events;
	}

	return;

hangup:
	close_connection(c);
	return;
}

