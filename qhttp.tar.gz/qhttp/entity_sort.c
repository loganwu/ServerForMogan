/* vim: set sw=4 ai :*/
#include <stdlib.h>

#include "entity_hash.h"

#define SWAP(a, b)	(({register struct entity_hash *_t = a; a = b; b = _t;}))
#define STACK_SIZE	(8 * sizeof(size_t))
#define PUSH(low, high)	(*top++ = (low), *top++ = (high))
#define	POP(low, high)	((high) = *--top, (low) = *--top)
#define THRESH	2

void sort_entity_hits(struct entity_hash **pbase, int total_elems, int fuzz) {
	/* STACK-USAGE: <100 */
    	int lm, hm;
	int lo;
	int hi;
	int stack[STACK_SIZE*2];
	int *top;

	if (total_elems <= THRESH)
	    goto out;

	if(fuzz > 0) {
	    lm = fuzz;
	    hm = -1;
	} else if(fuzz < 0) {
	    lm = total_elems;
	    hm = total_elems + fuzz;
	} else {
	    lm = total_elems;
	    hm = -1;
	}

    	lo = 0;
	hi = total_elems - 1;
	top = stack;
	PUSH (0, 0);

	while (stack < top)
	{
	    int lt, rt, mid;

	    mid = (hi + lo) >> 1;
	    if (pbase[mid]->hits > pbase[lo]->hits)
		SWAP (pbase[mid], pbase[lo]);
	    if (pbase[hi]->hits > pbase[mid]->hits)
		SWAP (pbase[mid], pbase[hi]);
	    else
		goto jump_over;
	    if (pbase[mid]->hits > pbase[lo]->hits)
		SWAP (pbase[mid], pbase[lo]);
jump_over:
	    lt = lo + 1;
	    rt = hi - 1;

	    mid = pbase[mid]->hits;
	    do
	    {

		while (pbase[lt]->hits > mid)
		    lt++;

		while (pbase[rt]->hits < mid)
		    rt--;

		if (lt < rt)
		{
		    SWAP (pbase[lt], pbase[rt]);
		    lt++;
		    rt--;
		}
		else if (lt == rt)
		{
		    lt++;
		    rt--;
		    break;
		}
	    } while (lt <= rt);

	    if(lt < hm) {
		if(hi-lt <= THRESH)
		    POP (lo, hi);
		else
		    lo = lt;
	    } else if(rt > lm) {
		if(rt-lo <= THRESH)
		    POP (lo, hi);
		else
		    hi = rt;
	    } else
	    if (rt-lo <= THRESH)
	    {
		if (hi-lt <= THRESH)
		    POP (lo, hi);
		else
		    lo = lt;
	    }
	    else if (hi-lt <= THRESH) {
		hi = rt;
	    } else if (rt-lo > hi-lt)
	    {
		PUSH (lo, rt);
		lo = lt;
	    }
	    else
	    {
		PUSH (lt, hi);
		hi = rt;
	    }
	}
out:
	if(fuzz > 0) {
	    lm = 0;
	    hm = fuzz;
	} else if(fuzz < 0) {
	    hm = total_elems + fuzz;
	    lm = total_elems - 1;
	} else {
	    lm = 0;
	    hm = total_elems - 1;
	}
	for(hi = 0; hi < THRESH; hi++)
	    for(lo = lm; lo < hm; lo++) {
		if(pbase[lo]->hits < pbase[lo+1]->hits)
		    SWAP(pbase[lo], pbase[lo+1]);
	    }
}

void split_entity_hits(struct entity_hash **pbase, int total_elems, int fuzz) {
	int lo;
	int hi;

	if (total_elems <= 1) return;
	if (fuzz < 0) fuzz += total_elems;

    	lo = 0;
	hi = total_elems - 1;

	while (1)
	{
	    int lt, rt, mid;

	    mid = (hi + lo) >> 1;
	    if (pbase[mid]->hits > pbase[lo]->hits)
		SWAP (pbase[mid], pbase[lo]);
	    if (pbase[hi]->hits > pbase[mid]->hits)
		SWAP (pbase[mid], pbase[hi]);
	    else
		goto jump_over;
	    if (pbase[mid]->hits > pbase[lo]->hits)
		SWAP (pbase[mid], pbase[lo]);
jump_over:
	    if(hi-lo <= 2) break;
	    lt = lo + 1;
	    rt = hi - 1;

	    mid = pbase[mid]->hits;
	    do
	    {

		while (pbase[lt]->hits > mid)
		    lt++;

		while (pbase[rt]->hits < mid)
		    rt--;

		if (lt < rt)
		{
		    SWAP (pbase[lt], pbase[rt]);
		    lt++;
		    rt--;
		}
		else if (lt == rt)
		{
		    lt++;
		    rt--;
		    break;
		}
	    } while (lt <= rt);

	    if(lt < fuzz) {
		    lo = lt;
	    } else if(rt > fuzz) {
		    hi = rt;
	    } else
		break;
	}
}
