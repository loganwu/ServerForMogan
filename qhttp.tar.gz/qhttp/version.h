#ifndef __TWS_VERSION_H
#define __TWS_VERSION_H

extern char qhttpd_version_string[];
extern char qhttpd_compiling_date[];

#endif // __TWS_VERSION_H
