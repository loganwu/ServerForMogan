/* vim: set sw=4 ai :*/
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <grp.h>
#include <sys/prctl.h>
#include <sys/fsuid.h>
#include "compat_ctype.h"
#include "compat_rlimit.h"

#include "autoconfig.h"
#include "global.h"
#include "myconfig.h"
#include "priv.h"
#include "log.h"
#include "fault.h"

static int role = ROLE_STARTUP;
static int usecap __init__ = -1;
static int orig_uid __init__= 0;
static int orig_gid __init__= 0;
static int runas_uid __init__;
static int runas_gid __init__;
int main_chown __init__;
int need_chroot __init__;

/* custom name2id() prevent libnss_* dependency, required for static link */
int name2id(const char *filename, const char *name) {
	int id = -1;

	if(is_digit(name[0]))
	    id = atoi(name);
	else {
	    FILE *fp = fopen(filename, "r");
	    if(fp) {
		char buf[100];
		int len = strlen(name);
		while(fgets(buf, 100, fp)) {
		    if(!memcmp(name, buf, len) && buf[len]==':') {
			char *p = strchr(buf+len+1, ':');
			if(p)
			    id = atoi(p+1);
			break;
		    }
		}
		fclose(fp);
	    }
	}
	return id;
}

void init_privilege(void) {
	orig_uid = fast_getuid();
	orig_gid = fast_getgid();
	usecap = check_capability();

	char *p;
	p = myconfig_get_value("runas_user");
	if(p && *p)
	    runas_uid = name2id("/etc/passwd", p);
	else if(orig_uid)
	    runas_uid = orig_uid;
	else
	    runas_uid = name2id("/etc/passwd", "nobody");
	//if(runas_uid<=0) runas_uid = 65534;
    if(runas_uid<0) runas_uid = 65534;

	p = myconfig_get_value("runas_group");
	if(p && *p)
	    runas_gid = name2id("/etc/group", p);
	else if(orig_gid)
	    runas_gid = orig_gid;
	else
	    runas_gid = name2id("/etc/group", "nobody");
	//if(runas_gid<=0) runas_gid = 65534;
    if(runas_gid<0) runas_gid = 65534;
	
    p = myconfig_get_value("umask");
	if(p==NULL)
	    umask(0027);
	else {
	    int mask;
	    char dummy;
	    if(sscanf(p, "%o%c", &mask, &dummy)==1)
	    	umask(mask);
	}

	main_chown = myconfig_get_intval("secure_main_thread", 0);
	need_chroot = myconfig_get_intval("disable_chroot", 0) == 0;

	if(usecap==-1) {
	    uid_t r=1, e=1, s=1;
	    fast_getresuid(&r, &e, &s);
	    if(r && e && s) {
	    	if(need_chroot) {
		    lprintf("No root privilege! Some function may failed!\n");
		    runas_uid = orig_uid;
		    runas_gid = orig_gid;
		} else {
		    lprintf("Need root privilege to continue!\n");
		    exit(-1);
		}
	    }
	} else {
#if 0
	    if((usecap & PRIV_NETBIND)==0) {
		lprintf("\7No enough privilege, listen port under 1024 may fail\n");
	    }
	    if((usecap & PRIV_RESOURCE)==0) {
		lprintf("\7No enough privilege increase file handle limitation\n");
	    }
#endif
	    if((usecap & PRIV_SETGID)==0 && runas_uid != orig_uid) {
		lprintf("\7No CAP_SETGID capability, runas_group ignored\n");
		runas_uid = orig_uid;
	    }
	    if((usecap & PRIV_SETUID)==0 && runas_uid != orig_uid) {
		lprintf("\7No CAP_SETUID capability, runas_user ignored\n");
		runas_gid = orig_gid;
	    }
	    if((usecap & PRIV_CHROOT)==0 && need_chroot) {
		lprintf("\7Need CAP_SYS_CHROOT capability to run!\n");
		exit(-1);
	    }

	    prctl(PR_SET_KEEPCAPS, 1);
	    uid_t ur, ue, us;
	    gid_t gr, ge, gs;
	    fast_getresgid(&gr, &ge, &gs);
	    fast_getresuid(&ur, &ue, &us);
	    if(ur != ue || gr != ge) {
		if(gr != ge)
		    fast_setresgid(gr, gr, gr);
		if(ur != ue)
		    fast_setresuid(ur, ur, ur);
	    }
	}

	if(orig_uid==runas_uid && orig_gid==runas_gid)
		main_chown = 0;
	if(need_chroot==0)
		lprintf("\7Disabling chroot behavior! Take your own risk!\n");
}

void set_security_role(int r) {
	if(r==role) return;
	if(usecap==-1) {
	    switch(r) {
	    case ROLE_ROOT:
		fast_setresgid(orig_gid, orig_gid, orig_gid);
		/* in pthread mode, parent process is killable by runas_user */
		fast_setresuid(0, 0, runas_uid);
		fast_setfsuid(orig_gid);
	    	break;
	    case ROLE_OWNER:
		fast_setresgid(orig_gid, orig_gid, orig_gid);
		if(orig_uid!=0)
		    fast_setresuid(orig_uid, orig_uid, runas_uid);
		break;
	    case ROLE_GUEST:
	    	if(orig_gid != runas_gid) {
		    fast_setresgid(runas_gid, runas_gid, runas_gid);
		    fast_setgroups(0, NULL);
		}
		fast_setresuid(runas_uid, runas_uid, runas_uid);
		break;
	    }
	} else {
	    switch(r) {
	    case ROLE_ROOT:
		init_capability();
		/* in pthread mode, parent process is killable by runas_user */
		if(orig_uid!=runas_uid)
		    fast_setresuid(orig_uid, orig_uid, runas_uid);
	    	break;
	    case ROLE_OWNER:
		set_capability_role(ROLE_OWNER);
		break;
	    case ROLE_GUEST:
	    	if(orig_gid!=runas_gid) {
		    fast_setresgid(runas_gid, runas_gid, runas_gid);
		    fast_setgroups(0, NULL);
		}
		if(orig_uid!=runas_uid)
		    fast_setresuid(runas_uid, runas_uid, runas_uid);
		set_capability_role(ROLE_GUEST);
		break;
	    }
	}
	if(need_chroot==0)
	    prctl(PR_SET_DUMPABLE, 1); // affect /proc/<tid> access perm
}

