#ifndef _H_MESSAGE_H_
#define _H_MESSAGE_H_ 1
#ifdef  __cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <stdarg.h>
#include <stdint.h>

#define MAX_MESSAGE_LENGTH 65536
#define MIN_MESSAGE_LENGTH 24
#define MSG_SYS_NOP	(0xFF000000)
#define MSG_SYS_PING	(0xFF000001)
#define MSG_SYS_PONG	(0xFF000002)
#define MSG_SYS_WELCOME	(0xFF000003)
#define MSG_SYS_QUEUED	(0xFF000004)
#define MSG_SYS_BUSY	(0xFF000005)
#define MSG_SYS_DENIED	(0xFF000006)
#define MSG_SYS_AUTH	(0xFF000007)
#define MSG_SYS_EXIT	(0xFF000008)
#define MSG_SYS_INVALID	(0xFF000009)
#define MSG_SYS_ACCEPTED	(0xFF00000A)
#define MSG_SYS_IGNORED		(0xFF00000B)
#define MSG_SYS_START_TRANSFER	(0xFF00000C)
#define MSG_SYS_END_TRANSFER	(0xFF00000D)
#define MSG_SYS_GET_SEQNO	(0xFF00000E)
#define MSG_SYS_CURRENT_SEQNO	(0xFF00000F)
#define MSG_SYS_SUSPEND 	(0xFF000010)
#define MSG_SYS_RESUME		(0xFF000011)
#define MSG_SYS_GETFILEINFO	(0xFF000012)
#define MSG_SYS_FILEINFO	(0xFF000013)
#define MSG_SYS_GETFILEDATA	(0xFF000014)
#define MSG_SYS_FILEDATA	(0xFF000015)
#define MSG_SYS_FILECHANGED	(0xFF000016)
#define MSG_PLATFORM_LINUX	(0xFF000017)
#define MSG_PLATFORM_WIN2K	(0xFF000018)
#define MSG_AUTH_NONE		(0xFF010000)
#define MSG_AUTH_RELAY		(0xFF010001)
#define MSG_AUTH_DIGEST		(0xFF010002)
#define MSG_REALM_SLAVE		(0xFF010201)
#define MSG_REALM_RELAY		(0xFF010202)
#define MSG_REALM_ADMIN		(0xFF010203)

#define OP_SET		1
#define OP_MIN		2
#define OP_MAX		3
#define OP_COUNT	4
#define OP_SUM		5
#define OP_UCOUNT	6
#define OP_LOG		7
#define OP_LOG_COUNT	8
#define OP_TIMESTAMP	9
#define OP_IPLOG	10
#define OP_IDCOUNT	11
#define OP_IDSUM	12
#define OP_IDSUM_ID0	13
#define OP_IDSUM_ID1	14

#define MF_DISCARDABLE	1
struct message_header {
	uint16_t len;
	uint8_t  hlen;
	uint8_t  flag0;
	uint32_t  flag;
	uint32_t  saddr;
	uint32_t  seqno;
	uint32_t  type;
	uint32_t  timestamp;
};

typedef struct message_header message_header_t;

struct message_log_record {
	uint8_t level;
	uint8_t reserved;
	uint16_t textlen;
	char text[0];
};

struct message {
	message_header_t *hdr;
	int dlen;
	char *dptr;
};

typedef struct message message_t;

struct msgio_content {
	int isfile;
	int sock;
	void *privacy;
	char buf[MAX_MESSAGE_LENGTH];
	int ptr;
	int len;
	uint32_t off;
	message_t msg;
};

typedef struct msgio_content msgio_t;

extern int msg_write_all(int sock, char *buf, int len);
extern int msg_send_simple(int sock, uint32_t type);
extern int msg_send_value4(int sock, uint32_t type, uint32_t value);
extern int msg_send_value8(int sock, uint32_t type, uint32_t val1, uint32_t val2);
static inline int msg_send_raw(int sock, message_header_t *msg)
{
	if(msg_write_all(sock, (char *)msg, msg->len) != msg->len)
	    return -1;
	return 0;
}

extern int msgp_send_simple(int sock, void *privacy, uint32_t type);
extern int msgp_send_value4(int sock, void *privacy, uint32_t type, uint32_t value);
extern int msgp_send_value8(int sock, void *privacy, uint32_t type, uint32_t val1, uint32_t val2);
extern int msgp_send_raw(int sock, void *privacy, message_header_t *msg);
extern int msgp_send_direct(int sock, void *privacy, message_header_t *msg);


extern int msgio_init_socket(msgio_t *mb, int sock);
extern int msgio_init_file(msgio_t *mb, int sock);
static inline int msgio_set_privacy(msgio_t *mb, void *p) { mb->privacy = p; return 0; }
extern int msgio_seek(msgio_t *mb, uint32_t off);
extern int msgio_read(msgio_t *mb, int timeout);

static inline int msgio_send_simple(msgio_t *mb, uint32_t type) {
	return msgp_send_simple(mb->sock, mb->privacy, type);
}
static inline int msgio_send_value4(msgio_t *mb, uint32_t type, uint32_t value) {
	return msgp_send_value4(mb->sock, mb->privacy, type, value);
}
static inline int msgio_send_value8(msgio_t *mb, uint32_t type, uint32_t val1, uint32_t val2){
	return msgp_send_value8(mb->sock, mb->privacy, type, val1, val2);
}

static inline int msgio_send_raw(msgio_t *mb, message_header_t *msg) {
    return msgp_send_raw(mb->sock, mb->privacy, msg);
}

static inline int msgio_send_direct(msgio_t *mb, message_header_t *msg) {
    return msgp_send_direct(mb->sock, mb->privacy, msg);
}

static inline int msgio_forward(msgio_t *dst, msgio_t *src) {
    return msgp_send_raw(dst->sock, dst->privacy, src->msg.hdr);
}

extern int msglog(const char *logfile, uint32_t type, time_t timestamp, const void *data, int len);
extern int msgprintf(const char *logfile, uint32_t type, time_t timestamp, const char *fmt, ...);
extern int vmsgprintf(const char *logfile, uint32_t type, time_t timestamp, const char *fmt, va_list ap);

static inline void set_int(char *ptr, int pos, uint32_t value) {
	*(uint32_t *)(ptr+pos*4) = value;
}
extern void set_str(char *ptr, int pos, const char *str, int *lenp);

#ifdef  __cplusplus
}
#endif
#endif
