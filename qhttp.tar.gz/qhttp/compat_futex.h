#ifndef __H_COMPAT_FUTEX_H_
#define __H_COMPAT_FUTEX_H_

#include <stdint.h>
#include "autoconfig.h"

#ifndef FUTEX_WAIT
#define FUTEX_WAIT (0)
#endif
#ifndef FUTEX_WAKE
#define FUTEX_WAKE (1)
#endif
#ifndef FUTEX_FD
#define FUTEX_FD (2)
#endif
#ifndef FUTEX_REQUEUE
#define FUTEX_REQUEUE (3)
#endif
#ifndef FUTEX_CMP_REQUEUE
#define FUTEX_CMP_REQUEUE (4)
#endif

static inline int fast_futex_fd(uint32_t *tidptr, int signo) {
	return fast_futex(tidptr, FUTEX_FD, signo);
}
static inline int fast_futex_wake(uint32_t *tidptr, int num) {
	return fast_futex(tidptr, FUTEX_WAKE, num);
}
static inline int fast_futex_wait(uint32_t *tidptr, uint32_t val) {
	return fast_futex4(tidptr, FUTEX_WAIT, val, NULL);
}

#endif
