
struct worker;
extern int register_sigio_callback(int, void(*)(void*, int), void *);
extern int remove_sigio_callback(int);
extern int register_shutdown_callback(void(*)(void*), void *);
extern int remove_shutdown_callback(void(*)(void*), void *);
extern int register_privilege_task(void(*)(void*), void *);
extern int register_worker_task(void(*)(struct worker*));
extern int remove_privilege_task(void(*)(void*), void *);
extern int delay_execute(void(*)(void *), void *, int);
extern int delay_close(int, int);
extern int delay_free(void *, int);
extern void run_sigio_callback(int, int);
extern void run_shutdown_callback(void);
extern void run_privilege_task(void);
extern void run_worker_task(struct worker *);
extern void cleanup_privilege_task(void);
