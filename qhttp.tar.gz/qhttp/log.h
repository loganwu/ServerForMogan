#ifndef __TWS_LOG_H
#define __TWS_LOG_H
#include "atomic.h"

struct conn;
extern int init_logging(void);
extern void free_logging(void);
extern void disable_console(void);
extern void log_request(struct conn *, uint32_t);
extern void scan_logfiles(void);

extern void cprintf(const char *fmt,...) __attr_printf__(1,2);
extern void lprintf(const char *fmt,...) __attr_printf__(1,2);
extern void loprintf(const char *fmt,...) __attr_printf__(1,2);
extern void cputs(const char *string);
extern void lputs(const char *string);
extern void lflush(void);
#if IPINFO_SUPPORT
extern void log_tcpinfo(int fd);
#else
#define log_tcpinfo(fd) /* */
#endif

#endif // __TWS_LOG_H
