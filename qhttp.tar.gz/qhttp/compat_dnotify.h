#include <fcntl.h>

#ifndef F_NOTIFY
#define F_NOTIFY        (1024+2)
#endif

/*
 * Types of directory notifications that may be requested.
 */
#ifndef DN_ACCESS
#define DN_ACCESS       0x00000001      /* File accessed */
#endif
#ifndef DN_MODIFY
#define DN_MODIFY       0x00000002      /* File modified */
#endif
#ifndef DN_CREATE
#define DN_CREATE       0x00000004      /* File created */
#endif
#ifndef DN_DELETE
#define DN_DELETE       0x00000008      /* File removed */
#endif
#ifndef DN_RENAME
#define DN_RENAME       0x00000010      /* File renamed */
#endif
#ifndef DN_ATTRIB
#define DN_ATTRIB       0x00000020      /* File changed attibutes */
#endif
#ifndef DN_MULTISHOT
#define DN_MULTISHOT    0x80000000      /* Don't remove notifier */
#endif

