#include "realconfig.h"

#define POLL_TIMEOUT	2000
#include "compiler.h"
#if INLINE_SYSCALL
#include "fastcall.h"
#else
#include "libccall.h"
#endif

#if USE_TLS
#if LINK_AS_SHARED
#define TLS_MODEL	tls_model("initial-exec")
#else
#define TLS_MODEL	tls_model("local-exec")
#endif
#endif

#define bugcheck(x)	(x)
#if TRACE_FD
#undef fast_close
extern int close_debug(int, const char *, int);
#define fast_close(x)	close_debug(x,__FILE__,__LINE__)
#endif
