#include "conn.h"

int relay_cgi(struct conn *c,struct forward_target *t);
void init_cgi_vhost();
int relay_check(struct conn *c);
