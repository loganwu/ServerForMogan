/* This file auto-generated from config.mk */
#define CC "gcc"
#define ARCH "i386"
#define GCCVER "4.1.2"
#define CFLAGS "-g -Wall -Werror -pthread -D_REENTRANT -D_GNU_SOURCE -march=pentium3 -mfpmath=387 -fomit-frame-pointer -O3 -minline-all-stringops -funroll-loops -D__USE_STRING_INLINES -fhosted -fno-strict-aliasing -pipe -fno-ident -ftracer -ftree-vectorize"
#define LDFLAGS "-g -Wall -Werror -z origin -Wl,--export-dynamic,--version-script,exports.lds,-soname=libqhttpd.so,-rpath,$ORIGIN -shared -z defs -z nodlopen -z nodelete -Wl,-dynamic-linker=/lib/ld-linux.so.2 -e _so_start -z now"
