#include <stddef.h>
#include <errno.h>
#include <stdint.h>
#include <fcntl.h>

#include "list.h"
#include "filecache.h"
#include "shmem.h"

struct fch {
	struct list_head olist;
	uint32_t spage;
	uint32_t npage:31;
	uint8_t inuse:1;
	struct list_head flist;
};

#define FCLSTSZ	1024
#define FCBLKSZ	4096

const unsigned int filecache_blocksize = FCBLKSZ;
const unsigned int filecache_maxsize = 1<<16;
unsigned int filecache_overhead = offsetof(struct fch, flist);
off64_t filecache_freesize;
static struct list_head *freelist;
static struct list_head freehead;
static struct fch offhead;
static struct fch offtail;
static int filecache_fd;

void filecache_set_overhead(int overhead) {
	filecache_overhead = offsetof(struct fch, flist) + overhead;
}

int filecache_create(const char *filename, int totalsize) {
	freelist = shalloc(FCLSTSZ*sizeof(struct list_head));
	if(freelist==NULL) return -ENOMEM;
	int i;
	for(i=0; i<FCLSTSZ; i++)
		INIT_LIST_HEAD(freelist+i);
	off64_t size64 = totalsize;
	totalsize *= (1<<20)/FCBLKSZ;
	filecache_fd = fast_open(filename, O_CREAT|O_RDWR, 0);
	ftruncate64(filecache_fd, size64 << 20);

	INIT_LIST_HEAD(&freehead);
	char *p = shalloc(1024 * filecache_overhead);
	if(p==NULL) return -ENOMEM;
	struct fch *f;
	for(i=0; i<1024-1; i++) {
	    f = (struct fch *)p;
	    p += filecache_overhead;
	    list_add(&f->flist, &freehead);
	}

	struct fch *h = &offhead;
	struct fch *t = &offtail;
	h->spage = 0;
	f->spage = 0;
	t->spage = totalsize;
	h->npage = 0;
	f->npage = totalsize;
	t->npage = 0;
	h->inuse = 1;
	f->inuse = 0;
	h->inuse = 1;
	INIT_LIST_HEAD(&h->olist);
	list_add(&f->olist, &h->olist);
	list_add(&t->olist, &f->olist);

	list_add(&f->flist, &freelist[0]);
	return 0;
}

void filecache_destroy(void) {
	if(filecache_fd>0) fast_close(filecache_fd);
}

void *filecache_alloc(int size) {
	size = (size+FCBLKSZ-1) / FCBLKSZ;

	int n;
	for(n=size/FCBLKSZ; n<FCLSTSZ; n++)
		if(!list_empty(freelist+n)) break;
	if(n==FCLSTSZ) {
		if(list_empty(freelist))
			return NULL;
		n = 0;
	}

	struct fch *ent;
	ent = list_entry(freelist[n].next, struct fch, flist);
	if(ent->npage!=size && list_empty(&freehead)) {
	    char *p = shalloc(1024 * filecache_overhead);
	    if(p==NULL) return NULL;
	    for(n=0; n<1024; n++) {
		struct fch *f = (struct fch *)p;
		p += filecache_overhead;
		list_add(&f->flist, &freehead);
	    }
	}

	list_del_init(&ent->flist);
	filecache_freesize -= (off64_t)size * FCLSTSZ;
	ent->inuse = 1;

	if(ent->npage==size) return &ent->flist;

	struct fch *ent1 = list_entry(freehead.next, struct fch, flist);
	ent1->spage = ent->spage + size;
	ent1->npage = ent->npage - size;
	ent1->inuse = 0;
	list_add(&ent1->olist, &ent->olist);

	ent->npage = size;
	ent->inuse = 0;

	n = ent1->npage;
	if(n >= FCLSTSZ) n = 0;
	list_add(&ent1->flist, freelist+n);
	return &ent->flist;
}

off64_t filecache_offset(void *ent0) {
	struct fch *ent = list_entry(ent0, struct fch, flist);
	return (off64_t)ent->spage *FCBLKSZ;
}

void filecache_free(void *ent0) {
	struct fch *ent = list_entry(ent0, struct fch, flist);
	struct fch *ent1 = list_entry(ent->olist.prev, struct fch, olist);
	if(ent1->inuse==0) {
		ent->spage -= ent1->npage;
		ent->npage += ent1->npage;
		list_del(&ent1->olist);
		list_del(&ent1->flist);
		list_add(&ent1->flist, &freehead);
	}
	ent1 = list_entry(ent->olist.next, struct fch, olist);
	if(ent1->inuse==0) {
		ent->npage += ent1->npage;
		list_del(&ent1->olist);
		list_del(&ent1->flist);
		list_add(&ent1->flist, &freehead);
	}
	ent->inuse = 0;
	list_add(&ent->flist, freelist+(ent->npage>=FCLSTSZ?0:ent->npage));
}
