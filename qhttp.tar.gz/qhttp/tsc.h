#include <stdint.h>

#define TSCMAX 0x7fffffff7fffffffLL
#define tsc_t uint64_t
extern int ncpus;
extern int ht;
extern int tscmsec;
extern double tscusecf;
extern int tsc4shift;
extern uint64_t tscsec;
extern uint64_t tscmin;
extern uint64_t tschour;
#define TSCRND(x)	((int)((x)>>tsc4shift))
#define SECRND(x)	((int)(((x)*tscsec)>>tsc4shift))

extern int init_tsc(void);
extern uint64_t (*readtsc)(void);
