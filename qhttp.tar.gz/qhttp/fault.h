extern int init_fault_handler(void);
extern void check_reentrant(void);
extern int check_symbol(void *, const char *, const char *const [], int);
extern void sigsys_callback(void *, int);
