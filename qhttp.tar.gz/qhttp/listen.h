#ifndef __H_LISTEN_H
#define __H_LISTEN_H 1

extern int init_fdlimit(void);
extern int init_worker_mode(void);
extern int init_fdinfo_array(void);
extern int init_timestamp(void);
extern int init_listen_socket(void);
extern void cleanup_sockets(void);
extern void close_idle_connections(struct list_head *head);
extern int init_worker_data(void);
extern int start_worker_threads(void);
extern void stop_worker_threads(void);
extern int poll_add_listening(struct pollfd *);
extern int rtsig_add_fdset(fd_set *);
extern int rtsig_add_pollfd(struct pollfd *);
extern int rtsig_add_listening(int);
extern int rtsig_set_listening(int);
extern int epoll_add_listening(int);
extern int epoll_stop_listening(int);
extern struct blacklist *incblist;
extern int match_blacklist(struct blacklist *, uint32_t);
extern struct blacklist *new_blacklist(const char *);

#endif
