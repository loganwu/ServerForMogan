#ifndef __H_FILECOUNT_H__
#define __H_FILECOUNT_H__
struct filecount;
extern struct filecount *get_fcid(const char *);
extern struct filecount *new_fcid(const char *);
#if NEED_FCINUSED
extern void dup_fcid(struct filecount *);
extern void put_fcid(struct filecount *);
#else
#define dup_fcid(x) /* x */
#define put_fcid(x) /* x */
#endif
// ***BEGIN*** Modified by yorkwang for file count on 2008-02-18
extern void log_fcid(void *, off64_t,const char *, const char *);
// ***END*** Modified by yorkwang for file count on 2008-02-18
extern int init_filecounting(void);
#endif
