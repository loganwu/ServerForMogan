#ifndef __COMPAT_SPLICE_H_
#define __COMPAT_SPLICE_H_

#include <fcntl.h>
#include <sys/uio.h>

#if !COMPAT_GLIBC && defined(SPLICE_F_MOVE)
#define sys_splice splice
#define sys_vmsplice vmsplice
#else
#include <unistd.h>
#include "syscall.h"
#include "realconfig.h"
static inline int sys_splice(int fd, off64_t *off, int out, off64_t *o, size_t count, int flags) {
	return syscall(__NR_splice, fd, off, out, o, count, flags);
}
static inline int sys_vmsplice(int fd, const struct iovec *v, int n, int flags) {
	return syscall(__NR_vmsplice, fd, v, n, flags);
}
#endif

#ifndef SPLICE_F_MOVE
#define SPLICE_F_MOVE   (0x01)   /* move pages instead of copying */
#define SPLICE_F_NONBLOCK (0x02) /* don't block on the pipe splicing (but */
                                 /* we may still block on the fd we splice */
				 /* from/to, of course */
#define SPLICE_F_MORE   (0x04)   /* expect more data */
#define SPLICE_F_GIFT   (0x08)   /* pages passed in are a gift */
#endif

#endif
