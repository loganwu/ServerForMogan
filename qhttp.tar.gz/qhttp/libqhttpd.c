#include <stdint.h>
#include "autoconfig.h"

uint64_t zero_int = 0;
const char empty_string[1] = "\0";
const char *empty_string_ptr = empty_string;
uint64_t zero_function(void) {return 0;}

extern const char config_syscall_method[1] __attribute__((alias("empty_string")));
extern const char config_thread_mode[1] __attribute__((alias("empty_string")));
extern const char config_poll_mode __attribute__((alias("empty_string_ptr")));
extern int config_pagesize __attribute__((alias("zero_int")));
extern int config_largefile_support __attribute__((alias("zero_int")));
extern int config_rcvbufsz __attribute__((alias("zero_int")));
extern int config_sndbufsz __attribute__((alias("zero_int")));
extern int config_maxurllen __attribute__((alias("zero_int")));
extern int config_maxhostlen __attribute__((alias("zero_int")));
extern int config_maxfds __attribute__((alias("zero_int")));
extern int config_ncpus __attribute__((alias("zero_int")));
extern int config_maximum_connections __attribute__((alias("zero_int")));
extern int config_use_vhost __attribute__((alias("zero_int")));
extern int config_working_threads __attribute__((alias("zero_int")));
extern int config_strip_query_string __attribute__((alias("zero_int")));
extern uint64_t tsc_per_msec __attribute__((alias("zero_int")));
extern uint64_t tsc_per_sec __attribute__((alias("zero_int")));
extern uint64_t tsc_per_min __attribute__((alias("zero_int")));
extern uint64_t tsc_per_hour __attribute__((alias("zero_int")));

int getparam(void) __attribute__((alias("zero_function")));
int getintparam(void) __attribute__((alias("zero_function")));
int myconfig_get_value(void) __attribute__((alias("zero_function")));
int myconfig_get_intval(void) __attribute__((alias("zero_function")));
int myconfig_get_multivalue(void) __attribute__((alias("zero_function")));
int decode_url(void) __attribute__((alias("zero_function")));
int str_explode(void) __attribute__((alias("zero_function")));
int entity_expired(void) __attribute__((alias("zero_function")));
int entity_size32(void) __attribute__((alias("zero_function")));
int entity_size64(void) __attribute__((alias("zero_function")));
int entity_fileno(void) __attribute__((alias("zero_function")));
int entity_timestamp(void) __attribute__((alias("zero_function")));
int entity_timestr(void) __attribute__((alias("zero_function")));
int entity_mime_thpe(void) __attribute__((alias("zero_function")));
int entity_read(void) __attribute__((alias("zero_function")));
int entity_updateinfo(void) __attribute__((alias("zero_function")));
int get_thread_id(void) __attribute__((alias("zero_function")));
int get_entity(const char *name, void **entp) { *entp = NULL; return -1; }
void put_entity() __attribute__((alias("zero_function")));
void lputs() __attribute__((alias("zero_function")));
void cputs() __attribute__((alias("zero_function")));
void lprintf() __attribute__((alias("zero_function")));
void cprintf() __attribute__((alias("zero_function")));
void vlprintf() __attribute__((alias("zero_function")));
void vcprintf() __attribute__((alias("zero_function")));
void register_shutdown_callback() __attribute__((alias("zero_function")));
void register_privilege_task() __attribute__((alias("zero_function")));
void register_url_filter() __attribute__((alias("zero_function")));
int cookie_offset() __attribute__((alias("zero_function")));
int cookie_maxlength() __attribute__((alias("zero_function")));
int cookie_auth_uin() __attribute__((alias("zero_function")));
int panel_auth() __attribute__((alias("zero_function")));
int shalloc() __attribute__((alias("zero_function")));
int shdup() __attribute__((alias("zero_function")));

int msglog() __attribute__((alias("zero_function")));
int msgprintf() __attribute__((alias("zero_function")));
int vmsgprintf() __attribute__((alias("zero_function")));

int open_global_file() __attribute__((alias("zero_function")));
int rotate_global_file() __attribute__((alias("zero_function")));
int delay_close() __attribute__((alias("zero_function")));
int delay_execute() __attribute__((alias("zero_function")));
int register_sigio_callback() __attribute__((alias("zero_function")));
int register_file_monitor() __attribute__((alias("zero_function")));

void *_create_pattern() __attribute__((alias("zero_function")));
void _add_prefix_pattern() __attribute__((alias("zero_function")));
void _add_suffix_pattern() __attribute__((alias("zero_function")));
void _add_pattern() __attribute__((alias("zero_function")));
void *_match_pattern() __attribute__((alias("zero_function")));
void *_match_url_pattern() __attribute__((alias("zero_function")));

void *find_forward_group() __attribute__((alias("zero_function")));

int ProcNetDev_activate() __attribute__((alias("zero_function")));
void ProcNetDev_deactivate() __attribute__((alias("zero_function")));
int ProcNetDev_getDevCount() __attribute__((alias("zero_function")));
int ProcNetDev_parse() __attribute__((alias("zero_function")));
void ProcNetDev_dump() __attribute__((alias("zero_function")));
void milli_sleep() __attribute__((alias("zero_function")));

#if DEBUG_MALLOC
#else
void *shalloc1() __attribute__((alias("zero_function")));
#endif
