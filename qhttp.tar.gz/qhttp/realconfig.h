/* This file auto-generated from config.mk */
#ifndef _H_CONFIG_H_
#define _H_CONFIG_H_
#define INLINE_SYSCALL 1
#define COMPAT_GLIBC 1
#define PLUGIN_SUPPORT 1
#define COOKIE_SUPPORT 1
#define RELAY_SUPPORT 1
#define IPINFO_SUPPORT 1
#define FILECOUNT_SUPPORT 1
#define ISDSTAT_SUPPORT 1
#define LINK_AS_SHARED 1
#endif /* _H_CONFIG_H_ */
