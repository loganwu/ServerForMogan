#if PLUGIN_SUPPORT
	extern void set_worker_key(struct worker *);
	set_worker_key(wt);
#endif

	int i, n;
	struct epoll_event *pev = wt->pev;

	if(pev==NULL) pev = alloca(sizeof(struct epoll_event)*nepoll_events);

#if WORKER_METHOD==2
	int accepting = 1;
	if(direct_accept)
#else
	if(direct_accept && wt->id==0)
#endif
	    epoll_add_listening(wt->epfd);
#if WORKER_METHOD==3
	i = (wt->id+1)%nworks;
	wt->epwake = worker[i].epfd;
#endif
#if PROFILE_SUPPORT
	init_poll(wt);
#endif
	wt->thst = get_threadstat();

	while(!stop) {
#if WORKER_METHOD==2
	    if(accepting && !wt->freeconn) {
		epoll_stop_listening(wt->epfd);
		accepting = 0;
	    } else if(!accepting && wt->freeconn) {
		epoll_add_listening(wt->epfd);
		accepting = 1;
	    }
#endif

#if PROFILE_SUPPORT
	    before_poll(wt);
#endif
	    if(loopdelay) {
		struct timespec tv;
		tv.tv_sec = 0;
		tv.tv_nsec = loopdelay;
		fast_nanosleep(&tv, &tv);
	    }
	    n = fast_epoll_wait(wt->epfd, pev, nepoll_events, calc_poll_timeout(wt));
	    thread_reached(wt->thst);
#if PROFILE_SUPPORT
	    after_poll(wt);
#endif
	    check_timestamp(wt);
	    for(i=0; i<n; i++) {
		thread_reached(wt->thst);
		if (is_stub(pev[i].data.fd, listenstub)) {
#if WORKER_METHOD==2
		    accept_connections_epoll_direct(wt, pev[i].data.fd);
#else
		    accept_connections_epoll_direct_rr(wt, pev[i].data.fd);
#endif
		} else
		    resume_connection(wt, pev[i].data.fd, pev[i].events);
	    }
	    check_pending(wt);
	    check_direct_idle_switch(wt);
	    check_timeout(wt);
	    check_idle_timeout(wt);
	}
	return 0;
