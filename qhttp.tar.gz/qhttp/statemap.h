struct statemap {
};

