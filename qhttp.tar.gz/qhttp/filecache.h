
#include <unistd.h>

extern const unsigned int filecache_blocksize;
extern const unsigned int filecache_maxsize;
extern unsigned int filecache_overhead;
extern off64_t filecache_freesize;
extern void filecache_set_overhead(int overhead);
extern int filecache_create(const char *filename, int totalsize);
extern void filecache_destroy(void);
extern void *filecache_alloc(int size);
extern void filecache_free(void *);
