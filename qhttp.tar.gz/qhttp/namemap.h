
struct namemap;
extern struct namemap *CreateNameMap(unsigned int hashbase, unsigned int valsz);
extern void *AddNameToMap(struct namemap *, const char *);
extern void *GetNameFromMap(struct namemap *, const char *);
extern int BuildFastNameMap(struct namemap *);
extern void FreeNameMap(struct namemap *, void(*)(void *));
extern void *IterateNameMap(struct namemap *, void *, int *);
extern const char *MapDataToName(struct namemap *, void *);
