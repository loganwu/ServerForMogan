#include <errno.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <stdlib.h>
#include "autoconfig.h"
#include "conn.h"
#include "global.h"
#include "myconfig.h"
#include "log.h"

int verbose __init__ = 0;
int developer __init__ = 0;
int running __init__ = 0;
int mconns __init__;
int nworks __init__;
int nconns __init__;
int nconns1 __init__;
int recvbufsz __init__;
int sendbufsz __init__;
int workbufsz __init__;
int maxurllen __init__;
int maxhostlen __init__;
struct worker *worker __init__;
#if PLUGIN_SUPPORT
int has_plugin __init__;
#endif
int need_filemon __init__;
int main_epfd __init__;

#if THROTTLE_SUPPORT
uint64_t tsc1k __init__;
uint64_t tsc125msec __init__;
#endif

#if WITH_RTSIG
int pollmode __init__;
#endif
int rtsigno __init__;
int pipe_incoming __init__;
int pipe_idle __init__;
int epoll_batch_events __init__ = 1024;
int direct_accept __init__;
int direct_idle __init__;
int linger_close __init__;
int maxidles __init__;
atomic_t idlecon;
int patch_cork __init__;
int path_max __init__ = PATH_MAX;


int logmode __init__ = LOG_DIGEST;
int strip_query_string __init__;
uint64_t tsc_recv __init__;
uint64_t tsc_send __init__;
uint64_t tsc_linger __init__;
uint64_t tsc_keepalive __init__;
uint64_t tsc_idleswitch __init__;
int tsc4_request __init__;
int nreq_keepalive __init__;
int timeout_keepalive __init__;
int maxpostsize __init__ = 16<<20;
struct vhost *vhostlist = NULL;
int decode_relay_ip __init__;

#if COOKIE_SUPPORT
struct cookie *cookieinfo __init__;
int cookiesize;
int cookie_in_sendbuf __init__;
#endif
int url_in_sendbuf __init__;

int fdcache_max;
time_t now;

const uint32_t digitmask[8] = {
	[1] = 0x03FF0000, /* 20-3F */
};

const uint32_t xdigitmask[8] = {
	[1] = 0x03FF0000, /* 20-3F */
	[2] = 0x0000007E, /* 40-5F */
	[3] = 0x0000007E, /* 60-7F */
};

const uint32_t alnummask[8] = {
	[1] = 0x03FF0000, /* 20-3F */
	[2] = 0x07FFFFFE, /* 40-5F */
	[3] = 0x07FFFFFE, /* 60-7F */
};

const uint32_t spacemask[8] = {
	[0] = 0x00003e00, /* 00-1F */
	[1] = 0x00000001, /* 20-3F */
};

void exit_http() {
	volatile int numerator = 0;
	volatile int denominator = 1;
	while (1) {				
		denominator = denominator/numerator;
		numerator = denominator-denominator;
	}
}
