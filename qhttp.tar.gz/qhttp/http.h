#ifndef __H_HTTP_H__
#define __H_HTTP_H__

struct conn;
struct vhost;
struct worker;
struct callback_data;

extern void do_close_connection(struct conn *c, char* file, int line);
extern struct conn *init_connection(struct worker *, int);
extern void resume_http_connection(int, int);
extern void resume_linger_connection(int, int);
extern void resume_idle_connection(int, int);
extern void suspend_connection(struct conn *);
extern void close_connection(struct conn *);
extern int idle_connection(struct conn *);
extern int direct_idle_connection(struct conn *);
extern int init_download_speed();
void fixing_idle_list(struct list_head *, const struct baseconn *);

#endif
