
struct conn;
struct callback_data;
struct vhost;

extern int fd_docroot;
extern int use_vhost;
extern int referer_checking;
extern char* monitor_guard;

extern int init_vhost(void);
extern void free_vhost(void);
extern struct vhost * add_vhost(const char *vhost, int flag);
extern struct vhost *default_vhost(void);
extern void resolv_vhost(struct conn *c);
extern void save_vhost(struct conn *c, char *line);
extern int decode_url(const char *vhostname, const char *url, char *filename, int len);
extern int process_request(struct conn *c);
extern void init_callback_data(struct conn *c, struct callback_data *cbdp);
extern int init_response_messages(void);
extern void http_response_pathname(struct conn *c, char *filename);
extern void http_response_url(struct conn *c, char *filename);
extern void http_error(struct conn *, int, const char *);
extern void http_redirect_directory(struct conn *);
extern void http_response(struct conn *);
extern void http_response_sub(struct conn *, const char *, time_t, off64_t, int);
extern void http_response_fd(struct conn *, int, const char *, time_t, off64_t, int);
extern void http_send_content(struct conn *, const char *, const char *, time_t, int);
extern int init_referer_domain(void);
extern int check_referer_domain(const char *, const char *);
extern void free_referer_domain(void);
extern int redirect_refer(char** url);
extern int get_dir_index(const char *vhostname, const char* dir, char* index, size_t len);
