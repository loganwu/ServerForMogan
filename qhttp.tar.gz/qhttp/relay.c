#include "realconfig.h"
#if RELAY_SUPPORT
/* headers {{{1 */
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/signal.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <sys/sendfile.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <regex.h>   //Added by yorkwang for file cache on 2008-01-25

#include "compat_ctype.h"
#include "compat_errno.h"

#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "conn.h"
#include "http.h"
#include "vhost.h"
#include "util.h"
#include "log.h"
#include "shmem.h"
#include "timestamp.h"
#include "relay.h"
#include "pattern.h"
#include "md5.h"
#include "cookie.h"
#include "plugin.h"
#include "entity.h"
#include "stat.h"
#include "watchdog.h"
#include "group.h"
#include "namemap.h"
#include "malloc.h"
#include "futex.h"
/* }}}1 */

#if 0
#define print_status() do { lprintf("%s:%d", __FILE__, __LINE__); } while(0)
#else
#define print_status()
#endif

int need_relay(char* url)
{
    return relay_mode;
}

//#define RESPONSE_CALLBACK	1
//#define RESP_DEBUG	1
//#define RECVBUF_DEBUG	1

/* enable connect queue */
#define UINX_RECONN

#ifndef UINX_RECONN
#define UNIX_LOCK_INIT()
#define UNIX_LOCK_DESTROY()
#define UNIX_LOCK()
#define UNIX_UNLOCK()
#define UNIX_INIT(size)   
#define UNIX_FINI()       
#define UNIX_FULL()       
#define UNIX_EMPTY()      
#define UNIX_FRONT()      
#define UNIX_POP()        
#define UNIX_PUSH(c,g,h)  
#define UNIX_RECONNECT(c)
#else
#define UNIX_LOCK_INIT() \
    do { \
        pthread_mutexattr_init(&__unix_mutex_attr__); \
        pthread_mutexattr_settype(&__unix_mutex_attr__, PTHREAD_MUTEX_RECURSIVE); \
        pthread_mutex_init(&__unix_mutex__, &__unix_mutex_attr__); \
    } while(0)
#define UNIX_LOCK_DESTROY() \
    do { \
        pthread_mutexattr_destroy(&__unix_mutex_attr__); \
        pthread_mutex_destroy(&__unix_mutex__); \
    } while(0)
//#define UNIX_LOCK()   futex_lock(&__unix_mutex__)
//#define UNIX_UNLOCK() futex_unlock(&__unix_mutex__)
#define UNIX_LOCK()       pthread_mutex_lock(&__unix_mutex__)
#define UNIX_UNLOCK()     pthread_mutex_unlock(&__unix_mutex__)
#define UNIX_INIT(size)   unix_init(&__unix_queue__, size)
#define UNIX_FINI()       unix_fini(&__unix_queue__)
#define UNIX_SIZE()       unix_size(&__unix_queue__)
#define UNIX_FULL()       unix_full(&__unix_queue__)
#define UNIX_EMPTY()      unix_empty(&__unix_queue__)
#define UNIX_FRONT()      unix_front(&__unix_queue__)
#define UNIX_POP()        unix_pop(&__unix_queue__)
#define UNIX_PUSH(c,g,h)  unix_push(&__unix_queue__, c, g, h)    
#define UNIX_RECONNECT(c) \
    do { \
        if (!UNIX_EMPTY()) { \
            UNIX_LOCK(); \
            unix_reconnect(&__unix_queue__, c); \
            UNIX_UNLOCK(); \
        } \
    }while (0)
#endif // UINX_RECONN

static void relay_error(struct conn *c);
static int relay_connection_aux(struct conn *c, group_t *g, ftarget_t *h);

#ifdef UINX_RECONN

#define UNIX_DEEP
#define UNIX_DEEP_MAX   8
#define UNIX_QUEUE_SIZE 20000

typedef struct {
    volatile int rear;
    volatile int front;
    volatile int state;
    volatile size_t size;  
    volatile size_t count;
    struct conn** array;    
}unix_queue;
static int __unix_deep__;
//static futex_t __unix_mutex__;
static pthread_mutex_t __unix_mutex__;
static pthread_mutexattr_t __unix_mutex_attr__;
static unix_queue __unix_queue__;

void unix_init(unix_queue* uq, size_t size)
{
    UNIX_LOCK_INIT();
    size_t qsz = sizeof(struct conn*) * size;
    uq->array = (struct conn **)malloc(qsz);    
    memset(uq->array, 0, qsz);
    uq->rear  = 0;
    uq->front = 0;    
    uq->size  = size;
    uq->count = 0;

    __unix_deep__ = myconfig_get_intval("unix_cache_deep", UNIX_DEEP_MAX);
}

void unix_fini(unix_queue* uq)
{
    free(uq->array);
    UNIX_LOCK_DESTROY();
}

int unix_full(unix_queue* uq)
{
    return (((uq->rear+1)%uq->size) == uq->front) ? 1 : 0;    
}

int unix_empty(unix_queue* uq)
{    
    return (uq->rear == uq->front) ? 1 : 0;    
}

struct conn* unix_front(unix_queue* uq)
{
    return uq->array[uq->front];
}

void unix_pop(unix_queue* uq)
{
    //struct conn* c         = uq->array[uq->front];
    //fdinfo[c->netfd].conn  = c;
    uq->array[uq->front]   = NULL;
    uq->front              = (uq->front+1) % uq->size; 
    --uq->count;
    //lprintf("[-]unix queue size is %d", uq->count);
}

void unix_push(unix_queue* uq, struct conn* c, group_t *g, ftarget_t* h)
{
    //fdinfo[c->netfd].conn = NULL;
    c->group              = (void *)g;
    c->target             = (void *)h;
    uq->array[uq->rear]   = c;
    uq->rear              = (uq->rear+1) % uq->size; 
    ++uq->count;    
}

size_t unix_size(unix_queue* uq)
{
    return uq->count;
}

void unix_reconnect(unix_queue* uq, struct conn* oldc)
{
    int relay = 0;
    int netfd = 0;
    int relayfd = 0;
    int netfd_old = 0;    
    struct conn* c = NULL;
        
    if (1 == uq->state) return;
    while (!UNIX_EMPTY()) 
    {        
        c = UNIX_FRONT();  
        UNIX_POP();
        
        if ((NULL == c) || (c == oldc)) continue;

        netfd = c->netfd;
        relayfd = c->relayfd;
        netfd_old = c->netfd_old;       
        if ((netfd < 0) || (netfd_old != netfd) || (relayfd > 0)) continue;
        
        uq->state = 1;
        //thread_reached(c->thread->thst);
        relay = relay_connection_aux(c, c->group, c->target);
#ifdef UNIX_DEEP
        if ((110 == relay) && (c->deep < __unix_deep__)) {
            ++c->deep;
            unix_push(uq, c, c->group, c->target);            
        }
        else if (relay != 1) {
            relay_error(c);
            http_error(c, 500, c->url);
        }
#else
        if (relay != 1) {
            relay_error(c);
            http_error(c, 500, c->url);
        }
#endif
        uq->state = 0;        
        break;
    }        
}
#endif // UINX_RECONN

// ***BEGIN*** Added by yijian for cache on 2008-01-23
//#ifdef CACHE_PROXY
static char* get_filename(struct conn* c, char* filename, size_t namelen) {
    extern int need_chroot;
    //lprintf("%s:%d, %s", __FILE__, __LINE__, filename);

    int len;
    char* host = c->host;
    char* url = c->url;
    if (1 == need_chroot) {
        len = snprintf(filename, namelen, "/%s", host);
    }
    else {
        len = snprintf(filename, namelen, "%s/%s", docroot, host);
    }
    
    const char* urlp = url;
    while (*urlp != 0) {
        if ('?' == *urlp) break;
        
        filename[len] = *urlp;
        ++urlp;
        ++len;
    }
    if ((0 == *urlp) && ('/' == *(urlp-1))) {
        strcpy(&filename[len], "index.cache");
        len += 11;
    }
    if (1 == c->relay_zipped) { // gzip
        strcpy(&filename[len], ".gzip");
        len += 4;
    }
    else if (2 == c->relay_zipped) { // deflate
        strcpy(&filename[len], ".deflate");
        len += 8;
    }

    filename[len] = 0;
    return filename;
}

static int need_cache(struct conn *c) {
	// ***BEGIN*** Modified by yorkwang for file cache on 2008-01-25
    //int ncmp = strncmp(c->url, "/cgi-bin/", sizeof("/cgi-bin/")-1);
    //return (0 == ncmp) ? 0 : 1; // don't cache CGIs application.
	
	if (relay_mode == 0)
		return 0;

	//���صĴ�����Ϣ���ܻ���
	if (c->sendcode != 200)
		return 0;

	if (fcache_url_pattern && !regexec(fcache_url_pattern, c->url, 0, NULL, 0))
		return 1; //cache
	else
		return 0; //not cache
	// ***END*** Modified by yorkwang for file cache on 2008-01-25
}

static void close_proxyfd(struct conn *c) {
    if (c->proxyfd > 0) {   
        //ISDSTAT(atomic_dec(&countermap->fcachefds));
	    close(c->proxyfd);    
        c->proxyfd = 0;
        if (c->cachedoffset == c->cachedsize) {
            //lprintf("close proxy file %s from %s ok", c->url, c->host);
        }
        else {
            ISDSTAT(atomic_inc(&countermap->fcachematch));
#if TRACE_FD
            lprintf("remove proxy file %s from %s for size %lld not match %lld", c->url, c->host, c->cachedoffset, c->cachedsize);
#endif
            char filename[512] = {0};
            get_filename(c, filename, sizeof(filename)-1);
            fast_unlink(filename);
        }
    }    
}

static int build_path(char* filename, int* build_count) {    
    char dir[256] = {0};
    char* dirp = dir;
    char* filenamep = filename;
    ++(*build_count);
    if (*build_count > 1) {
        lprintf("can't build %s", filename);
        return 0;
    }
    
    for (;;) {
        if (('/' == *filenamep) || (0 == *filenamep)) {
            if (0 == *filenamep) 
                return 1;

            *dirp = 0;
            if (dirp != dir) {
                if (-1 == mkdir(dir, S_IRWXU|S_IRWXG|S_IRWXO)) {
                    if ((errno != EEXIST) && (errno != EACCES)) {
                        lprintf("mkdir %s[%s] error: %s", filename, dir, strerror(errno));
                        return 0;
                    }
                }
            }            
        } 
        
        *dirp = *filenamep;
        ++dirp;
        ++filenamep;                
    }
    
    return 1;
}

static void cache_reply(struct conn *c, char* sendbuf, int sendlen)
{   
    if (c->proxyfd < 0) return;		
    if (NULL == sendbuf) return;
    if (sendlen < 1) return;
    
    if (0 == c->proxyfd) {
        if (!need_cache(c)) return;

        int build_count = 0;
        char filename[512] = {0};        
        get_filename(c, filename, sizeof(filename)-1);        
        for (;;) {            
            c->proxyfd = open(filename, O_CREAT | O_EXCL | O_WRONLY);
            if (-1 == c->proxyfd) {
                if (ENOENT == errno) {
                    if (build_path(filename, &build_count))
                        continue;
                }
                else if (EEXIST == errno) {
                    //lprintf("needn't cache for the destination file %s already exists", filename);
                }
                else {  
                    int errcode = errno;
                    lprintf("can't cache %s for %s", filename, strerror(errcode));
                    if ((EMFILE == errcode) || (ENFILE == errcode)) {
                        exit_http();
                    }                    
                }
                return;
            }
            else {            
                ISDSTAT(atomic_inc(&countermap->fcachefds));
                //lprintf("%s:%d, open %s ok", __FILE__, __LINE__, filename);
                fchmod(c->proxyfd, S_IWUSR | S_IRUSR | S_IRGRP | S_IROTH);                
            }
            
            break;
        }
    }

    // ????
    if (c->cachedoffset == c->cachedsize) return;
        	
    int nw = fast_write(c->proxyfd, sendbuf, sendlen);
    //if (EOF == nw) {
	if (nw == sendlen){
        c->cachedoffset += nw;
        if (c->cachedoffset == c->cachedsize) {
            close_proxyfd(c);
        }
    }
    else {        
        if (nw < 1)
            lprintf("write %s%s error: %s", c->host, c->url, strerror(errno));
        else
            lprintf("write %s from %s bytes %d not match %d", c->host, c->url, nw, sendlen);        
        close_proxyfd(c);
    }    	
}
//#endif // CACHE_PROXY

static void free_ftarget(struct conn *c)
{
    return;
    struct forward_target *ftarget = c->ftarget;
    c->ftarget = NULL;
    
    if (ftarget != NULL && ftarget->addr == UNIX_DOMAIN_IP) {
        free(ftarget);
    }        
}

/* http_error_debug() {{{1 */
#if RESP_DEBUG
static void http_error_debug(struct conn *c, int r, char *u, const char *f, int l) {
	lprintf("%s(%d): HTTP ERROR RESPONSE %d URL %s\n", f, l, r, u);
	http_error(c,r,u);
}
#define	http_error(x,y,z)	http_error_debug(x,y,z,__FILE__,__LINE__)
#endif
/* }}}1 */

/* recvbuf_debug() {{{1 */
#if RECVBUF_DEBUG
	static void recvbuf_debug(struct conn *c, const char *f, int l) {
		if(c->recvlen > recvbufsz || c->recvptr+c->recvcnt > c->recvlen)
			lprintf("%s(%d): BAD recvbuf: ptr=%d cnt=%d len=%d\n",
					f, l, c->recvptr, c->recvcnt, c->recvlen);
		else if(c->recvbuf[c->recvlen] != '\0') {
			lprintf("%s(%d): BAD recvbuf: not NULL terminate: %d\n",
					f, l, c->recvbuf[c->recvlen] & 0xFF);
		}
	}
#define CHECK_RECVBUF	recvbuf_debug(c, __FILE__, __LINE__)
#else
#define CHECK_RECVBUF	/* */
#endif
/* }}}1 */

/* static/globals {{{1 */
/*
 * async connect:
 *     assume connect() never return non -EINPROGRESS error code
 */
static int hsendbufsz __init__;
static uint64_t tsc_transfer, tsc_connect;
int timeout_connect;

static void resume_nop(int fd, int events) {}
static void resume_keep_client(int, int);
static void resume_client_connection(int, int);
static void resume_server_connection(int, int);
static void resume_server_connected(int, int);
static void resume_server_connected_sf(int, int);
static int pass_server2client(struct conn *);
static int pass_client2server(struct conn *);
static int pass_client2cache(struct conn *);
static int pass_cache2server(struct conn *);
/* }}}1 */

/* init_relay_system() {{{1 */
int init_relay_system(void) {
//	if(has_plugin==0) return 0;

    UNIX_INIT(UNIX_QUEUE_SIZE);
	timeout_connect = myconfig_get_intval("forward_connect_timeout", 10);
	if(timeout_connect < 1) timeout_connect = 1;
	tsc_connect = timeout_connect * tscsec;

	tsc_transfer = myconfig_get_intval("forward_transfer_timeout", 300);
	if(tsc_transfer < 10) tsc_transfer = 10;
	tsc_transfer *= tscsec;

	hsendbufsz = sendbufsz - 24; /* Connection: keep-alive\r\n */
	return 0;
}
/* }}}1 */

/* init_relay_data() {{{1 */
static void init_relay_data(struct conn *c) {
	list_del_init(&c->timer_io);
	list_del(&c->timer_req);
	c->relayfd = -1;
	c->cachefd = -1;
    c->proxyfd = 0;
    c->relay_zipped = 0;
    c->cachedsize = 0;
    c->cachedoffset = 0;
	c->cachefd_start = 0;
	c->cachefd_end = 0;
	c->proc = resume_keep_client;
	c->thread1 = c->thread;
#if TRACE_FD
	snprintf(c->relayname, 16, "relay%d.%d", c->thread->id, c - c->thread->conn);
#endif
	c->relayproc = resume_nop;
	c->relayevents = POLL_DEFER_ACCEPT;
	c->state = CSR_FORWARD;
	c->relaymode = 1;
	c->relayflag_all = 0;
	c->replysize = 0;
	//c->ftarget = NULL;
	c->fgroup = NULL;

	c->sendcnt = c->recvcnt = 0;
	if(c->no_header) {
		c->sendcode = 200;
		c->reply_mode = REPLY_PASS;
		c->pass_mode = REQ_PASS;
	} else {
		c->sendcode = 0;
		c->reply_mode = REPLY_STATUS;
		c->pass_mode = c->header_parsed==0 ? REQ_HEADER :
			c->has_chunked ? REQ_CLEN1:
			c->postsize > 0 ? REQ_POST:
			REQ_PARSED;
	}
	CHECK_RECVBUF;
}
/* }}}1 */

/* open_server_socket() {{{1 */
/* return -errno */
static int open_server_socket(struct conn *c, ftarget_t *h) {
    int rv;
	struct sockaddr_in addr_in;	
	struct sockaddr_un addr_un;
	
	if(c->relayfd > 0) {
		fdinfo[c->relayfd].conn = NULL;
		fast_close(c->relayfd); /* CHECKED OK */
        //ISDSTAT(atomic_dec(&countermap->proxyfds));
	}

	c->relayevents = POLL_DEFER_ACCEPT;

	//if(h->addr == str2ip(UNIX_DOMAIN_IP,NULL)){
    if(h->addr == UNIX_DOMAIN_IP){
		//unix socket
		c->relayfd = fast_socket(AF_UNIX, SOCK_STREAM, 0);
	}else{
		c->relayfd = fast_socket(AF_INET, SOCK_STREAM, 0);
	}
	FAST_ERRNO(c->relayfd);
	if(c->relayfd > 0) {
        ISDSTAT(atomic_inc(&countermap->proxyfds));
		check_new_fd(c->relayfd);
		if(pollmode) {
			new_fdinfo_epoll(c->relayfd, 0xFFFFFFFF);
		}
#if WITH_RTSIG
		else {
			fast_fcntl(c->relayfd, F_SETOWN, c->thread->mypid);
			new_fdinfo_rtsig(c->relayfd, 0xFFFFFFFF);
		}
#endif
		fdinfo[c->relayfd].conn = &c->relayconn;

		socklen_t slen;
		//if(h->addr == str2ip(UNIX_DOMAIN_IP,NULL)){
        if(h->addr == UNIX_DOMAIN_IP){
			addr_un.sun_family = AF_UNIX;
			if(h->upath > 0){
				sprintf(addr_un.sun_path,"%s",h->upath);
			}else{
				if(h->port > 0)
					sprintf(addr_un.sun_path,"@group%d",h->port);
				else
					sprintf(addr_un.sun_path,"@group0");
			}
			slen=SUN_LEN(&addr_un);
			if(addr_un.sun_path[0] == '@')
				addr_un.sun_path[0]=0;
		}else{
			addr_in.sin_family = AF_INET;
			addr_in.sin_addr.s_addr = h->addr;
			addr_in.sin_port = h->port;
			slen = sizeof(addr_in);
		}
		c->relay_retry++;		
        if(c->ftarget > 0 && c->ftarget->addr == UNIX_DOMAIN_IP ){
			//nop
		}else{
			c->ftarget = h->has_counter || h->callback || h->response ? h : NULL;
		}		
		if(h->has_counter) {
			atomic_inc(&h->count_inuse);
			atomic_inc(&h->count_access);
		}		
        if(h->addr == UNIX_DOMAIN_IP){
			rv = fast_connect(c->relayfd, (struct sockaddr *)&addr_un, slen);
		}else{
			rv = fast_connect(c->relayfd, (struct sockaddr *)&addr_in, slen);
		}
        if(rv == 0) {            
            return 0;
        }
		FAST_ERRNO(rv);
		if(rv != -EINPROGRESS) {
            if (rv != -EAGAIN) {
                lprintf("Can't connect %s:%d for %s", inet_ntoa(addr_in.sin_addr), h->port, strerror(-rv));
            }
			if(h->has_counter) {
				atomic_dec(&h->count_inuse);
				atomic_inc(&h->count_error);
			}
            free_ftarget(c);            
		}
		return rv;
	}
	if(c->relayfd==0) {
		lprintf("\7Someone close stdin %s(%d)\n", __FILE__, __LINE__);
		return -EPERM;
	}
	else if ((-EMFILE == c->relayfd) || (-ENFILE == c->relayfd)) {
		lprintf("open relay-server error: %s", strerror(-c->relayfd)); // EMFILE,ENFILE,EBADF 
		exit_http();
	}
	return -c->relayfd;
}
/* }}}1 */

/* open_cache_file() {{{1 */
/* return fd */
int open_cache_file(struct conn *c) {
	int fd;
	char buf[30];

	*(int64_t *)(buf+0) = *(int64_t *)"/.sftmp/";
	int2hex(buf+8, (unsigned)(unsigned long)c)[0] = '\0';
	/* zero access perm prevent unintentional access */
#if IOPERF_SUPPORT
	if(ioperf_exp) {
		uint64_t iostart = readtsc();
#endif
		fd = fast_open(buf, O_RDWR|O_CREAT|O_TRUNC, 0);
#if IOPERF_SUPPORT
		uint64_t iostop = readtsc() - iostart;
		c->thread->ioperf_sum += iostop;
		c->iowait += iostop;
	} else
#endif
		fd = fast_open(buf, O_RDWR|O_CREAT|O_TRUNC, 0);
	if(fd <= 0) {
		static int warning_cache = 0;
		if(warning_cache==0) {
			warning_cache = 1;
			lprintf("\7Cannot open cache file under @docroot/.sftmp/\n");
			lprintf("\7Store-forwarding mode may not work.\n");
		}
		return -1;
	}
	check_new_fd(fd);
	fast_unlink(buf);
	return fd;
}
/* }}}1 */

/* close_relay_connection() {{{1 */
void close_relay_connection(struct conn *c) {    
	struct worker *wt = c->thread;
	uint32_t addr;

	addr = fdinfo[c->netfd].addr;
	log_tcpinfo(c->netfd);    
	fdinfo[c->netfd].conn = NULL;
	fast_close(c->netfd); /* CHECKED OK */
	c->netfd = -1;
	if(c->cookiestr){
		free(c->cookiestr);
		c->cookiestr = NULL;
	}
	if(c->relayfd>0) {
		fdinfo[c->relayfd].conn = NULL;
		fast_close(c->relayfd); /* CHECKED OK */ 
        //ISDSTAT(atomic_dec(&countermap->proxyfds));
        UNIX_RECONNECT(c);
	}
	if(c->cachefd>0) {
		fast_close(c->cachefd); /* CHECKED OK */
        //ISDSTAT(atomic_dec(&countermap->ccachefds));
	}
    close_proxyfd(c);
	if(c->ftarget) {
		if(c->ftarget->has_counter)
			atomic_dec(&c->ftarget->count_inuse);
		//if(c->ftarget->addr == str2ip(UNIX_DOMAIN_IP,NULL)){        
        free_ftarget(c);
	}
	if(logmode > STAT_DIGEST && c->sendcode)
		log_request(c, addr);
	c->flag_all = 0;
	c->proc = resume_http_connection;
	ISDSTAT(atomic_dec(&countermap->workcon));
	c->entity = NULL;
	list_del_init(&c->timer_io);
	INIT_LIST_HEAD(&c->timer_req);
	c->freenext = wt->freeconn;
	wt->freeconn = c;
	if(wt->inc_negative>0)
		wt->inc_negative--;
	else
		NEXT_LIST_ITEM(wt->inc_head, nconns1);
}
/* }}}1 */

/* end_of_relay() {{{1 */
static void end_of_relay(struct conn *c) {
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
	struct worker *wt = c->thread;

	if(c->relayfd>0) {
		fdinfo[c->relayfd].conn = NULL;
		fast_close(c->relayfd); /* CHECKED OK */
        //ISDSTAT(atomic_dec(&countermap->proxyfds));
	}
	if(c->cachefd>0) {
		fast_close(c->cachefd); /* CHECKED OK */
        //ISDSTAT(atomic_dec(&countermap->ccachefds));
	}
	if(c->ftarget) {
		if(c->ftarget->has_counter)
			atomic_dec(&c->ftarget->count_inuse);
		//add by stnawnag
		//if(c->ftarget->addr == str2ip(UNIX_DOMAIN_IP,NULL)){        
        free_ftarget(c);
	}
	if(logmode > STAT_DIGEST && c->sendcode)
		log_request(c, fdinfo[c->netfd].addr);
	CHECK_RECVBUF;
	c->recvptr += c->recvcnt;
	c->recvcnt = 0; CHECK_RECVBUF;
	c->proc = resume_http_connection;
	c->entity = NULL;
	c->flag_zero = 0;
	c->pending = 1;
	c->resume = 1;
	fdinfo[c->netfd].nreq++;

	c->range_start = 0;
	c->range_last = -1;
	c->imstime = 0;
	c->sendfd = 0;
	c->sendcode = 0;
	c->host[0] = '\0';
	c->url[0] = '\0';
	c->vhost = NULL;
	c->logsize = 0;
#if THROTTLE_SUPPORT
	c->speed = 0;
#endif
#if COOKIE_SUPPORT
	clear_cookie_buffer(c->cookie);
	if(c->cookiestr > 0){
		free(c->cookiestr);
		c->cookiestr = NULL;
	}
#endif
	c->tsc4_req = TSCRND(wt->tsc_now) + tsc4_request;
	list_add_tail(&c->timer_req, &wt->timer_req);
	list_move_tail(&c->timer_io, &wt->pending);
	c->sendptr = c->sendlen = 0;
	c->sendbuf[0] = '\0';
}
/* }}}1 */

/* relay_error() {{{1 */
static void relay_error(struct conn *c) {
	struct worker *wt = c->thread;
    ISDSTAT(atomic_inc(&countermap->relayerror));

	if(c->relayfd>0) {
		fdinfo[c->relayfd].conn = NULL;
		fast_close(c->relayfd); /* CHECKED OK */
        //ISDSTAT(atomic_dec(&countermap->proxyfds));
	}
	if(c->cachefd>0) {
		fast_close(c->cachefd); /* CHECKED OK */
        //ISDSTAT(atomic_dec(&countermap->ccachefds));
	}
	if(c->ftarget != NULL) {
		if(c->ftarget->has_counter)
			atomic_dec(&c->ftarget->count_inuse);
		//add by stnawnag
		//if(c->ftarget->addr == str2ip(UNIX_DOMAIN_IP,NULL)){
        free_ftarget(c);
    }
    
    CHECK_RECVBUF;
	c->recvptr += c->recvcnt;
	c->recvcnt=0; CHECK_RECVBUF;
	if(c->pass_mode >= REQ_PARSED ||
			(c->pass_mode==REQ_POST && !c->has_chunked))
	{
		c->header_parsed = 1;
	} else 
		c->keepalive = 0;
	c->proc = resume_http_connection;
	c->sendfd = 0;
	c->entity = NULL;
	c->range_start = 0;
	c->range_last = -1;
	c->imstime = 0;

	c->sendptr = c->sendlen = 0;
	c->sendbuf[0] = '\0';
	c->relaymode = 0;
	c->resume = 1;
	INIT_LIST_HEAD(&c->timer_req);
	list_move_tail(&c->timer_io, &wt->pending);
	c->sendfd = 0;
	c->logsize = 0;
	c->expire = 0;
#if THROTTLE_SUPPORT
	c->speed = 0;
#endif
}
/* }}}1 */

/* close_server_peer() {{{1 */
static void close_server_peer(struct conn *c) {    
	if(c->relayfd>0) {
		fdinfo[c->relayfd].conn = NULL;
		fast_close(c->relayfd); /* CHECKED OK */
		c->relayfd = -1;
        //ISDSTAT(atomic_dec(&countermap->proxyfds));
        UNIX_RECONNECT(c);
	}
	if(c->cachefd>0) {
		fast_close(c->cachefd); /* CHECKED OK */
		c->cachefd = -1;
        //ISDSTAT(atomic_dec(&countermap->ccachefds));
	}
    close_proxyfd(c);
	if(c->ftarget) {
		// ***BEGIN*** Commented by yorkwang on 2008-03-04
		//if(c->ftarget->has_counter)
			//atomic_dec(&c->ftarget->count_inuse);
		// ***END*** Commented by yorkwang on 2008-03-04

		//add by stnawnag
		//if(c->ftarget->addr == str2ip(UNIX_DOMAIN_IP,NULL)){
        free_ftarget(c);
    }
    CHECK_RECVBUF;
    if(c->recvcnt) {
		c->recvptr += c->recvcnt;
		c->recvcnt = 0;
		memmove(c->recvbuf, c->recvbuf+c->recvptr, c->recvlen-c->recvptr+1);
		c->recvlen -= c->recvptr;
		c->recvptr = 0;
	}
	CHECK_RECVBUF;
	c->reply_mode = REPLY_PARSED;
}
/* }}}1 */

/* bad_group_callback() {{{1 */
/* return
 * 0 -- error, END
 * 1 -- target
 * 2 -- group
 */
static int bad_group_callback(struct conn *c, group_t **gp, ftarget_t **hp) {
	cbdata_t cp[1];
	int rv;

	init_callback_data(c, cp);
	cp->reason = -EBUSY;
	cp->priv = *gp;
	rv = no_target_callback(cp);
#define RESPONSE_PROCESS	relay_error(c)
#define FORWARD_PROCESS if(c->relay_retry >= 7) \
	break; \
	if(cp->ftarget==NULL) \
	break; \
	if(rv != RF_FORWARD_GROUP) { \
		*gp = NULL; \
		*hp = cp->ftarget; \
		return 1; \
	} \
	if(*gp != (group_t *)cp->ftarget) { \
		c->relay_retry++; \
		*gp = cp->ftarget; \
		return 2; \
	} \
	break;
#include "callback.c"
	relay_error(c);
	//http_error(c, 503, c->url);
    http_error(c, 550, c->url);
	return 0;
}
/* }}}1 */

/* resolv_group() {{{1 */
/*
 * return
 * NULL -- error, END
 */
static struct forward_target * resolve_group(struct conn *c, struct group *g) {
	c->fgroup = NULL;
	while(1) {
		struct forward_target *h;
		if((h=schedule_target(g, fdinfo[c->netfd].addr))) {
			c->fgroup = g;
			return h;
		}
		switch(bad_group_callback(c, &g, &h)) {
			case 0:
				return NULL;
			case 1:
				return h;
		}
	}
	/* NOTREACHABLE */
	relay_error(c);
	http_error(c, 503, c->url);
	return NULL;
}
/* }}}1 */

/* resume_peer_error() {{{1 */
/*
 * return
 * 0 -- error&END
 * 1 -- reconnected
 * 2 -- reconnecting
 */
static int resume_peer_error(struct conn *c, int err) {
	ftarget_t *h = c->ftarget;
	group_t *g = c->fgroup;
	int rv;

	if(h) {
		if(h->has_counter) {
			atomic_dec(&h->count_inuse);
			atomic_inc(&h->count_error);
		}
		//c->ftarget = NULL;
		if(h->callback) {
			cbdata_t cp[1];

			init_callback_data(c, cp);
			cp->priv = h;
			cp->reason = err;
			if(g)
				rv = group_callback(cp, g);
			else
				rv = h->callback(cp);
#define RESPONSE_PROCESS relay_error(c)
#define FORWARD_PROCESS if(c->relay_retry >= 7) break; \
			if(cp->ftarget==NULL) break; \
			if(rv != RF_FORWARD_GROUP) { \
				g = NULL; \
				h = cp->ftarget; \
			} else { \
				h = NULL; \
				c->fgroup = NULL; \
				g = cp->ftarget; \
			} \
			goto retry;
#include "callback.c"
		}
	}

	relay_error(c);
	//http_error(c, 503, c->url);
    http_error(c, 551, c->url);
	return 0;

err500:
	relay_error(c);
	http_error(c, 500, c->url);
	return 0;
retry:
	if(g && (h = resolve_group(c, g))==NULL)
		return 0;
	rv = open_server_socket(c, h);
	if(rv == 0)
		return 1;
	if(rv != -EINPROGRESS)
		goto err500;

	if(pollmode) {
		struct epoll_event ev;
		ev.events = POLLOUT|EPOLLET;
		ev.data.fd = c->relayfd;
		fast_epoll_ctl(c->thread->epfd, EPOLL_CTL_ADD, c->relayfd, &ev);
		c->relayevents = POLLOUT;
	}
	c->tsc_io = readtsc() + tsc_connect;
	list_move_tail(&c->timer_io, &c->thread->timer_connect);
	return 2;
}
/* }}}1 */

/* relay_timeout() {{{1 */
void relay_timeout(struct conn *c) {
	if(resume_peer_error(c, ETIMEDOUT)==1){
		c->relayproc(c->relayfd, POLLOUT);
	}
}
/* }}}1 */

/* resume_peer_hangup() {{{1 */
/*
 * return
 * 0 -- error&END
 * 1 -- reconnected
 * 2 -- reconnecting
 */
static int resume_peer_hangup(struct conn *c) {
	int err;
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
	socklen_t len = sizeof(err);
	fast_getsockopt(c->relayfd, SOL_SOCKET, SO_ERROR, &err, &len);
	return resume_peer_error(c, err);
}
/* }}}1 */

/* hook_response() {{{1 */
#if RESPONSE_CALLBACK
/* FIXME: not stable */
static int hook_response(struct conn *c, int err) {
	ftarget_t *h = c->ftarget;
	group_t *g = c->fgroup;
	int rv;
	cbdata_t cp[1];

	init_callback_data(c, cp);
	cp->priv = h;
	cp->reason = err;
	rv = h->response(cp);
#define RESPONSE_PROCESS relay_error(c); 
#define FORWARD_PROCESS if(h->has_counter) \
	atomic_dec(&h->count_inuse); \
	if(c->relay_retry >= 7) goto err503; \
	if(cp->ftarget==NULL) goto err500; \
	if(c->cachefd<=0) goto err500; \
	c->cachefd_start = 0; \
	c->pass_mode = REQ_PARSED; \
	c->reply_mode = REPLY_STATUS; \
	c->fgroup = NULL; \
	if(rv != RF_FORWARD_GROUP) { \
		g = NULL; \
		h = cp->ftarget; \
	} else { \
		h = NULL; \
		g = cp->ftarget; \
	} \
	goto redirect;
#include "callback.c"

	return 1; /* continue processing */
err500:
	relay_error(c);
	http_error(c, 500, c->url);
	return 0;
err503:
	relay_error(c);
	http_error(c, 503, c->url);
	return 0;

redirect:
	if(g && (h = resolve_group(c, g))==NULL)
		return 0;
	rv = open_server_socket(c, h);
	if(rv == 0) {
		resume_server_connected(c->relayfd, POLLOUT);
		return 0;
	}
	if(rv != -EINPROGRESS)
		goto err500;

	if(pollmode) {
		struct epoll_event ev;
		ev.events = POLLOUT|EPOLLET;
		ev.data.fd = c->relayfd;
		fast_epoll_ctl(c->thread->epfd, EPOLL_CTL_ADD, c->relayfd, &ev);
		c->relayevents = POLLOUT;
	}
	c->relayproc = resume_server_connected;
	c->tsc_io = readtsc() + tsc_connect;
	list_move_tail(&c->timer_io, &c->thread->timer_connect);
	return 0;
}
#endif
/* }}}1 */

/* update_events() {{{1 */
static void update_events(struct conn *c) {
	int ec=0, es=0;

	if(c->reply_mode==REPLY_FORWARDED)
	{
		if(c->keepalive && c->pass_mode >= REQ_PARSED) {
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
			end_of_relay(c);
		} else{
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
			close_relay_connection(c);
		}
		return;
	}
	CHECK_RECVBUF;
	if(c->recvptr != 0) {
		memmove(c->recvbuf, c->recvbuf+c->recvptr, c->recvlen-c->recvptr+1);
		c->recvlen -= c->recvptr;
		c->recvptr = 0;
		CHECK_RECVBUF;
		if(c->pass_mode < REQ_PARSED)
			ec |= POLLIN;
	} else if(c->recvlen < recvbufsz && c->pass_mode < REQ_PARSED)
		ec |= POLLIN;

	if((c->recvcnt||c->cachefd_end>c->cachefd_start) && c->pass_mode != REQ_FORWARDED)
		es |= POLLOUT;

	if(c->sendptr != 0) {
		memmove(c->sendbuf, c->sendbuf+c->sendptr, c->sendlen-c->sendptr+1);
		c->sendlen -= c->sendptr;
		c->sendptr = 0;
		es |= POLLIN;
	} else if(c->sendlen < sendbufsz) {
		es |= POLLIN;
	}

	if(c->sendcnt)
		ec |= POLLOUT;

	if(pollmode) {
		struct epoll_event ev;

		if(c->relayfd > 0 && es != c->relayevents) {
			ev.events = es|EPOLLET;
			ev.data.fd = c->relayfd;
			fast_epoll_ctl(c->thread->epfd, c->relayevents==POLL_DEFER_ACCEPT?EPOLL_CTL_ADD:EPOLL_CTL_MOD, c->relayfd, &ev);
			c->relayevents = es;
		}

		if(c->events==POLL_DEFER_ACCEPT) {
			if(ec != 0) {
				ev.events = ec|EPOLLET;
				ev.data.fd = c->netfd;
				fast_epoll_ctl(c->thread->epfd, EPOLL_CTL_ADD, c->netfd, &ev);
				c->events = ec;
			}
		} else if(ec != c->events) {
			ev.events = ec|EPOLLET;
			ev.data.fd = c->netfd;
			fast_epoll_ctl(c->thread->epfd, EPOLL_CTL_MOD, c->netfd, &ev);
			c->events = ec;
		}
	}
	c->tsc_io = readtsc() + tsc_transfer;
	list_move_tail(&c->timer_io, &c->thread->timer_relay);
}
/* }}}1 */

/* connecting_to_server() {{{1 */
/*
 * return
 * 0 -- error & END
 * 1 -- forwarding
 */
static int connecting_to_server(struct conn *c) {
	int rv;
	ftarget_t *h = c->ftarget;
	group_t *g = c->fgroup;

#if 0
	if(c->cachefd_end != fast_lseek(c->cachefd, 0L, SEEK_END))
		lprintf("BUG: cachefd_end != filesize\n");
#endif

	if(h && h->has_counter)
		atomic_dec(&h->count_inuse);

	if(g && (h = resolve_group(c, g))==NULL)
		return 0;
	rv = open_server_socket(c, h);

	if(rv==0) {
		/* pass_cache2server() may return 0 or 502 */
		if((rv=pass_cache2server(c))!=0) {
			relay_error(c);
			http_error(c, rv, c->url);
			return 0;
		}
		c->relayproc = resume_server_connection;
		update_events(c);
		return 1;
	}
	if(rv != -EINPROGRESS) {
		relay_error(c);
		http_error(c, 500, c->url);
		return 0;
	}

	if(pollmode) {
		struct epoll_event ev;
		ev.events = POLLOUT|EPOLLET;
		ev.data.fd = c->relayfd;
		fast_epoll_ctl(c->thread->epfd, EPOLL_CTL_ADD, c->relayfd, &ev);
		c->relayevents = POLLOUT;
	}
	c->relayproc = resume_server_connected_sf;
	c->tsc_io = readtsc() + tsc_connect;
	list_move_tail(&c->timer_io, &c->thread->timer_connect);
	return 1;
}
/* }}}1 */

/* substring() {{{1 */
static int substring(const char *s1, const char *s2) {
	char c1, c2;
	while((c1=*s1++)) {
		if(!(c2 = *s2++))
			return 0;
		if((c1^c2)&~0x20)
			return -1;
	}
	return 1;
}
/* }}}1 */

#if 0
struct match_table {
	char *str;
	int len;
};
#define MATCH_ENTRY(x)	{ .str = x, .len = sizeof(x)-1 }
static int match_strings(struct match_table *mt, char *p) {
	int idx = 1;
	int v;
	while(mt->len) {
		v = substring(p, mt->str);
		if(v > 0)
			/* partial name*/
			return 0;

		if(v==0)
			return idx;
	}
	return idx;
}
#endif

/* parse_http_request() {{{1 */
/*
 * parse & Remove: Connection:
 * parse: Content-Length:
 * parse: Expect: 100-continue
 * parse: Transfer-Encoding: chunked
 * return 0 or status code
 */
#define RECVBUF_ALL c->recvcnt = c->recvlen - c->recvptr
#define RECVBUF_CUR c->recvcnt = p - c->recvbuf - c->recvptr
#define RECVBUF_FULL c->recvcnt==0 && c->recvptr==0 && c->recvlen==recvbufsz
#if 0
static struct match_table request_table[] = {
	MATCH_ENTRY("Connection:"),		// 1
	MATCH_ENTRY("Host:"),			// 2
	MATCH_ENTRY("Content-Length:"),		// 3
	MATCH_ENTRY("Expect:"),			// 4
	MATCH_ENTRY("Transfer-Encoding:"),	// 5
};
#endif
static int parse_http_request(struct conn *c) {
	static void * const reqjump[REQ_TOTAL_STATES] = {
		[REQ_HEADER] = &&jmp_header,
		[REQ_PASS] = &&jmp_pass,
		[REQ_CLEN] = &&jmp_clen,
		[REQ_CLEN1] = &&jmp_clen1,
		[REQ_POST] = &&jmp_post,
		[REQ_TRAILER] = &&jmp_header,
		[REQ_PARSED] = &&jmp_parsed,
		[REQ_FORWARDED] = &&jmp_parsed,
	};
	char *p, *q;
	int v;

	CHECK_RECVBUF;
	p = c->recvbuf+c->recvptr+c->recvcnt;
	goto *reqjump[c->pass_mode];

jmp_pass:
	RECVBUF_ALL;
jmp_parsed:
	return 0;

jmp_header:
	if(c->long_line) {
		q = strchr(p, '\n');
		if(q==NULL) {
			RECVBUF_ALL;
			return 0;
		}
		p = q + 1;
		c->long_line = 0;
	}
trailer:
	while(1) {
		v = substring(p, "Connection:");
		if(v > 0) {
			/* partial name */
			RECVBUF_CUR;
			return 0;
		} else if(v==0) {
			char *line = p+11;
			if((q = strchr(line, '\n'))==NULL ) {
				/* partial line */
				RECVBUF_CUR;
				if(RECVBUF_FULL) {
					memcpy(c->recvbuf, "Connection:", 12);
					c->recvlen = 11;
					c->keepalive = 0;
					c->keepalive_off = 1;
				}
				return 0;
			}

			/* parse Connection: */
			while(*line==' '||*line=='\t') line++;
			if(!strncasecmp(line, "close", 5)) {
				c->keepalive = 0;
				c->keepalive_off = 1;
			} else if(!c->keepalive && !c->keepalive_off && timeout_keepalive &&
					!strncasecmp(line, "keep-alive", 10))
			{
				if(fdinfo[c->netfd].nreq < nreq_keepalive)
					c->keepalive = 1;
			}
			/* Remove Connection: */
			++q;
			memmove(p, q, c->recvbuf+c->recvlen-q+1);
			c->recvlen -= q-p;
			continue;
		}

		v = substring(p, "Host:");
		if(v > 0) {
			/* partial name */
			RECVBUF_CUR;
			return 0;
		} else if(v==0) {
			char *line = p+5;
			if((q = strchr(line, '\n'))==NULL ) {
				/* partial line */
				RECVBUF_CUR;
				return RECVBUF_FULL ? 413 : 0;
			}

			/* parse Content-Length: */
			while(*line==' '||*line=='\t') line++;
			save_vhost(c, line);
			p = q+1;
			continue;
		}

		v = substring(p, "Content-Length:");
		if(v > 0) {
			/* partial name */
			RECVBUF_CUR;
			return 0;
		} else if(v==0) {
			char *line = p+15;
			if((q = strchr(line, '\n'))==NULL ) {
				/* partial line */
				RECVBUF_CUR;
				return RECVBUF_FULL ? 413 : 0;
			}

			/* parse Content-Length: */
			while(*line==' '||*line=='\t') line++;
			c->postsize = atoi(line);
			if(c->postsize < 0 || c->postsize > maxpostsize) {
				c->postsize = 0;
				c->keepalive_off = 1;
				c->keepalive = 0;
				return 413;
			}
			c->has_cl = 1;
			p = q+1;
			continue;
		}

		if(c->cachefd > 0) {
			/* store-forward mode conflict w/ 100-continue */
			v = substring(p, "Expect:");
			if(v > 0) {
				/* partial name */
				RECVBUF_CUR;
				return 0;
			} else if(v==0) {
				char *line = p+7;
				if((q = strchr(line, '\n'))==NULL ) {
					/* partial line */
					RECVBUF_CUR;
					return RECVBUF_FULL ? 417 : 0;
				}

				/* parse Expect: */
				while(*line==' '||*line=='\t') line++;
				if(*(uint32_t *)line == *(uint32_t *)"100-")
				{
					/* Remove Expect: */
					++q;
					memmove(p, q, c->recvbuf+c->recvlen-q+1);
					c->recvlen -= q-p;
					memcpy(c->sendbuf, "100 Continue\r\n\r\n", 17);
					c->sendptr = 0;
					c->sendlen = 16;
					c->sendcnt = 16;
					c->expect100 = 1;
				} else
					return 417;
				continue;
			}
		}

		/* NOT Content-type: */
		v = substring(p, "Transfer-Encoding:");
		if(v > 0) {
			/* partial name */
			RECVBUF_CUR;
			return 0;
		} else if(v==0) {
			char *line = p+18;
			if((q = strchr(line, '\n'))==NULL) {
				/* partial line */
				RECVBUF_CUR;
				if(RECVBUF_FULL) {
					c->long_line = 1;
					c->keepalive = 0;
					c->keepalive_off = 1;
					RECVBUF_ALL;
				}
				return 0;
			}

			/* parse Transfer-Encoding: */
			while((p=strchr(line, ',')) && p < q)
				line = p + 1;
			while(*line==' '||*line=='\t') line++;
			if(!strncasecmp(line, "chunked", 7)) {
				c->has_chunked = 1;
			} else {
				c->keepalive = 0;
				c->keepalive_off = 1;
			}

			p = q+1;
			continue;
		}

		/* other */
		if((q = strchr(p, '\n'))==NULL) {
			/* partial line */
			c->long_line = 1;
			RECVBUF_ALL;
			return 0;
		}
		if(p==q || *(uint16_t *)p == *(uint16_t *)"\r\n")
			break;
		p = q+1;
	}

	if(c->pass_mode == REQ_TRAILER) {
		p = q+1;
		RECVBUF_CUR;
		c->pass_mode = REQ_PARSED;
		return 0;
	}

	if(!c->has_chunked)
		p = q+1;
	RECVBUF_CUR;

	if(c->has_chunked) {
		c->pass_mode = REQ_CLEN;
	} else if(c->has_cl) {
		c->pass_mode = REQ_POST;
		goto jmp_post;
	} else if(c->method==METHOD_POST) {
		if(c->cachefd > 0)
			return 411;
		c->pass_mode = REQ_PASS;
		goto jmp_pass;
	} else {
		c->pass_mode = REQ_PARSED;
		return 0;
	}

jmp_clen:
	if(p[0]!='\r' || p[1]!='\n' || (q = strchr(p+2, '\n'))==NULL) {
		/* partial line */
		RECVBUF_CUR;
		return RECVBUF_FULL ? 413 : 0;
	}
	c->postsize = strtol(p+2, NULL, 16);
	if(c->postsize < 0)
		return 413;
	p = q+1;
	if(c->postsize==0) {
		c->pass_mode = REQ_TRAILER;
		goto trailer;
	}
	c->pass_mode = REQ_POST;

jmp_post:
	v = c->recvbuf + c->recvlen - p;
	if(v < c->postsize) {
		c->postsize -= v;
		RECVBUF_ALL;
		return 0;
	}

	p += c->postsize;
	c->postsize = 0;
	if(c->has_chunked) {
		c->pass_mode = REQ_CLEN;
		goto jmp_clen;
	}

	c->pass_mode = REQ_PARSED;
	RECVBUF_CUR;
	return 0;

jmp_clen1: /* clen without prefix */
	if((q = strchr(p, '\n'))==NULL) {
		/* partial line */
		RECVBUF_CUR;
		return RECVBUF_FULL ? 413 : 0;
	}
	c->postsize = strtol(p, NULL, 16);
	if(c->postsize < 0)
		return 413;
	p = q+1;
	if(c->postsize==0) {
		c->pass_mode = REQ_TRAILER;
		goto trailer;
	}
	c->pass_mode = REQ_POST;
	goto jmp_post;
}
/* }}}1 */

/* parse_http_reply() {{{1 */
/*
 * remove & add: Connection:
 * remove: bogus 100 Continue
 * parse: Content-Length:
 * parse: Content-Type:
 * parse: Transfer-Encoding: chunked
 * return 0 or status code
 */
#define SENDBUF_ALL c->sendcnt = c->sendlen - c->sendptr
#define SENDBUF_CUR c->sendcnt = p - c->sendbuf - c->sendptr
#define SENDBUF_FULL c->sendcnt==0 && c->sendptr==0 && c->sendlen >= hsendbufsz

static int parse_http_reply(struct conn *c) {
	static void * const replyjump[REPLY_TOTAL_STATES] = {
		[REPLY_STATUS] = &&jmp_status,
		[REPLY_HEADER] = &&jmp_header,
		[REPLY_PASS] = &&jmp_pass,
		[REPLY_CLEN] = &&jmp_clen,
		[REPLY_DATA] = &&jmp_data,
		[REPLY_TRAILER] = &&jmp_header,
		[REPLY_PARSED] = &&jmp_parsed,
		[REPLY_FORWARDED] = &&jmp_parsed,
	};
	char *p, *q;
	int v;    

	p = c->sendbuf+c->sendptr+c->sendcnt;
	goto *replyjump[c->reply_mode];

jmp_pass:
    print_status();
	SENDBUF_ALL;
jmp_parsed:
    print_status();
	return 0;

jmp_status: // Pointer to the header of HTTP package
    print_status();
	q = strchr(p, '\n');
	if(q==NULL)
		return 0;

	if(*(uint32_t *)p != *(uint32_t *)"HTTP" ||
			p[4] != '/' || !is_digit(p[5]) || p[6]!='.' ||
			!is_digit(p[7]) || p[8]!=' ' ||
			!is_digit(p[9]) || !is_digit(p[10]) || !is_digit(p[11])
	  )
	{
		return 502;
	}
	c->sendcode = (p[9]-'0')*100 + (p[10]-'0')*10 + (p[11]-'0');
	p = q+1;
	if(timeout_keepalive==0 || (c->pass_mode>=REPLY_HEADER && !c->keepalive))
	{
		c->reply_mode = REPLY_PASS;
		goto jmp_pass;
	}
	c->reply_mode = REPLY_HEADER;

jmp_header: // Pointer to next line of status-line    
    print_status();
	if(c->reply_long_line) {
		if((q = strchr(p, '\n'))==NULL) {
			SENDBUF_ALL;
			return 0;
		}
		p = q + 1;
		c->reply_long_line = 0;
	}

trailer: // Pointer to next line of status-line    
    print_status();
	while(1) {
		v = substring(p, "Connection:");
		if(v > 0) {
			/* partial name */
			SENDBUF_CUR;
			return 0;
		} else if(v==0) {
			if((q = strchr(p+11, '\n'))==NULL ) {
				/* partial line */
				SENDBUF_CUR;
				if(SENDBUF_FULL) {
					memcpy(c->sendbuf, "Connection:", 12);
					c->sendlen = 11;
					c->keepalive = 0;
					c->keepalive_off = 1;
				}
				return 0;
			}

			/* Remove Connection: */
			++q;
			memmove(p, q, c->sendbuf+c->sendlen-q+1);
			c->sendlen -= q-p;
			continue;
		}

		/* NOT Connection: */
		v = substring(p, "Content-Type:");
		if(v > 0) {
			/* partial name */
			SENDBUF_CUR;
			return 0;
		} else if(v==0) {
			c->reply_has_content = 1;
			if((q = strchr(p+15, '\n'))==NULL) {
				/* partial line */
				SENDBUF_CUR;
				if(SENDBUF_FULL) {
					c->reply_long_line = 1;
					SENDBUF_ALL;
				}
				return 0;
			}
			p = q+1;
			continue;
		}

        /* NOT Content-Encoding: */
        v = substring(p, "Content-Encoding:");
        if(v > 0) {
            /* partial name */
            SENDBUF_CUR;
            return 0;
        } else if(v==0) {
            char *line = p+17;
            if((q = strchr(line, '\n'))==NULL ) {
                /* partial line */
                SENDBUF_CUR;
                if(SENDBUF_FULL) {
                    c->keepalive = 0;
                    c->keepalive_off = 1;
                    c->reply_long_line = 1;
                    SENDBUF_ALL;
                }
                return 0;
            }
            
            /* parse Content-Length: */
            while(*line==' '||*line=='\t') line++;
            if (strstr(line , "gzip")) {
                //lprintf("%s:%d, gzip %s from %s", __FILE__, __LINE__, c->url, c->host);
                c->relay_zipped = 1;
            }
            else if (strstr(line , "deflate")) {
                //lprintf("%s:%d, deflate %s from %s", __FILE__, __LINE__, c->url, c->host);
                c->relay_zipped = 2;
            }
            else {
                //lprintf("%s:%d, uncompress %s from %s", __FILE__, __LINE__, c->url, c->host);
            }
            
            p = q+1;
            continue;
		}

		/* NOT Content-type: */
		v = substring(p, "Content-Length:");
		if(v > 0) {
			/* partial name */
			SENDBUF_CUR;
			return 0;
		} else if(v==0) {
			char *line = p+15;
			if((q = strchr(line, '\n'))==NULL ) {
				/* partial line */
				SENDBUF_CUR;
				if(SENDBUF_FULL) {
					c->keepalive = 0;
					c->keepalive_off = 1;
					c->reply_long_line = 1;
					SENDBUF_ALL;
				}
				return 0;
			}

			/* parse Content-Length: */
			while(*line==' '||*line=='\t') line++;
            // yijian
			//c->replysize = atoll(line);
            c->replysize = strtoll(line, NULL, 10);
			if(c->replysize < 0)
				c->replysize = 0;
            c->cachedsize = c->replysize;
			c->reply_has_content = 1;
			c->reply_has_length = 1;
			p = q+1;
			continue;
		}

		/* NOT Content-type: */
		v = substring(p, "Transfer-Encoding:");
		if(v > 0) {
			/* partial name */
			SENDBUF_CUR;
			return 0;
		} else if(v==0) {
			char *line = p + 18;
			if((q = strchr(line, '\n'))==NULL ) {
				/* partial line */
				SENDBUF_CUR;
				if(SENDBUF_FULL) {
					c->keepalive = 0;
					c->keepalive_off = 1;
					c->reply_long_line = 1;
					SENDBUF_ALL;
				}
				return 0;
			}

			/* parse Transfer-Encoding: */
			while((p=strchr(line, ',')) && p < q)
				line = p + 1;
			while(*line==' '||*line=='\t') line++;
			if(!strncasecmp(line, "chunked", 7)) {
				c->reply_has_length = 1;
				c->reply_chunked = 1;
			} else {
				c->keepalive = 0;
				c->keepalive_off = 1;
			}

			p = q+1;
			continue;
		}
		/* other */
		if((q = strchr(p, '\n'))==NULL) {
			/* partial line */
			c->reply_long_line = 1;
			SENDBUF_ALL;
			return 0;
		}
		if(p==q || *(uint16_t *)p == *(uint16_t *)"\r\n")
			break;
		p = q+1;
	}

	if(c->reply_mode == REPLY_TRAILER) {
		p = q + 1;
		SENDBUF_CUR;
		close_server_peer(c);
		return 0;
	}

	if(c->sendcode==100||c->sendcode==102) {
		p = q+1;
		SENDBUF_CUR;
		c->reply_has_content = 0;
		c->reply_has_length = 0;
		c->reply_chunked = 0;
		c->sendcode = 0;
		goto jmp_status;
	}

	if((c->method==METHOD_HEAD)) {
		c->reply_has_length = 1;
		c->reply_chunked = 0;
		c->replysize = 0;
	} else if(c->sendcode==204 || c->sendcode==205 || c->sendcode==304)
		c->reply_has_length = 1;

	if(c->reply_has_length && !c->reply_chunked && c->replysize==0)
		c->reply_has_content = c->reply_has_length = 0;

	if( c->sendcode==101 ||
			c->pass_mode < REQ_PARSED ||
			(c->reply_has_content && !c->reply_has_length)
	  )
		c->keepalive = 0;

	if(c->keepalive) {
		memmove(p+24, p, c->sendbuf+c->sendlen-p+1);
		memcpy(p, "Connection: keep-alive\r\n", 24);
		p += 24;
		q += 24;
		c->sendlen += 24;
	} else {
		c->reply_mode = REPLY_PASS;
		if(c->sendcode==101)
			c->pass_mode = REQ_PASS;
		memmove(p+19, p, c->sendbuf+c->sendlen-p+1);
		memcpy(p, "Connection: close\r\n", 19);
		p += 19;
		q += 19;
		c->sendlen += 19;
		SENDBUF_ALL;
		return 0;
	}

	if(!c->reply_chunked)
		p = q+1;
	SENDBUF_CUR;
	if(!c->reply_has_content) {
		c->reply_mode = REPLY_PARSED;
		return 0;
	}

	if(c->reply_chunked==0) {
		c->reply_mode = REPLY_DATA;
		goto jmp_data;
	}

	c->reply_mode = REPLY_CLEN;

jmp_clen:    
    print_status();
	if(p[0]!='\r' || p[1]!='\n' || (q = strchr(p+2, '\n'))==NULL) {
		/* partial line */
		SENDBUF_CUR;
		return SENDBUF_FULL ? 500 : 0;
	}
	c->replysize = strtol(p+2, NULL, 16);
	if(c->replysize < 0)
		return 413;
	p = q+1;
	if(c->replysize==0) {
		c->reply_mode = REPLY_TRAILER;
		goto trailer;
	}
	c->reply_mode = REPLY_DATA;

jmp_data:  // Pointer to the body    
    print_status();
	v = c->sendbuf + c->sendlen - p;
    if (0 == c->proxyfd)
        cache_reply(c, p, v);
	if(v < c->replysize) {
		c->replysize -= v;
		SENDBUF_ALL;        
		return 0;
	}

	p += c->replysize;
	c->replysize = 0;

	if(c->reply_chunked) {
		c->reply_mode = REPLY_CLEN;
		goto jmp_clen;
	}

	SENDBUF_CUR;    
	close_server_peer(c);
	return 0;
}
/* }}}1 */

/* parse_client2server() {{{1 */
/*
 * return
 * 0  -- OK
 * -1 -- client disconnected
 * >0 -- status code
 */
static int pass_client2server(struct conn *c) {
	int bytes;

restart:
	CHECK_RECVBUF;
	thread_reached(c->thread->thst);
	if(c->recvcnt) {
		if(c->relayfd <= 0)
			bytes = c->recvcnt;
		else{
			bytes = fast_send(c->relayfd, c->recvbuf+c->recvptr, c->recvcnt,
					MSG_DONTWAIT|MSG_NOSIGNAL);
		}
		FAST_ERRNO(bytes);
		if(unlikely(bytes<0)) {
			if(bytes!=-EINTR && bytes!=-EAGAIN) return 502;
		} else if(likely(bytes>0)) {
			c->recvptr += bytes;
			c->recvcnt -= bytes;
			if(c->recvcnt==0 && c->pass_mode>=REQ_PARSED)
			{
				c->pass_mode = REQ_FORWARDED;
				/* half close don't work 
				   if(c->reply_mode != REPLY_FORWARDED)
				   fast_shutdown(c->relayfd, SHUT_WR);
				 */
				return 0;
			}
			if(c->recvptr != 0) {
				memmove(c->recvbuf, c->recvbuf+c->recvptr, c->recvlen-c->recvptr+1);
				c->recvlen -= c->recvptr;
				c->recvptr = 0;
			}
			CHECK_RECVBUF;
		}
	}
	CHECK_RECVBUF;
	if(c->recvlen < recvbufsz) {
		if(c->recvlen >= recvbufsz) {
			lprintf("%s(%d): recvlen overflow: %d netfd=%d\n", __FILE__, __LINE__, c->recvlen, c->netfd);
			c->recvlen = 0;
		}
		bytes = fast_recv(c->netfd,
				c->recvbuf+c->recvlen, recvbufsz-c->recvlen,
				MSG_DONTWAIT);
		FAST_ERRNO(bytes);
		if(bytes==0) return -1;
		if(bytes < 0) {
			if(bytes!=-EINTR && bytes!=-EAGAIN) return 502;
		} else {
			c->recvlen += bytes;
			c->recvbuf[c->recvlen] = '\0';
			CHECK_RECVBUF;
			if((bytes=parse_http_request(c)))
			{
				CHECK_RECVBUF;
				return bytes;
			}
			CHECK_RECVBUF;
			goto restart;
		}
	}
	return 0;
}
/* }}}1 */

/* parse_client2cache() {{{1 */
/*
 * return
 * 0  -- OK
 * -1 -- client disconnected
 * >0 -- status code
 */
static int pass_client2cache(struct conn *c) {
	int bytes;

restart:
	CHECK_RECVBUF;
	thread_reached(c->thread->thst);
	if(c->recvcnt) {
#if IOPERF_SUPPORT
		if(ioperf_exp) {
			uint64_t iostart = readtsc();
#endif
			bytes = fast_write(c->cachefd, c->recvbuf+c->recvptr, c->recvcnt);
#if IOPERF_SUPPORT
			uint64_t iostop = readtsc() - iostart;
			c->thread->ioperf_sum += iostop;
			c->iowait += iostop;
		} else
#endif
			bytes = fast_write(c->cachefd, c->recvbuf+c->recvptr, c->recvcnt);
		if(unlikely(bytes<c->recvcnt))
			return 500;
		c->recvptr += bytes;
		c->recvcnt -= bytes;
		c->cachefd_end += bytes;
		if(c->cachefd_end > maxpostsize+(64<<10))
			return 413;
		if(c->recvcnt==0 && c->pass_mode >= REQ_PARSED)
			return 0;
		if(c->recvptr != 0) {
			memmove(c->recvbuf, c->recvbuf+c->recvptr, c->recvlen-c->recvptr+1);
			c->recvlen -= c->recvptr;
			c->recvptr = 0;
		}
	}
	CHECK_RECVBUF;
	if(c->recvlen < recvbufsz) {
		bytes = fast_recv(c->netfd,
				c->recvbuf+c->recvlen, recvbufsz-c->recvlen,
				MSG_DONTWAIT);
		FAST_ERRNO(bytes);
		if(bytes==0) return -1;
		if(bytes < 0) {
			if(bytes!=-EINTR && bytes!=-EAGAIN) return 502;
		} else {
			c->recvlen += bytes;
			c->recvbuf[c->recvlen] = '\0';
			CHECK_RECVBUF;
			if((bytes=parse_http_request(c)))
			{
				CHECK_RECVBUF;
				return bytes;
			}
			CHECK_RECVBUF;
			goto restart;
		}
	}
	return 0;
}
/* }}}1 */

/* parse_cache2server() {{{1 */
/*
 * return
 * 0  -- OK
 * >0 -- status code 502
 */
static int pass_cache2server(struct conn *c) {
	int bytes;

	while((bytes = c->cachefd_end - c->cachefd_start) > 0) {
		thread_reached(c->thread->thst);
#if IOPERF_SUPPORT
		if(ioperf_exp) {
			uint64_t iostart = readtsc();
#endif
			bytes = fast_sendfile(c->relayfd, c->cachefd, &c->cachefd_start, bytes);
#if IOPERF_SUPPORT
			uint64_t iostop = readtsc() - iostart;
			c->thread->ioperf_sum += iostop;
			c->iowait += iostop;
		} else
#endif
			bytes = fast_sendfile(c->relayfd, c->cachefd, &c->cachefd_start, bytes);
		FAST_ERRNO(bytes);
		if(unlikely(bytes<0)) {
			if(bytes!=-EINTR && bytes!=-EAGAIN) return 502;
			break;
		}
	}

	if(bytes==0) {
		c->pass_mode = REQ_FORWARDED;
		/* half close don't work 
		   if(c->reply_mode != REPLY_FORWARDED)
		   fast_shutdown(c->relayfd, SHUT_WR);
		 */
		return 0;
	}
	return 0;
}
/* }}}1 */

/* parse_server2cache() {{{1 */
/*
 * return
 * 0  -- OK
 * -1 -- client disconnected
 * >0 -- status code
 */
static int pass_server2client(struct conn *c) {
	int bytes;

restart:
	thread_reached(c->thread->thst);
	if(c->sendcnt) {
		bytes = fast_send(c->netfd, c->sendbuf+c->sendptr, c->sendcnt,
				MSG_DONTWAIT|MSG_NOSIGNAL);
		FAST_ERRNO(bytes);
		if(unlikely(bytes<0)) {
			if(bytes!=-EINTR && bytes!=-EAGAIN) return 502;
		} else if(likely(bytes>0)) {
			c->sendptr += bytes;
			c->sendcnt -= bytes;
			c->logsize += bytes;
			if(c->vhost) {
#if HAS_ATOMIC8
				atomic8_add(bytes, &c->vhost->bytes);
#else
				atomic_add(bytes & 0x3FF, &c->vhost->bytes);
				bytes >>= 10;
				if(bytes)
					atomic_add(bytes, &c->vhost->kbytes);
#endif
			}
			if(c->sendptr != 0) {
				memmove(c->sendbuf, c->sendbuf+c->sendptr, c->sendlen-c->sendptr+1);
				c->sendlen -= c->sendptr;
				c->sendptr = 0;
			}
			if(c->sendcnt==0) {
				if(c->reply_mode == REPLY_PARSED) {
					c->reply_mode = REPLY_FORWARDED;
					return 0;
				}
				/* called by flush 100 Continue */
				if(c->expect100)
					return 0;
				/* server closed in REPLY_PASS mode, close client too */
				if(c->relayfd <= 0)
					return -1;
			}
		}
	}
	bytes = c->reply_mode > REPLY_HEADER ? sendbufsz : hsendbufsz;
	if(c->relayfd > 0 && c->sendlen < bytes) {
		bytes = fast_recv(c->relayfd,
				c->sendbuf+c->sendlen, bytes-c->sendlen,
				MSG_DONTWAIT);
		FAST_ERRNO(bytes);
		if(bytes==0) return -1;
		if(bytes < 0) {
			if(bytes!=-EINTR && bytes!=-EAGAIN) return 502;
		} else {
            if (c->proxyfd > 0)
                cache_reply(c, c->sendbuf+c->sendlen, bytes);
			c->sendlen += bytes;
			c->sendbuf[c->sendlen] = '\0';            

			if(url_in_sendbuf && c->sendlen >= url_in_sendbuf)
				c->urloverwriten = 1;
			if((bytes=parse_http_reply(c)))
				return bytes;
			goto restart;
		}
	}
	return 0;
}
/* }}}1 */

/* resume_client_connection() {{{1 */
static void resume_keep_client(int fd, int events)
{
	struct conn *c = fd2conn(fd, baseconn);

	if(c->netfd != fd) {
		lprintf("RESUME BAD RELAY CLIENT CONNECTION fd=%d %d\n", fd, c->netfd);
		return;
	}
#if TRACE_FD
	check_bad_events(fd, events);
#endif

	if(events & (POLLHUP|POLLERR)){
		close_relay_connection(c);
	}
	else
	{
		struct epoll_event ev;
		ev.events = EPOLLET;
		ev.data.fd = c->netfd;
		fast_epoll_ctl(c->thread->epfd,
				c->events==POLL_DEFER_ACCEPT?EPOLL_CTL_ADD:EPOLL_CTL_MOD,
				c->netfd, &ev);
		c->events = 0;
	}
}

static void resume_client_connection(int fd, int events) {
	struct conn *c = fd2conn(fd, baseconn);
	int rv = -1;

	if(c->netfd != fd) {
		lprintf("RESUME BAD RELAY CLIENT CONNECTION fd=%d %d\n", fd, c->netfd);
		return;
	}
#if TRACE_FD
	check_bad_events(fd, events);
#endif

	c->thread->workconn = c;
	if(events & (POLLHUP|POLLERR)) goto hangup;
	if((events & POLLOUT) && c->reply_mode < REPLY_FORWARDED) {
		if((rv=pass_server2client(c)))
			goto hangup;
	}
	if((events & POLLIN) && c->pass_mode < REQ_PARSED) {
		if(c->cachefd <= 0) {
			if(c->relayfd > 0 && (rv=pass_client2server(c)))
				goto hangup;
		} else {
			if((rv=pass_client2cache(c)))
				goto hangup;
			if(c->expect100) {
				rv=pass_server2client(c);
				c->expect100 = 0;
				if(rv)
					goto hangup;
			}
			if(c->pass_mode == REQ_PARSED) {
				if(c->host[0] && c->fgroup->vhostmap) {
					struct group **gptr = GetNameFromMap(c->fgroup->vhostmap, c->host);
					if(gptr && *gptr) {
						c->fgroup = *gptr;
						if(use_vhost==1)
							resolv_vhost(c);
					}
				}
				connecting_to_server(c);
				return;
			}
		}
	}
	CHECK_RECVBUF;
	update_events(c);
	return;
hangup:
	CHECK_RECVBUF;
	if(rv==-1) {
		close_relay_connection(c);
	} else {
		relay_error(c);
		http_error(c, rv, c->url);
	}
}
/* }}}1 */

/* resume_server_connection() {{{1 */
static void resume_server_connection(int fd, int events) {
	struct conn *c = fd2conn(fd, relayconn);
	int rv = -1;

	if(c->relayfd != fd) {
		lprintf("RESUME BAD RELAY SERVER CONNECTION fd=%d %d\n", fd, c->netfd);
		return;
	}
#if TRACE_FD
	check_bad_events(fd, events);
#endif

	c->thread->workconn = c;
    // ***BEGIN*** Added by yijian on 2007-12-29
    // events can't be (POLLIN|POLLHUP) for ever, correct it now.
    // ������eventsֵ������Ϊ(POLLIN|POLLHUP)����򵥵�ʡ��������������ǿ�ƾ�������
    // �������α겻�α�����������Ҫ��ֵ���֤���ԣ��Ա�֤������Ϊ�ǿ�ȡ�ģ������㹻��ʱ��ʱ��
    // �ٻع�ͷ���ҳ�����ĸ���ԭ��
    if ((POLLIN|POLLHUP) == events)
        events = POLLIN; // ������ǿ�ƾ���eventsֵ
    // ***END*** Added by yijian on 2007-12-29
	if(events & (POLLHUP|POLLERR)) {
		if(c->reply_mode == REPLY_STATUS) {
#if !NO_BOGUS_CHECK
			if(c->cachefd > 0 && c->cachefd_start==0) {
				/* from connecting_to_server() */
				if(resume_peer_hangup(c)!=1)
					return;
				fd = c->relayfd;
				events = POLLIN|POLLOUT; // never happen
			} else
#endif
			{
//lprintf("file[%s] line[%d] bad response",__FILE__,__LINE__);
				/* bad response */
				rv = 502;
				goto hangup;
			}
		} else if(c->reply_mode > REPLY_HEADER) {
			/* header sent, trying flush partial data */
			close_server_peer(c);
			fd = -1;
			events &= ~POLLOUT;
		} else
			goto hangup;
	}

	if((events&POLLIN) && c->reply_mode < REPLY_PARSED) {
#if RESPONSE_CALLBACK
		if(c->reply_mode==REPLY_STATUS && c->ftarget && c->ftarget->response)
		{
			char *buf = c->sendbuf;
			if(fast_recv(fd, buf, 13, MSG_PEEK|MSG_DONTWAIT)==13 &&
					*(uint32_t *)buf == *(uint32_t *)"HTTP" &&
					buf[4]=='/' && is_digit(buf[5]) && buf[6]=='.' &&
					is_digit(buf[7]) && buf[8]==' ' &&
					is_digit(buf[9]) && is_digit(buf[10]) &&
					is_digit(buf[11]) && buf[12]==' ')
			{
				if(hook_response(c, (buf[9]-'0')*100+(buf[10]-'0')*10+buf[11]-'0')==0)
					return;
			} else {
				rv = 502;
				goto hangup;
			}
		}
#endif
		if((rv = pass_server2client(c)))
			goto hangup;
		if(c->relayfd <= 0)
			events = 0;
	}
	if((events&POLLOUT) && c->pass_mode != REQ_FORWARDED) {
		if(c->cachefd <= 0) {
			if((rv=pass_client2server(c)))
				goto hangup;
		} else if(c->pass_mode == REQ_PARSED) {
			if((rv=pass_cache2server(c)))
				goto hangup;
		}
	}
	CHECK_RECVBUF;
	update_events(c);
	return;
hangup:
	CHECK_RECVBUF;
	if(rv==-1 || c->reply_mode != REPLY_STATUS) {
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
		close_relay_connection(c);
	} else {
		relay_error(c);
		http_error(c, rv, c->url);
	}
}
/* }}}1 */

/* resume_server_connected_sf() {{{1 */
static void resume_server_connected_sf(int fd, int events) {
	struct conn *c = fd2conn(fd, relayconn);

	if(c->relayfd != fd) {
		lprintf("RESUME BAD RELAY SERVER CONNECTION fd=%d %d\n", fd, c->netfd);
		return;
	}
#if TRACE_FD
	check_bad_events(fd, events);
#endif

#if NO_BOGUS_CHECK
	struct pollfd pfd;
	pfd.fd = fd;
	pfd.events = POLLIN|POLLOUT;
	if(poll(&pfd, 1, 0) <= 0) return;
	events = pfd.revents;
#endif

	c->thread->workconn = c;
	if(events & (POLLHUP|POLLERR)) {
		/* from connecting_to_server() */
		if(resume_peer_hangup(c)!=1)
			return;
		fd = c->relayfd;
		events = POLLIN|POLLOUT;
	}
	if((events & POLLOUT)==0) return;
	CHECK_RECVBUF;
	c->relayproc = resume_server_connection;
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
	resume_server_connection(fd, events);
	CHECK_RECVBUF;
}
/* }}}1 */

/* resume_server_connected() {{{1 */
static void resume_server_connected(int fd, int events) {
	struct conn *c = fd2conn(fd, relayconn);
	int rv=0;

	if(c->relayfd != fd) {
		lprintf("RESUME BAD RELAY CONNECTED fd=%d %d\n", fd, c->netfd);
		return;
	}

#if TRACE_FD
	check_bad_events(fd, events);
#endif

	c->thread->workconn = c;

	while(1) {
		CHECK_RECVBUF;
		if(events & (POLLHUP|POLLERR)) {
			if(resume_peer_hangup(c)!=1)
				return;
			fd = c->relayfd;
			// events = POLLIN|POLLOUT; // unused
		}
		CHECK_RECVBUF;

		if((events & POLLOUT)==0) return;

		struct iovec v[3];

		int n=1, l=c->sendlen;

		if(c->expect100) {
			v[0].iov_base = c->sendbuf;
			v[0].iov_len  = c->sendlen-2;
			v[1].iov_base = "Expect: 100-continue\r\n\r\n";
			v[1].iov_len = 24;
			n = 2;
			l += 22;
		} else {
			v[0].iov_base = c->sendbuf;
			v[0].iov_len  = c->sendlen;
		}
		CHECK_RECVBUF;
		if(c->recvcnt) {
			v[n].iov_base = c->recvbuf + c->recvptr;
			v[n].iov_len  = c->recvcnt;
			l += c->recvcnt;
			n++;
		}

		rv = fast_writev(fd, v, n);
/*
{
static int ac;
ac ++;
lprintf("file[%s] line[%d],rv[%d],n[%d],ac[%d],buf[%s]",__FILE__,__LINE__,rv,n,ac,(char *)v[0].iov_base);
}
*/
		if(rv == l) break;
		FAST_ERRNO(rv);
		if(rv!=-EAGAIN) return;
		if(rv > 0) {
			/* short write, impossible */
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
			rv = 500;
			goto hangup;
		}
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
		events = POLLHUP;
	}
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
	CHECK_RECVBUF;
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
	c->proc = resume_client_connection;
	c->relayproc = resume_server_connection;
	c->expect100 = 0;
	c->recvptr += c->recvcnt;
	c->recvcnt = 0;
	c->sendbuf[0] = '\0';
	c->sendptr = c->sendlen = c->sendcnt = 0;
	if(c->pass_mode == REQ_PARSED)
		c->pass_mode = REQ_FORWARDED;

	CHECK_RECVBUF;
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
	if((rv=pass_server2client(c)))
		goto hangup;
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
	CHECK_RECVBUF;
	update_events(c);
	CHECK_RECVBUF;
	return;

hangup:
	if(rv==-1 || c->reply_mode != REPLY_STATUS) {
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
		close_relay_connection(c);
	} else {
		relay_error(c);
		http_error(c, rv, c->url);
	}
}
/* }}}1 */

/* relay_connection() {{{1 */
static int relay_connection(struct conn *c, group_t *g, ftarget_t *h) {
    int relay = relay_connection_aux(c, g, h);
#ifdef UINX_RECONN
    if (110 == relay) {   
        UNIX_LOCK();
        if (UNIX_FULL()) {
            relay = 0;
        }
        else {
            relay = 1;
            c->deep = 0;
            c->relayfd = -1;
            c->netfd_old = c->netfd;
            UNIX_PUSH(c,g,h);            
        }
        UNIX_UNLOCK();
    }
#endif // UINX_RECONN
    if (0 == relay) {
        relay_error(c);
        http_error(c, 500, c->url);
    }

    return relay;
}

static int relay_connection_aux(struct conn *c, group_t *g, ftarget_t *h) {
	int rv;

	if(g && (h = resolve_group(c, g))==NULL)
		return 1;

	rv = open_server_socket(c, h);
	if(rv == 0) {		
        if(h->addr == UNIX_DOMAIN_IP)
        {
			struct sockaddr addr;
			socklen_t len;
			char tbuf[4096];
			fast_getpeername(c->netfd, &addr, (len=sizeof(addr), &len));
			if(addr.sa_family==AF_INET) {
				memcpy(tbuf,&len,4);
				memcpy(tbuf+4,&addr,len);
			}else{
				//Ŀǰֻ����AF_INET�����
			}
			int n=fast_write(c->relayfd,tbuf,len+4);
			if(n < len+4){
				lprintf("send ip to cgi err,send len[%d]  buf len[%d]",n,len+4);
			}
		}		

		resume_server_connected(c->relayfd, POLLOUT);
		return 1;
	}

	if(rv != -EINPROGRESS) {
#ifdef UINX_RECONN
        if (-EAGAIN == rv) return 110;
#endif // UINX_RECONN
		return 0;
	}

	if(pollmode) {
		struct epoll_event ev;
		ev.events = POLLOUT|EPOLLET;
		ev.data.fd = c->relayfd;
		fast_epoll_ctl(c->thread->epfd, EPOLL_CTL_ADD, c->relayfd, &ev);
		c->relayevents = POLLOUT;

//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
		if(c->pass_mode == REQ_PARSED) {
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
			if(c->events != 0 && c->events != POLL_DEFER_ACCEPT) {
				ev.events = 0;
				ev.data.fd = c->netfd;
				fast_epoll_ctl(c->thread->epfd, EPOLL_CTL_MOD, c->netfd, &ev);
				c->events = 0;
			}
#if 0
		} else if(c->events != POLLIN) {
			ev.events = POLLIN|EPOLLET;
			ev.data.fd = c->netfd;
			fast_epoll_ctl(c->thread->epfd,
					c->events==POLL_DEFER_ACCEPT?EPOLL_CTL_ADD:EPOLL_CTL_MOD,
					c->netfd, &ev);
			c->events = POLLIN;
#else
		} else if(c->events != 0) {
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
			ev.events = EPOLLET;
			ev.data.fd = c->netfd;
			fast_epoll_ctl(c->thread->epfd,
					c->events==POLL_DEFER_ACCEPT?EPOLL_CTL_ADD:EPOLL_CTL_MOD,
					c->netfd, &ev);
			c->events = 0;
#endif
		}
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
	}
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
	c->relayproc = resume_server_connected;
	c->tsc_io = readtsc() + tsc_connect;
	list_move_tail(&c->timer_io, &c->thread->timer_connect);
	return 1;
}
/* }}}1 */

/* store_forward_connection() {{{1 */
static int store_forward_connection(struct conn *c, group_t *g, ftarget_t *h) {
	int rv = 500;

	c->fgroup = g;
	c->ftarget = h;
	if(h && h->has_counter)
		atomic_inc(&h->count_inuse);

	if(c->recvcnt==0) {
		int n;

#if IOPERF_SUPPORT
		if(ioperf_exp) {
			uint64_t iostart = readtsc();
#endif
			n = fast_write(c->cachefd, c->sendbuf, c->sendlen);
#if IOPERF_SUPPORT
			uint64_t iostop = readtsc() - iostart;
			c->thread->ioperf_sum += iostop;
			c->iowait += iostop;
		} else
#endif
			n = fast_write(c->cachefd, c->sendbuf, c->sendlen);

		if(n != c->sendlen)
			goto hangup;
		c->cachefd_end = c->sendlen;
	} else {
		struct iovec v[2];
		int n;

		CHECK_RECVBUF;
		v[0].iov_base = c->sendbuf;
		v[0].iov_len  = c->sendlen;
		v[1].iov_base = c->recvbuf + c->recvptr;
		v[1].iov_len  = c->recvcnt;
		c->recvptr += c->recvcnt;
		c->recvcnt = 0;
		CHECK_RECVBUF;

#if IOPERF_SUPPORT
		if(ioperf_exp) {
			uint64_t iostart = readtsc();
#endif
			n = fast_writev(c->cachefd, v, 2);
#if IOPERF_SUPPORT
			uint64_t iostop = readtsc() - iostart;
			c->thread->ioperf_sum += iostop;
			c->iowait += iostop;
		} else
#endif
			n = fast_writev(c->cachefd, v, 2);

		if(n != v[0].iov_len+v[1].iov_len)
			goto hangup;
		c->cachefd_end = v[0].iov_len + v[1].iov_len;
	}

	if(c->expect100) {
		memcpy(c->sendbuf, "100 Continue\r\n\r\n", 17);
		c->sendptr = 0;
		c->sendlen = 16;
		c->sendcnt = 16;
		c->expect100 = 0;
	} else {
		c->sendbuf[0] = '\0';
		c->sendptr = c->sendlen = c->sendcnt = 0;
	}

	if(c->pass_mode < REQ_PARSED) {
		if((rv=pass_client2cache(c))==-1) {
//lprintf("file[%s] line[%d]",__FILE__,__LINE__);
			close_relay_connection(c);
			return 1;
		}
		if(rv)
			goto hangup;
	}
	if(c->pass_mode == REQ_PARSED)
		return connecting_to_server(c);

	c->proc = resume_client_connection;
	update_events(c);
	return 1;
hangup:
	relay_error(c);
	http_error(c, rv, c->url);
	return 0;
}
/* }}}1 */

/* forward_connection() {{{1 */
int forward_connection(struct conn *c, void *target, int mode) {
	struct group *tgroup;
	int fd;

	init_relay_data(c);
#if RECVBUF_DEBUG
	int pmode = c->pass_mode;
	int rcnt = c->recvcnt;
	int rptr = c->recvptr;
	int rlen = c->recvlen;
#endif
	fd = parse_http_request(c);
#if RECVBUF_DEBUG
	CHECK_RECVBUF;
	if(c->recvptr+c->recvcnt > c->recvlen)
	{
		lprintf("init pass_mode=%d recvptr=%d recvcnt=%d recvlen=%d\n", pmode, rptr, rcnt, rlen);
		int i;
		for(i=0; i<c->recvlen; i+=16) {
			char *p = c->recvbuf + i;
			lprintf("%04x: %02x %02x %02x %02x %02x %02x %02x %02x-%02x %02x %02x %02x %02x %02x %02x %02x  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",
					i,
					p[0] & 0xff,
					p[1] & 0xff,
					p[2] & 0xff,
					p[3] & 0xff,
					p[4] & 0xff,
					p[5] & 0xff,
					p[6] & 0xff,
					p[7] & 0xff,
					p[8] & 0xff,
					p[9] & 0xff,
					p[10] & 0xff,
					p[11] & 0xff,
					p[12] & 0xff,
					p[13] & 0xff,
					p[14] & 0xff,
					p[15] & 0xff,
					p[0]<' '||p[0]>'\x7e' ? '.' : p[0],
					p[1]<' '||p[1]>'\x7e' ? '.' : p[1],
					p[2]<' '||p[2]>'\x7e' ? '.' : p[2],
					p[3]<' '||p[3]>'\x7e' ? '.' : p[3],
					p[4]<' '||p[4]>'\x7e' ? '.' : p[4],
					p[5]<' '||p[5]>'\x7e' ? '.' : p[5],
					p[6]<' '||p[6]>'\x7e' ? '.' : p[6],
					p[7]<' '||p[7]>'\x7e' ? '.' : p[7],
					p[8]<' '||p[8]>'\x7e' ? '.' : p[8],
					p[9]<' '||p[9]>'\x7e' ? '.' : p[9],
					p[10]<' '||p[10]>'\x7e' ? '.' : p[10],
					p[11]<' '||p[11]>'\x7e' ? '.' : p[11],
					p[12]<' '||p[12]>'\x7e' ? '.' : p[12],
					p[13]<' '||p[13]>'\x7e' ? '.' : p[13],
					p[14]<' '||p[14]>'\x7e' ? '.' : p[14],
					p[15]<' '||p[15]>'\x7e' ? '.' : p[15]
						);
		}
	}
#endif
	if(fd != 0) {
		relay_error(c);
		http_error(c, fd, c->url);
		return 0;
	}

	if(c->tcpcork) {
		int cork;
		fast_setsockopt(c->netfd, SOL_TCP, TCP_CORK, (cork=0,&cork), sizeof(cork));
		if(patch_cork)
			fast_setsockopt(c->netfd, SOL_TCP, TCP_NODELAY,
					(cork=1,&cork), sizeof(cork));
		c->tcpcork = 0;
	}

	switch(mode) {
		case RF_SFORWARD_TARGET:
			if(c->pass_mode != REQ_PARSED &&
					(fd=open_cache_file(c)) >= 0)
			{
				c->cachefd = fd;
                ISDSTAT(atomic_inc(&countermap->ccachefds));
				return store_forward_connection(c, NULL, target);
			}
		case RF_FORWARD_TARGET:
			return relay_connection(c, NULL, target);
		case RF_FORWARD_GROUP:
			tgroup = (struct group *)target;
			if(tgroup->sfmode) {
				if(c->pass_mode != REQ_PARSED) {
					if((fd=open_cache_file(c)) >= 0) {
						c->cachefd = fd;                    
                        ISDSTAT(atomic_inc(&countermap->ccachefds));
						return store_forward_connection(c, target, NULL);
					}
					/* BAD cache file, fallback */
					if(c->pass_mode == REQ_HEADER && tgroup->vhostmap && !c->host[0])
					{
						relay_error(c);
						http_error(c, 500, c->url);
						return 0;
					}
				}
			}
			if(c->host[0] && tgroup->vhostmap) {
				struct group **gptr = GetNameFromMap(tgroup->vhostmap, c->host);
				if(gptr && *gptr) {
					target = *gptr;
					if(use_vhost==1)
						resolv_vhost(c);
				}
			}
			return relay_connection(c, target, NULL);
	}

	relay_error(c);
	http_error(c, 500, c->url);
	return 0;
}
/* }}}1 */

/* warning_sendbuf_too_small() {{{1 */
static int warning_sendbuf_too_small(void) {
	static int warning_sendbuf = 0;
	if(warning_sendbuf==0) {
		warning_sendbuf = 1;
		lprintf("\7send_buffer_size too small to forward cookie\n");
		lprintf("\7You shound increase send_buffer_size\n");
	}
	return -1;
}
/* }}}1 */

/* construct_http_header() {{{1 */
int construct_http_header(struct conn *c, const char *url) {
	char *p = c->sendbuf;
	char *e = c->sendbuf + sendbufsz;
	md5_t ctx;
	int i = 0, ctn=0;
	char *ct = NULL;

	if(c->has_ct && !c->no_header) {
		ctn = strnlen(c->sendbuf, 128);
		if(ctn==128) 
			return -1;
		ct = alloca(ctn);
		memcpy(ct, c->sendbuf, ctn);
	}

	/*
	 * assume buffer never overflow here,
	 * becuase minimum sendbufsz is maxurllen+1024
	 *
	 * buffer usage: current_size: accumulate_size
	 */

	/* 5: 5 */
	p = stpcpy(p, ((char * []){ "GET ", "HEAD ", "POST ", "BAD " })[c->method]);

	/* maxurllen: 5 + maxurllen */
	i = strlen(url);
	if(i>maxurllen) i = maxurllen;
	p = mempcpy(p, url, i);
	if(c->no_header) {
		*(uint16_t *)p = *(uint16_t *)"\r\n";
		c->sendptr = 0;
		c->sendlen = p - c->sendbuf + 2;
		if(url_in_sendbuf && c->sendlen >= url_in_sendbuf)
			c->urloverwriten = 1;
		return 0;
	}

#define ADDCSTR(x)	memcpy(p, x, sizeof(x)-1), p+=sizeof(x)-1
	/* 36: 41 + maxurllen */
	if(c->http_v11) {
		ADDCSTR(" HTTP/1.1\r\nConnection: close\r\nQVia: ");
	} else {
		ADDCSTR(" HTTP/1.0\r\nConnection: close\r\nQVia: ");
	}

	/* 40: 81 + maxurllen */
	*(int *)(p+40) = fdinfo[c->netfd].addr;
	MD5Init(&ctx);
	MD5Update(&ctx, (unsigned char *)QVPREFIX, sizeof(QVPREFIX)-1);
	MD5Update(&ctx, (unsigned char *)p+40, 4);
	MD5Update(&ctx, (unsigned char *)QVSUFFIX, sizeof(QVPREFIX)-1);
	MD5Final((unsigned char *)p+44, &ctx);

	encode_hex(p, p+40, 20);
	p += 40;

	/* 8+maxhostlen: 89 + maxurllen + maxhostlen */
	if(c->host[0]) {
		ADDCSTR("\r\nHost: ");
		p = stpcpy(p, c->host);
	}
	/* 16+128: 233 + maxurllen + maxhostlen */
	if(c->has_ct) {
		ADDCSTR("\r\nContent-Type: ");
		p = mempcpy(p, ct, ctn);
	}

	/* 28: 261 + maxurllen + maxhostlen */
	if(c->has_chunked) {
		ADDCSTR("\r\nTransfer-Encoding: chunked");
	}

	/* 18+10: 289 + maxurllen + maxhostlen */
	if(c->has_cl) {
		ADDCSTR("\r\nContent-Length: ");
		p = uint2str(p, c->postsize);
	}

	/* 23+29: 341 + maxurllen + maxhostlen */
	if(c->ims) {
		p = stpcpy(p,
				((char *[]){
				 "\r\nXXX: ",
				 "\r\nIf-Modified-Since: ",
				 "\r\nIf-Unmodified-Since: ",
				 "\r\nIf-Range: "
				 })[c->ims]
			  );
		gmtimestr(c->imstime, p);
		p += 29;
	}
	/* 9+19+1+19: 389 + maxurllen + maxhostlen */
	if(c->range_start) {
		ADDCSTR("\r\nRange: ");
		p = ll2str(p, c->range_start);
		*p++ = '-';
		if(c->range_last != -1)
			p = ll2str(p, c->range_last);
	} else if(c->range_last != -1) {
		ADDCSTR("\r\nRange: -");
		p = ll2str(p, c->range_last);
	}
	/* 23: 412 + maxurllen + maxhostlen */
	if(c->gzippable)
		ADDCSTR("\r\nAccept-Encoding: gzip");
	/* above buffer usage: 412+maxurllen+128 */

#if COOKIE_SUPPORT
	/* cookie: 89 + maxurllen + maxhostlen + cookie */
	if(c->cookie) {
		ADDCSTR("\r\nCookie: ");
		if(cookie_in_sendbuf)
			i = encode_cookie_overlay(p, c->cookie);
		else
			i = encode_cookie(p, e-p, c->cookie);
		if(i<0) {
			if(url_in_sendbuf && !cookie_in_sendbuf)
				c->urloverwriten = 1;
			return warning_sendbuf_too_small();
		}
		if(i==0) p -= 10;
		else p += i;
	}

	if(c->cookiestr) {
		if(c->cookie){
			ADDCSTR("; ");
		}else{
			ADDCSTR("\r\nCookie: ");
		}
		memcpy(p, c->cookiestr , strlen(c->cookiestr) );
		p+=strlen(c->cookiestr) ;
		free(c->cookiestr);
		c->cookiestr = NULL;
	}
#endif

	/* 4: 416 + maxurllen + maxhostlen + cookie */
	if(e-p < 4) {
		if(url_in_sendbuf)
			c->urloverwriten = 1;
		return warning_sendbuf_too_small();
	}
	*(uint32_t *)p = *(uint32_t *)"\r\n\r\n";

	c->sendptr = 0;
	c->sendlen = p - c->sendbuf + 4;
	if(url_in_sendbuf && c->sendlen >= url_in_sendbuf)
		c->urloverwriten = 1;
	return 0;
}
/* }}}1 */

/* construct_http_reqline() {{{1 */
int construct_http_reqline(struct conn *c, const char *url, const char *trailer, int tlen) {
	char *p = c->sendbuf;
	md5_t ctx;
	int ulen;

	/* buffer usage: 5 + maxurllen + tlen + 36 + 42 */
	p = stpcpy(p, ((char * []){ "GET ", "HEAD ", "POST ", "BAD " })[c->method]);

	ulen = strlen(url);
	if(ulen > maxurllen) ulen = maxurllen;
	p = mempcpy(p, url, ulen);
	if(c->no_header) {
		*(uint16_t *)p = *(uint16_t *)"\r\n";
		c->sendptr = 0;
		c->sendlen = p - c->sendbuf + 2;
		if(url_in_sendbuf && c->sendlen >= url_in_sendbuf)
			c->urloverwriten = 1;
		return 0;
	}

	if(tlen) {
		/* tlen limited to 800 bytes */
		if(tlen > 812) tlen = 800;
		memcpy(p, trailer, tlen);
		p += tlen;
	}

	if(c->http_v11) {
		p = stpcpy(p, "\r\nConnection: close\r\nQVia: ");
	} else {
		p = stpcpy(p, "\r\nConnection: close\r\nQVia: ");
	}

	*(int *)(p+40) = fdinfo[c->netfd].addr;
	MD5Init(&ctx);
	MD5Update(&ctx, (unsigned char *)QVPREFIX, sizeof(QVPREFIX)-1);
	MD5Update(&ctx, (unsigned char *)p+40, 4);
	MD5Update(&ctx, (unsigned char *)QVSUFFIX, sizeof(QVPREFIX)-1);
	MD5Final((unsigned char *)p+44, &ctx);

	encode_hex(p, p+40, 20);
	*(uint32_t *)(p+40) = *(uint32_t *)"\r\n";

	c->sendptr = 0;
	c->sendlen = p - c->sendbuf + 42;
	if(url_in_sendbuf && c->sendlen >= url_in_sendbuf)
		c->urloverwriten = 1;
	return 0;
}
/* }}}1 */

#endif
