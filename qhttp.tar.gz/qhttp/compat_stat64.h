#ifndef __COMPAT_STAT64_H_
#define __COMPAT_STAT64_H_

#include <features.h>
#include <sys/stat.h>
#if !__x86_64__
#include "realconfig.h"
#include "compiler.h"

#if !COMPAT_GLIBC && __GLIBC_PREREQ(2,2)
#define filestat fstat64
#define linkstat lstat64
#else
#include <unistd.h>
#include "syscall.h"
static inline int filestat(int fd, stat64_t *st) {
#ifdef __NR_fstat64
	return syscall(__NR_fstat64, fd, st);
#else
	return syscall(__NR_fstat, fd, st);
#endif
}
static inline int linkstat(const char *src, stat64_t *st) {
#ifdef __NR_1stat64
	return syscall(__NR_lstat64, src, st);
#else
	return syscall(__NR_lstat, src, st);
#endif
}
#endif
#endif
#endif
