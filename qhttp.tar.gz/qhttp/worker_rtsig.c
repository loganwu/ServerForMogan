
#if PLUGIN_SUPPORT
	extern void set_worker_key(struct worker *);
	set_worker_key(wt);
#endif
#if WORKER_METHOD!=2
	int tail;
#endif
	int n=0;
	int i;
	struct timespec tv;
	sigset_t sset;
	siginfo_t si;

	sigemptyset(&sset);
	sigaddset(&sset, SIGIO);
	sigaddset(&sset, SIGALRM);
	sigaddset(&sset, rtsigno);
	sigprocmask(SIG_BLOCK, &sset, NULL);

	wt->mypid = fast_gettid();
	kill(wt->mypid, SIGIO);
#if WORKER_METHOD==2
	i = (wt->id+1) % nworks;
	/* wait next worker startup */
	while(!stop && (wt->nextpid=worker[i].mypid)==0) {
	    tv.tv_sec = 0;
	    tv.tv_nsec = 10000000;
	    fast_nanosleep(&tv, &tv);
	}

	if(wt->id==0 && direct_accept)
	    rtsig_add_listening(wt->mypid);
#endif

#if PROFILE_SUPPORT
	init_poll(wt);
#endif
	wt->thst = get_threadstat();

	while(!stop) {
#if PROFILE_SUPPORT
	    before_poll(wt);
#endif
	    if(loopdelay) {
		tv.tv_sec = 0;
		tv.tv_nsec = loopdelay;
		fast_nanosleep(&tv, &tv);
	    }

	    tv.tv_sec = calc_poll_timeout(wt);
	    tv.tv_nsec = (tv.tv_sec%1000)*1000000;
	    tv.tv_sec = tv.tv_sec/1000;
	    if((i=sigtimedwait(&sset, &si, &tv))==rtsigno) {
		if(si.si_code==SI_QUEUE) {
		    si.si_fd = si.si_int;
		    si.si_band = POLLIN;
		} else if(si.si_code > 0) {
		    si.si_band &= POLLIN|POLLOUT|POLLHUP|POLLERR;
		}
		else
		    si.si_fd = 0;
	    } else if(i==SIGIO) {
		thread_reached(wt->thst);
		uint64_t tsc0;
		if(si.si_code==SI_USER||si.si_code==SI_TKILL) {
		    tsc0 = 0;
		} else {
		    tsc0 = readtsc();
		}
		tv.tv_sec = 0;
		tv.tv_nsec = 0;
		while(sigtimedwait(&sset, &si, &tv)==SIGIO)
		    /* */;
#if WORKER_METHOD==2
		n = rtsig_add_pollfd(wt->pfd);
#else
		n = 0;
#endif
		n = build_pollfd_worker(wt, n);
#if WORKER_METHOD
		n = build_pollfd_idle(wt, n);
#endif
		if(tsc0 && verbose)
		    lprintf("rtsig%d: RT signal queue overflow %"F64"d\n", wt->id, readtsc()-tsc0);
		thread_reached(wt->thst);
		if(n>0 && fast_poll(wt->pfd, n, calc_poll_timeout(wt))<=0)
		    n = 0;
		si.si_fd = 0;
	    } else {
		si.si_fd = 0;
	    }

	    thread_reached(wt->thst);
#if PROFILE_SUPPORT
	    after_poll(wt);
#endif
	    check_timestamp(wt);

#if WORKER_METHOD<2
	    tail = wt->inc_tail;
	    while(wt->inc_pend != tail) {
		/* new incoming */
		thread_reached(wt->thst);
		GET_LIST_ITEM(i, wt->inc_list, wt->inc_pend, nconns1);
#if WORKER_METHOD==0
		init_connection(wt, i);
		fast_fcntl(i, F_SETOWN, wt->mypid);
		resume_http_connection(i, check_events(i, POLLIN));
#else
        if(try_init_connection(wt, i)==NULL) {
		    ISDSTAT(atomic_dec(&countermap->workcon));
        }
		else {
		    /*
		     * Linux 2.4 return EPERM here, but the pid does set to new pid
		     * the errno EPERM means the OOB notify pid doesn't change
		     */
		    fast_fcntl(i, F_SETOWN, wt->mypid);
		    resume_http_connection(i, check_events(i, POLLIN));
		}
#endif
	    }

	    if(si.si_fd) {
		resume_connection(wt, si.si_fd, si.si_band);
	    } else {
		for(i=0; i<n; i++) {
		    if(wt->pfd[i].revents == 0) continue;
		    thread_reached(wt->thst);
		    resume_connection(wt, wt->pfd[i].fd, wt->pfd[i].revents);
		}
		n = 0;
	    }
#else
	    if(si.si_fd) {
		if (is_stub(si.si_fd, listenstub))
		    accept_connections_rtsig_direct(wt, si.si_fd);
		else 
		    resume_connection(wt, si.si_fd, si.si_band);
	    } else {
		for(i=0; i<n; i++) {
		    if(wt->pfd[i].revents == 0) continue;
		    thread_reached(wt->thst);
		    if(is_stub(wt->pfd[i].fd, listenstub))
			accept_connections_rtsig_direct(wt, wt->pfd[i].fd);
		    else
			resume_connection(wt, wt->pfd[i].fd, wt->pfd[i].revents);
		}
		n = 0;
	    }
#endif

	    check_pending(wt);
#if WORKER_METHOD==0
	    check_idle_switch(wt);
#else
	    check_direct_idle_switch(wt);
#endif
	    check_timeout(wt);
#if WORKER_METHOD
	    check_idle_timeout(wt);
#endif
	}
	return 0;

#undef threadname
#undef WORKER_METHOD
