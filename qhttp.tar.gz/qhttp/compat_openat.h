#ifndef	_H_COMPAT_OPENAT_H_
#define	_H_COMPAT_OPENAT_H_

#include <features.h>
#include "realconfig.h"
#if !COMPAT_GLIBC && __GLIBC_PREREQ(2, 4)
#define sys_openat openat
#define sys_openat3 openat
#else
__BEGIN_DECLS

#include <unistd.h>
#include "syscall.h"
static inline int sys_openat (int fd, const char *name, int flags, mode_t mode)
{ return syscall(__NR_openat, fd, name, flags, mode); }

static inline int sys_openat3 (int fd, const char *name, int flags)
{ return syscall(__NR_openat, fd, name, flags); }

__END_DECLS

#endif
#endif
