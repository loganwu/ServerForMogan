/* vim: set sw=4 ai fdm=marker fmr={{{,}}} :*/

/* headers {{{1 */
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include "compat_sendfile64.h"

#include "autoconfig.h"
#include "myconfig.h"
#include "global.h"
#include "memcache.h"
#include "entity_hash.h"
#include "global.h"
#include "atomic.h"
#include "list.h"
#include "shmem.h"
#include "md5.h"
#include "thread.h"
#include "log.h"
#include "timestamp.h"
#include "profile.h"
#include "task.h"
#include "util.h"
#include "lock.h"
#include "detect.h"
#include "filecount.h"
/* }}}1 */

/* globals {{{1 */
struct entity_hash *gfd_entry;
struct list_head fdlru;
struct list_head memlru;
struct list_head fdexp;
struct list_head negexp;

static struct list_head *globalhash;
static int gfd_maxslots;
static int gmem_totalsize;
static int gmem_maxsize;
static int gmem_hits = 10;

static mutex_t *cachelock;
#define LOCK_CACHE	(cachelock==NULL?0:cachelock->lock(cachelock, 0))
#define UNLOCK_CACHE	(cachelock==NULL?0:cachelock->unlock(cachelock, 0))
#define TRYLOCK_CACHE	(cachelock==NULL?0:cachelock->trylock(cachelock, 0))
/* }}}1 */

/* ghashidx() {{{1 */
static inline int ghashidx(const unsigned char h[16]) {
	return *(uint16_t *)h;
}
/* }}}1 */

/* close_entity() {{{1 */
static inline void close_entity(struct entity_hash * ent) {
	if(isfd(ent->fd)) {
	    close_fdentity(ent->fd);
	}
	ent->fd = OE_BAD;
	list_del_init(&ent->list);
	list_del_init(&ent->exp);
}
static inline void free_mementity(struct entity_hash *ent) {
	list_del_init(&ent->lru);
	//list_del_init(&ent->exp);
#if FILECOUNT_SUPPORT
	put_fcid(ent->mem->fcid);
#endif
	memcache_free(ent);
}
/* }}}1 */

static int insert_into_cache(const unsigned char *hash, int fd, uint32_t tsc4, void **pent) {
	if(fd > 2) {
	    if(!list_empty(&fdlru)) {
		struct entity_hash *ent = list_entry(fdlru.next, struct entity_hash, lru);
		if(isfd(ent->fd)) {
#if TRACE_FD
		    if(atomic_read(&ent->count) != 0) {
			lprintf("%s(%d): INVALID counter %d fd %d in LRU\n", __FILE__, __LINE__, atomic_read(&ent->count), ent->fd);
		    }
#endif
		    close_entity(ent);
		}

#if TRACE_FD
		strcpy(ent->name, "globalentity");
#endif
		ent->type = ET_GLOBAL;
		ent->expired = 0;
		ent->flag = 0;
		atomic_set(&ent->count, 1);
		ent->hits = 1;
		list_del_init(&ent->lru);
		ent->tsc4 = tsc4 + tsc4_fdcache;
		hashcp(ent->hash, hash);
		list_move(&ent->list, globalhash+ghashidx(hash));
		list_move_tail(&ent->exp, &fdexp);
		fdent(fd)->entity = ent;
		ent->fd = fd;
	    }
	    *pent = fd2ent(fd);
	    return 0;
	}
	if(tsc4_fdcache_negative && !list_empty(&fdlru)) {
	    struct entity_hash *ent;
	    ent = list_entry(fdlru.next, struct entity_hash, lru);
	    if(isfd(ent->fd)) {
#if TRACE_FD
		if(atomic_read(&ent->count) != 0) {
		    lprintf("%s(%d): INVALID counter %d fd %d in LRU\n", __FILE__, __LINE__, atomic_read(&ent->count), ent->fd);
		}
#endif
		close_entity(ent);
	    }

#if TRACE_FD
	    strcpy(ent->name, "negativeentity");
#endif
	    ent->fd = OE_BAD;
	    atomic_set(&ent->count, -fd-1);
	    ent->hits = 0;
	    ent->type = ET_NEGATIVE;
	    ent->expired = 0;
	    list_move_tail(&ent->lru, &fdlru);
	    ent->tsc4 = tsc4 + tsc4_fdcache_negative;
	    hashcp(ent->hash, hash);
	    list_move(&ent->list, globalhash+ghashidx(hash));
	    list_move_tail(&ent->exp, &negexp);
	}

	return -fd-1;
}

static struct mementity *gmem_read_entity(struct entity_hash *ent) {
	struct fdentity *fe = fdent(ent->fd);
	struct entity_hash *ent1;

	if(fe->size > gmem_maxsize) return NULL;
	while((ent1=memcache_alloc(fe->size+(isfd(fe->zfd)?fdent(fe->zfd)->size:0)))==NULL) {
	    if(list_empty(&memlru)) return NULL;
	    ent1 = list_entry(memlru.next, struct entity_hash, lru);
	    free_mementity(ent1);
	}

	hashcp(ent1->hash, ent->hash);
	ent1->tsc4 = ent->tsc4;
	ent1->type = ET_MEMORY;
	ent1->flag = 0;
	ent1->hits = 1;
	atomic_set(&ent1->count, 1);
	ent1->fd = OE_BAD;
	INIT_LIST_HEAD(&ent1->lru);
	list_add(&ent1->list, globalhash+ghashidx(ent1->hash));

	struct mementity *me = mem2ent(ent1);
	me->fd = 0;
#if FILECOUNT_SUPPORT
	me->fcid = fe->fcid;
	dup_fcid(me->fcid);
#endif
	me->mime = fe->mime;
	me->mtime = fe->mtime;
	me->size = fe->size;
	if(fe->size>0) {
	    int n = fast_pread(ent->fd, me->data, me->size, 0);
	    if(n < me->size)
		memset(me->data+n, 0, me->size-n);
	}
	if(isfd(fe->zfd)) {
	    me->zsize = fdent(fe->zfd)->size;
	    int n = fast_pread(fe->zfd, me->data+me->size, me->zsize, 0);
	    if(n < me->zsize)
		memset(me->data+me->size+n, 0, me->zsize-n);
	} else
	    me->zsize = fe->zfd;
    	return me;
}

/* get_entity_cache() {{{1 */
static int get_entity_global(struct worker *wt, const char *filename, void **pent) {
	unsigned char hash[16];
	md5_t ctx;
	int rv;

	*pent = NULL;

	MD5Init(&ctx);
	MD5Update(&ctx, (const unsigned char *)filename, strlen(filename));
	MD5Final(hash, &ctx);

	uint32_t tsc4 = TSCRND(readtsc());

	/* search thread hash table {{{2*/
	struct entity_hash *ent0 = NULL;
	struct entity_hash *ent;
	if(TRYLOCK_CACHE)
		return get_entity_nocache(wt, filename, pent);
	list_for_each_entry(ent, globalhash+ghashidx(hash), list) {
	    if(hasheq(hash, ent->hash)) {
	        /* cache hit */
		if(ent->tsc4 >= tsc4) {
		    /* not exipred */
		    if(ent->type == ET_NEGATIVE) {
			if(atomic_read(&ent->count) >= 0 || atomic_read(&ent->count) < -2) {
			    lprintf("BAD negative cache value %d\n", atomic_read(&ent->count));
			    rv = -4;
			} else
			    rv = atomic_read(&ent->count);
		    } else {
			if(
				gmem_totalsize &&
				ent->hits >= gmem_hits &&
				ent->type!=ET_GLOBAL &&
				(*pent = gmem_read_entity(ent)) != NULL )
			{
			    /* convert to memcache */
			    list_del_init(&ent->list);
			    if(atomic_read(&ent->count)==0) {
				close_entity(ent);
			    	list_move(&ent->lru, &fdlru);
			    } else
			    	ent->expired = 1;
			} else {
			    list_del_init(&ent->lru);
			    atomic_inc(&ent->count);
			    ++ent->hits;
			    *pent = hash2ent(ent);
			}
			rv = 0;
		    }
		    UNLOCK_CACHE;
		    return rv;
		}
		/* expired */
		if(ent->type!=ET_NEGATIVE) {
		    list_del_init(&ent->lru);
		    atomic_inc(&ent->count);
		    ent0 = ent;
		} else {
		    list_del_init(&ent->list);
		    list_del_init(&ent->exp);
		    list_move(&ent->exp, &fdlru);
		}
		break;
	    }
	}
	ent = ent0;
	UNLOCK_CACHE;

	if(ent==NULL) {
	    PROFILE_START;
	    rv = open_fdentity(filename, wt);
	    PROFILE_WORKER(PROFILE_INIT_ENTITY);
	    LOCK_CACHE;
	    rv = insert_into_cache(hash, rv, tsc4, pent);
	    UNLOCK_CACHE;
	    return rv;
	}

	/* refresh entity {{{2 */
	PROFILE_START;
	if(ent->type == ET_MEMORY)
	    rv = update_mementity(filename, mem2ent(ent), wt);
	else
	    rv = update_fdentity(filename, fdent(ent->fd), 0, wt);
	PROFILE_WORKER(PROFILE_INIT_ENTITY);

	if(rv == OE_FRESH) {
	    LOCK_CACHE;
	    ent->tsc4 = tsc4 + tsc4_fdcache;
	    ++ent->hits;
	    list_move_tail(&ent->exp, &fdexp);
	    *pent = hash2ent(ent);
	    UNLOCK_CACHE;
	    return 0;
	}

	LOCK_CACHE;
	if(atomic_dec_and_test(&ent->count)) {
	    /* last instant, free it */
	    if(ent->type==ET_MEMORY) {
		free_mementity(ent);
	    } else {
	    	close_entity(ent);
		list_move(&ent->lru, &fdlru);
	    }
	}
	else {
	    if(nworks>1 && ent->expired) {
	    	/* expired by other thread */
		if(rv > 2) {
		    *pent = fd2ent(rv);
		    rv = 0;
		} else {
		    rv = -rv-1;
		}
		UNLOCK_CACHE;
		return rv;
	    } 
	    /* mark it expired */
	    list_del_init(&ent->list);
	    ent->expired = 1;
	}

	rv = insert_into_cache(hash, rv, tsc4, pent);
	UNLOCK_CACHE;
	return rv;
}
/* }}}1 */

/* put_entity_cache() {{{1 */
static void put_entity_global(struct worker *wt, void *ent0) {
	if(isfd(ent0)) {
	    int fd = PTR2INT(ent0);
	    struct entity_hash *ent = fdent(fd)->entity;
	    if(ent==NULL) {
		close_fdentity(fd);
	    } else {
		LOCK_CACHE;
#if TRACE_FD
		if(atomic_read(&ent->count)==0) {
			lprintf("%s(%d): trying closing already closed entity, fd=%d\n",
				__FILE__, __LINE__, fd);
		} else
#endif
		if(atomic_dec_and_test(&ent->count)) {
		    if(ent->expired)
		    	close_entity(ent);
		    list_add_tail(&ent->lru, &fdlru);
		}
		UNLOCK_CACHE;
	    }
	} else if(isptr(ent0)) {
	    struct entity_hash *ent = ent2mem(ent0);
	    LOCK_CACHE;
#if TRACE_FD
	    if(atomic_read(&ent->count)==0) {
		lprintf("%s(%d): trying closing already closed entity %p\n",
			__FILE__, __LINE__, ent);
	    } else
#endif
	    if(atomic_dec_and_test(&ent->count)) {
		if(ent->expired) {
		    free_mementity(ent);
		} else
		    list_add_tail(&ent->lru, &memlru);
	    }
	    UNLOCK_CACHE;
	}
}
/* }}}1 */

/* cleanup_entity() {{{1 */
static void cleanup_global_entity(void *priv) {
	struct list_head *list;
	struct entity_hash *ent;
	uint32_t tsc4 = TSCRND(readtsc());

	LOCK_CACHE;
	/* expire positve cache */
	list_for_each_entry_safe_l(ent, list, &fdexp, exp)
	{
	    if(ent->tsc4 > tsc4-tsc4_fdcache) break;
	    if(atomic_read(&ent->count) > 0) continue;
	    close_entity(ent);
	    list_move(&ent->lru, &fdlru);
	}

	/* expire negative cache */
	list_for_each_entry_safe_l(ent, list, &negexp, exp)
	{
	    if(ent->tsc4 > tsc4) break;
	    list_del_init(&ent->list);
	    list_del_init(&ent->exp);
	    list_move(&ent->lru, &fdlru);
	}
	UNLOCK_CACHE;
}
/* }}}1 */

/* init_fdcache() {{{1 */
int init_fdcache_global(void) {
	int i;

	if(get_entity_internal != get_entity_global) return 0;

	INIT_LIST_HEAD(&fdlru);
	INIT_LIST_HEAD(&memlru);
	INIT_LIST_HEAD(&fdexp);
	INIT_LIST_HEAD(&negexp);

	switch(cachelockmode) {
	case CLM_MUTEX:
	    cachelock = CreatePosixMutex(1);
	    break;
	case CLM_FUTEX:
	    cachelock = CreateLinuxFutex(1);
	    break;
	case CLM_SYSVSEM:
	    cachelock = CreateSysVSem(1);
	    break;
	}

	globalhash = shalloc(0x10000*sizeof(struct list_head));
	if(globalhash==NULL) return -ENOMEM;
	for(i=0; i<0x10000; i++)
	    INIT_LIST_HEAD(globalhash+i);

	gfd_entry = shalloc(gfd_maxslots*sizeof(struct entity_hash));
	if(gfd_entry==NULL) return -ENOMEM;
	for(i=0; i<gfd_maxslots; i++) {
	    atomic_set(&gfd_entry[i].count, 0);
	    gfd_entry[i].hits = 0;
	    gfd_entry[i].fd = 0;
	    gfd_entry[i].type = ET_GLOBAL;
	    gfd_entry[i].flag = 0;
	    INIT_LIST_HEAD(&gfd_entry[i].list);
	    INIT_LIST_HEAD(&gfd_entry[i].exp);
	    list_add(&gfd_entry[i].lru, &fdlru);
	}

	if(gmem_totalsize) {
	    if(memcache_create(gmem_totalsize) < 0) return -ENOMEM;
	    char buf1[30];
	    lprintf("Memory cache size: %dM, filesize %d%s\n",
		    gmem_totalsize,
		    gmem_maxsize, pretty_r(buf1, gmem_maxsize)
		   );
	}
	if(nworks==1)
	    register_worker_task((void *)cleanup_global_entity);
	else
	    register_privilege_task(cleanup_global_entity, NULL);
	return 0;
}
/* }}}1 */

/* free_fdcache() {{{1 */
void free_fdcache_global(void) {
	if(get_entity_internal != get_entity_global) return;
	if(gfd_entry) {
	    int i;
	    for(i=0; i<gfd_maxslots; i++) {
		if(isfd(gfd_entry[i].fd)) {
		    close_fdentity(gfd_entry[i].fd);
		}
	    }
	}
	memcache_destroy();
	if(cachelock) cachelock->destroy(cachelock);
}
/* }}}1 */

/* fdcache_shmem_size() {{{1 */
int init_fdcache_mode_global(void) {
	SHMEM_NEEDED(0x10000, sizeof(struct list_head));
	gfd_maxslots = myconfig_get_intval("fdcache_global_slots", 0);
	if(gfd_maxslots < mconns) gfd_maxslots = mconns;
	SHMEM_NEEDED(gfd_maxslots, sizeof(struct entity_hash));

	gmem_totalsize = myconfig_get_intval("memcache_size", 0);
	if(gmem_totalsize <= 0 || gmem_totalsize >= 3072)
	    gmem_totalsize = 0;
	else {
	    memcache_set_overhead(MCOVERHEAD);
	    gmem_maxsize = myconfig_get_intval("memcache_file_size", 8192);
	    if(gmem_maxsize > memcache_maxsize)
		    gmem_maxsize = memcache_maxsize;
	    if(gmem_maxsize < 2*memcache_blocksize - memcache_overhead)
		    gmem_maxsize = 2*memcache_blocksize - memcache_overhead;

	    if(gfd_maxslots < 8192)
		    gfd_maxslots = 8192;
	    gmem_hits = myconfig_get_intval("memcache_hits", 10);
	    if(gmem_hits < 2) gmem_hits = 2;
	}

	fdcache_max = gfd_maxslots;
	get_entity_internal = get_entity_global;
	put_entity_internal = put_entity_global;
    
    lprintf("+fdcache_global_slots/gfd_maxslots is %d", gfd_maxslots);
    lprintf("+memcache_size/gmem_totalsize is %d", gmem_totalsize);
    lprintf("+memcache_file_size/gmem_maxsize is %d", gmem_maxsize);
    lprintf("+memcache_hits/gmem_hits is %d", gmem_hits);    
    lprintf("+fdcache_max is %d", fdcache_max);
	return 0;
}
/* }}}1 */

